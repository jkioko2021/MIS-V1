﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
'Imports Microsoft.Office.Interop.Word
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Configuration

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Imports Telerik.Charting

Partial Class Default2
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim searchStr As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            loadGrid()
        End If
    End Sub
    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try
            GD_SUMM.DataSource = Nothing
            GD_SUMM.DataBind()
          
            RD_ACTIVITY.DataSource = Nothing
            RD_ACTIVITY.DataBind()
            RD_ACTSUMM.DataSource = Nothing
            RD_ACTSUMM.DataBind()

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Session("datefrom") = Nothing
            Session("dateto") = Nothing
            If cbosearch.SelectedValue = "Q" Then
                SqlAction = " SELECT [QUARTER],[PERIOD_FROM],[PERIOD_TO]  FROM [CRM].[dbo].[TBL_MIS_CRM_QUOTA] WHERE QUARTER='" & cboS_1.SelectedValue & "'"
                Dim MyDatable As New Data.DataTable
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    Session("datefrom") = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                    'Session("dateto") = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd")

                    SqlAction = "SELECT [FROM_DT],[TO_DT],[RE_CODE],[RE_NAME],[CLASS_CODE],[TOT_CORP_COUNT],[EXP_CNT_ACTIVITY],[ACT_CNT_ACTIVITY],[PERC_PERF],[NSM_CODE]  FROM [CRM].[dbo].[TBL_MIS_CRM_ACT_PRODUCTION] WHERE FROM_DT='" & Session("datefrom") & "'"
                    MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                    If MyDatable.Rows.Count > 0 Then
                        GD_QUOTA.DataSource = MyDatable
                        GD_QUOTA.DataBind()

                        MyDatable = Nothing
                    Else
                        GD_QUOTA.DataSource = MyDatable
                        GD_QUOTA.DataBind()
                    End If

                End If
            ElseIf cbosearch.SelectedValue = "RM" Then

                SqlAction = "SELECT  [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE RM_CODE='" & cboS_1.SelectedValue & "'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDatable.Rows.Count > 0 Then
                    RD_ACTIVITY.DataSource = MyDatable
                    RD_ACTIVITY.DataBind()
                    Session("DAD_5") = MyDatable
                    MyDatable = Nothing
                Else
                    RD_ACTIVITY.DataSource = MyDatable
                    RD_ACTIVITY.DataBind()
                End If
            Else

                SqlAction = "SELECT [FROM_DT],[TO_DT],[RE_CODE],[RE_NAME],[CLASS_CODE],[TOT_CORP_COUNT],[EXP_CNT_ACTIVITY],[ACT_CNT_ACTIVITY],[PERC_PERF],[NSM_CODE]  FROM [CRM].[dbo].[TBL_MIS_CRM_ACT_PRODUCTION]"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_QUOTA.DataSource = MyDatable
                    GD_QUOTA.DataBind()

                    MyDatable = Nothing
                Else
                    GD_QUOTA.DataSource = MyDatable
                    GD_QUOTA.DataBind()
                End If


                SqlAction = "SELECT  DISTINCT  [PERIOD_FROM],[PERIOD_TO],[PROPOSER_DISPLAY_NAME],[EMP_NAME],[Q1],[Q2],[Q3],[Q4],[PERC_ACT]  FROM [CRM].[dbo].[VW_RET_DASHBOARD]"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SUMM.DataSource = MyDatable
                    GD_SUMM.DataBind()
                    Session("DAD_5") = MyDatable
                    MyDatable = Nothing
                Else
                    GD_SUMM.DataSource = MyDatable
                    GD_SUMM.DataBind()
                End If

                SqlAction = "SELECT  [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY]"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDatable.Rows.Count > 0 Then
                    RD_ACTIVITY.DataSource = MyDatable
                    RD_ACTIVITY.DataBind()
                    Session("DAD_5") = MyDatable
                    MyDatable = Nothing
                Else
                    RD_ACTIVITY.DataSource = MyDatable
                    RD_ACTIVITY.DataBind()
                End If

                SqlAction = "SELECT DISTINCT EMP_NAME,RM_CODE,AVG(PERC_ACT) AVER_PERCENT,COUNT([PROPOSER_DISPLAY_NAME])CNT_CORPORATES,CAST(SUM(ISNULL(Q1,0)+ISNULL(Q2,0)+ISNULL(Q3,0)+ISNULL(Q4,0)) AS NUMERIC) CNT_ACTIVITIES  FROM [VW_RET_DASHBOARD]   GROUP BY EMP_NAME,RM_CODE"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    RD_ACTSUMM.DataSource = MyDatable
                    RD_ACTSUMM.DataBind()

                    MyDatable = Nothing
                Else
                    RD_ACTSUMM.DataSource = MyDatable
                    RD_ACTSUMM.DataBind()
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub



    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        MyDatable = Nothing

        SqlAction = "SELECT  [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY]"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
        End If

        SqlAction = "SELECT  DISTINCT  [PERIOD_FROM],[PERIOD_TO],[PROPOSER_DISPLAY_NAME],[EMP_NAME],[Q1],[Q2],[Q3],[Q4],[PERC_ACT]  FROM [CRM].[dbo].[VW_RET_DASHBOARD]"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GD_SUMM.DataSource = MyDatable
            GD_SUMM.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GD_SUMM.DataSource = MyDatable
            GD_SUMM.DataBind()
        End If

        SqlAction = "SELECT DISTINCT EMP_NAME,RM_CODE,AVG(PERC_ACT) AVER_PERCENT,COUNT([PROPOSER_DISPLAY_NAME])CNT_CORPORATES,CAST(SUM(ISNULL(Q1,0)+ISNULL(Q2,0)+ISNULL(Q3,0)+ISNULL(Q4,0)) AS NUMERIC) CNT_ACTIVITIES  FROM [VW_RET_DASHBOARD] GROUP BY EMP_NAME,RM_CODE"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            RD_ACTSUMM.DataSource = MyDatable
            RD_ACTSUMM.DataBind()

            MyDatable = Nothing
        Else
            RD_ACTSUMM.DataSource = MyDatable
            RD_ACTSUMM.DataBind()
        End If

        SqlAction = "SELECT [FROM_DT],[TO_DT],[RE_CODE],[RE_NAME],[CLASS_CODE],[TOT_CORP_COUNT],[EXP_CNT_ACTIVITY],[ACT_CNT_ACTIVITY],[PERC_PERF],[NSM_CODE]  FROM [CRM].[dbo].[TBL_MIS_CRM_ACT_PRODUCTION]"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_QUOTA.DataSource = MyDatable
            GD_QUOTA.DataBind()

            MyDatable = Nothing
        Else
            GD_QUOTA.DataSource = MyDatable
            GD_QUOTA.DataBind()
        End If
    End Sub



    Protected Sub RD_ACTIVITY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_ACTIVITY.PageIndexChanged
        RD_ACTIVITY.CurrentPageIndex = e.NewPageIndex
        RD_ACTIVITY.DataSource = Session("DAD_6")
        RD_ACTIVITY.DataBind()
    End Sub
    Protected Sub View(ByVal sender As Object, ByVal e As EventArgs)
        Try
            Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
            Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""800px"" height=""600px"">"
            embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
            embed += " or download <a target = ""_blank"" href = ""http://get.adobe.com/reader/"">Adobe PDF Reader</a> to view the file."
            embed += "</object>"
            ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileVB.ashx?Id="), id)
        Catch ex As Exception
            ltEmbed.Text = ex.Message
        End Try

    End Sub

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click

        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "RETENTION As -& " & cbosearch.Text & ""

        Session("EXCEL") = "TO EXCEL"

        Str = "SELECT  DISTINCT  [PERIOD_FROM],[PERIOD_TO],[PROPOSER_DISPLAY_NAME],[EMP_NAME],[Q1],[Q2],[Q3],[Q4],[PERC_ACT]  FROM [CRM].[dbo].[VW_RET_DASHBOARD] WHERE PERIOD_TO>=GETDATE()"
        Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        'Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing

        System.Threading.Thread.Sleep(5000)

        System.Threading.Thread.Sleep(5000)


    End Sub



    Protected Sub cbosearch_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbosearch.SelectedIndexChanged
        If cbosearch.SelectedValue = "Q" Then
            Str = "SELECT [QUARTER]   FROM [CRM].[dbo].[TBL_MIS_CRM_QUOTA]" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboS_1
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("QUARTER").ToString
                .DataValueField = MyDatatable.Columns("QUARTER").ToString
                .DataBind()
            End With
        ElseIf cbosearch.SelectedValue = "RM" Then

            Str = "SELECT [RE_CODE],[RE_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_RMS] WHERE C_CODE='C'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboS_1
                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()

            End With
        Else
            Str = "select CLASS_CODE,CLASS_NAME from [dbo].[TBL_MIS_CRM_CLASS]" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboS_1
                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("CLASS_NAME").ToString
                .DataValueField = MyDatatable.Columns("CLASS_CODE").ToString
                .DataBind()

            End With
        End If

        MyDatatable = Nothing
    End Sub
End Class
