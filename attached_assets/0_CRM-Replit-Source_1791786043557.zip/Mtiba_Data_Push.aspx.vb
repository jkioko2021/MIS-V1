﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("PRINT") = Nothing
            Session("Report_") = Nothing
            Session("EXCEL") = Nothing

            'Plan Info
            SqlAction = "SELECT [DATA_TYPE],[CNT_EOX_UPDATED],[CNT_PUSH_SUCCESS],[CNT_FAILED],[DATA_DATE]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_SUMMARY_CNT]"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_SUMM.DataSource = MyDatable
                GD_SUMM.DataBind()
                MyDatable = Nothing
            Else
                GD_SUMM.DataSource = Nothing
                GD_SUMM.DataBind()
            End If
        End If

    End Sub
    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try
            GD_MEM.DataSource = Nothing
            GD_MEM.DataBind()
            GD_PLAN.DataSource = Nothing
            GD_PLAN.DataBind()
            GD_SEARCH.DataSource = Nothing
            GD_SEARCH.DataBind()
            GD_POL.DataSource = Nothing
            GD_POL.DataBind()
            GD_PROP.DataSource = Nothing
            GD_PROP.DataBind()
            GD_CAT.DataSource = Nothing
            GD_CAT.DataBind()
            Dim MyDatable As New Data.DataTable
            ' SqlAction = "SELECT[PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"
            If cboclient.SelectedValue = "C" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND POLICY_STATUS='ACTIVE' AND CLIENT_TYPE='CORP'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SEARCH.DataSource = MyDatable
                    GD_SEARCH.DataBind()
                    MyDatable = Nothing
                Else
                    GD_SEARCH.DataSource = Nothing
                    GD_SEARCH.DataBind()
                End If
            ElseIf cboclient.SelectedValue = "M" Then
            

                SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO LIKE '%" & Trim(TXTSEARCH.Text) & "%' order by ENTRY_TIME desc"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_MEM.DataSource = MyDatable
                    GD_MEM.DataBind()
                    Session("MEMBER") = MyDatable
                    MyDatable = Nothing
                Else
                    GD_MEM.DataSource = Nothing
                    GD_MEM.DataBind()
                End If

            Else
                SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND POLICY_STATUS='ACTIVE' AND CLIENT_TYPE<>'CORP'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SEARCH.DataSource = MyDatable
                    GD_SEARCH.DataBind()

                    MyDatable = Nothing
                Else
                    GD_SEARCH.DataSource = Nothing
                    GD_SEARCH.DataBind()

                End If
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GD_SEARCH_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_SEARCH.SelectedIndexChanged
        Try
            lblPROP.Text = ""
            GD_PLAN.DataSource = Nothing
            GD_PLAN.DataBind()
            GD_SUMM_PLAN.DataSource = Nothing
            GD_SUMM_PLAN.DataBind()
            GD_SUMM_CAT.DataSource = Nothing
            GD_SUMM_CAT.DataBind()
            GD_SUMM_POL.DataSource = Nothing
            GD_SUMM_POL.DataBind()
            GD_POL.DataSource = Nothing
            GD_POL.DataBind()
            GD_SUMM_PROP.DataSource = Nothing
            GD_SUMM_PROP.DataBind()
            GD_SUMM_MEM.DataSource = Nothing
            GD_SUMM_MEM.DataBind()
            GD_ENDR_1.DataSource = Nothing
            GD_ENDR_1.DataBind()
            GD_RENEW_1.DataSource = Nothing
            GD_RENEW_1.DataBind()
            GD_RENEW.DataSource = Nothing
            GD_RENEW.DataBind()
            GD_ENDR.DataSource = Nothing
            GD_ENDR.DataBind()

            Session("PROPOSER_ID") = (DirectCast(GD_SEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()
            lblPROP.Text = Session("PROPOSER_ID")
            SqlAction = "SELECT DISTINCT PLAN_ID FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_ID='" & Session("PROPOSER_ID") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                LBLPLAN.Text = MyDatable.Rows(0).Item("PLAN_ID").ToString
            End If

            'Plan Info
            SqlAction = "SELECT   [DATA_TYPE],[PLAN_ID],[REMARKS],[ENTRY_TIME],[PLAN_NAME]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_PLAN]  with(nolock) WHERE PLAN_ID ='" & LBLPLAN.Text & "' order by ENTRY_TIME desc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_PLAN.DataSource = MyDatable
                GD_PLAN.DataBind()
                MyDatable = Nothing
                SqlAction = "SELECT 'PLAN' DATA_TYPE,  PLAN_ID  , SUM([CNT_TOTAL_PLAN])[CNT_EOX_UPDATED],SUM([CNT_PLAN_PUSHED])[CNT_PUSH_SUCCESS],(SUM([CNT_TOTAL_PLAN])-SUM([CNT_PLAN_PUSHED]))[CNT_FAILED]   FROM [COM_ACTIVITIES_DB].[dbo].[VW_MIS_COM_MTIBA_PLAN_STATUS]  WHERE PLAN_ID ='" & LBLPLAN.Text & "'   GROUP BY PLAN_ID"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SUMM_PLAN.DataSource = MyDatable
                    GD_SUMM_PLAN.DataBind()
                    MyDatable = Nothing
                Else
                    GD_SUMM_PLAN.DataSource = Nothing
                    GD_SUMM_PLAN.DataBind()
                End If
            Else
                GD_PLAN.DataSource = Nothing
                GD_PLAN.DataBind()
            End If



            'Scheme Info
            SqlAction = "SELECT [DATA_TYPE],[SCHEME_ID],[REMARKS],[ENTRY_TIME],[SCHEME_NAME],[PLAN_NAME],[PLAN_ID]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_CAT]  WHERE SCHEME_ID IN (SELECT DISTINCT SCHEME_ID  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]   WHERE POLICY_STATUS='ACTIVE'  AND CARD_TYPE='T' AND PROPOSER_ID='" & Session("PROPOSER_ID") & "')"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_CAT.DataSource = MyDatable
                GD_CAT.DataBind()
                Session("CAT") = MyDatable
                MyDatable = Nothing
                SqlAction = "SELECT 'CATEGORY' DATA_TYPE,  PLAN_ID DATA_ID, SUM(CNT_TOTAL_CAT)CNT_EOX_UPDATED,SUM([CNT_CAT_PUSHED])[CNT_PUSH_SUCCESS],(SUM(CNT_TOTAL_CAT)-SUM([CNT_CAT_PUSHED]))[CNT_FAILED]   FROM [COM_ACTIVITIES_DB].[dbo].[VW_MIS_COM_MTIBA_CAT_STATUS] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' GROUP BY PLAN_ID,PROPOSER_ID"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SUMM_CAT.DataSource = MyDatable
                    GD_SUMM_CAT.DataBind()
                    MyDatable = Nothing
                Else
                    GD_SUMM_CAT.DataSource = Nothing
                    GD_SUMM_CAT.DataBind()
                End If
            Else
                GD_CAT.DataSource = Nothing
                GD_CAT.DataBind()
            End If

            'Policy Info
            SqlAction = "SELECT  [DATA_TYPE],[PLAN_DETAIL_ID],[REMARKS],[ENTRY_TIME],[CLAUSE_CODE_DEP],[SCHEME_NAME],[PLAN_NAME],[PLAN_ID]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_POL] P  WHERE [PLAN_ID] IN (SELECT DISTINCT [PLAN_ID]  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]   WHERE POLICY_STATUS='ACTIVE'  AND CARD_TYPE='T' AND PROPOSER_ID='" & Session("PROPOSER_ID") & "' AND SCHEME_ID=P.SCHEME_ID)"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_POL.DataSource = MyDatable
                GD_POL.DataBind()
                Session("POL") = MyDatable
                MyDatable = Nothing

                SqlAction = "SELECT 'POLICY' DATA_TYPE,  PLAN_ID  , SUM(CNT_TOTAL_POL)CNT_EOX_UPDATED,SUM([CNT_POL_PUSHED])[CNT_PUSH_SUCCESS],(SUM(CNT_TOTAL_POL)-SUM([CNT_POL_PUSHED]))[CNT_FAILED]   FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_POL_SUMM_STATUS]  WHERE PROPOSER_ID='" & Session("PROPOSER_ID") & "'  GROUP BY PLAN_ID,PROPOSER_ID"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SUMM_POL.DataSource = MyDatable
                    GD_SUMM_POL.DataBind()
                    MyDatable = Nothing
                Else
                    GD_SUMM_POL.DataSource = Nothing
                    GD_SUMM_POL.DataBind()
                End If
            Else
                GD_POL.DataSource = Nothing
                GD_POL.DataBind()
            End If


            'proposer Info
            SqlAction = "SELECT [DATA_TYPE],[PROPOSER_ID],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_NAME],[PLAN_ID]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_PROP]  with(nolock) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_PROP.DataSource = MyDatable
                GD_PROP.DataBind()
                MyDatable = Nothing
                SqlAction = "SELECT 'PROPOSER' DATA_TYPE, PROPOSER_ID DATA_ID, SUM(CNT_TOTAL_PROP)CNT_EOX_UPDATED,SUM([CNT_PROP_PUSHED])[CNT_PUSH_SUCCESS],(SUM(CNT_TOTAL_PROP)-SUM([CNT_PROP_PUSHED]))[CNT_FAILED]   FROM [COM_ACTIVITIES_DB].[dbo].[VW_MIS_COM_MTIBA_PROP_STATUS] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "'   GROUP BY PROPOSER_ID"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SUMM_PROP.DataSource = MyDatable
                    GD_SUMM_PROP.DataBind()
                    MyDatable = Nothing
                Else
                    GD_SUMM_PROP.DataSource = Nothing
                    GD_SUMM_PROP.DataBind()
                End If
            Else
                GD_PROP.DataSource = Nothing
                GD_PROP.DataBind()
            End If

            'NEW Member Info
            SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND DATA_TYPE='NEW_POLICY' order by ENTRY_TIME desc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_MEM.DataSource = MyDatable
                GD_MEM.DataBind()
                Session("MEMBER") = MyDatable
                MyDatable = Nothing

                SqlAction = "SELECT DATA_TYPE,  PROPOSER_ID,CNT_EOX_UPDATED,[CNT_PUSH_SUCCESS],[CNT_FAILED] FROM [COM_ACTIVITIES_DB].[dbo].TBL_MIS_COM_MTIBA_PUSH_LIST_SUM_PROP WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND DATA_TYPE='NEW_POLICY'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_SUMM_MEM.DataSource = MyDatable
                    GD_SUMM_MEM.DataBind()
                    MyDatable = Nothing
                Else
                    GD_SUMM_MEM.DataSource = Nothing
                    GD_SUMM_MEM.DataBind()
                End If
            Else
                GD_MEM.DataSource = Nothing
                GD_MEM.DataBind()
            End If

            'renNEW Member Info
            SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE PROPOSER_ID ='" & lblPROP.Text & "' AND DATA_TYPE='REN_POLICY' order by ENTRY_TIME desc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_RENEW_1.DataSource = MyDatable
                GD_RENEW_1.DataBind()
                Session("RENEW_MEMBER") = MyDatable
                MyDatable = Nothing

                SqlAction = "SELECT DATA_TYPE,  PROPOSER_ID,CNT_EOX_UPDATED,[CNT_PUSH_SUCCESS],[CNT_FAILED] FROM [COM_ACTIVITIES_DB].[dbo].TBL_MIS_COM_MTIBA_PUSH_LIST_SUM_PROP WHERE PROPOSER_ID ='" & lblPROP.Text & "' AND DATA_TYPE='REN_POLICY'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_RENEW.DataSource = MyDatable
                    GD_RENEW.DataBind()
                    MyDatable = Nothing
                Else
                    GD_RENEW.DataSource = Nothing
                    GD_RENEW.DataBind()
                End If
            Else
                GD_RENEW_1.DataSource = Nothing
                GD_RENEW_1.DataBind()
            End If


            'ENDORSE Member Info
            SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE PROPOSER_ID ='" & lblPROP.Text & "' AND DATA_TYPE='ENDR_MEMBER' order by ENTRY_TIME desc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_ENDR_1.DataSource = MyDatable
                GD_ENDR_1.DataBind()
                Session("ENDR_MEMBER") = MyDatable
                MyDatable = Nothing

                SqlAction = "SELECT DATA_TYPE,  PROPOSER_ID,CNT_EOX_UPDATED,[CNT_PUSH_SUCCESS],[CNT_FAILED] FROM [COM_ACTIVITIES_DB].[dbo].TBL_MIS_COM_MTIBA_PUSH_LIST_SUM_PROP WHERE PROPOSER_ID ='" & lblPROP.Text & "' and DATA_TYPE='ENDR_POLICY'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_ENDR.DataSource = MyDatable
                    GD_ENDR.DataBind()
                    MyDatable = Nothing
                Else
                    GD_ENDR.DataSource = Nothing
                    GD_ENDR.DataBind()
                End If
            Else
                GD_ENDR_1.DataSource = Nothing
                GD_ENDR_1.DataBind()
            End If

            'Session("PROPOSER_ID") = Nothing
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GD_MEM_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_MEM.PageIndexChanged
        GD_MEM.CurrentPageIndex = e.NewPageIndex
        GD_MEM.DataSource = Session("MEMBER")
        GD_MEM.DataBind()
    End Sub

    Protected Sub GD_RENEW_1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_RENEW_1.PageIndexChanged
        GD_RENEW_1.CurrentPageIndex = e.NewPageIndex
        GD_RENEW_1.DataSource = Session("RENEW_MEMBER")
        GD_RENEW_1.DataBind()
    End Sub
    Protected Sub GD_ENDR_1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_ENDR_1.PageIndexChanged
        GD_ENDR_1.CurrentPageIndex = e.NewPageIndex
        GD_ENDR_1.DataSource = Session("ENDR_MEMBER")
        GD_ENDR_1.DataBind()
    End Sub
    Protected Sub GD_POL_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_POL.PageIndexChanged
        GD_POL.CurrentPageIndex = e.NewPageIndex
        GD_POL.DataSource = Session("POL")
        GD_POL.DataBind()
    End Sub
    Protected Sub GD_CAT_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_CAT.PageIndexChanged
        GD_CAT.CurrentPageIndex = e.NewPageIndex
        GD_CAT.DataSource = Session("CAT")
        GD_CAT.DataBind()
    End Sub



    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Session("Reportname") = Nothing
            Dim Reportname As String = cboreport_name.Text & "_" & cboreport.Text
            Session("EXCEL") = "TO EXCEL"
            If chkall.Checked = False Then

                If cboreport.SelectedValue = "F" Then
                    If cboreport_name.SelectedValue = "PD" Then
                        SqlAction = "SELECT DATA_TYPE, PLAN_DETAIL_ID,PLAN_NAME, SCHEME_NAME, CLAUSE_CODE_DEP,MAXIMUM_LIMIT, REMARKS,ENTRY_TIME FROM [COM_ACTIVITIES_DB].[dbo].[VW_MIS_COM_MTIBA_POLICY_PUSH_FAILED]  with(nolock) WHERE PLAN_ID ='" & LBLPLAN.Text & "'"
                    ElseIf cboreport_name.SelectedValue = "CA" Then
                        SqlAction = "SELECT DATA_TYPE, SCHEME_ID,PLAN_NAME,PLAN_CODE,SCHEME_NAME,SCHEME_CODE,REMARKS,ENTRY_TIME FROM [COM_ACTIVITIES_DB].[dbo].[VW_MIS_COM_MTIBA_CAT_PUSH_FAILED]  with(nolock) WHERE PLAN_ID ='" & LBLPLAN.Text & "'"
                    ElseIf cboreport_name.SelectedValue = "ME" Then
                        'SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND REMARKS LIKE '%FAILED%' order by ENTRY_TIME desc"
                        SqlAction = "SELECT  [DATA_TYPE],[REMARKS],[CNT_MEM_PUSHED],[PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],CONVERT(DATE,[FIRST_ENROLLMENT_DATE])[FIRST_ENROLLMENT_DATE],CONVERT(DATE,[POLICY_VALID_FROM])POLICY_VALID_FROM,CONVERT(DATE,[POLICY_VALID_UPTO])[POLICY_VALID_UPTO],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[GRP_INDV],CONVERT(DATE,[DATA_DATE])[DATA_DATE],ENTRY_TIME,[ID_DOC_NO],[CARD_TYPE],[ENDR_NO],UPDATE_BY,UPDATE_DATE   FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_PUSHED_SUMMARY]    WHERE PROPOSER_ID ='" & lblPROP.Text & "' and CNT_MEM_PUSHED=0 AND UPDATE_DATE BETWEEN '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateto.DbSelectedDate).ToString("yyyy-MM-dd") & "'  order by ENTRY_TIME desc"
                    End If

                ElseIf cboreport.SelectedValue = "S" Then
                    If cboreport_name.SelectedValue = "PD" Then
                        'SqlAction = "SELECT DATA_TYPE, PLAN_DETAIL_ID,PLAN_NAME, SCHEME_NAME, CLAUSE_CODE_DEP,MAXIMUM_LIMIT, REMARKS FROM [VW_MIS_COM_MTIBA_POLICY_PUSH_FAILED]  with(nolock) WHERE PLAN_ID ='" & LBLPLAN.Text & "'"
                    ElseIf cboreport_name.SelectedValue = "CA" Then
                        'SqlAction = "SELECT DATA_TYPE, SCHEME_ID,PLAN_NAME,PLAN_CODE,SCHEME_NAME,SCHEME_CODE,REMARKS FROM [VW_MIS_COM_MTIBA_CAT_PUSH_FAILED] with(nolock) WHERE PLAN_ID ='" & LBLPLAN.Text & "'"
                    ElseIf cboreport_name.SelectedValue = "ME" Then
                        'SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND REMARKS LIKE '%SUCCESS%' order by ENTRY_TIME desc"
                        SqlAction = "SELECT  [DATA_TYPE],[REMARKS],[CNT_MEM_PUSHED],[PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],CONVERT(DATE,[FIRST_ENROLLMENT_DATE])[FIRST_ENROLLMENT_DATE],CONVERT(DATE,[POLICY_VALID_FROM])POLICY_VALID_FROM,CONVERT(DATE,[POLICY_VALID_UPTO])[POLICY_VALID_UPTO],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[GRP_INDV],CONVERT(DATE,[DATA_DATE])[DATA_DATE],ENTRY_TIME,[ID_DOC_NO],[CARD_TYPE],[ENDR_NO],UPDATE_BY,UPDATE_DATE   FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_PUSHED_SUMMARY]    WHERE PROPOSER_ID ='" & lblPROP.Text & "' and CNT_MEM_PUSHED=1 AND UPDATE_DATE BETWEEN '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateto.DbSelectedDate).ToString("yyyy-MM-dd") & "' order by ENTRY_TIME desc"
                    End If
                 
                End If
                Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = (Mytable)
                Session("Reportname") = Reportname
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Mytable = Nothing

            Else

                If cboreport.SelectedValue = "F" Then
                    If cboreport_name.SelectedValue = "PD" Then
                        SqlAction = "SELECT DATA_TYPE, PLAN_DETAIL_ID,PLAN_NAME, SCHEME_NAME, CLAUSE_CODE_DEP,MAXIMUM_LIMIT, REMARKS FROM [COM_ACTIVITIES_DB].[dbo].[VW_MIS_COM_MTIBA_POLICY_PUSH_FAILED]  with(nolock)"
                    ElseIf cboreport_name.SelectedValue = "CA" Then
                        SqlAction = "SELECT DATA_TYPE, SCHEME_ID,PLAN_NAME,PLAN_CODE,SCHEME_NAME,SCHEME_CODE,REMARKS FROM [COM_ACTIVITIES_DB].[dbo].[VW_MIS_COM_MTIBA_CAT_PUSH_FAILED]  with(nolock)"
                    ElseIf cboreport_name.SelectedValue = "ME" Then
                        'SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE  REMARKS LIKE '%FAILED%' and year([ENTRY_TIME])=2021 order by ENTRY_TIME desc"
                        SqlAction = "SELECT  [DATA_TYPE],[REMARKS],[CNT_MEM_PUSHED],[PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],CONVERT(DATE,[FIRST_ENROLLMENT_DATE])[FIRST_ENROLLMENT_DATE],CONVERT(DATE,[POLICY_VALID_FROM])POLICY_VALID_FROM,CONVERT(DATE,[POLICY_VALID_UPTO])[POLICY_VALID_UPTO],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[GRP_INDV],CONVERT(DATE,[DATA_DATE])[DATA_DATE],ENTRY_TIME,[ID_DOC_NO],[CARD_TYPE],[ENDR_NO],UPDATE_BY,UPDATE_DATE   FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_PUSHED_SUMMARY] where CNT_MEM_PUSHED=0 AND UPDATE_DATE BETWEEN '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateto.DbSelectedDate).ToString("yyyy-MM-dd") & "' order by ENTRY_TIME desc"
                    End If

                ElseIf cboreport.SelectedValue = "S" Then
                    If cboreport_name.SelectedValue = "PD" Then
                        ' SqlAction = "SSELECT DATA_TYPE, PLAN_DETAIL_ID,PLAN_NAME, SCHEME_NAME, CLAUSE_CODE_DEP,MAXIMUM_LIMIT, REMARKS FROM [VW_MIS_COM_MTIBA_POLICY_PUSH_FAILED]  with(nolock)"
                    ElseIf cboreport_name.SelectedValue = "CA" Then
                        ' SqlAction = "SELECT DATA_TYPE, SCHEME_ID,PLAN_NAME,PLAN_CODE,SCHEME_NAME,SCHEME_CODE,REMARKS FROM [VW_MIS_COM_MTIBA_CAT_PUSH_FAILED]  with(nolock)  with(nolock)"
                    ElseIf cboreport_name.SelectedValue = "ME" Then
                        'SqlAction = "SELECT [DATA_TYPE],[DISPLAY_MEMBERSHIP_NO],[MEMBER_DISPLAY_NAME],[MEMBER_RELATIONSHIP],[MEMBER_PRI_MOBILE],[ID_DOC_TYPE],[ID_DOC_NO],[REMARKS],[ENTRY_TIME],[PROPOSER_DISPLAY_NAME],[PLAN_ID],[PROPOSER_ID],[GRP_INDV]  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_LOG_MEM]  with(nolock) WHERE   REMARKS LIKE '%SUCCESS%' and year([ENTRY_TIME])=2021 order by ENTRY_TIME desc"
                        SqlAction = "SELECT  [DATA_TYPE],[REMARKS],[CNT_MEM_PUSHED],[PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],CONVERT(DATE,[FIRST_ENROLLMENT_DATE])[FIRST_ENROLLMENT_DATE],CONVERT(DATE,[POLICY_VALID_FROM])POLICY_VALID_FROM,CONVERT(DATE,[POLICY_VALID_UPTO])[POLICY_VALID_UPTO],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[GRP_INDV],CONVERT(DATE,[DATA_DATE])[DATA_DATE],ENTRY_TIME,[ID_DOC_NO],[CARD_TYPE],[ENDR_NO],UPDATE_BY,UPDATE_DATE  FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_COM_MTIBA_PUSHED_SUMMARY] where CNT_MEM_PUSHED=1 AND UPDATE_DATE BETWEEN '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateto.DbSelectedDate).ToString("yyyy-MM-dd") & "' order by ENTRY_TIME desc"
                    End If
                End If
                Session("Mytable") = Nothing


                Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                'Mytable = TryCast(MyDBAction.eoxegen(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = (Mytable)
                Session("Reportname") = Reportname
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Mytable = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    
    Protected Sub cmdview_1_Click(sender As Object, e As System.EventArgs) Handles cmdview_1.Click

    End Sub
End Class
