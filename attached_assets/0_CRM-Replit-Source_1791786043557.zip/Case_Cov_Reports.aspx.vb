﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                dtfrom.DbSelectedDate = Date.Now()
                dtto.DbSelectedDate = Date.Now()

                loadGrid_N()

                Session("EXCEL") = Nothing
                Session("Reportname") = Nothing
            End If
        Catch ex As Exception

        End Try
    End Sub
    Public Sub loadGrid_N()

        SqlAction = "SELECT  [Admission_status],SUM([cnt_Cases])[cnt_Cases],SUM([Pre_Auth_Amt])[Pre_Auth_Amt],SUM([Test_Cost])[Test_Cost],SUM([Treatment_Cost])[Treatment_Cost],SUM([Isolation_Cost])[Isolation_Cost],SUM([PPE_Cost])[PPE_Cost],SUM([Other_Charges])[Other_Charges],SUM([Total_Actual_Cost])[Total_Actual_Cost]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_SUMMARY] GROUP BY Admission_status"

        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_0.DataSource = MyDatable
            GDTracking_0.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
        End If
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String
            If cboreposrt.SelectedValue = "CL" Then
                Reportname = "IP-Case List-Detail"
                'SqlAction = "SELECT  [Case_id],[Case_No],[Admission_Dt],[Member_Name],[Proposer_Name],[Client_Type],[Member_No],[Initial_Provider],[Transfer_To_Provider],[Facility_Type],[Test_Results],[Admission_Status],[Case_Status],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost],[Entered_by],[Entry_date],[Claim_No],[Discharge_Date],[Discharge_By],[Close_Date],[Closed_By],[Re_Opened],[Re_Open_Dt],[Re_Opened_By],Claim_Type,Recovery_Status  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST] Where Admission_Dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Claim_Type='IP'"

                SqlAction = "SELECT  [Case_id],[Case_No],[Admission_Dt],[Member_Name],[Proposer_Name],[Client_Type],[Member_No],[Initial_Provider],[Transfer_To_Provider],[Facility_Type],[Test_Results],[Admission_Status],[Case_Status],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost],[Entered_by],[Entry_date],[Claim_No],[Discharge_Date],[Discharge_By],[Close_Date],[Closed_By],[Re_Opened],[Re_Open_Dt],[Re_Opened_By],Claim_Type,Recovery_Status  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST] Where  Claim_Type='IP' ORDER BY CASE_ID ASC"
            ElseIf cboreposrt.SelectedValue = "OP" Then
                Reportname = "OP-Case List-Detail"
                SqlAction = "SELECT  [Case_id],[Case_No],[Admission_Dt],[Member_Name],[Proposer_Name],[Client_Type],[Member_No],[Initial_Provider],[Transfer_To_Provider],[Facility_Type],[Test_Results],[Admission_Status],[Case_Status],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost],[Entered_by],[Entry_date],[Claim_No],[Discharge_Date],[Discharge_By],[Close_Date],[Closed_By],[Re_Opened],[Re_Open_Dt],[Re_Opened_By],Claim_Type,Recovery_Status  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST] Where  Claim_Type='OP' ORDER BY CASE_ID ASC"

            ElseIf cboreposrt.SelectedValue = "CM" Then
                Reportname = "Case Summary-Per Member"
                SqlAction = "SELECT [Member_No],[Member_Name],[Proposer_Name],[Client_Type],[Cnt_Cases],[Test_Results],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST_SUMMARY]"
            ElseIf cboreposrt.SelectedValue = "CA" Then
                Reportname = "Case Summary-Admitted"
                SqlAction = "SELECT  [Member_No],[Member_Name],[Proposer_Name],[Client_Type],[Provider],[Facility_Type],[Test_Results],[admission_status],[case_Status],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST_ADMISSION]"
            ElseIf cboreposrt.SelectedValue = "CH" Then
                Reportname = "Case Summary-HomeCare"
                SqlAction = "SELECT  [Member_No],[Member_Name],[Proposer_Name],[Client_Type],[Provider],[Facility_Type],[Test_Results],[admission_status],[case_Status],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST_HOMECARE]"
            ElseIf cboreposrt.SelectedValue = "CC" Then
                Reportname = "Case Summary-Closed"
                SqlAction = "SELECT  [Member_No],[Member_Name],[Proposer_Name],[Client_Type],[Provider],[Facility_Type],[Test_Results],[admission_status],[case_Status],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST_CLOSED]"
            ElseIf cboreposrt.SelectedValue = "SP" Then
                Reportname = "Cost Summary Per Provider"
                SqlAction = "SELECT   [Cost_Date],[Admission_Dt],[Provider],[Case_code],[Treatment],[Isolation],[Test],[PPE],[Other],[Pre_Auth_Amt],[Total_Actual_Cost]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_PROV_SUMMARY] Where Admission_Dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
            ElseIf cboreposrt.SelectedValue = "A" Then
                Reportname = "Cost Summary-Admitted"
                SqlAction = "SELECT  [Mon],[Provider],[No_of_Cases],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_PROV_SUMMARY_ADMI]"
            ElseIf cboreposrt.SelectedValue = "C" Then
                Reportname = "Comorbidities Per Member"
                SqlAction = "SELECT [Admission_Dt],[Case_no],[Member_No],[Dx_Date],[Comorb_Name]  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CORM]"
            End If

            Session("EXCEL") = "TO EXCEL"
            Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
            'Reportname = ""
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click

    End Sub
End Class
