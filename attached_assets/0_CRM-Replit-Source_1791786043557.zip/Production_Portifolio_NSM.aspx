﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Production_Portifolio_NSM.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
          <div id="Div_inner">
            <table style="width: 1300" Width="1200px">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4" Width="1200px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="DASH BOARD-PORTFOLIO"></asp:Label>
                    </td>
                </tr>
    <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Width="1200px" Wrap="False">
                                            <table style="width: 100%" Width="1200px">
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        <telerik:RadComboBox ID="cboyear" Runat="server" Height="19px" 
                                                            style="margin-left: 0px" Skin="Outlook">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="2019" Value="2019" />
                                                                <telerik:RadComboBoxItem runat="server" Text="2020" Value="2020" />
                                                                <telerik:RadComboBoxItem runat="server" Text="2021" Value="2021" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="width: 81px">
                                                        <telerik:RadComboBox ID="cboNSM" Runat="server" AutoPostBack="True" 
                                                            style="margin-left: 0px" Width="227px" Skin="Outlook">
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td class="style10" style="width: 122px">
                                                        <asp:Label ID="Label87" runat="server" Text="Date From"></asp:Label>
                                                    </td>
                                                    <td style="width: 11px">
                                                        <telerik:RadDatePicker ID="dtDateFrom" Runat="server" AutoPostBack="True" 
                                                            Culture="en-US" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput AutoPostBack="True" DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="width: 151px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        &nbsp;</td>
                                                    <td style="width: 81px">
                                                        &nbsp;</td>
                                                    <td class="style10" style="width: 122px">
                                                        <asp:Label ID="Label88" runat="server" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td style="width: 11px">
                                                        <telerik:RadDatePicker ID="dtDateTo" Runat="server" AutoPostBack="True" 
                                                            Culture="en-US" Skin="Outlook" Width="150px">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput AutoPostBack="True" DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="width: 151px">
                                                        <telerik:RadButton ID="SEARCH" runat="server" Skin="Outlook" Text="View " 
                                                            Width="100px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                     
                                              <telerik:RadTabStrip ID="RadTabStrip1" runat="server" SelectedIndex="3" 
                                                  MultiPageID="RadMultiPage1" Width="1200px" Skin="Outlook">
                                                  <Tabs>
                                                      <telerik:RadTab runat="server" PageViewID="V1" Text="Medical">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V2" Text="NonMed">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V3" Text="Market ">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V4" 
                                                          Text="RM's &amp; RE's" SelectedIndex="0" Selected="True">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V5" Text="Medical List">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V6" Text="Non-Med List">
                                                      </telerik:RadTab>
                                                  </Tabs>
                                              </telerik:RadTabStrip>
             
                                    </td>
                                </tr>
                <tr>
                    <td class="style8" colspan="4">
                        <asp:Panel ID="Panel20" runat="server" Width="1200px">
                            <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="1200px">
                                <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V1" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label2" runat="server" style="font-weight: 700" 
                                                                Text="PORTFOLIO MEDICAL"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel2" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_PORT_MED" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="NSM_CODE">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                <ItemStyle Width="50px" />
                                                                            </telerik:GridButtonColumn>
                                                                            <telerik:GridBoundColumn DataField="NSM_NAME" 
                                                                                FilterControlAltText="Filter NSM_NAME column" HeaderText="NAME" 
                                                                                SortExpression="NSM_NAME" UniqueName="NSM_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label3" runat="server" style="font-weight: 700" 
                                                                Text="MONTH -PORTFOLIO"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_PORT_MED_1" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="MONTH_FROM" 
                                                                                FilterControlAltText="Filter MONTH_FROM column" HeaderText="MONTH_FROM" 
                                                                                SortExpression="MONTH_FROM" UniqueName="MONTH_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MONTH_TO" 
                                                                                FilterControlAltText="Filter MONTH_TO column" HeaderText="MONTH_TO" 
                                                                                SortExpression="MONTH_TO" UniqueName="MONTH_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V2" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label89" runat="server" style="font-weight: 700" 
                                                                Text="PORTFOLIO NON- MEDICAL"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel21" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_PORT_NON" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="NSM_CODE">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                <ItemStyle Width="50px" />
                                                                            </telerik:GridButtonColumn>
                                                                            <telerik:GridBoundColumn DataField="NSM_NAME" 
                                                                                FilterControlAltText="Filter NSM_NAME column" HeaderText="NAME" 
                                                                                SortExpression="NSM_NAME" UniqueName="NSM_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="NON_CNT_POLICY" 
                                                                                FilterControlAltText="Filter NON_CNT_POLICY column" HeaderText="NON_CNT_POLICY" 
                                                                                SortExpression="NON_CNT_POLICY" UniqueName="NON_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="NON_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter NON_PREM column" HeaderText="NON_PREM" 
                                                                                SortExpression="NON_PREM" UniqueName="NON_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="NON_CNT_LIVES" 
                                                                                FilterControlAltText="Filter NON_CNT_LIVES column" HeaderText="NON_CNT_LIVES" 
                                                                                SortExpression="NON_CNT_LIVES" UniqueName="NON_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                          
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label90" runat="server" style="font-weight: 700" 
                                                                Text="MONTH -PORTFOLIO"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel22" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_PORT_NON_1" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="MONTH_FROM" 
                                                                                FilterControlAltText="Filter MONTH_FROM column" HeaderText="MONTH_FROM" 
                                                                                SortExpression="MONTH_FROM" UniqueName="MONTH_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MONTH_TO" 
                                                                                FilterControlAltText="Filter MONTH_TO column" HeaderText="MONTH_TO" 
                                                                                SortExpression="MONTH_TO" UniqueName="MONTH_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V3" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label91" runat="server" style="font-weight: 700" 
                                                                Text="PORTFOLIO -MARKET"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel23" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_CLASS" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="CLASS_CODE">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                <ItemStyle Width="50px" />
                                                                            </telerik:GridButtonColumn>
                                                                            <telerik:GridBoundColumn DataField="MGR_NAME" 
                                                                                FilterControlAltText="Filter MGR_NAME column" HeaderText="NAME" 
                                                                                SortExpression="MGR_NAME" UniqueName="MGR_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label92" runat="server" style="font-weight: 700" 
                                                                Text="MONTH -PORTFOLIO"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel24" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_CLASS_1" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="MONTH_FROM" 
                                                                                FilterControlAltText="Filter MONTH_FROM column" HeaderText="MONTH_FROM" 
                                                                                SortExpression="MONTH_FROM" UniqueName="MONTH_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MONTH_TO" 
                                                                                FilterControlAltText="Filter MONTH_TO column" HeaderText="MONTH_TO" 
                                                                                SortExpression="MONTH_TO" UniqueName="MONTH_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V4" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label93" runat="server" style="font-weight: 700" 
                                                                Text="PORTFOLIO RM"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel25" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_RM_PORT" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="RM_CODE">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                <ItemStyle Width="50px" />
                                                                            </telerik:GridButtonColumn>
                                                                            <telerik:GridBoundColumn DataField="RM_NAME" 
                                                                                FilterControlAltText="Filter RM_NAME column" HeaderText="NAME" 
                                                                                SortExpression="RM_NAME" UniqueName="RM_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label94" runat="server" style="font-weight: 700" 
                                                                Text="MONTH -PORTFOLIO"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel26" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_RM_PORT_1" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="MONTH_FROM" 
                                                                                FilterControlAltText="Filter MONTH_FROM column" HeaderText="MONTH_FROM" 
                                                                                SortExpression="MONTH_FROM" UniqueName="MONTH_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MONTH_TO" 
                                                                                FilterControlAltText="Filter MONTH_TO column" HeaderText="MONTH_TO" 
                                                                                SortExpression="MONTH_TO" UniqueName="MONTH_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V5" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label7" runat="server" style="font-weight: 700" 
                                                                Text="RE -MEDICAL POLICIES"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_MED_POLICY" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="PROPOSER_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PREMIUMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                SortExpression="PREMIUMS" UniqueName="PREMIUMS">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="LIVES" 
                                                                                FilterControlAltText="Filter LIVES column" HeaderText="LIVES" 
                                                                                SortExpression="LIVES" UniqueName="LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="CONTACT_PERSON" 
                                                                                FilterControlAltText="Filter CONTACT_PERSON column" HeaderText="CONTACT_PERSON" 
                                                                                SortExpression="CONTACT_PERSON" UniqueName="CONTACT_PERSON">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MOBILE_NO" 
                                                                                FilterControlAltText="Filter MOBILE_NO column" HeaderText="MOBILE_NO" 
                                                                                SortExpression="MOBILE_NO" UniqueName="MOBILE_NO">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V6" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label9" runat="server" style="font-weight: 700" 
                                                                Text="RE -NONMEDICAL POLICIES"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_NON_POLICY" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="PROPOSER_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PREMIUMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                SortExpression="PREMIUMS" UniqueName="PREMIUMS">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="LIVES" 
                                                                                FilterControlAltText="Filter LIVES column" HeaderText="LIVES" 
                                                                                SortExpression="LIVES" UniqueName="LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="CONTACT_PERSON" 
                                                                                FilterControlAltText="Filter CONTACT_PERSON column" HeaderText="CONTACT_PERSON" 
                                                                                SortExpression="CONTACT_PERSON" UniqueName="CONTACT_PERSON">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MOBILE_NO" 
                                                                                FilterControlAltText="Filter MOBILE_NO column" HeaderText="MOBILE_NO" 
                                                                                SortExpression="MOBILE_NO" UniqueName="MOBILE_NO">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            &nbsp;</td>
                                    </tr>
                                </table>

                            </telerik:RadMultiPage>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        <asp:Label ID="lbltext" runat="server" ForeColor="#CC0000"></asp:Label>
                        <asp:Label ID="lblID" runat="server" ForeColor="#CC0000" Visible="False"></asp:Label>
                        <asp:HiddenField ID="HiddenField1" runat="server" />
                    </td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
           
                            <table style="width: 1200px" width="1200">
                                <tr>
                                    <td bgcolor="#999999" colspan="4">
                                        <asp:Label ID="Label86" runat="server" Text="Report Extract (Debits)"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 159px">
                                        <telerik:RadComboBox ID="cbotype" Runat="server" Skin="Outlook">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" 
                                                    Text="Production Summary" Value="P" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Debits-Ret" 
                                                    Value="DR" />
                                                <telerik:RadComboBoxItem runat="server" Text="Debits-Corp" Value="DC" />
                                                <telerik:RadComboBoxItem runat="server" Text="Policy Listing Ret" 
                                                    Value="PLR" />
                                                <telerik:RadComboBoxItem runat="server" Text="Policy Listing Corp" 
                                                    Value="PLC" />
                                                <telerik:RadComboBoxItem runat="server" Text="Portfolio Summary" Value="PO" />
                                                <telerik:RadComboBoxItem runat="server" Text="RM Portfolio" Value="RM" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style9" style="width: 112px">
                                        <asp:Label ID="Label81" runat="server" Text="Date From"></asp:Label>
                                    </td>
                                    <td class="style9" style="width: 14px">
                                        <telerik:RadDatePicker ID="dtDateFrom_1" Runat="server" Culture="en-US" 
                                            Skin="Web20">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 159px">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 112px">
                                        <asp:Label ID="Label82" runat="server" Text="Date To"></asp:Label>
                                    </td>
                                    <td class="style9" style="width: 14px">
                                        <telerik:RadDatePicker ID="dtDateTo_1" Runat="server" Culture="en-US" 
                                            Skin="Sunset" Width="150px">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="btnGenerate" runat="server" Skin="Sunset" 
                                            Text="Generate">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                     
                        
                            <table width="1200px">
                                <tr>
                                    <td style="width: 159px">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 112px">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 14px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                            </table>
             </div>          
        </ContentTemplate>

    </asp:UpdatePanel>
</asp:Content>
