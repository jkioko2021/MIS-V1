﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
            
                dtupload.DbSelectedDate = Date.Now
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing
                Session("med") = 0
                Session("Allocate") = 0
                Session("INVOICED") = 0
                'ltEmbed.Text = ""


                Me.Str = "SELECT  [DOC_CODE],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] WHERE ACTIVE=1  AND CODE=5"
                Me.MyDatatable = TryCast(Me.MyDBAction.DBAction(Me.Str, DataManagement.DBActionType.DataTable, "", Nothing), DataTable)
                Dim cbodocs As RadComboBox = Me.cbodocs
                cbodocs.Items.Clear()
                cbodocs.DataSource = Me.MyDatatable
                cbodocs.DataTextField = Me.MyDatatable.Columns("DOC_NAME").ToString()
                cbodocs.DataValueField = Me.MyDatatable.Columns("DOC_CODE").ToString()
                cbodocs.DataBind()

                'Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1  ORDER BY AGENT_NAME" '"
                'MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                'With cboagent
                '    .Items.Clear()
                '    .DataSource = MyDatatable
                '    .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                '    .DataValueField = MyDatatable.Columns("USER_ID").ToString
                '    .DataBind()
                'End With

                Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 AND Department IN ('MEMBERSHIP')" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboAllocateto
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                    .DataValueField = MyDatatable.Columns("username").ToString
                    .DataBind()
                End With
                loadGrid_N()
                'SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE entered_by='" & Session("username") & "' and Forwarded=0 AND Is_Active=1"
                'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                'If MyDatable.Rows.Count > 0 Then
                '    GDTracking.DataSource = MyDatable
                '    GDTracking.DataBind()
                '    Session("DAD_T") = MyDatable
                '    MyDatable = Nothing
                'Else
                '    GDTracking.DataSource = Nothing
                '    GDTracking.DataBind()
                'End If

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            If cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE File_No Like '%" & Trim(txtsearch.Text.ToUpper) & "%' AND Is_Active=1 and Is_Declined=1 and Refund_req=0"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE Proposer_Name Like '%" & Trim(txtsearch.Text.ToUpper) & "%' AND Is_Active=1 and Is_Declined=1 and Refund_req=0"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking.DataSource = MyDatable
                GDTracking.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                If cbosearch.SelectedValue = "F" Then
                    SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE File_No Like '%" & Trim(txtsearch.Text.ToUpper) & "%' AND Is_Active=1 "
                ElseIf cbosearch.SelectedValue = "P" Then
                    SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE Proposer_Name Like '%" & Trim(txtsearch.Text.ToUpper) & "%' AND Is_Active=1"
                End If
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDTrackingRef.DataSource = MyDatable
                    GDTrackingRef.DataBind()
                    Session("DAD_T") = MyDatable
                    MyDatable = Nothing
                Else
                    GDTrackingRef.DataSource = Nothing
                    GDTrackingRef.DataBind()

                    GDTracking.DataSource = Nothing
                    GDTracking.DataBind()
                End If


            End If
        Catch ex As Exception
            lblupload.Text = ex.Message
        End Try
    End Sub
    Public Sub loadGrid_N()
        SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type,entered_by  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE  Is_Declined=1 and Refund_req=0 AND  File_Status='DECLINED'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking.DataSource = MyDatable
            GDTracking.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking.DataSource = Nothing
            GDTracking.DataBind()
        End If

        SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE Entered_By = '" & Session("username") & "' AND Is_Active=1 and Requested=0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTrackingRef.DataSource = MyDatable
            GDTrackingRef.DataBind()
            MyDatable = Nothing
        Else
            GDTrackingRef.DataSource = Nothing
            GDTrackingRef.DataBind()
        End If
    End Sub

    Public Sub loadGrid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDTrackingRef.DataSource = Nothing
            GDTrackingRef.DataBind()

            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = Nothing
                GD_DOCS.DataBind()
            End If

            SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE File_No = '" & FILE_NO.Text & "' AND Is_Active=1 and Requested=0 "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTrackingRef.DataSource = MyDatable
                GDTrackingRef.DataBind()
                MyDatable = Nothing
            Else
                GDTrackingRef.DataSource = Nothing
                GDTrackingRef.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_BUS_TRACKING_NOTES] WHERE  File_No ='" & STR & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDTracking_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTracking.SelectedIndexChanged
        Try
            'ltEmbed.Text = ""
            RefNo.Text = ""
            Dim client_type = ""
            HiddenField1.Value = 0
            Dim W As String = ""
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()

            ID = (DirectCast(GDTracking.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            SqlAction = "SELECT [File_No],[Proposer_Name],[Family_code],Premium,File_Status,Business_Type,Business,Pay_Ref_No,Paid_Amt, Receive_dt,Client_Type,Is_Mtiba,Is_Complete,Agent_id,Medical_UW,Allocated,INVOICED,Walk_In_Client,Allocated_to,Rate_Type,Is_IPF,Benefit_Verified ,entered_by  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE File_No='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                FILE_NO.Text = MyDatable.Rows(0).Item("File_No").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                client_type = MyDatable.Rows(0).Item("Client_Type").ToString()
                txtpaid.Text = MyDatable.Rows(0).Item("Paid_Amt").ToString()
                txtrefund.Text = MyDatable.Rows(0).Item("Paid_Amt").ToString()
                lblentered.Text = MyDatable.Rows(0).Item("entered_by").ToString()
                If client_type = "R" Then
                    lblclient.Text = "RET"
                Else
                    lblclient.Text = "CORP"
                End If
                loadGrid(FILE_NO.Text)

                Str = "SELECT EMAIL FROM employees WHERE username='" & lblentered.Text & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    Session("email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                Else
                    Str = "SELECT EMAIL FROM SALES.dbo.employees WHERE username='" & lblentered.Text & "'" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    If MyDatatable.Rows.Count > 0 Then
                        Session("email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                    Else
                        Session("email") = "relationship-managers@aar.co.ke"
                    End If

                End If

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Generate_Task()

        SqlAction = "SELECT ISNULL((MAX(Refund_id)+1),1) NUMBER FROM [dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            RefNo.Text = "REF-D" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub
    Protected Sub btnsave_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try
            If txtname.Text = "" Then
                lblsave.Text = "Invalid Name Details!"
                Exit Sub
            End If
            If txtemail.Text = "" Or txtmobile.Text = "" Then
                lblsave.Text = "Invalid Contact Details!"
                Exit Sub
            End If

            If txtrefund.Text = 0 Or txtrefund.Text > txtpaid.Text Or txtpaid.Text = 0 Then
                lblsave.Text = "Invalid amount to Refund!"
                Exit Sub
            End If

            If HiddenField1.Value = 0 Then
                Generate_Task()
            End If
            MyDBAction.Save_Refund(RefNo.Text, FILE_NO.Text, txtpaid.Text, txtrefund.Text, txtname.Text, txtemail.Text, txtmobile.Text, "REF-REGISTERED", "DECLINE", CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"), lblclient.Text, RefNo.Text, txtproposer.Text)

            loadGrid(FILE_NO.Text)
            lblsave.Text = "Saved Successfull!"

            HiddenField1.Value = 0

        Catch ex As Exception
            lblsave.Text = ex.Message
        End Try
    End Sub


    Protected Sub GD_DOCS_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GD_DOCS.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("DOC_ID").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable

            Dim Proposer_Name As String = ""

            DeleteRecord("DELETE FROM   [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS]  WHERE DOC_ID='" & HiddenField1.Value.ToString & "' and Entered_By='" & Session("username") & "'")

            Dim audit As New DataManagement
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Business Decline Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = 0

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid(FILE_NO.Text)

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub
    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String

        lblupload.Text = ""
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If cbodocs.SelectedValue = "" Then
                lblerr.Text = "You must enter Document Name!"
                Exit Sub
            End If

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".jpeg"
                    contenttype = "image/jpeg"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                Case ".eml"
                    contenttype = "application/zip"
                    Exit Select
                Case ".msg"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                Me.MyDBAction.UPLOAD_ITEMS_1(Me.FILE_NO.Text, Me.cbodocs.SelectedValue, Me.cbodocs.Text, DateTime.Now.ToString("yyyy-MM-dd"), Me.Session("username"), bytes, filename, contenttype)
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green

                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            loadGrid(FILE_NO.Text)

            DOC_ID.Text = ""
            'lbltaskno.Text = ""

            dtupload.DbSelectedDate = Date.Now

        Catch ex As Exception
            lblupload.Text = ex.Message
        End Try

    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub btnforward_Click(sender As Object, e As System.EventArgs) Handles btnforward.Click
        Try
            If RefNo.Text = "" Then
                lblsave.Text = "You must select the File No"
                Exit Sub
            End If

            SqlAction = "SELECT  File_Name FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE File_No='" & FILE_NO.Text & "' AND ACTIVE=1 AND Upload_Done=0"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                btnsave.Enabled = True
                lblerr.Text = "You must upload the Missing Documents!"
                Exit Sub
            Else
                If cboAction.SelectedValue = "A" Then
                    UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET Request_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',[Request_By]= '" & Session("username") & "',Requested=1,[Refund_Status]='ALLOCATED'  WHERE [Refund_No]='" & RefNo.Text & "'")
                    'UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] SET Refund_req=1   WHERE [File_No]='" & FILE_NO.Text & "'")
                    UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET Refund_req=1 , Refund_Status='ALLOCATED',Allocated =1,Allocate_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Allocate_To='" & cboAllocateto.SelectedValue & "'  WHERE [Refund_No]='" & RefNo.Text & "'")

                ElseIf cboAction.SelectedValue = "F" Then
                    UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET Request_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',[Request_By]= '" & Session("username") & "',Requested=1,[Refund_Status]='PROCESSED'  WHERE [Refund_No]='" & RefNo.Text & "'")
                    'UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] SET Refund_req=1   WHERE [File_No]='" & FILE_NO.Text & "'")
                    UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET  Refund_req=1, Refund_Status='PROCESSED', Allocated =1,Allocate_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Allocate_To='" & Session("username") & "',Processed=1,Process_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Process_By='" & Session("username") & "'    WHERE [Refund_No]='" & RefNo.Text & "'")

                End If


                If txtcomment.Text <> "" Then
                    MyDBAction.TRACKING_MESSAGES(FILE_NO.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
                End If

                '  UpdateRecord("UPDATE CRM.dbo.[TBL_MIS_CRM_BUSINESS_TRACKING] SET  Ready_For_update=0,  File_Status='DECLINED',Refund_req=0, [Refund_Proc_Dt]= '" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Refund_Proc_By='" & Session("username") & "' where [File_No]= '" & FILE_NO.Text & "'")
                Session("to") = lblentered.Text
                Session("msg") = "Kindly note that Rfund for the above has been submitted to membership for processing."
                MailSent = SendLoginDetails(lblentered.Text, Session("email"), "computer-operations@aar.co.ke")
            End If
            lblerr.Text = "Submitted successfull!"

            loadGrid_N()

            RefNo.Text = ""
            FILE_NO.Text = ""
            txtmobile.Text = ""
            txtname.Text = ""
            txtpaid.Text = 0
            txtrefund.Text = 0
            txtemail.Text = ""

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GDTrackingRef_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTrackingRef.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = 1
            'ltEmbed.Text = ""
            stst = (DirectCast(GDTrackingRef.SelectedItems(0), GridDataItem)).GetDataKeyValue("Refund_No").ToString()
            SqlAction = "SELECT Refund_No,[File_No],payee_email,Payee_Mobile,Payee_Name,[Amount_Paid],[Refund_Amt],Proposer_id,Client_Type,proposer  FROM  TBL_MIS_BUSINESS_TRACKING_REFUNDS WHERE  Refund_No ='" & stst & "'"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RefNo.Text = MyDatable.Rows(0).Item("Refund_No").ToString()
                FILE_NO.Text = MyDatable.Rows(0).Item("File_No").ToString()
                txtmobile.Text = MyDatable.Rows(0).Item("Payee_Mobile").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Payee_Name").ToString()
                txtpaid.Text = MyDatable.Rows(0).Item("Amount_Paid").ToString()
                txtrefund.Text = MyDatable.Rows(0).Item("Refund_Amt").ToString()
                txtemail.Text = MyDatable.Rows(0).Item("payee_email").ToString()
                lblclient.Text = MyDatable.Rows(0).Item("Client_Type").ToString()
                txtPROPOSER.Text = MyDatable.Rows(0).Item("Proposer").ToString()

            End If

            loadGrid(FILE_NO.Text)
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            'LoginSubject = "BUSINESS ALLOCATION"
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>ATT:" & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = "'" & "DECLINE REFUND-" & txtname.Text & "-" & FILE_NO.Text & " ' "
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Refund No:" & RefNo.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Payee Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Submitted By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

    Protected Sub GD_DOCS_NeedDataSource(sender As Object, e As GridNeedDataSourceEventArgs) Handles GD_DOCS.NeedDataSource

    End Sub
End Class
