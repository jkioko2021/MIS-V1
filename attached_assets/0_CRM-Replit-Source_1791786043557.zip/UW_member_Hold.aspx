﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="UW_member_Hold.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:MultiView ID="MultiView1" runat="server">
    </asp:MultiView>
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table>
                <tr>
                    <td align="center" bgcolor="#333333" style="height: 44px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="Member on Hold"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <asp:Panel ID="Panel6" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1010px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel21" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="right" style="width: 1126px; height: 25px">
                                                        &nbsp;</td>
                                                    <td align="right" style="width: 627px; height: 25px">
                                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                                            Text="Family Member No"></asp:Label>
                                                    </td>
                                                    <td style="height: 25px; width: 240px">
                                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Simple" Width="225px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td style="height: 25px">
                                                        <telerik:RadButton ID="Search" runat="server" Text="update">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td style="height: 25px">
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel20" runat="server" ScrollBars="Both">
                                            <telerik:RadGrid ID="RDHOLD" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" DataType="System.Decimal" 
                                                            FilterControlAltText="Filter ID column" HeaderText="ID" ReadOnly="True" 
                                                            SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                            FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                            <ItemStyle Wrap="False" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                            <ItemStyle Wrap="False" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                            <ItemStyle Wrap="False" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                            HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                            SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                            <ItemStyle Wrap="False" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                            HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                            UniqueName="POLICY_VALID_UPTO">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;</td>
                                    <td class="style8" colspan="2" rowspan="3">
                                        <telerik:RadTextBox ID="txthold" Runat="server" Height="90px" Skin="Sunset" 
                                            TextMode="MultiLine" Width="350px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Label ID="Label9" runat="server" Text="Notes"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:CheckBox ID="chkhD" runat="server" Font-Bold="True" ForeColor="#CC0000" 
                                            style="font-weight: 700" Text="Hold Renewal" />
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <telerik:RadButton ID="RadButton8" runat="server" Skin="Simple" Text="UPDATE">
                                        </telerik:RadButton>
                                    </td>
                                    <td align="left" style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="lblhold" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="lblmem" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td align="left" style="width: 287px">
                                        <asp:Label ID="lblpOlicy" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1001px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Note_From" UniqueName="Note_From">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel10" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Width="1001px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td bgcolor="#999999" colspan="4">
                                                        <asp:Label ID="Label14" runat="server" Text="Report Extract (Entry Date)"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel22" runat="server" ScrollBars="Both">
                                                            <telerik:RadGrid ID="RDHOLD_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" PageSize="20" Skin="WebBlue" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                    
                                                                        <telerik:GridBoundColumn DataField="ID" DataType="System.Decimal" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="ID" ReadOnly="True" 
                                                                            SortExpression="ID" UniqueName="ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                            FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                            ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                            HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                            SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                            HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                            UniqueName="POLICY_VALID_UPTO">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 199px">
                                                        &nbsp;</td>
                                                    <td style="width: 199px">
                                                        <asp:Label ID="Label15" runat="server" Text="Date From"></asp:Label>
                                                    </td>
                                                    <td style="width: 143px">
                                                        <telerik:RadDatePicker ID="dtholdfrom" Runat="server" Skin="Web20">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 199px">
                                                        &nbsp;</td>
                                                    <td style="width: 199px">
                                                        <asp:Label ID="Label16" runat="server" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td style="width: 143px">
                                                        <telerik:RadDatePicker ID="dtholdto" Runat="server" Skin="Web20" Width="150px">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="RadButton7" runat="server" Skin="Sunset" Text="Generate">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3" style="height: 100%">
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                </table>
              
  
        </ContentTemplate>
                       
          </asp:UpdatePanel>
</asp:Content>
