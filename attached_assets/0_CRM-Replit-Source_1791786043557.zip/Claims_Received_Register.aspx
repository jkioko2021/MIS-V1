﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Claims_Received_Register.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="3">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="#CCCCCC" style="font-weight: 700" Text="RECEIVED CLAIM REGISTER"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="979px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 3043px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 384px">
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Provider" Value="P" />
                                                <telerik:RadComboBoxItem runat="server" Text="File No" Value="F" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cboprovid" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Forest" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="511px" style="font-weight: 700" Width="1010px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1001px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="5" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FILE_NO" 
                                                            FilterControlAltText="Filter FILE_NO column" HeaderText="FILE_NO" 
                                                            SortExpression="FILE_NO" UniqueName="FILE_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RECEIVE_DT" 
                                                            FilterControlAltText="Filter RECEIVE_DT column" HeaderText="RECEIVE_DT" 
                                                            SortExpression="RECEIVE_DT" UniqueName="RECEIVE_DT">
                                                            </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="INVOICE_AMT" 
                                                            FilterControlAltText="Filter INVOICE_AMT column" HeaderText="INVOICE_AMT" 
                                                            SortExpression="INVOICE_AMT" UniqueName="INVOICE_AMT">                                                       
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="INVOICE_CNT" 
                                                            FilterControlAltText="Filter INVOICE_CNT column" HeaderText="INVOICE_CNT" 
                                                            SortExpression="INVOICE_CNT" UniqueName="INVOICE_CNT">
                                                             <HeaderStyle Width="200px" />
                                                            <ItemStyle Width="200px" />
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" FilterControlAltText="Filter DeleteColumn column"
                                                                       Text="Delete" UniqueName="DeleteColumn"
                                                                      Resizable="false" ConfirmText="Delete record?">
                                                                      <HeaderStyle CssClass="rgHeader ButtonColumnHeader"></HeaderStyle>
                                                                      <ItemStyle CssClass="ButtonColumn" />
                                                                  </telerik:GridButtonColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 107px">
                                        <asp:Label ID="Label102" runat="server" Text="Receive Date"></asp:Label>
                                    </td>
                                    <td style="width: 83px">
                                        <telerik:RadDatePicker ID="dtreceive" Runat="server" MinDate="" Skin="Forest">
                                            <Calendar Skin="Forest" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        <asp:Label ID="Label132" runat="server" Text="Provider"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadComboBox ID="cboprovider" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Forest" Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cboprovider" 
                                                    Text="Card Inactive" Value="Card Inactive" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboprovider" 
                                                    Text="Card Not Dispatched" Value="Card Not Dispatched" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboprovider" 
                                                    Text="Incorrect Balances" Value="Incorrect Balances" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboprovider" 
                                                    Text="Smart Technical issue" Value="Smart Technical issue" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboprovider" Text="Other" 
                                                    Value="Other" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 107px">
                                        <asp:Label ID="Label130" runat="server" Text="Claim Type"></asp:Label>
                                    </td>
                                    <td style="width: 83px">
                                        <telerik:RadComboBox ID="cbotype" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Forest" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="IP/OP" Value="IP/OP" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        <asp:Label ID="Label131" runat="server" Text="Provider Name"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtProvider_Name" Runat="server" Skin="Forest" 
                                            Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 107px">
                                        <asp:Label ID="Label126" runat="server" Text="Invoice Count"></asp:Label>
                                    </td>
                                    <td style="width: 83px">
                                        <telerik:RadNumericTextBox ID="txtinv_cnt" Runat="server" Culture="en-US" 
                                            DataType="System.Int16" Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        <asp:Label ID="Label121" runat="server" Text="Comments"></asp:Label>
                                    </td>
                                    <td style="width: 287px" rowspan="3">
                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="70px" Skin="Forest" 
                                            TextMode="MultiLine" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 107px">
                                        <asp:Label ID="Label106" runat="server" Text="Total Amt"></asp:Label>
                                    </td>
                                    <td style="width: 83px">
                                        <telerik:RadNumericTextBox ID="txtinv_amt" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 107px">
                                        &nbsp;</td>
                                    <td style="width: 83px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 107px">
                                        <asp:Label ID="lblID" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 83px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                    <td rowspan="2" style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 107px">
                                        &nbsp;</td>
                                    <td style="width: 83px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadButton ID="cmdsave" runat="server" Skin="Simple" 
                                            style="height: 26px" Text="Save" Width="80px">
                                        </telerik:RadButton>
                                        &nbsp;<telerik:RadButton ID="cmdedit" runat="server" Skin="Simple" Text="Edit" 
                                            Width="80px">
                                        </telerik:RadButton>
                                        &nbsp;<telerik:RadButton ID="cmdnew" runat="server" Skin="Simple" Text="New" 
                                            Width="80px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>

    </asp:UpdatePanel>
</asp:Content>





