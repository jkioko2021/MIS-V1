﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="UW_Loading_Flag.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%" Width="1030px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td style="width: 431px" align="right">
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Member No"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel17" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" style="font-weight: 700" Width="1010px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Panel ID="Panel18" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1001px">
                                                            <telerik:RadGrid ID="GDSEARCH_1" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" 
                                                                    DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                                            HeaderText="DISPLAY_MEMBERSHIP_NO" ItemStyle-Wrap="False" 
                                                                            SortExpression="DISPLAY_MEMBERSHIP_NO" UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                            ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                            HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                            SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                            HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                            UniqueName="POLICY_VALID_UPTO">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label160" runat="server" Text="Member No."></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="txtno_1" Runat="server" Skin="Sunset" Width="200px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label161" runat="server" Text="Member Name"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadTextBox ID="txtname_1" Runat="server" Skin="Sunset" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label162" runat="server" Text="Period From"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadDatePicker ID="dtfrom_1" Runat="server" MinDate="" Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label163" runat="server" Text="Period To"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="DTto_1" Runat="server" MinDate="" Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td bgcolor="#666666" class="style8" colspan="4">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="lblID_1" runat="server" ForeColor="Red"></asp:Label>
                                                        &nbsp;</td>
                                                    <td style="width: 287px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8">
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label174" runat="server" Text="Notes"></asp:Label>
                                                    </td>
                                                    <td class="style8" colspan="2" rowspan="2">
                                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="90px" 
                                                            Skin="Sunset" TextMode="MultiLine" Width="400px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="2">
                                                        <asp:Label ID="lblerr0" runat="server" ForeColor="Red"></asp:Label>
                                                        <asp:HiddenField ID="HiddenField2" runat="server" />
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <telerik:RadButton ID="cmdsave_1" runat="server" Height="37px" Skin="Simple" 
                                                            Text="Save" Width="100px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td style="width: 287px">
                                                        &nbsp;<telerik:RadButton ID="cmdedit_1" runat="server" Skin="Simple" Text="Edit" 
                                                            Width="100px">
                                                        </telerik:RadButton>
                                                        &nbsp;<telerik:RadButton ID="cmdnew_1" runat="server" Skin="Simple" Text="New" 
                                                            Width="80px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td bgcolor="#999999" colspan="4">
                                                        <asp:Label ID="Label175" runat="server" Text="Report Extract (Entry Date)"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 199px">
                                                        &nbsp;</td>
                                                    <td style="width: 199px">
                                                        <asp:Label ID="Label177" runat="server" Text="Date From"></asp:Label>
                                                    </td>
                                                    <td style="width: 143px">
                                                        <telerik:RadDatePicker ID="dtF_1" Runat="server" Skin="Web20">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 199px">
                                                        &nbsp;</td>
                                                    <td style="width: 199px">
                                                        <asp:Label ID="Label178" runat="server" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td style="width: 143px">
                                                        <telerik:RadDatePicker ID="DTt_1" Runat="server" Skin="Web20" Width="150px">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="RadButton6" runat="server" Skin="Sunset" Text="Generate">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel20" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1001px">
                                                            <telerik:RadGrid ID="GDSEARCH_2" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" 
                                                                    DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                                            HeaderText="DISPLAY_MEMBERSHIP_NO" ItemStyle-Wrap="False" 
                                                                            SortExpression="DISPLAY_MEMBERSHIP_NO" UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                    
                                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                            HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                            SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                            HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                            UniqueName="POLICY_VALID_UPTO">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1001px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Note_From" UniqueName="Note_From">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblID" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
   
    </asp:UpdatePanel>
</asp:Content>


