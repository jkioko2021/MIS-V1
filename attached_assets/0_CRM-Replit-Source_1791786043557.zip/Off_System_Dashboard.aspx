﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Off_System_Dashboard.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1162px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="OFFSYSTEM DASHBOARD" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td style="width: 1639px">
                                                    &nbsp;</td>
                                                <td style="width: 125px">
                                                    <asp:Label ID="Label156" runat="server" Text="Date From"></asp:Label>
                                                </td>
                                                <td style="width: 264px">
                                                    <telerik:RadDatePicker ID="dtfrom" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1639px">
                                                    <asp:Label ID="FILE_NO" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    <asp:Label ID="Label157" runat="server" Text="Date To"></asp:Label>
                                                </td>
                                                <td style="width: 264px">
                                                    <telerik:RadDatePicker ID="dtto" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTracking_0" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Sunset" 
                                                            Width="100%"  ShowFooter="True">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="entered_by">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                                    <telerik:GridBoundColumn DataField="Entered_by" 
                                                                        FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                        SortExpression="Entered_by" UniqueName="Entered_by" FooterText="Totals"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_SUBMITTED"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter NOT_SUBMITTED column" HeaderText="NOT_SUBMITTED" 
                                                                        SortExpression="NOT_SUBMITTED" UniqueName="NOT_SUBMITTED"  Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_SCANNED"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter NOT_SCANNED column" HeaderText="NOT_SCANNED" 
                                                                        SortExpression="NOT_SCANNED" UniqueName="NOT_SCANNED"  Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_ALLOCATED"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter NOT_ALLOCATED column" HeaderText="NOT_ALLOCATED" 
                                                                        SortExpression="NOT_ALLOCATED" UniqueName="NOT_ALLOCATED"  Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_BILLED"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter NOT_BILLED column" HeaderText="NOT_BILLED" 
                                                                        SortExpression="NOT_BILLED" UniqueName="NOT_BILLED"  Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="BILLED"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter BILLED column" HeaderText="BILLED" 
                                                                        SortExpression="BILLED" UniqueName="BILLED"  Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="WITH_ISSUES"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter WITH_ISSUES column" HeaderText="ISSUES" 
                                                                        SortExpression="WITH_ISSUES" UniqueName="WITH_ISSUES"  Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="RETURNED_INCOMPLETE"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter RETURNED_INCOMPLETE column" 
                                                                        HeaderText="RETURNED_INCOMPLETE" SortExpression="RETURNED_INCOMPLETE" 
                                                                        UniqueName="RETURNED_INCOMPLETE"  Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                       <telerik:GridBoundColumn DataField="TOTAL_APPROVALS"  DataFormatString="{0:#,#}"
                                                                        FilterControlAltText="Filter TOTAL_APPROVALS column" HeaderText="TOTAL_APPROVALS" 
                                                                        SortExpression="TOTAL_APPROVALS" UniqueName="TOTAL_APPROVALS" Aggregate="Sum"  FooterStyle-Font-Bold="true">
                                                                    </telerik:GridBoundColumn>
                                                                                                                                  
                                                                 </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1140px">
                                                        <telerik:RadGrid ID="GDTracking" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="Id">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridBoundColumn DataField="Ref_No" 
                                                                        FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                        SortExpression="Ref_No" UniqueName="Ref_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Member_No" 
                                                                        FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                        SortExpression="Member_No" UniqueName="Member_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Member_Name" 
                                                                        FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                                        SortExpression="Member_Name" UniqueName="Member_Name">
                                                                    </telerik:GridBoundColumn>     
    
 
<telerik:GridBoundColumn DataField="Proposer_Name" 
FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
SortExpression="Proposer_Name" UniqueName="Proposer_Name">
</telerik:GridBoundColumn>  
  
<telerik:GridBoundColumn DataField="Provider_name" 
FilterControlAltText="Filter Provider_name column" HeaderText="Provider" 
SortExpression="Provider_name" UniqueName="Provider">
</telerik:GridBoundColumn>    

<telerik:GridBoundColumn DataField="Service_Dt" 
FilterControlAltText="Filter Service_Dt column" HeaderText="Service_Dt" 
SortExpression="Service_Dt" UniqueName="Service_Dt" DataFormatString="{0:dd-MM-yyyy}">
</telerik:GridBoundColumn>               
                                                
<telerik:GridBoundColumn DataField="Inv_Status" 
FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
SortExpression="Inv_Status" UniqueName="Inv_Status">
</telerik:GridBoundColumn>    

<telerik:GridBoundColumn DataField="Entered_By" 
FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
SortExpression="Entered_By" UniqueName="Entered_By">
</telerik:GridBoundColumn>  
                                               
</Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 193px">
                                                    <asp:Label ID="Label159" runat="server" Text="Status"></asp:Label>
                                                </td>
                                                <td style="width: 246px">
                                                    <telerik:RadComboBox ID="cboNAME" Runat="server" AllowCustomText="True" 
                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="ALL" Value="ALL" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboNAME" Text="REGISTERED" 
                                                                Value="RE" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboNAME" Text="SUBMITTED" 
                                                                Value="SU" />
                                                            <telerik:RadComboBoxItem runat="server" Text="SCANNED" Value="SC" />
                                                            <telerik:RadComboBoxItem runat="server" Text="ALLOCATED" Value="AL" />
                                                            <telerik:RadComboBoxItem runat="server" Text="BILLED" Value="BI" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td style="width: 246px">
                                                    <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" 
                                                        Text="Export to Excel">
                                                    </telerik:RadButton>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    &nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
       
            </asp:UpdatePanel>
</asp:Content>

