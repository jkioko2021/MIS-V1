﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            empcode = ""
            Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                'empcode = "0111"
            Else
                lblerr.Text = "You are not authorized to view this page"
                Exit Sub
            End If
            Str = ""
            Str = "SELECT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1 AND C_CODE='R' AND RE_CODE ='" & empcode & "' " '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cborm
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()
            End With
            cborm.SelectedValue = empcode

            MyDatatable = Nothing
            Str = "SELECT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1 AND RMS_CODE_RET='" & cborm.SelectedValue & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboagent
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()
            End With
            MyDatatable = Nothing


            Str = "SELECT [Item_Code],[Item_Name]  FROM [CRM].[dbo].[TBL_MIS_CRM_CALL_ITEMS] WHERE CODE=0"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With chklist
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Item_Name").ToString
                .DataValueField = MyDatatable.Columns("Item_Code").ToString
                .DataBind()
            End With

            Str = "SELECT [Item_Code],[Item_Name]  FROM [CRM].[dbo].[TBL_MIS_CRM_CALL_ITEMS] WHERE CODE=1"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With chklist_1
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Item_Name").ToString
                .DataValueField = MyDatatable.Columns("Item_Code").ToString
                .DataBind()
            End With
            loadgrid()
        End If
    End Sub
    Public Sub loadgrid()
        Try
            SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM [TBL_MIS_CRM_NEW_POLICIES_RET] WHERE [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=0 AND PERIOD_TO>=Getdate()"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
                Session("DAD_C_0") = MyDatable
                MyDatable = Nothing
            Else
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
            End If

            Str = "SELECT [Item_Code],[Item_Name]  FROM [CRM].[dbo].[TBL_MIS_CRM_CALL_ITEMS] WHERE CODE=0"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With chklist
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Item_Name").ToString
                .DataValueField = MyDatatable.Columns("Item_Code").ToString
                .DataBind()
            End With
            Str = "SELECT [Item_Code],[Item_Name]  FROM [CRM].[dbo].[TBL_MIS_CRM_CALL_ITEMS] WHERE CODE=1"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With chklist_1
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Item_Name").ToString
                .DataValueField = MyDatatable.Columns("Item_Code").ToString
                .DataBind()
            End With
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDProposer.DataSource = Nothing
            GDProposer.DataBind()
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()

            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM TBL_MIS_CRM_NEW_POLICIES_RET WHERE PROPOSER_DISPLAY_NAME LIKE '%" & cbosearch_1.Text & "%'  AND [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=0"
            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM TBL_MIS_CRM_NEW_POLICIES_RET WHERE POLICY_CODE LIKE '%" & cbosearch_1.Text & "%' AND  [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=0"
            ElseIf cbosearch.SelectedValue = "A" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM TBL_MIS_CRM_NEW_POLICIES_RET WHERE USER_ID = '" & cbosearch_1.SelectedValue & "'  AND [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=0"

            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
                Session("DAD_C_0") = MyDatable
                MyDatable = Nothing
            Else
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
            End If
            '

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDProposer_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDProposer.PageIndexChanged
        GDProposer.CurrentPageIndex = e.NewPageIndex
        GDProposer.DataSource = Session("DAD_C_0")
        GDProposer.DataBind()
    End Sub


    Protected Sub cbosearch_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbosearch.SelectedIndexChanged
        If cbosearch.SelectedValue = "A" Then
            Str = "SELECT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1 AND RMS_CODE_RET='" & cborm.SelectedValue & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbosearch_1
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()
            End With

        Else
            cbosearch_1.SelectedValue = ""
            cbosearch_1.Text = ""
        End If
    End Sub
    Protected Sub GDProposer_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDProposer.SelectedIndexChanged
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            Session("FAMILY_NO") = Nothing
            PRD.Text = ""
            PRD.Text = (DirectCast(GDProposer.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing

            SqlAction = "SELECT FAMILY_NO, [PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE]      ,[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                cboagent.SelectedValue = MyDatable.Rows(0).Item("USER_ID").ToString()
                Session("FAMILY_NO") = MyDatable.Rows(0).Item("FAMILY_NO").ToString()
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_C_0") = MyDatable
                MyDatable = Nothing

            Else
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

            

    Public Sub Generate_Task()
        Dim AB As Integer

        SqlAction = "SELECT ISNULL((MAX(Call_id)+1),1) NUMBER FROM [dbo].[TBL_MIS_CRM_NEW_RET_CALL_LOG]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblcode.Text = "CA/" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If

    End Sub

    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            If PRD.Text = "" Then
                lblerr.Text = "Select proposer!"
                Exit Sub
            End If
            Generate_Task()
            MyDBAction.Call_Confirmation(PRD.Text, lblcode.Text, Session("username"), Date.Now(), cbo_1.SelectedValue, cbo_2.SelectedValue, cbo_3.SelectedValue, cbo_4.SelectedValue, cbo_5.SelectedValue, "", cbo_6.SelectedValue, "NEW MEMBER CALL")
            If txtdescr.Text <> "" Then
                MyDBAction.TASK_MESSAGES(PRD.Text, txtdescr.Text, Session("username"), Date.Now(), "NEW MEMBER CALL", Session("FAMILY_NO"))
            End If
            For Each MyItem In chklist.Items
                If MyItem.Selected = True Then
                    MyDBAction.CALL_UPLOAD_ITEMS(lblcode.Text, PRD.Text, MyItem.value, 0)
                End If
            Next
            For Each MyItem_1 In chklist_1.Items
                If MyItem_1.Selected = True Then
                    MyDBAction.CALL_UPLOAD_ITEMS(lblcode.Text, PRD.Text, MyItem_1.value, 1)
                End If
            Next
            txtdescr.Text = ""
            lblerr.Text = "Saved Successfull"

            lblcode.Text = ""
            Session("FAMILY_NO") = Nothing
            loadgrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
