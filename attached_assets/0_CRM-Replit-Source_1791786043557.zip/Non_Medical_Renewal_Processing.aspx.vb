﻿
Imports System.Data
Imports DocManage
Imports Mymail
Imports Telerik.Web.UI
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim audit As New DataManagement
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""

                SqlAction = "SELECT MIN([Period_From]) [Period_From]     ,MIN([Period_To])[Period_To]  FROM [CRM].[dbo].[TBL_MIS_CRM_NON_MED_RENEWAL_PROCESS]  WHERE [Signed_Off] =0"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("Period_From").ToString()
                    dtto.DbSelectedDate = MyDatable.Rows(0).Item("Period_To").ToString()

                Else
                    dtfrom.DbSelectedDate = Date.Now
                    dtto.DbSelectedDate = Date.Now
                End If


                Str = "SELECT CODE,DESCRIPTION FROM  [COMMISSION].[dbo].[TBL_MIS_SALES_NON_MED_COMM_RATE] order by CODE " '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboclass
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("DESCRIPTION").ToString
                    .DataValueField = MyDatatable.Columns("CODE").ToString
                    .DataBind()
                End With

                loadGrid()
                txtBasicPrem_L.Enabled = False
                txttot_L.Enabled = False
                txtlevy_L.Enabled = False
                txtfund_L.Enabled = False
                txtBasicPrem.Enabled = False
                txttot.Enabled = False
                txtprem.Enabled = False
                txtlevy.Enabled = False
                txtfund.Enabled = False
                txtsumIns.Enabled = False

            Catch ex As Exception
                lblcode.Text = ex.Message
            End Try
        End If
    End Sub
    Public Sub Load_Notes(ByVal policy As String)
        SqlAction = "SELECT   [Note_id],[Policy_Number],[Notes],[Note_From],[Note_Date],[Note_Type] FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Notes] WHERE  Policy_Number ='" & policy & "'  AND Active=1 ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If

    End Sub
    Public Sub loadGrid()
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()

        GDMEMBER.DataSource = Nothing
        GDMEMBER.DataBind()
        GDMEMBER.DataSource = Nothing
        GDMEMBER.DataBind()

        SqlAction = "SELECT  [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and [Verified]=0 and  [Hold]=0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_Signoff.DataSource = MyDatable
            GD_Signoff.DataBind()
            Session("NON_1_1") = MyDatable
            MyDatable = Nothing
        Else
            GD_Signoff.DataSource = Nothing
            GD_Signoff.DataBind()
        End If
        SqlAction = "SELECT  [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Claim_Amount>0 AND [Verified]=0  AND Is_Loading=0 and  [Hold]=0 and Processed=0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("NON_1") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
        SqlAction = "SELECT  [Policy_Number],[Period_From],[Period_To],[Sum_Insured],[Basic_Premium],[Policy_Fund],[Training_Levy],[Total_Premium],[Loading_Rate],[Loading_Item],[Loading_AMT],[Loading_Date],[Loading_By]  FROM [AIMSOFT_DATADUMP].[dbo].[Tbl_MIs_GI_Loading] WHERE Period_From BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and Processed=0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_Loading.DataSource = MyDatable
            GD_Loading.DataBind()
            Session("NON_12") = MyDatable
            MyDatable = Nothing
        Else
            GD_Loading.DataSource = Nothing
            GD_Loading.DataBind()
        End If

        SqlAction = "SELECT  [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  [Verified]=0  AND  [Hold]=1 and Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_HOLD.DataSource = MyDatable
            GD_HOLD.DataBind()
            Session("GD_HOLD") = MyDatable
            MyDatable = Nothing
        Else
            GD_HOLD.DataSource = Nothing
            GD_HOLD.DataBind()
        End If


    End Sub
    Protected Sub GD_1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_Signoff.PageIndexChanged
        GD_Signoff.CurrentPageIndex = e.NewPageIndex
        GD_Signoff.DataSource = Session("NON_1_1")
        GD_Signoff.DataBind()
    End Sub
    Protected Sub GD_HOLD_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_HOLD.PageIndexChanged
        GD_HOLD.CurrentPageIndex = e.NewPageIndex
        GD_HOLD.DataSource = Session("GD_HOLD")
        GD_HOLD.DataBind()
    End Sub
    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            txttot.Text = 0
            txtrate.Text = 0
            txtpolicy.Text = ""
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            txtpolicy.Text = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Policy_Number").ToString()
            SqlAction = "SELECT  [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Policy_Number='" & txtpolicy.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txtpolicy.Text = MyDatable.Rows(0).Item("Policy_Number").ToString()
                chkhold.Checked = MyDatable.Rows(0).Item("Hold").ToString()
                txtBasicPrem.Text = MyDatable.Rows(0).Item("Basic_Premium").ToString()
                txttot.Text = MyDatable.Rows(0).Item("Total_Premium").ToString()
                txtprem.Text = MyDatable.Rows(0).Item("Total_Premium").ToString()
                txtlevy.Text = MyDatable.Rows(0).Item("Training_Levy").ToString()
                txtfund.Text = MyDatable.Rows(0).Item("Policy_Fund").ToString()
                txtsumIns.Text = MyDatable.Rows(0).Item("Sum_Insured").ToString()
                dtStart.DbSelectedDate = MyDatable.Rows(0).Item("Renewal_start_date").ToString()
                dtend.DbSelectedDate = MyDatable.Rows(0).Item("Renewal_end_date").ToString()
                txtClaim.Text = MyDatable.Rows(0).Item("Claim_Amount").ToString()
                dtPeriodFrom.DbSelectedDate = MyDatable.Rows(0).Item("Renewal_start_date").ToString()
                dtPeriodTo.DbSelectedDate = MyDatable.Rows(0).Item("Renewal_end_date").ToString()



            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

    End Sub
    Protected Sub GDTracking_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GD_Loading.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("Policy_Number").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""

            DeleteRecord("DELETE FROM  [AIMSOFT_DATADUMP].[dbo].[Tbl_MIs_GI_Loading] WHERE POLICY_NUMBER='" & HiddenField1.Value & "' AND Period_From between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND   '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'")
            'DeleteRecord("DELETE FROM TBL_MIS_CRM_DOCS WHERE  File_No='" & HiddenField1.Value.ToString & "'")
            UpdateRecord("UPDATE [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] SET  Processed=0  WHERE [Policy_Number]='" & txtpolicy.Text & "' AND  Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'")


            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid()

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Dim Rate As Decimal
        If Decimal.TryParse(txtrate.Text, Rate) Then
            Rate = Rate / 100D
        Else
            Rate = 0
        End If
        If Rate = 0 Then
            lblerr.Text = "Loading Rate Cannot Be Zero"
            Exit Sub
        End If
        If cboload.SelectedValue = "" Then
            lblerr.Text = "Select The Loading Type"
            cboload.Focus()
            Exit Sub
        End If
        Try

            If cboType.SelectedValue = "P" Then
                If txtpolicy.Text = "" Then
                    lblerr.Text = "Select Policy Number"
                    Exit Sub
                Else
                    MyDBAction.GI_LOADING(txtpolicy.Text, CDate(dtStart.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd"), cboload.SelectedValue, Rate, txtBasicPrem.Text, txtsumIns.Text, Session("username"))
                    If txtnotes.Text <> "" Then
                        MyDBAction.TRACKING_MESSAGES_NON(txtpolicy.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text)
                    End If
                    lblerr.Text = "Saved Successfully!"
                    Load_Notes(txtpolicy.Text)
                    audit.AddAdminAuditTrail(Session("UserName").ToString, "GI Loading", "Policy Loading :-   :" & txtpolicy.Text & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".",
          Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
                End If

            ElseIf cboType.SelectedValue = "C" Then
                If cboclass.SelectedValue = "" Then
                    lblerr.Text = "Select Policy Number"
                    Exit Sub
                Else
                    MyDBAction.GI_LOADING_CLASS(CDate(dtStart.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd"), Rate, cboclass.SelectedValue, cboType.SelectedValue, Session("username"))
                    'EXEC [dbo].[SP_GI_Loading_Per_Class] '2026-06-01', '2026-06-30',0.0001,'FIRE INDUSTRIAL','P'
                    lblerr.Text = "Saved Successfully!"
                    audit.AddAdminAuditTrail(Session("UserName").ToString, "GI Loading", "Class Loading :-   :" & cboclass.SelectedValue & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".",
                    Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
                End If

            End If
            loadGrid()
            ' MyDBAction.TRACKING_MESSAGES_NON(txtpolicy.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text)

            txttot.Text = 0
            txtrate.Text = 0
            txtpolicy.Text = ""
            txtnotes.Text = ""
            lblerr.Text = "Saved Successfull!"
            cboclass.SelectedValue = ""
            cboload.SelectedValue = ""
            cboType.SelectedValue = ""
            'load_grid(txtpolicy.Text)





        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub txtrate_TextChanged(sender As Object, e As System.EventArgs) Handles txtrate.TextChanged
        txttot.Text = txtprem.Text + (txtrate.Text * txtprem.Text)
    End Sub

    Protected Sub RadButton2_Click(sender As Object, e As System.EventArgs) Handles btnsign.Click
        If chksign.Checked = True Then

            UpdateRecord("UPDATE [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] SET [Verified]=1,[Verified_by]='" & Session("username") & "' ,[Verified_Date]=getdate()  WHERE Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and [Verified]=0 and  [Hold]=0")
            MyDBAction.RENEWAL_EMAIL_DISPATCH_NON(CDate(Date.Now).ToString("yyyy-MM-dd"))
            UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_NON_MED_RENEWAL_PROCESS] SET  [Signed_Off]=1  WHERE   PERIOD_FROM = '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "'")
            'MailSent = SendLoginDetails(Session("EMPNAME"), Session("Path"), Session("RecepientEmail"), Session("agentEmail"))


            lblerr.Text = "Sign-off done successfully"
            SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [CRM].[dbo].[TBL_MIS_CRM_NON_MED_RENEWAL_PROCESS] WHERE Signed_Off=0"


            lblerr.Text = "Saved Successfull"
            loadGrid()
        End If
    End Sub

    Protected Sub RadButton3_Click(sender As Object, e As System.EventArgs) Handles RadButton3.Click

        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String
        Session("Mytable") = Nothing
        Session("Reportname") = Nothing
        Session("EXCEL") = "TO EXCEL"
        Reportname = "Renewal-List As At-& " & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & ""
        SqlAction = "SELECT +''''+[Policy_Number], [Insured],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],Basic_Premium,Policy_Fund,Training_Levy, [Total_Premium],verified  FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If Mytable.Rows.Count > 0 Then
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        GDMEMBER.DataSource = Nothing
        GDMEMBER.DataBind()
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        If cbosearch.SelectedValue = "P" Then
            SqlAction = "SELECT  [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy  FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE Policy_Number='" & Trim(txtsearch.Text) & "'"
        ElseIf cbosearch.SelectedValue = "I" Then
            SqlAction = "SELECT  [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy  FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE Insured LIKE '%" & Trim(txtsearch.Text) & "%'"
        End If
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("NON_1") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub



    Protected Sub RadButton4_Click(sender As Object, e As EventArgs) Handles RadButton4.Click
        Try

            MyDBAction.GI_LOADING_POST(CDate(dtStart.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd"))

            audit.AddAdminAuditTrail(Session("UserName").ToString, "GI Loading", "Post Loading :-   :" & CDate(dtStart.DbSelectedDate).ToString("yyyy-MM-dd") & ", Name - " & Session("FullNames") & ".",
                    Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            'UpdateRecord("UPDATE [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] SET   Is_Loading=1, Basic_Premium='" & txtBasicPrem_L.Text & "',Policy_Fund='" & txtfund_L.Text & "',Training_Levy='" & txtlevy_L.Text & "',Total_Premium='" & txttot_L.Text & "',Loading='" & txtrate.Text & "'  WHERE Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and  Policy_Number='" & txtpolicy.Text & "'")
            'UpdateRecord("UPDATE [AIMSOFT_DATADUMP].[dbo].[Tbl_MIs_GI_Loading] SET Processed=1 WHERE Policy_Number='" & txtpolicy.Text & "' AND Period_From BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND   '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and  Policy_Number='" & txtpolicy.Text & "'")
            loadGrid()
            lblerr.Text = "Posted Successfull"
            txtBasicPrem_L.Text = 0
            txttot_L.Text = 0
            txtlevy_L.Text = 0
            txtfund_L.Text = 0
            txtBasicPrem.Text = 0
            txttot.Text = 0
            txtprem.Text = 0
            txtlevy.Text = 0
            txtfund.Text = 0
            txtsumIns.Text = 0
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try



    End Sub

    Protected Sub GD_MEM_NeedDataSource(sender As Object, e As GridNeedDataSourceEventArgs) Handles GD_Loading.NeedDataSource

    End Sub

    Private Sub GD_MEM_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GD_Loading.SelectedIndexChanged
        txtpolicy.Text = (DirectCast(GD_Loading.SelectedItems(0), GridDataItem)).GetDataKeyValue("Policy_Number").ToString()
        SqlAction = "SELECT  [Policy_Number],[Period_From],[Period_To],[Sum_Insured],[Basic_Premium],[Policy_Fund],[Training_Levy],[Total_Premium],[Loading_Rate],[Loading_Item],[Loading_AMT],[Loading_Date],[Loading_By]  FROM [AIMSOFT_DATADUMP].[dbo].[Tbl_MIs_GI_Loading] where Policy_Number='" & Trim(txtpolicy.Text) & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            'txtpolicy.Text = MyDatable.Rows(0).Item("Policy_Number").ToString()
            txtBasicPrem_L.Text = MyDatable.Rows(0).Item("Basic_Premium").ToString()
            txtfund_L.Text = MyDatable.Rows(0).Item("Policy_Fund").ToString()
            txtlevy_L.Text = MyDatable.Rows(0).Item("Training_Levy").ToString()
            txttot_L.Text = MyDatable.Rows(0).Item("Total_Premium").ToString()
            txtrate.Text = MyDatable.Rows(0).Item("Loading_Rate").ToString()
        End If

    End Sub

    Protected Sub RadButton5_Click(sender As Object, e As EventArgs) Handles RadButton5.Click
        Try
            If chkhold.Checked = True Then
                UpdateRecord("UPDATE [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] SET  [Hold]=1  WHERE [Policy_Number]='" & txtpolicy.Text & "' AND Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'")
            Else
                UpdateRecord("UPDATE [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] SET  [Hold]=0  WHERE [Policy_Number]='" & txtpolicy.Text & "' AND Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'")
            End If

            If txtHold_notes.Text <> "" Then
                MyDBAction.TRACKING_MESSAGES_NON(txtpolicy.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text)
            End If

            SqlAction = "SELECT  [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  [Verified]=0  AND  [Hold]=1 and Renewal_start_date BETWEEN '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Policy_Number='" & Trim(txtpolicy.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_HOLD.DataSource = MyDatable
                GD_HOLD.DataBind()
                Session("GD_HOLD") = MyDatable
                MyDatable = Nothing
            Else
                GD_HOLD.DataSource = Nothing
                GD_HOLD.DataBind()
            End If
            Load_Notes(txtpolicy.Text)

            ' MyDBAction.TRACKING_MESSAGES_NON(txtpolicy.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text)

            txttot.Text = 0
            txtrate.Text = 0
            txtpolicy.Text = ""
            txtnotes.Text = ""
            lblerr_1.Text = "Saved Successfull!"
            'load_grid(txtpolicy.Text)


        Catch ex As Exception

        End Try
    End Sub



    Private Sub GD_HOLD_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GD_HOLD.SelectedIndexChanged
        txtpolicy.Text = (DirectCast(GD_HOLD.SelectedItems(0), GridDataItem)).GetDataKeyValue("Policy_Number").ToString()
        SqlAction = "SELECT  [Policy_Number],[Period_From],[Period_To],[Sum_Insured],[Basic_Premium],[Policy_Fund],[Training_Levy],[Total_Premium],[Loading_Rate],[Loading_Item],[Loading_AMT],[Loading_Date],[Loading_By]  FROM [AIMSOFT_DATADUMP].[dbo].[Tbl_MIs_GI_Loading] where Policy_Number='" & Trim(txtpolicy.Text) & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            txtpolicy.Text = MyDatable.Rows(0).Item("Policy_Number").ToString()

            dtPeriodFrom.DbSelectedDate = MyDatable.Rows(0).Item("Period_From").ToString()
            dtPeriodTo.DbSelectedDate = MyDatable.Rows(0).Item("Period_To").ToString()
        End If
    End Sub


End Class
