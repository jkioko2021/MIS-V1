﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim emp_code As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0

                Str = "SELECT [Depart_Code],[Department] FROM [AAR_RISK_DB].[dbo].[TBL_MIS_RISK_DEPART]" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbodepart
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Department").ToString
                    .DataValueField = MyDatatable.Columns("Depart_Code").ToString
                    .DataBind()
                End With
                With cbodepart_1
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Department").ToString
                    .DataValueField = MyDatatable.Columns("Depart_Code").ToString
                    .DataBind()
                End With

                'Str = "SELECT [Issue_Code],[Issue_Name]  FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] WHERE ACTIVE=1"
             

                Str = "SELECT ltrim(rtrim(Emp_code))Emp_code,employeename FROM employees WHERE DELETED=0" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboemp
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("employeename").ToString
                    .DataValueField = MyDatatable.Columns("Emp_code").ToString
                    .DataBind()
                End With



                Session("empcode") = Nothing
                Session("agentemail") = Nothing

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
    Public Sub Load_Grid()
        SqlAction = "SELECT  [Issue_Code],[Depart_Code],[Issue_Name],e.employeename [Escalate],[SLA_Hrs]  FROM [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] S LEFT JOIN EMPLOYEES E ON E.emp_code=s.Supervisor"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCOMPL.DataSource = MyDatable
            GDCOMPL.DataBind()
            MyDatable = Nothing
        Else
            GDCOMPL.DataSource = Nothing
            GDCOMPL.DataBind()
        End If
    End Sub
    Public Sub Generate_Task()
        SqlAction = "SELECT ISNULL((MAX(Id)+1),1) NUMBER FROM CRM.[dbo].[TBL_MIS_COMPLAINT_TRACKING]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblcode.Text = "A" & numStr4ch & ""
        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        '   SqlAction = "SELECT  [Issue_Code],[Depart_Code],[Issue_Name],[Supervisor],[SLA_Hrs]  FROM [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] where Depart_Code= '" & cbodepart_1.SelectedValue & "'"
        SqlAction = "SELECT  [Issue_Code],[Depart_Code],[Issue_Name],e.employeename [Escalate],[SLA_Hrs],Supervisor  FROM [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] S LEFT JOIN EMPLOYEES E ON E.emp_code=s.Supervisor where Depart_Code= '" & cbodepart_1.SelectedValue & "'"

        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCOMPL.DataSource = MyDatable
            GDCOMPL.DataBind()

            MyDatable = Nothing
        Else
            GDCOMPL.DataSource = Nothing
            GDCOMPL.DataBind()
        End If
    End Sub

    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try

            If cbodepart.SelectedValue = "" Then
                lblerr.Text = "Select Department"
                Exit Sub
            End If
            If HiddenField1.Value = 0 Then
                Generate_Task()
                MyDBAction.TASK_SUMMARY_COMPLAIN(lblcode.Text, cbodepart.SelectedValue, txtissue.Text, cboemp.SelectedValue, txtsla.Text, 0)
            Else
                MyDBAction.TASK_SUMMARY_COMPLAIN(lblcode.Text, cbodepart.SelectedValue, txtissue.Text, cboemp.SelectedValue, txtsla.Text, 1)
            End If

            SqlAction = "SELECT  [Issue_Code],[Depart_Code],[Issue_Name],e.employeename [Escalate],[SLA_Hrs]  FROM [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] S LEFT JOIN EMPLOYEES E ON E.emp_code=s.Supervisor where Depart_Code= '" & cbodepart_1.SelectedValue & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCOMPL.DataSource = MyDatable
                GDCOMPL.DataBind()
                MyDatable = Nothing
            Else
                GDCOMPL.DataSource = Nothing
                GDCOMPL.DataBind()
            End If
            lblcode.Text = ""
            cbodepart.SelectedValue = ""
            txtissue.Text = ""
            cboemp.SelectedValue = ""
            txtsla.Text = 0
            lblerr.Text = "Saved Successfull"
            HiddenField1.Value = 1
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

 

    Protected Sub GDCOMPL_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCOMPL.SelectedIndexChanged
        Try
            Dim number As String = ""
            number = (DirectCast(GDCOMPL.SelectedItems(0), GridDataItem)).GetDataKeyValue("Issue_Code").ToString()
            SqlAction = "SELECT  [Issue_Code],[Depart_Code],[Issue_Name],ltrim(rtrim([Supervisor]))Supervisor,[SLA_Hrs]  FROM [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] Where Issue_Code='" & number & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                cbodepart.SelectedValue = MyDatatable.Rows(0).Item("Depart_Code").ToString()
                lblcode.Text = MyDatatable.Rows(0).Item("Issue_Code").ToString()
                txtissue.Text = MyDatatable.Rows(0).Item("Issue_Name").ToString()
                cboemp.SelectedValue = MyDatatable.Rows(0).Item("Supervisor").ToString()
                txtsla.Text = MyDatatable.Rows(0).Item("SLA_Hrs").ToString()

            End If

            HiddenField1.Value = 1
            cbodepart.Enabled = False
            lblcode.Enabled = False
            txtissue.Enabled = False
            cboemp.Enabled = False
            txtsla.Enabled = False
            btnsave.Enabled = False

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try


    End Sub

    Protected Sub btnupload0_Click(sender As Object, e As System.EventArgs) Handles btnnew.Click
        lblcode.Text = ""
        cbodepart.SelectedValue = ""
        txtissue.Text = ""

        txtsla.Text = 0
        HiddenField1.Value = 0
        btnsave.Enabled = True
        cbodepart.Enabled = True
        lblcode.Enabled = True
        txtissue.Enabled = True
        cboemp.Enabled = True
        txtsla.Enabled = True
    End Sub

 
    Protected Sub btnedit_Click(sender As Object, e As System.EventArgs) Handles btnedit.Click
        HiddenField1.Value = 1
        btnsave.Enabled = True
        cbodepart.Enabled = True
        lblcode.Enabled = True
        txtissue.Enabled = True
        cboemp.Enabled = True
        txtsla.Enabled = True
    End Sub

    Protected Sub cbodepart_1_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbodepart_1.SelectedIndexChanged
        cbodepart.SelectedValue = cbodepart_1.SelectedValue
    End Sub
End Class
