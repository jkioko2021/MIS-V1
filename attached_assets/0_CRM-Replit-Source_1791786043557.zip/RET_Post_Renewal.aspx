﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="RET_Post_Renewal.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%;">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="#CCCCCC" style="font-weight: 700" 
                            Text="VIEW POST RENEWALS"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="center" style="text-align: left">
                        <telerik:RadComboBox ID="cborm" Runat="server" AllowCustomText="True" 
                            MarkFirstMatch="True" Skin="Sunset" Width="250px">
                            <Items>
                                <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Proposer Name" 
                                    Value="P" />
                                <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Family Code" 
                                    Value="F" />
                                <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Agent" 
                                    Value="Agent" />
                            </Items>
                        </telerik:RadComboBox>
                    </td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td align="center" style="text-align: left">
                        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td align="center" colspan="4" style="text-align: left">
                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                            <table style="width: 100%">
                                <tr>
                                    <td>
                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" Text="Select"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" AutoPostBack="True" 
                                            Skin="Outlook">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="RM" Value="RM" />
                                                <telerik:RadComboBoxItem runat="server" Text="Agent" Value="A" 
                                                    Owner="cbosearch" />
                                                <telerik:RadComboBoxItem runat="server" Text="Family Code" Value="F" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbotext" Runat="server" AllowCustomText="True" 
                                            MarkFirstMatch="True" Width="300px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                            Width="157px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1162px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel2" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GD_PROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                      FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                      UniqueName="Select">
                                                                      <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                      <ItemStyle Width="50px" />
                                                                  </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FAMILY_NO" 
                                                            FilterControlAltText="Filter FAMILY_NO column" HeaderText="FAMILY_NO" 
                                                            SortExpression="FAMILY_NO" UniqueName="FAMILY_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DAYS_DUE" 
                                                            FilterControlAltText="Filter DAYS_DUE column" HeaderText="DAYS_OVERDUE" 
                                                            SortExpression="DAYS_DUE" UniqueName="DAYS_DUE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT" 
                                                            FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                            SortExpression="AGENT" UniqueName="AGENT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MOBILE_NO" 
                                                            FilterControlAltText="Filter MOBILE_NO column" HeaderText="MOBILE_NO" 
                                                            SortExpression="MOBILE_NO" UniqueName="MOBILE_NO">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>                                                       
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                    
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="FAMILY_NO" 
                                                            FilterControlAltText="Filter FAMILY_NO column" HeaderText="FAMILY_NO" 
                                                            SortExpression="FAMILY_NO" UniqueName="FAMILY_NO">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                            HeaderText="POLICY_VALID_FROM" SortExpression="POLICY_VALID_FROM" 
                                                            UniqueName="POLICY_VALID_FROM" DataFormatString="{0:yyyy-MM-dd}">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                            HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                            UniqueName="POLICY_VALID_UPTO" DataFormatString="{0:yyyy-MM-dd}">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="DISPLAY_MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>                                                      
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" 
                                                            HeaderText="MEMBER_BIRTH_DATE" SortExpression="MEMBER_BIRTH_DATE" 
                                                            UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" 
                                                            HeaderText="MEMBER_ADMINISTRATIVE_SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT" 
                                                            FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                            SortExpression="AGENT" UniqueName="AGENT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGE_AT_RENEWAL" 
                                                            FilterControlAltText="Filter AGE_AT_RENEWAL column" HeaderText="AGE_AT_RENEWAL" 
                                                            SortExpression="AGE_AT_RENEWAL" UniqueName="AGE_AT_RENEWAL">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CATEGORY" 
                                                            FilterControlAltText="Filter CATEGORY column" HeaderText="CATEGORY" 
                                                            SortExpression="CATEGORY" UniqueName="CATEGORY">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OP_LIMIT" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter OP_LIMIT column" 
                                                            HeaderText="OP_LIMIT" SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OP_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter OP_PREMIUM column" 
                                                            HeaderText="OP_PREMIUM" SortExpression="OP_PREMIUM" UniqueName="OP_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_LIMIT" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter IP_LIMIT column" 
                                                            HeaderText="IP_LIMIT" SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter IP_PREMIUM column" 
                                                            HeaderText="IP_PREMIUM" SortExpression="IP_PREMIUM" UniqueName="IP_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PA" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter PA column" 
                                                            HeaderText="PA" SortExpression="PA" UniqueName="PA">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="NCD" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter NCD column" 
                                                            HeaderText="NCD" SortExpression="NCD" UniqueName="NCD">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="LEVIES" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter LEVIES column" 
                                                            HeaderText="LEVIES" SortExpression="LEVIES" UniqueName="LEVIES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label104" runat="server" Text="Total Premiums"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txttotal" Runat="server" Width="155px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblPolicy" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label140" runat="server" Text="Call Comments"></asp:Label>
                                    </td>
                                    <td colspan="2">
                                        <telerik:RadTextBox ID="txtcomments" Runat="server" Height="70px" 
                                            Skin="Office2007" Width="400px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="lblproposer" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        <telerik:RadButton ID="RadButton1" runat="server" Text="Update ">
                                        </telerik:RadButton>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#333333" colspan="4">
                                        <asp:Label ID="Label135" runat="server" 
                                            style="font-weight: 700; color: #FFFFFF;" Text="Print"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        <telerik:RadButton ID="BTNprint0" runat="server" Skin="Simple" 
                                            Text="Export List">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 151px; height: 11px;">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        <telerik:RadButton ID="BTNprint" runat="server" Skin="Simple" 
                                            Text="Print Schedule">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 11px;" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>

