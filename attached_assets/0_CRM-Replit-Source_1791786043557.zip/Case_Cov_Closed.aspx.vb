﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False



    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           
            dtreopen.DbSelectedDate = Date.Now()



            LoadGrid_M()

        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            lblno.Text = ""
            lblcode.Text = ""
            lblprov.Text = ""
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
        
            If cbosearch.SelectedValue = "M" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Member_No='" & Trim(txtsearch.Text) & "' AND R.Claim_Type='IP' and R.Case_Status='Closed'"
            ElseIf cbosearch.SelectedValue = "C" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Case_No='" & Trim(txtsearch.Text) & "'  AND R.Claim_Type='IP' and R.Case_Status='Closed'"
            ElseIf cbosearch.SelectedValue = "P" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE P.ORG_NAME LIKE '%" & Trim(txtsearch.Text) & "%'  AND R.Claim_Type='IP' and R.Case_Status='Closed'"
            ElseIf cbosearch.SelectedValue = "N" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Member_Name LIKE '%" & Trim(txtsearch.Text) & "%'  AND R.Claim_Type='IP' and R.Case_Status='Closed'"

            End If
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE.DataSource = MyDatable
                GDCASE.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDCASE.DataSource = Nothing
                GDCASE.DataBind()

            End If
            loadGrid(txtsearch.Text)
        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub

    
    Public Sub LoadGrid_M()
        Str = "SELECT R.Case_No, R.Admission_Dt,R.Admission_Status,R.Claim_No, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE  R.Case_Status='Closed'  AND R.Claim_Type='IP' order by R.Case_No  desc"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCASE.DataSource = MyDatable
            GDCASE.DataBind()
            Session("DAD0_T") = MyDatable
            MyDatable = Nothing
        Else
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
        End If

     
    End Sub
    Public Sub loadGrid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
    
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
     
        Try

            'Notes
            SqlAction = ""
            SqlAction = "SELECT [Note_id],[Note_Type],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_NOTES] WHERE  Member_No ='" & STR & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDCASE_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCASE.SelectedIndexChanged
        Try
            lblno.Text = ""
            lblcode.Text = ""

            lbldp.Text = ""
          
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            lblcode.Text = (DirectCast(GDCASE.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_No").ToString()
            Str = "SELECT [Case_No] ,Claim_No, [Member_No],Transfer_To_Provider,[Pre_Auth_Amt],[Total_Actual_Cost]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Case_No='" & Trim(lblcode.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                lblprov.Text = MyDatable.Rows(0).Item("Transfer_To_Provider").ToString()
               
                lbldp.Text = MyDatable.Rows(0).Item("Claim_No").ToString()
                loadGrid(lblno.Text)
            End If

        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub


    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDCASE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDCASE.PageIndexChanged
        GDCASE.CurrentPageIndex = e.NewPageIndex
        GDCASE.DataSource = Session("DAD0_T")
        GDCASE.DataBind()
    End Sub
 


    Protected Sub RadButton1_Click1(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            If lblcode.Text = "" Then
                lblerrreop.Text = "You Must select the Case to Reopen"
                Exit Sub
            End If

            If txtclosenote.Text = "" Then
                lblerrreop.Text = "You Must Enter Short Notes"
                Exit Sub
            End If

            If txtclosenote.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(lblno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtclosenote.Text, "ADM-NOTES")
            End If
            UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET [Re_Opened]=1,[Case_Status]='" & cboreopen.SelectedValue & "', [Re_Opened_By]='" & Session("username") & "',[Re_Open_Dt]='" & CDate(dtreopen.DbSelectedDate).ToString("yyyy-MM-dd") & "' where [Case_No]='" & lblcode.Text & "'")


            lblerrreop.Text = "Case updated successfull."
            txtclosenote.Text = ""

            cboreopen.Text = ""
            cboreopen.SelectedValue = ""
            dtreopen.DbSelectedDate = Date.Now()
            LoadGrid_M()
            loadGrid(lblno.Text)

        Catch ex As Exception
            lblerrreop.Text = ex.Message
        End Try
    End Sub

 
End Class
