﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Reimbursement_Processing.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" style="height: 40px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="PROCESSING"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1200px">
                            <table style="width: 97%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" 
                                            Text="Reimbursement Claims"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                            SortExpression="File_No" UniqueName="File_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_No" 
                                                            FilterControlAltText="Filter Invoice_No column" HeaderText="Invoice_No" 
                                                            SortExpression="Invoice_No" UniqueName="Invoice_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_Amt" 
                                                            DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Invoice_Amt column" HeaderText="Invoice_Amt" 
                                                            SortExpression="Invoice_Amt" UniqueName="Invoice_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                            SortExpression="Member_Name" UniqueName="Member_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Claim_Type" 
                                                            FilterControlAltText="Filter Claim_Type column" HeaderText="Claim_Type" 
                                                            SortExpression="Claim_Type" UniqueName="Claim_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Inv_Status" 
                                                            FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
                                                            SortExpression="Inv_Status" UniqueName="Inv_Status">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 242px">
                                        <asp:Label ID="Label102" runat="server" Text="Receive Date"></asp:Label>
                                    </td>
                                    <td style="width: 83px">
                                        <telerik:RadDatePicker ID="dtreceive" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label128" runat="server" Text="Service Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtservice" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 242px">
                                        <asp:Label ID="Label130" runat="server" Text="Reimb Type"></asp:Label>
                                    </td>
                                    <td style="width: 83px">
                                        <telerik:RadComboBox ID="cbotype" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Sunset" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="IP" Value="IP" />
                                                <telerik:RadComboBoxItem runat="server" Text="OP" Value="OP" />
                                                <telerik:RadComboBoxItem runat="server" Text="Funeral" Value="Funeral" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label132" runat="server" Text="Reason"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadComboBox ID="cboreason" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 242px">
                                        <asp:Label ID="Label126" runat="server" Text="Member No."></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Sunset" Width="250px" 
                                            EmptyMessage="KE123456700">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label133" runat="server" Text="Corporate/Proposer "></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 242px">
                                        <asp:Label ID="Label131" runat="server" Text=" Member Name"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label134" runat="server" Text="Mobile No"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadNumericTextBox ID="txtmobile" Runat="server" Culture="en-US" 
                                            DataType="System.Int16" Skin="Simple" Value="0" Width="250px">
                                            <NumberFormat DecimalDigits="0" GroupSeparator="" />
                                        </telerik:RadNumericTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 242px">
                                        <asp:Label ID="Label105" runat="server" Text="Invoice No"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtinv_no" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label135" runat="server" Text="e-Mail"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 242px">
                                        <asp:Label ID="Label106" runat="server" Text="Invoice Amt"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txtinv_amt" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label148" runat="server" Text="File Number"></asp:Label>
                                    </td>
                                    <td rowspan="2">
                                        <asp:Label ID="lblfile" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 242px">
                                        <asp:Label ID="Label151" runat="server" Text="Bar code"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtbarcode" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label150" runat="server" Text="Entered By"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;<asp:Label ID="lblenteredby" runat="server"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr style="width: 1120px" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel2" runat="server" Width="1176px" Height="100%">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label147" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="100%">
                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                            SortExpression="DOC_ID">
                                                                            <ItemTemplate>
                                                                                <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                    CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                            </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                                    
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                            ScrollBars="Horizontal" Width="1100px">
                                                            <asp:Literal ID="ltEmbed" runat="server" />
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 13px; width: 242px;">
                                        <asp:Label ID="Label153" runat="server" Text="Decline/Rejection "></asp:Label>
                                    </td>
                                    <td style="height: 13px">
                                        <telerik:RadComboBox ID="cbodoc" Runat="server" MarkFirstMatch="True" 
                                            Skin="Sunset" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 166px; height: 13px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 13px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 13px; width: 242px;">
                                        &nbsp;</td>
                                    <td style="height: 13px">
                                        <asp:FileUpload ID="FL2" runat="server" Width="330px" />
                                    </td>
                                    <td class="style8" style="width: 166px; height: 13px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 13px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 13px; width: 242px;">
                                        &nbsp;</td>
                                    <td style="height: 13px">
                                        <telerik:RadButton ID="btnupload_1" runat="server" Skin="Simple" Text="Upload">
                                        </telerik:RadButton>
                                        <asp:Label ID="LBLUPLOAD" runat="server"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 166px; height: 13px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 13px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4" style="height: 39px">
                                        <hr />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 23px; width: 242px;">
                                        <asp:Label ID="Label154" runat="server" Text="RC No/Mtiba No."></asp:Label>
                                    </td>
                                    <td class="style8" style="height: 23px">
                                        <telerik:RadTextBox ID="txtrcno" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" colspan="2" style="height: 23px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 23px; width: 242px;">
                                        <asp:Label ID="Label152" runat="server" Text="Payable Amt"></asp:Label>
                                    </td>
                                    <td class="style8" style="height: 23px">
                                        <telerik:RadNumericTextBox ID="txtpayable" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" colspan="2" style="height: 23px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 23px; width: 242px;">
                                        <asp:Label ID="Label149" runat="server" style="font-weight: 700" Text="Action"></asp:Label>
                                    </td>
                                    <td class="style8" style="height: 23px">
                                        <telerik:RadComboBox ID="cboaction" Runat="server" Skin="Simple">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cboaction" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboaction" 
                                                    Text="Approved-Full Pay" Value="AF" />
                                                <telerik:RadComboBoxItem runat="server" Text="Approved-Part Pay" Value="AP" />
                                                <telerik:RadComboBoxItem runat="server" Text="Declined" Value="D" />
                                                <telerik:RadComboBoxItem runat="server" Text="Return Incomplete" Value="RI" />
                                                <telerik:RadComboBoxItem runat="server" Text="Membership Issue" Value="MI" />
                                                <telerik:RadComboBoxItem runat="server" Text="Return DPU" Value="DPU" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="height: 23px;">
                                        <asp:Label ID="Label155" runat="server" style="font-weight: 700" 
                                            Text="Membership user"></asp:Label>
                                    </td>
                                    <td class="style8" style="height: 23px;">
                                        <telerik:RadComboBox ID="cbomship" Runat="server" AllowCustomText="True" 
                                            AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbomship" Text="RM Name" 
                                                    Value="R" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbomship" Text="Date Range" 
                                                    Value="D" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 23px; width: 242px;">
                                        <asp:Label ID="Label121" runat="server" style="font-weight: 700" 
                                            Text="Comments"></asp:Label>
                                    </td>
                                    <td class="style8" rowspan="2">
                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="70px" Rows="1" 
                                            Skin="Sunset" TextMode="MultiLine" Width="450px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" colspan="2" style="height: 23px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 23px; width: 242px;">
                                        &nbsp;</td>
                                    <td class="style8" colspan="2" style="height: 23px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 39px; width: 242px;">
                                        &nbsp;</td>
                                    <td class="style8" style="height: 39px;">
                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Submit" 
                                            Width="150px">
                                        </telerik:RadButton>
                                    </td>
                                    <td class="style8" style="height: 39px;" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1100px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload_1" />
          </Triggers>
    </asp:UpdatePanel>
</asp:Content>
