﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim emp_code As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0

                Str = "SELECT [Depart_Code],[Department] FROM [AAR_RISK_DB].[dbo].[TBL_MIS_RISK_DEPART]" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbodepart
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Department").ToString
                    .DataValueField = MyDatatable.Columns("Depart_Code").ToString
                    .DataBind()
                End With

                Str = "SELECT [Issue_Code],[Issue_Name]  FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] WHERE ACTIVE=1"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbissue
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Issue_Name").ToString
                    .DataValueField = MyDatatable.Columns("Issue_Code").ToString
                    .DataBind()
                End With
           

                load_grid()


                Session("empcode") = Nothing
                Session("agentemail") = Nothing

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub

    Public Sub load_grid()
        GD_DUE.DataSource = Nothing
        GD_DUE.DataBind()
        GD_OPEN.DataSource = Nothing
        GD_OPEN.DataBind()
        GD_RESOLVED.DataSource = Nothing
        GD_RESOLVED.DataBind()
        GD_CLOSED.DataSource = Nothing
        GD_CLOSED.DataBind()

        SqlAction = "SELECT  t.Due_Dt , t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where  t.[Status]='OPEN' and DATEDIFF(HOUR,due_dt,Date_of_Resolution)>0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_DUE.DataSource = MyDatable
            GD_DUE.DataBind()
            Session("GD_DUE") = MyDatable
            MyDatable = Nothing
        Else
            GD_DUE.DataSource = Nothing
            GD_DUE.DataBind()
        End If

        SqlAction = "SELECT t.Over_Due,  t.Due_Dt , t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where  t.[Status]='OPEN'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_OPEN.DataSource = MyDatable
            GD_OPEN.DataBind()
            Session("GD_OPEN") = MyDatable
            MyDatable = Nothing
        Else
            GD_OPEN.DataSource = Nothing
            GD_OPEN.DataBind()
        End If

        SqlAction = " SELECT t.Due_Dt , t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where  t.[Status]='RESOLVED'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_RESOLVED.DataSource = MyDatable
            GD_RESOLVED.DataBind()
            Session("GD_RESOLVED") = MyDatable
            MyDatable = Nothing
        Else
            GD_RESOLVED.DataSource = Nothing
            GD_RESOLVED.DataBind()
        End If
        SqlAction = " SELECT t.Due_Dt , t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where  t.[Status]='CLOSED'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_CLOSED.DataSource = MyDatable
            GD_CLOSED.DataBind()
            Session("GD_CLOSED") = MyDatable
            MyDatable = Nothing
        Else
            GD_CLOSED.DataSource = Nothing
            GD_CLOSED.DataBind()
        End If
    End Sub
    Public Sub Notes(ByVal STR As String)

        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        GD_DOCS.DataSource = Nothing
        GD_DOCS.DataBind()

        MyDatable = Nothing
        SqlAction = "SELECT [DOC_ID],[Ref_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_COMPLAIN_DOCS] WHERE  [Ref_No] ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
            MyDatable = Nothing
        Else
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
        End If

        SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINTS_NOTES] WHERE  case_No ='" & STR & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If



    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try

            GD_DUE.DataSource = Nothing
            GD_DUE.DataBind()

            SqlAction = "SELECT t.Due_Dt , t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where t.[Case_no]='" & txtsearch.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DUE.DataSource = MyDatable
                GD_DUE.DataBind()
                MyDatable = Nothing
            Else
                GD_DUE.DataSource = Nothing
                GD_DUE.DataBind()
            End If

            'SqlAction = " SELECT  t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where t.[Case_no]='" & txtsearch.Text & "'"
            'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatable.Rows.Count > 0 Then
            '    GD_OPEN.DataSource = MyDatable
            '    GD_OPEN.DataBind()
            '    MyDatable = Nothing
            'Else
            '    GD_OPEN.DataSource = Nothing
            '    GD_OPEN.DataBind()
            'End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "CLIENT COMPLAINT ESCALATION" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "CLIENT COMPLAINT ESCALATIONest:-" & lblcode.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear:, " & lblesc.Text & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Case No:" & lblcode.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Description--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtdescr.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function



    Protected Sub GD_OPEN_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_OPEN.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            Session("FAMILY_NO") = Nothing
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            ltEmbed.Text = ""
            lblcode.Text = (DirectCast(GD_OPEN.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_no").ToString()
            SqlAction = "SELECT  [Case_no] ,[Summary_of_issue],[Action_Taken],Department,Description  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] where [Case_no]='" & lblcode.Text & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                cbodepart.SelectedValue = MyDatatable.Rows(0).Item("Department").ToString()
                cbissue.SelectedValue = MyDatatable.Rows(0).Item("Summary_of_issue").ToString()
                txtdescr.Text = MyDatatable.Rows(0).Item("Description").ToString()
                cboaction.SelectedValue = MyDatatable.Rows(0).Item("Action_Taken").ToString()
                txtdescr.Enabled = False
                Notes(lblcode.Text)

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GD_RESOLVED_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_RESOLVED.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            Session("FAMILY_NO") = Nothing
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            ltEmbed.Text = ""
            lblcode.Text = (DirectCast(GD_RESOLVED.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_no").ToString()
            SqlAction = "SELECT  [Case_no] ,[Summary_of_issue],[Action_Taken],Department,Description  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] where [Case_no]='" & lblcode.Text & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                cbodepart.SelectedValue = MyDatatable.Rows(0).Item("Department").ToString()
                cbissue.SelectedValue = MyDatatable.Rows(0).Item("Summary_of_issue").ToString()
                txtdescr.Text = MyDatatable.Rows(0).Item("Description").ToString()
                cboaction.SelectedValue = MyDatatable.Rows(0).Item("Action_Taken").ToString()
                txtdescr.Enabled = False
                Notes(lblcode.Text)

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/Complains.ashx?Id="), id)
    End Sub
 
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDCOMPL0_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_DUE.PageIndexChanged
        GD_DUE.CurrentPageIndex = e.NewPageIndex
        GD_DUE.DataSource = Session("GD_DUE")
        GD_DUE.DataBind()
    End Sub
    Protected Sub GD_OPEN_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_OPEN.PageIndexChanged
        GD_OPEN.CurrentPageIndex = e.NewPageIndex
        GD_OPEN.DataSource = Session("GD_OPEN")
        GD_OPEN.DataBind()
    End Sub
    Protected Sub GD_RESOLVED_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_RESOLVED.PageIndexChanged
        GD_RESOLVED.CurrentPageIndex = e.NewPageIndex
        GD_RESOLVED.DataSource = Session("GD_RESOLVED")
        GD_RESOLVED.DataBind()
    End Sub

    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Try
            Try
                Dim adm_status As String = ""
                Dim case_status As String = ""
                HiddenField1.Value = 0
                If lblcode.Text = "" Then
                    lblerr.Text = "Select case No"
                    Exit Sub
                End If
                If txtcomment.Text = "" Then
                    lblerr.Text = "You Must enter notes!"
                    Exit Sub

                End If

                If cboaction.SelectedValue = "R" Then
                    UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] SET Action_Taken='Escalated',Status='OPEN',Re_Open=1,Re_Open_dt='" & CDate(Date.Now()).ToString("yyyy-MM-dd hh:mm") & "'  where [Case_No]='" & lblcode.Text & "'")
                    UpdateRecord("UPDATE [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] SET [Status]='Escalated'  where [Case_No]='" & lblcode.Text & "' and [Status]='Resolved'")

                    Session("cc_email") = Nothing
                    Session("email") = Nothing
                    Str = "SELECT TOP 1 NAME,EMAIL FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] WHERE Case_No='" & lblcode.Text & "' AND [Status]='Escalated'" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    If MyDatatable.Rows.Count > 0 Then
                        Session("EMAIL") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                        lblesc.Text = MyDatatable.Rows(0).Item("NAME").ToString()
                    End If
                    Session("msg") = "Kindly note the below concern that has been RE-OPENED due to the below reasons."
                    'Session("email") = Trim(txtescaemail.Text)

                    'Session("cc_email") = "jmwaniki@aar.co.ke"
                    Session("Header") = "CLIENT COMPLAINT/ENQUIRY ESCALATION"

                    lblerr.Text = "Saved Successfully.."


                ElseIf cboaction.SelectedValue = "C" Then
                    UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] SET Action_Taken='CLOSED',Status='CLOSED',Date_closed='" & CDate(Date.Now()).ToString("yyyy-MM-dd hh:mm") & "'  where [Case_No]='" & lblcode.Text & "'")
                    UpdateRecord("UPDATE [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] SET [Status]='CLOSED'  where [Case_No]='" & lblcode.Text & "' and [Status]='Resolved'")

                    Session("cc_email") = Nothing
                    Session("email") = Nothing
                    Str = "SELECT TOP 1 NAME,EMAIL FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] WHERE Case_No='" & lblcode.Text & "' AND [Status]='Escalated'" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    If MyDatatable.Rows.Count > 0 Then
                        Session("EMAIL") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                        lblesc.Text = MyDatatable.Rows(0).Item("NAME").ToString()
                    End If
                    Session("msg") = "Kindly note the below concern that has been CLOSED."
                    'Session("email") = Trim(txtescaemail.Text)

                    'Session("cc_email") = "jmwaniki@aar.co.ke"
                    Session("Header") = "CLIENT COMPLAINT/ENQUIRY ESCALATION"
                    lblerr.Text = "Saved Successfully.."

                End If

                MyDBAction.TASK_MESSAGES_COMPLAIN(lblcode.Text, txtcomment.Text, Session("username"), Date.Now(), "COMPLAINTS/QUERY", Session("FAMILY_NO"))
                MailSent = SendLoginDetails(lblesc.Text, Session("email"), "")

                load_grid()

                HiddenField1.Value = 0
                lblcode.Text = ""
                txtdescr.Text = ""


                ltEmbed.Text = ""
                txtcomment.Text = ""

                lblcode.Enabled = True
                txtdescr.Enabled = True





            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GD_OPEN_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GD_OPEN.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then

            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("Over_Due")
            If myCell.Text = 1 Then
                dataItem.BackColor = Drawing.Color.Red
            End If


        End If
    End Sub

    Protected Sub btnupload0_Click(sender As Object, e As System.EventArgs) Handles btnupload0.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String

            If cboreport.SelectedValue = "A" Then
                SqlAction = "SELECT C.[Case_no] ,C.[Date_Received] ,C.[Time_Received],C.[Mode_of_Receipt],C.[Received_By],C.[Membership_No],C.[Customer_Name],C.[Customer_Type],C.[Contacts],C.[Email],C.[Complain_Type],A.SUB_AREA,C.[Action_Taken],C.[Escalated_To],C.due_dt, C.[Date_of_Resolution],C.[Member_ack],C.[Date_closed],C.[Entered_By],C.[Updated_By],C.[Update_Date],DATEDIFF(HOUR,C.Date_Received,C.Date_of_Resolution) [TAT] FROM   CRM.dbo.TBL_MIS_COMPLAINT_TRACKING C LEFT JOIN CRM.dbo.TBL_MIS_CRM_COMPLAINT_AREA A ON C.Summary_of_issue = A.CODE where convert(date,C.date_received) between '" & CDate(dtFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY case_no asc"
                Reportname = cboreport.Text
            Else
                SqlAction = "SELECT C.[Case_no] ,C.[Date_Received] ,C.[Time_Received],C.[Mode_of_Receipt],C.[Received_By],C.[Membership_No],C.[Customer_Name],C.[Customer_Type],C.[Contacts],C.[Email],C.[Complain_Type],A.SUB_AREA,C.[Action_Taken],C.[Escalated_To],C.due_dt,C.[Date_of_Resolution],C.[Member_ack],C.[Date_closed],C.[Entered_By],C.[Updated_By],C.[Update_Date],DATEDIFF(HOUR,C.Date_Received,C.Date_of_Resolution) [TAT] FROM   CRM.dbo.TBL_MIS_COMPLAINT_TRACKING C LEFT JOIN CRM.dbo.TBL_MIS_CRM_COMPLAINT_AREA A ON C.Summary_of_issue = A.CODE WHERE C.Action_Taken='" & cboreport.SelectedValue & "'  and   convert(date,C.date_received) between '" & CDate(dtFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
                Reportname = cboreport.Text
            End If
            Session("EXCEL") = "TO EXCEL"
            Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
            'Reportname = ""
        Catch ex As Exception

        End Try
    End Sub
End Class
