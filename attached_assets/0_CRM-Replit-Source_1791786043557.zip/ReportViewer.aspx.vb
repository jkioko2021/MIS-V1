﻿Imports System
Imports System.Collections
Imports System.Configuration
Imports System.Data
Imports System.Data.Odbc
Imports System.Data.SqlClient
Imports System.IO
Imports System.Web.Configuration
Imports System.Windows.Forms
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.[Shared]
Imports DocManage
Imports iTextSharp.text
'Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports Microsoft.Office.Interop
Imports Microsoft.VisualBasic
Imports Telerik.Web.UI




Partial Class ReportViewer
    Inherits System.Web.UI.Page


    '============================================================
    ' EXISTING OBJECTS
    '============================================================

    Dim MyDbAction As New DataManagement

    Dim rpt As ReportDocument = Nothing

    Dim tbs As Tables = Nothing
    Dim tb As Table = Nothing
    Dim s As MemoryStream
    Dim cInfo As New ConnectionInfo

    Dim Reportpath As String = ""
    Dim Reportname As String = ""

    Private MyReportViewing As ReportDocument


    '============================================================
    ' PAGE INIT
    '============================================================

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        Try

            Dim requestedReport As String = ""

            '----------------------------------------------------
            ' First check QueryString
            '----------------------------------------------------

            If Request.QueryString("Reportname") IsNot Nothing Then

                requestedReport =
                    Request.QueryString("Reportname").ToString().Trim()

            ElseIf Session("Reportname") IsNot Nothing Then

                requestedReport =
                    Session("Reportname").ToString().Trim()

            End If


            '----------------------------------------------------
            ' RENEWAL ADVICE
            '----------------------------------------------------

            If requestedReport.ToUpper() = "RENEWAL_ADVICE" Then

                ShowRenewalAdvice()

            Else

                '------------------------------------------------
                ' EXISTING REPORT ENGINE
                '------------------------------------------------

                ShowReport()

            End If


            '====================================================
            ' IMPORTANT
            '
            ' DO NOT CLOSE OR DISPOSE THE REPORT HERE.
            '
            ' The report may still be required by the viewer
            ' and PDF export.
            '
            ' Cleanup is handled in Page_Unload().
            '====================================================


        Catch ex As Exception

            LblErr.Text =
                "Error loading report: " &
                ex.Message

            Panel3.Visible = True

            MyDbAction.DoLogs(
                "Class==ReportViewer.vb: Page_Init()" &
                " : Error : " &
                ex.ToString())

        End Try

    End Sub


    '============================================================
    ' PAGE LOAD
    '============================================================

    Protected Sub Page_Load(
        ByVal sender As Object,
        ByVal e As System.EventArgs) Handles Me.Load

        '--------------------------------------------------------
        ' Do not reload Crystal Report here.
        '
        ' Crystal Report is loaded during Page_Init.
        '--------------------------------------------------------

    End Sub


    '============================================================
    ' EXISTING REPORT ENGINE
    '============================================================

    Private Sub ShowReport()

        Try

            Dim EnctryptionAlgorith As String = "rijndael"

            Dim CryptographyFactory As New DocManagementSecurity.CryptoFactory()

            Dim Cryptographer As DocManagementSecurity.ICrypto =
                CryptographyFactory.MakeCryptographer(
                    EnctryptionAlgorith)

            Dim s As MemoryStream

            Dim DecryptedStr As String =
                Cryptographer.Decrypt(
                    WebConfigurationManager.
                    ConnectionStrings("CRM").
                    ConnectionString)


            If Session("Reportname") Is Nothing Then
                Exit Sub
            End If


            '====================================================
            ' EXCEL EXPORT
            '====================================================

            If Session("EXCEL") IsNot Nothing Then

                ExporttoExcel(
                    Session("Mytable"),
                    Session("Reportname"))

                Exit Sub

            End If


            '====================================================
            ' INITIALIZE REPORT
            '====================================================

            CrystalReportViewer1.ReportSource = Nothing


            Reportname =
                Session("Reportname").ToString()


            Session("ReportTitle") =
                Reportname


            Session("Company") =
                "AAR INSURANCE"


            '====================================================
            ' REPORT PATH
            '====================================================

            Reportpath =
                Server.MapPath("~\Reports") &
                "\" &
                Reportname &
                ".rpt"


            If Not File.Exists(Reportpath) Then

                Throw New Exception(
                    "Report file not found: " &
                    Reportpath)

            End If


            '====================================================
            ' LOAD REPORT
            '====================================================

            rpt = New ReportDocument()

            rpt.Load(Reportpath)


            '====================================================
            ' EXISTING DATA SOURCE
            '====================================================

            If Session("Mytable") IsNot Nothing Then

                rpt.SetDataSource(
                    Session("Mytable"))

            End If


            '====================================================
            ' DATABASE CONNECTION
            '====================================================

            cInfo = GetReportConnectionInfo()


            tbs =
                rpt.Database.Tables


            For Each tb In tbs

                ApplyTableConnection(
                    tb,
                    cInfo)

            Next


            '====================================================
            ' FORMULA FIELDS
            '====================================================

            If Session("ReportTitle") IsNot Nothing Then

                SetFormulaIfExists(
                    rpt,
                    "ReportTitle",
                    Session("ReportTitle").ToString())

            End If


            If Session("Company") IsNot Nothing Then

                SetFormulaIfExists(
                    rpt,
                    "Company",
                    Session("Company").ToString())

            End If


            If Session("FrmDT") IsNot Nothing AndAlso
               Session("ToDt") IsNot Nothing Then

                SetFormulaIfExists(
                    rpt,
                    "FrmDT",
                    Session("FrmDT").ToString())

                SetFormulaIfExists(
                    rpt,
                    "ToDt",
                    Session("ToDt").ToString())

            End If


            '====================================================
            ' DISPLAY
            '====================================================

            CrystalReportViewer1.ReportSource = rpt

            CrystalReportViewer1.DataBind()


            '====================================================
            ' PDF
            '====================================================

            If Session("PRINT") IsNot Nothing Then

                If Session("PRINT").ToString().
                    ToUpper() = "PDF" Then

                    s = rpt.ExportToStream(ExportFormatType.PortableDocFormat)


                    Response.ClearContent()
                    Response.ClearHeaders()

                    Response.ContentType =
                        "application/pdf"

                    Response.AddHeader(
                        "Content-Disposition",
                        "inline; filename='" &
                        Session("Reportname").ToString() &
                        "'.pdf")


                    Response.BinaryWrite(
                        s.ToArray())

                    Response.Flush()

                End If

            End If


        Catch ex As Exception

            LblErr.Text =
                ex.Message.ToString()

            Panel3.Visible = True

            MyDbAction.DoLogs(
                "Class==ReportViewer.vb: Private Sub ShowReport()" &
                " : Error : " &
                ex.ToString())

        End Try

    End Sub


    '============================================================
    ' RENEWAL ADVICE
    '============================================================



    Private Sub ShowRenewalAdvice()

        Try


            Dim policyCode As String = ""

            '====================================================
            ' GET POLICY CODE
            '====================================================

            If Request.QueryString("PolicyCode") IsNot Nothing Then

                policyCode =
                Request.QueryString("PolicyCode").
                ToString().
                Trim()

            ElseIf Session("PolicyCode") IsNot Nothing Then

                policyCode =
                Session("PolicyCode").
                ToString().
                Trim()

            End If


            '====================================================
            ' VALIDATE POLICY CODE
            '====================================================

            If String.IsNullOrWhiteSpace(policyCode) Then

                Throw New Exception(
                "Policy Code is required to generate Renewal Advice.")

            End If
            '====================================================
            ' CLEAR EXISTING REPORT
            '====================================================

            CrystalReportViewer1.ReportSource = Nothing
            '====================================================
            ' REPORT INFORMATION
            '====================================================

            Reportname = "RENEWAL_ADVICE"
            Reportname = Session("Reportname")
            Session("ReportTitle") = Reportname
            Session("Company") = "AAR INSURANCE"
            Reportpath = Server.MapPath("~\Reports") & "\" & Reportname & ".rpt"

            If Not File.Exists(Reportpath) Then

                Throw New Exception(
                "Renewal Advice report not found: " &
                Reportpath)

            End If



            '====================================================
            ' CREATE REPORT
            '====================================================

            rpt = New ReportDocument()

            rpt.Load(Reportpath)


            '====================================================
            ' GET DATABASE CONNECTION
            '====================================================

            cInfo = GetReportConnectionInfo()


            '====================================================
            ' APPLY DATABASE CONNECTION TO MAIN REPORT
            '====================================================

            ApplyReportConnection(
            rpt,
            cInfo)


            '====================================================
            ' APPLY DATABASE CONNECTION TO SUBREPORTS
            '====================================================

            ApplySubreportConnections(
            rpt,
            cInfo)


            '====================================================
            ' APPLY POLICY CODE PARAMETER
            '====================================================

            Dim parameterApplied As Boolean = False


            Try

                rpt.SetParameterValue("pPolicyCode", policyCode)

                parameterApplied = True

            Catch

                parameterApplied = False

            End Try


            '====================================================
            ' FALLBACK RECORD SELECTION
            '
            ' IMPORTANT:
            ' The Crystal report must use:
            '
            ' VW_RENEWAL_ADVICE_HEADER
            '
            ' NOT:
            '
            ' TBL_RenewalAdvice_Header
            '====================================================

            If Session("ReportTitle") IsNot Nothing Then
                rpt.DataDefinition.FormulaFields("ReportTitle").Text = "'" & Session("ReportTitle") & "'"
            End If
            If Session("Company") IsNot Nothing Then
                rpt.DataDefinition.FormulaFields("Company").Text = "'" & Session("Company") & "'"
            End If

            If Session("FrmDT") IsNot Nothing And Session("ToDt") IsNot Nothing Then
                rpt.DataDefinition.FormulaFields("FrmDT").Text = "'" & Session("FrmDT") & "'"
                rpt.DataDefinition.FormulaFields("ToDt").Text = "'" & Session("ToDt") & "'"
            End If
            CrystalReportViewer1.ReportSource = rpt
            s = rpt.ExportToStream(ExportFormatType.PortableDocFormat)



            'If Session("PRINT") = "PDF" Then
            '    HttpContext.Current.Response.ClearContent()
            '    HttpContext.Current.Response.ClearHeaders()
            '    HttpContext.Current.Response.ContentType = "application/pdf"
            '    HttpContext.Current.Response.AddHeader("Content-Disposition", "inline; filename='" & Session("Reportname") & "'.pdf")
            '    HttpContext.Current.Response.BinaryWrite(s.ToArray())
            '    'HttpContext.Current.Response.End()
            'End If


            'CrystalReportViewer1.ReportSource = Nothing
            'rpt.Database.Dispose()
            'rpt.Refresh()
            'rpt.Close()
            'rpt.Dispose()

            ''rpt.Close()

            ''Session("ReportTitle") = Nothing
            'Session("SelectionFormula") = Nothing
            'Session("EXCEL") = Nothing
            'Session("Reportname") = Nothing
            'Session("PRINT") = Nothing


            ''====================================================
            '' REPORT FORMULAS
            ''====================================================

            'SetFormulaIfExists(rpt, "ReportTitle", "RENEWAL ADVICE")


            'SetFormulaIfExists(
            'rpt,
            '"Company",
            '"AAR INSURANCE")


            ''====================================================
            '' SAVE SESSION VALUES
            ''====================================================

            'Session("PolicyCode") =
            'policyCode

            'Session("Reportname") =
            '"RENEWAL_ADVICE"

            'Session("ReportTitle") =
            '"RENEWAL ADVICE"

            'Session("Company") =
            '"AAR INSURANCE"


            ''====================================================
            '' DISPLAY REPORT
            ''====================================================

            'CrystalReportViewer1.ReportSource =
            'rpt

            'CrystalReportViewer1.DataBind()


            'ViewState("Show_Report") =
            '"True"


            ''====================================================
            '' PDF EXPORT
            ''====================================================

            'If Session("PRINT") IsNot Nothing Then

            '    If Session("PRINT").ToString().
            '    ToUpper() = "PDF" Then

            '        ExportRenewalAdvicePDF(
            '        rpt,
            '        policyCode)

            '    End If

            'End If

            '===========================================================
            ' SET REPORT FORMULA FIELDS
            '===========================================================

            'If Session("ReportTitle") IsNot Nothing Then
            '    rpt.DataDefinition.FormulaFields("ReportTitle").Text = "'" & Session("ReportTitle").ToString() & "'"
            'End If

            'If Session("Company") IsNot Nothing Then
            '    rpt.DataDefinition.FormulaFields("Company").Text = "'" & Session("Company").ToString() & "'"
            'End If

            'If Session("FrmDT") IsNot Nothing AndAlso
            'Session("ToDt") IsNot Nothing Then

            '    rpt.DataDefinition.FormulaFields("FrmDT").Text = "'" & Session("FrmDT").ToString() & "'"

            '    rpt.DataDefinition.FormulaFields("ToDt").Text = "'" & Session("ToDt").ToString() & "'"
            'End If


            ''===========================================================
            '' DISPLAY REPORT
            ''===========================================================

            'CrystalReportViewer1.ReportSource = rpt


            ''===========================================================
            '' EXPORT REPORT TO PDF
            ''===========================================================



            If Session("PRINT") IsNot Nothing AndAlso
                   Session("PRINT").ToString().ToUpper() = "PDF" Then

                Dim tempFolder As String = Server.MapPath("~\TempReports") & ""
                Dim crystalPdf As String = Path.Combine(tempFolder, "RENEWAL_ADVICE.pdf")
                Dim finalPdf As String = Path.Combine(tempFolder, "RENEWAL_ADVICE_EDITABLE.pdf")

                '===========================================================
                ' CREATE FOLDER
                '===========================================================

                If Not Directory.Exists(tempFolder) Then
                    Directory.CreateDirectory(tempFolder)
                End If

                '===========================================================
                ' DELETE OLD FILES
                '===========================================================

                If File.Exists(crystalPdf) Then
                    File.Delete(crystalPdf)
                End If

                If File.Exists(finalPdf) Then
                    File.Delete(finalPdf)
                End If

                '===========================================================
                ' EXPORT CRYSTAL REPORT
                '===========================================================

                rpt.ExportToDisk(
                    ExportFormatType.PortableDocFormat,
                    crystalPdf
                )

                '===========================================================
                ' VERIFY CRYSTAL PDF
                '===========================================================

                If Not File.Exists(crystalPdf) Then

                    Throw New Exception(
                        "Crystal Reports failed to create the PDF." &
                        vbCrLf &
                        "Expected file: " & crystalPdf
                    )

                End If

                '===========================================================
                ' CREATE EDITABLE PDF
                '===========================================================

                MakeContactDetailsFillable(crystalPdf, finalPdf)

                '===========================================================
                ' VERIFY EDITABLE PDF
                '===========================================================

                If Not File.Exists(finalPdf) Then

                    Throw New Exception(
                        "MakePdfFillable completed but the editable PDF was not created." &
                        vbCrLf &
                        "Expected file: " & finalPdf
                    )

                End If

                '===========================================================
                ' SEND PDF TO BROWSER
                '===========================================================

                Dim pdfBytes As Byte() = File.ReadAllBytes(finalPdf)

                Response.Clear()
                Response.ClearHeaders()
                Response.ClearContent()

                Response.ContentType = "application/pdf"

                Response.AddHeader(
                    "Content-Disposition",
                    "inline; filename=RENEWAL_ADVICE_EDITABLE.pdf"
                )

                Response.AddHeader(
                    "Content-Length",
                    pdfBytes.Length.ToString()
                )

                Response.BinaryWrite(pdfBytes)
                Response.Flush()

                HttpContext.Current.ApplicationInstance.CompleteRequest()

            End If

        Catch ex As Exception

            Response.Clear()
            Response.ClearHeaders()
            Response.ContentType = "text/plain"

            Response.Write(
                "RENEWAL ADVICE PDF ERROR" &
                vbCrLf &
                "========================" &
                vbCrLf &
                vbCrLf &
                ex.ToString()
            )

            '    HttpContext.Current.ApplicationInstance.CompleteRequest()

        End Try

    End Sub




    '============================================================
    ' GET REPORT CONNECTION INFORMATION
    '============================================================

    Private Function GetReportConnectionInfo() _
        As ConnectionInfo

        Dim connectionInfo As New ConnectionInfo


        With connectionInfo

            .Type =
                ConnectionInfoType.SQL


            

            .ServerName = WebConfigurationManager.AppSettings("ReportServerName")
            .Password = WebConfigurationManager.AppSettings("ReportPassword")
            .UserID = WebConfigurationManager.AppSettings("ReportUsername")
            '.DatabaseName = cn.Database
            .DatabaseName = WebConfigurationManager.AppSettings("ReportdatbaseName")


        End With


        Return connectionInfo

    End Function


    '============================================================
    ' APPLY CONNECTION TO MAIN REPORT
    '============================================================

    Private Sub ApplyReportConnection(
        ByVal report As ReportDocument,
        ByVal connectionInfo As ConnectionInfo)

        Try

            For Each table As Table In
                report.Database.Tables

                ApplyTableConnection(
                    table,
                    connectionInfo)

            Next


        Catch ex As Exception

            Throw New Exception(
                "Unable to connect Renewal Advice to SQL Server: " &
                ex.Message,
                ex)

        End Try

    End Sub


    '============================================================
    ' APPLY CONNECTION TO TABLE
    '============================================================

    Private Sub ApplyTableConnection(
        ByVal table As Table,
        ByVal connectionInfo As ConnectionInfo)

        Dim logonInfo As TableLogOnInfo =
            table.LogOnInfo


        logonInfo.ConnectionInfo =
            connectionInfo


        table.ApplyLogOnInfo(
            logonInfo)


        '--------------------------------------------------------
        ' Force the table location to retain its original
        ' database/schema/table or view definition.
        '
        ' We intentionally do NOT replace the table name here.
        ' Crystal must use the datasource defined in the .rpt.
        '--------------------------------------------------------

    End Sub


    '============================================================
    ' APPLY CONNECTION TO SUBREPORTS
    '============================================================

    Private Sub ApplySubreportConnections(ByVal report As ReportDocument, ByVal connectionInfo As ConnectionInfo)

        Try

            For Each section As CrystalDecisions.CrystalReports.Engine.Section In report.ReportDefinition.Sections


                For Each obj As ReportObject In
                    section.ReportObjects


                    If obj.Kind =
                        ReportObjectKind.SubreportObject Then


                        Dim subReportObject As SubreportObject =
                            CType(
                                obj,
                                SubreportObject)


                        Dim subReport As ReportDocument =
                            subReportObject.OpenSubreport(
                                subReportObject.
                                SubreportName)


                        For Each table As Table In
                            subReport.Database.Tables


                            ApplyTableConnection(
                                table,
                                connectionInfo)


                        Next

                    End If

                Next

            Next


        Catch ex As Exception

            Throw New Exception(
                "Unable to connect Renewal Advice subreports to SQL Server: " &
                ex.Message,
                ex)

        End Try

    End Sub


    '============================================================
    ' SET FORMULA IF IT EXISTS
    '============================================================

    Private Sub SetFormulaIfExists(
        ByVal report As ReportDocument,
        ByVal formulaName As String,
        ByVal value As String)

        Try

            report.DataDefinition.
                FormulaFields(formulaName).
                Text =
                "'" &
                value.Replace("'", "''") &
                "'"


        Catch

            '----------------------------------------------------
            ' Formula does not exist.
            ' No action required.
            '----------------------------------------------------

        End Try

    End Sub


    '============================================================
    ' EXPORT RENEWAL ADVICE TO PDF
    '============================================================

    Private Sub ExportRenewalAdvicePDF(
        ByVal report As ReportDocument,
        ByVal policyCode As String)

        Dim stream As Stream = Nothing


        Try

            '====================================================
            ' EXPORT
            '====================================================

            stream =
                report.ExportToStream(
                    ExportFormatType.
                    PortableDocFormat)


            '====================================================
            ' RESPONSE
            '====================================================

            Response.Clear()
            Response.ClearHeaders()


            Response.ContentType =
                "application/pdf"


            '====================================================
            ' SAFE FILE NAME
            '====================================================

            Dim safePolicyCode As String =
                policyCode.Replace("/", "_").
                Replace("\", "_").
                Replace(":", "_").
                Replace("*", "_").
                Replace("?", "_").
                Replace("""", "_").
                Replace("<", "_").
                Replace(">", "_").
                Replace("|", "_")


            Response.AddHeader(
                "Content-Disposition",
                "inline; filename=RenewalAdvice_" &
                safePolicyCode &
                ".pdf")


            '====================================================
            ' WRITE PDF
            '====================================================

            stream.CopyTo(
                Response.OutputStream)


            Response.Flush()


        Catch ex As Exception

            Throw New Exception(
                "Unable to export Renewal Advice to PDF: " &
                ex.Message,
                ex)


        Finally

            If stream IsNot Nothing Then

                Try

                    stream.Dispose()

                Catch

                End Try

            End If

        End Try

    End Sub


    '============================================================
    ' EXCEL EXPORT
    '============================================================

    Private Sub ExporttoExcel(
        ByVal table As DataTable,
        ByVal FileName As String)

        Try

            Dim attachment As String =
                "attachment; filename=" &
                FileName &
                ".xls"


            Response.ClearContent()


            Response.AddHeader(
                "content-disposition",
                attachment)


            Response.ContentType =
                "application/vnd.ms-excel"


            Dim tab As String = ""


            For Each dc As DataColumn In
                table.Columns

                Response.Write(
                    tab +
                    dc.ColumnName)

                tab = vbTab

            Next


            Response.Write(
                vbLf)


            Dim i As Integer


            For Each dr As DataRow In
                table.Rows

                tab = ""


                For i = 0 To table.Columns.Count - 1

                    Response.Write(
                        tab &
                        dr(i).ToString())

                    tab = vbTab

                Next


                Response.Write(
                    vbLf)

            Next


            Response.End()


        Catch ex As Exception

            LblErr.Text =
                "Excel Export Error: " &
                ex.Message


            Panel3.Visible = True

        End Try

    End Sub


    '============================================================
    ' RELEASE COM OBJECT
    '============================================================

    Private Sub ReleaseObject(
        ByVal o As Object)

        Try

            While (
                System.Runtime.InteropServices.
                Marshal.ReleaseComObject(o) > 0)

            End While


        Catch

        Finally

            o = Nothing

        End Try

    End Sub


    '============================================================
    ' PAGE UNLOAD
    '============================================================

    Protected Sub Page_Unload(
        ByVal sender As Object,
        ByVal e As System.EventArgs) Handles Me.Unload

        Try

            '====================================================
            ' REMOVE REPORT FROM VIEWER
            '====================================================

            If CrystalReportViewer1 IsNot Nothing Then

                CrystalReportViewer1.ReportSource =
                    Nothing

            End If


            '====================================================
            ' CLOSE CRYSTAL REPORT
            '====================================================

            If rpt IsNot Nothing Then

                Try

                    rpt.Close()

                Catch

                End Try


                Try

                    rpt.Dispose()

                Catch

                End Try


                rpt = Nothing

            End If


        Catch

            '----------------------------------------------------
            ' Do not allow cleanup errors to affect response.
            '----------------------------------------------------

        End Try


        '========================================================
        ' EXISTING SESSION CLEANUP
        '========================================================

        Session("EXCEL") =
            Nothing


        Session("PRINT") = Nothing


        Session("Reportname") = Nothing

    End Sub
    Private Sub MakeContactDetailsFillable(ByVal inputPdf As String,
                                       ByVal outputPdf As String)

        Dim reader As PdfReader = Nothing
        Dim stamper As PdfStamper = Nothing

        Try

            ' Delete existing output file first
            If File.Exists(outputPdf) Then
                File.Delete(outputPdf)
            End If

            ' Open the Crystal Reports PDF
            reader = New PdfReader(inputPdf)

            ' Create the final PDF ONLY ONCE
            Using fs As New FileStream(
            outputPdf,
            FileMode.Create,
            FileAccess.Write,
            FileShare.None)

                stamper = New PdfStamper(reader, fs)

                ' Keep PDF form fields editable
                stamper.FormFlattening = False

                ' =====================================================
                ' PDF PASSWORD PROTECTION
                ' =====================================================

                ' Password required when opening the PDF
                Dim userPassword As String = ""

                ' Owner password
                Dim ownerPassword As String = ""

                stamper.SetEncryption(
                System.Text.Encoding.UTF8.GetBytes(userPassword),
                System.Text.Encoding.UTF8.GetBytes(ownerPassword),
                PdfWriter.ALLOW_FILL_IN,
                PdfWriter.ENCRYPTION_AES_128
            )

                ' =====================================================
                ' LAST PAGE - CONTACT DETAILS UPDATE FORM
                ' =====================================================

                Dim page As Integer = reader.NumberOfPages

                ' -----------------------------------------------------
                ' 1. POLICY DETAILS
                ' -----------------------------------------------------

                AddTextField(
                stamper,
                "policy_holder_name",
                page,
                185, 690,
                483, 716)

                AddTextField(
                stamper,
                "family_number_policy",
                page,
                185, 659,
                483, 685)

                AddTextField(
                stamper,
                "national_id_passport",
                page,
                185, 629,
                483, 654)


                ' -----------------------------------------------------
                ' 2. CONTACT INFORMATION
                ' -----------------------------------------------------

                AddTextField(
                stamper,
                "current_mobile_number",
                page,
                68, 520,
                174, 547)

                AddTextField(
                stamper,
                "new_mobile_number",
                page,
                175, 520,
                482, 547)

                AddTextField(
                stamper,
                "current_alternate_address",
                page,
                68, 497,
                174, 520)

                AddTextField(
                stamper,
                "new_alternate_address",
                page,
                175, 497,
                482, 520)

                AddTextField(
                stamper,
                "current_email",
                page,
                68, 474,
                174, 497)

                AddTextField(
                stamper,
                "new_email",
                page,
                175, 474,
                482, 497)

                AddTextField(
                stamper,
                "current_postal_address",
                page,
                68, 451,
                174, 474,
                True)

                AddTextField(
                stamper,
                "new_postal_address",
                page,
                175, 451,
                482, 474,
                True)

                AddTextField(
                stamper,
                "current_physical_address",
                page,
                68, 429,
                174, 451,
                True)

                AddTextField(
                stamper,
                "new_physical_address",
                page,
                175, 429,
                482, 451,
                True)


                ' -----------------------------------------------------
                ' 3. EMERGENCY / NEXT OF KIN
                ' -----------------------------------------------------

                AddTextField(
                stamper,
                "next_of_kin_name",
                page,
                189, 347,
                486, 375)

                AddTextField(
                stamper,
                "next_of_kin_relationship",
                page,
                189, 325,
                486, 347)

                AddTextField(
                stamper,
                "next_of_kin_phone_number",
                page,
                189, 296,
                486, 325)


                ' -----------------------------------------------------
                ' 4. BANKING DETAILS
                ' -----------------------------------------------------

                AddTextField(
                stamper,
                "bank_name",
                page,
                196, 438,
                487, 454)

                AddTextField(
                stamper,
                "bank_branch",
                page,
                196, 421,
                487, 438)

                AddTextField(
                stamper,
                "account_name",
                page,
                196, 397,
                487, 420)

                AddTextField(
                stamper,
                "account_number",
                page,
                196, 386,
                487, 404)


                ' -----------------------------------------------------
                ' 5. DECLARATION
                ' -----------------------------------------------------

                AddTextField(
                stamper,
                "declaration_name",
                page,
                196, 327,
                487, 344)

                AddTextField(
                stamper,
                "signature",
                page,
                196, 311,
                487, 327)

                AddTextField(
                stamper,
                "date",
                page,
                196, 295,
                487, 311)


                ' =====================================================
                ' IMPORTANT
                ' =====================================================
                ' Closing the stamper writes the PDF completely and
                ' releases the output file.
                stamper.Close()
                stamper = Nothing

            End Using

        Catch ex As Exception

            Throw New Exception(
            "Unable to create password-protected fillable PDF: " &
            ex.Message,
            ex)

        Finally

            If stamper IsNot Nothing Then
                Try
                    stamper.Close()
                Catch
                End Try
            End If

            If reader IsNot Nothing Then
                Try
                    reader.Close()
                Catch
                End Try
            End If

        End Try

    End Sub
    'Private Sub MakeContactDetailsFillable(ByVal inputPdf As String,
    '                                       ByVal outputPdf As String)

    '    Dim reader As New PdfReader(inputPdf)

    '    Try
    '        Using fs As New FileStream(outputPdf, FileMode.Create, FileAccess.Write)
    '            Dim stamper As New PdfStamper(reader, fs)

    '            ' Keep fields editable
    '            stamper.FormFlattening = False

    '            ' The Contact Details Update Form is the last page
    '            Dim page As Integer = reader.NumberOfPages

    '            ' =========================================================
    '            ' 1. POLICY DETAILS
    '            ' =========================================================

    '            AddTextField(stamper,
    '                         "policy_holder_name",
    '                         page,
    '                         185, 690, 483, 716)

    '            AddTextField(stamper,
    '                         "family_number_policy",
    '                         page,
    '                         185, 659, 483, 685)

    '            AddTextField(stamper,
    '                         "national_id_passport",
    '                         page,
    '                         185, 629, 483, 654)


    '            ' =========================================================
    '            ' 2. CONTACT INFORMATION
    '            ' =========================================================

    '            ' Mobile Number
    '            AddTextField(stamper,
    '                         "current_mobile_number",
    '                         page,
    '                         68, 520, 174, 547)

    '            AddTextField(stamper,
    '                         "new_mobile_number",
    '                         page,
    '                         175, 520, 482, 547)

    '            ' Alternate Address
    '            AddTextField(stamper,
    '                         "current_alternate_address",
    '                         page,
    '                         68, 497, 174, 520)

    '            AddTextField(stamper,
    '                         "new_alternate_address",
    '                         page,
    '                         175, 497, 482, 520)

    '            ' Email Address
    '            AddTextField(stamper,
    '                         "current_email",
    '                         page,
    '                         68, 474, 174, 497)

    '            AddTextField(stamper,
    '                         "new_email",
    '                         page,
    '                         175, 474, 482, 497)

    '            ' Postal Address
    '            AddTextField(stamper,
    '                         "current_postal_address",
    '                         page,
    '                         68, 451, 174, 474,
    '                         True)

    '            AddTextField(stamper,
    '                         "new_postal_address",
    '                         page,
    '                         175, 451, 482, 474,
    '                         True)

    '            ' Physical Address
    '            AddTextField(stamper,
    '                         "current_physical_address",
    '                         page,
    '                         68, 429, 174, 451,
    '                         True)

    '            AddTextField(stamper,
    '                         "new_physical_address",
    '                         page,
    '                         175, 429, 482, 451,
    '                         True)


    '            ' =========================================================
    '            ' 3. EMERGENCY CONTACT / NEXT OF KIN
    '            ' =========================================================

    '            AddTextField(stamper,
    '                         "next_of_kin_name",
    '                         page,
    '                         189, 347, 486, 375)

    '            AddTextField(stamper,
    '                         "next_of_kin_relationship",
    '                         page,
    '                         189, 325, 486, 347)

    '            AddTextField(stamper,
    '                         "next_of_kin_phone_number",
    '                         page,
    '                         189, 296, 486, 325)


    '            ' =========================================================
    '            ' 4. BANKING DETAILS
    '            ' =========================================================

    '            AddTextField(stamper,
    '                         "bank_name",
    '                         page,
    '                         196, 438, 487, 454)

    '            AddTextField(stamper,
    '                         "bank_branch",
    '                         page,
    '                         196, 421, 487, 438)

    '            AddTextField(stamper,
    '                         "account_name",
    '                         page,
    '                         196, 397, 487, 420)

    '            AddTextField(stamper,
    '                         "account_number",
    '                         page,
    '                         196, 386, 487, 404)


    '            ' =========================================================
    '            ' 5. DECLARATION
    '            ' =========================================================

    '            AddTextField(stamper,
    '                         "declaration_name",
    '                         page,
    '                         196, 327, 487, 344)

    '            AddTextField(stamper,
    '                         "signature",
    '                         page,
    '                         196, 311, 487, 327)

    '            AddTextField(stamper,
    '                         "date",
    '                         page,
    '                         196, 295, 487, 311)


    '            stamper.Close()
    '        End Using

    '    Finally
    '        reader.Close()
    '    End Try

    'End Sub


    Private Sub AddTextField(ByVal stamper As PdfStamper,
                             ByVal fieldName As String,
                             ByVal pageNumber As Integer,
                             ByVal llx As Single,
                             ByVal lly As Single,
                             ByVal urx As Single,
                             ByVal ury As Single,
                             Optional ByVal multiline As Boolean = False)

        Dim field As New TextField(
            stamper.Writer,
            New Rectangle(llx, lly, urx, ury),
            fieldName)

        ' Font
        field.FontSize = 9
        field.BorderWidth = 0
        field.BackgroundColor = Nothing

        ' Multiline fields
        If multiline Then
            field.Options = TextField.MULTILINE
        End If

        ' Add field to PDF
        stamper.AddAnnotation(
            field.GetTextField(),
            pageNumber)

    End Sub
End Class

