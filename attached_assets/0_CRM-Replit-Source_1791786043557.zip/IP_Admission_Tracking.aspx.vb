﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                dtadmin.DbSelectedDate = Date.Now()
                dtdisch.DbSelectedDate = DateAdd(DateInterval.Day, 3, Date.Now())
                DtReceive.DbSelectedDate = Date.Now()
                dtnokdate.DbSelectedDate = Date.Now()

                Str = "SELECT DISTINCT ORG_NAME,ORG_ID  FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST where terminated='NO' AND PROVIDER_TYPE<>'DOCTOR'  ORDER BY ORG_NAME" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboProvi
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                    .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                    .DataBind()
                End With




                Str = "SELECT DISTINCT ORG_NAME,ORG_ID   FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST where terminated='NO' AND PROVIDER_TYPE='DOCTOR'  ORDER BY ORG_NAME" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboDoc
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                    .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                    .DataBind()
                End With

                Session("empcode") = Nothing
                Session("agentemail") = Nothing
                'Str = "SELECT DISTINCT [BENEFIT]  FROM [dbo].[TBL_MIS_BENEFITS] ORDER BY BENEFIT" '"
                'MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                'With cboBenefit
                '    .Items.Clear()
                '    .DataSource = MyDatatable
                '    .DataTextField = MyDatatable.Columns("BENEFIT").ToString
                '    .DataValueField = MyDatatable.Columns("BENEFIT").ToString
                '    .DataBind()
                'End With

                Str = "SELECT USER_ID,AGENT_NAME FROM [COMMISSION].[dbo].[TBL_MIS_SALES_AGENTS] WHERE TERMINATED=0" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboAgent
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                    .DataValueField = MyDatatable.Columns("USER_ID").ToString
                    .DataBind()
                End With
                Str = "SELECT DISTINCT [RE_CODE],[RE_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_RMS] WHERE   IS_ACTIVE=1" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cborm
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                    .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                    .DataBind()
                End With
            Catch ex As Exception
                lblProv.Text = ex.Message
            End Try
        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],FIRST_ENROLLMENT_DATE,[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE MEMBER_NAME  LIKE '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME,[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],FIRST_ENROLLMENT_DATE,[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO like '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDMEMBER.DataSource = Nothing
                GDMEMBER.DataBind()
            End If


        Catch ex As Exception
            lblProv.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblProv.Text = ""
            lblnok.Text = ""

            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
            number = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],GRP_INDV,USER_ID,RMS_CODE FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO ='" & number & "' order by DISPLAY_MEMBERSHIP_NO"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()
                txtmobile.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()
                txtemail.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_EMAIL").ToString()
                cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()
                cboAgent.SelectedValue = MyDatatable.Rows(0).Item("USER_ID").ToString()
                cborm.SelectedValue = MyDatatable.Rows(0).Item("RMS_CODE").ToString()

                'Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Transfer_To_Provider FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Member_No='" & number & "' AND Claim_type='IP'"
                'MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                'If MyDatable.Rows.Count > 0 Then
                '    GDCASE.DataSource = MyDatable
                '    GDCASE.DataBind()
                '    MyDatable = Nothing
                '    HiddenField1.Value = 0
                '    cmdsave.Enabled = True
                'Else
                '    GDCASE.DataSource = Nothing
                '    GDCASE.DataBind()
                '    HiddenField1.Value = 0
                '    cmdsave.Enabled = True
                'End If

                Load_grid(number)

            End If
        Catch ex As Exception
            lblProv.Text = ex.Message
        End Try
    End Sub
    Public Sub Load_grid_Code(ByVal Code_no As String)
        GD_BENEFIT_1.DataSource = Nothing
        GD_BENEFIT_1.DataBind()
        GDLetter.DataSource = Nothing
        GDLetter.DataBind()
        GDNOK.DataSource = Nothing
        GDNOK.DataBind()
        GDDOC_NOTES.DataSource = Nothing
        GDDOC_NOTES.DataBind()

        Str = "SELECT   [Benefit_Id],[Case_No],[Benefit_Name],[Pre_auth_Amt],[Pre_auth_By],[Pre_auth_dt]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_BENEFIT_PREAUTH] WHERE  Case_No='" & lblcode.Text & "'"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_BENEFIT_1.DataSource = MyDatable
            GD_BENEFIT_1.DataBind()
        Else
            GD_BENEFIT_1.DataSource = Nothing
            GD_BENEFIT_1.DataBind()
        End If
        Str = "SELECT Id, [Prov_Type], [Case_No],P.[ORG_NAME] Provider,[Pre_Auth_Amt],[Pre_Auth_Dt],[Pre_Auth_By]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_PROVIDER_AMT] A  INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST  P ON A.[Provider]=P.ORG_ID WHERE  Case_No='" & lblcode.Text & "'"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDLetter.DataSource = MyDatable
            GDLetter.DataBind()
        Else
            GDLetter.DataSource = Nothing
            GDLetter.DataBind()
        End If

        '
        Str = "SELECT Nok_ID, [Name],[Relation],[Mobile_no],[Email],[Notified],[Notify_Date],[Notify_By]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_NOK] WHERE  Case_No='" & lblcode.Text & "'"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOK.DataSource = MyDatable
            GDNOK.DataBind()
        Else
            GDNOK.DataSource = Nothing
            GDNOK.DataBind()
        End If

        '
        Str = "SELECT  [Note_id],[Case_No],[Notes],[Note_From],[Note_Date],[Note_Type],[Active]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_DOC_NOTES] WHERE  Dr_ID='" & lblid.Text & "'"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDDOC_NOTES.DataSource = MyDatable
            GDDOC_NOTES.DataBind()
        Else
            GDDOC_NOTES.DataSource = Nothing
            GDDOC_NOTES.DataBind()
        End If

    End Sub
    Public Sub Load_grid(ByVal mem_no As String)
        Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM DATA_REPOSITORY_DB.[dbo].[TBL_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & mem_no & "' AND clause_code_dep='IPD' ORDER BY LIMIT_AMT DESC"
        'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_BENEFIT.DataSource = MyDatable
            GD_BENEFIT.DataBind()
            GD_BENEFIT_0.DataSource = MyDatable
            GD_BENEFIT_0.DataBind()
            MyDatable = Nothing
        Else
            GD_BENEFIT.DataSource = Nothing
            GD_BENEFIT.DataBind()
            GD_BENEFIT_0.DataSource = Nothing
            GD_BENEFIT_0.DataBind()
        End If

        Str = "SELECT [Case_ID],[Case_No],[Member_No],[Member_Name],[Proposer_Name],[Client_Type],[Receive_Dt],[Receive_Time],[Mode],[Case_Status],[Admission_Dt],p.[ORG_NAME] Hospital,n.[ORG_NAME][Pri_Doctor],[RM_Code],[Entered_By],[Entry_Dt]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_CASE_BOOKING] B INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST  P ON B.Hospital=P.ORG_ID INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST  n ON B.pri_Doctor=n.ORG_ID WHERE  Member_No='" & mem_no & "' and Case_Status='SCHEDULED'"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCASE.DataSource = MyDatable
            GDCASE.DataBind()
        End If

        SqlAction = "SELECT  M.Id,M.DX_code, M.Member_No, C.Name,M.Dx_Date,M.Entered_By,M.Entry_date,M.Other_Doctor FROM   dbo.TBL_MIS_CRM_HPC_MEMBER_COMORB M INNER JOIN  dbo.TBL_MIS_CRM_HPC_DISEASES C ON M.DX_code = C.Code  WHERE  M.Member_No ='" & mem_no & "' AND M.Is_Active=1 order by M.Id desc"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCOMORM.DataSource = MyDatable
            GDCOMORM.DataBind()
            MyDatable = Nothing
        Else
            GDCOMORM.DataSource = MyDatable
            GDCOMORM.DataBind()
        End If

        SqlAction = "SELECT [Note_id],[Note_Type],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_NOTES] WHERE  Member_No ='" & mem_no & "' ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If


    End Sub
    Public Sub Generate_Task()
        SqlAction = "SELECT ISNULL((MAX(Case_Id)+1),1) NUMBER FROM [CRM].[dbo].[TBL_MIS_CRM_IP_CASE_BOOKING]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblCode.Text = "ADM" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            GDDIAG.DataSource = Nothing
            GDDIAG.DataBind()

            SqlAction = "SELECT [Disease_code],[Discription]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_ICD_CODES] where Discription LIKE '%" & txtDiag.Text & "%'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDDIAG.DataSource = MyDatable
                GDDIAG.DataBind()
                'Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else

                SqlAction = "SELECT [Disease_code],[Discription]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_ICD_CODES] where Disease_code LIKE '%" & txtDiag.Text & "%'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDDIAG.DataSource = MyDatable
                    GDDIAG.DataBind()
                    'Session("DAD_T") = MyDatable
                    MyDatable = Nothing
                Else
                    GDDIAG.DataSource = Nothing
                    GDDIAG.DataBind()
                End If
            End If
        Catch ex As Exception
            lblProv.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton5_Click(sender As Object, e As System.EventArgs) Handles RadButton5.Click
        Try
            GDPROV.DataSource = Nothing
            GDPROV.DataBind()

            SqlAction = "SELECT DISTINCT ORG_NAME,ORG_ID   FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST where terminated='NO' AND ORG_NAME LIKE '%" & txtprov_1.Text & "%'  ORDER BY ORG_NAME"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROV.DataSource = MyDatable
                GDPROV.DataBind()
                'Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDPROV.DataSource = Nothing
                GDPROV.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub



    Protected Sub GDDIAG_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDDIAG.SelectedIndexChanged
        lblcode.Text = ""
        Try
            lblcode.Text = (DirectCast(GDDIAG.SelectedItems(0), GridDataItem)).GetDataKeyValue("Disease_code").ToString()

        Catch ex As Exception
            lblsave.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDPROV_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROV.SelectedIndexChanged
        lblid.Text = ""
        Try
            lblid.Text = (DirectCast(GDPROV.SelectedItems(0), GridDataItem)).GetDataKeyValue("ORG_ID").ToString()

        Catch ex As Exception
            lblsave.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton3_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try
            Dim adm_status As String = ""
            Dim case_status As String = ""
            HiddenField1.Value = 0
            lblProv.Text = ""
            If HiddenField1.Value = 0 Then
                Generate_Task()
                MyDBAction.Pre_Auth_reg(lblCode.Text, txtmemno.Text, txtname.Text, txtprop.Text, cboTYPE.SelectedValue, txtmobile.Text, txtemail.Text, CDate(DtReceive.DbSelectedDate).ToString("yyyy-MM-dd HH:MM"), CDate(DtReceive.DbSelectedDate).ToString("HH:MM"), cbomode.SelectedValue, CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtdisch.DbSelectedDate).ToString("yyyy-MM-dd"), cboProvi.SelectedValue, cboDoc.SelectedValue, Session("UserName").ToString, CDate(Date.Now).ToString("yyyy-MM-dd HH:MM"), cboTYPE.SelectedValue, cboAgent.SelectedValue, cborm.SelectedValue, 0)
            Else

            End If
            If txtnotes.Text <> "" Then
                MyDBAction.TRACKING_PREAUTH_MESSAGES(txtmemno.Text, lblCode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text, "AUTH-NOTES")
            End If

            Str = "SELECT [Case_ID],[Case_No],[Member_No],[Member_Name],[Proposer_Name],[Client_Type],[Receive_Dt],[Receive_Time],[Mode],[Case_Status],[Admission_Dt],p.[ORG_NAME] Hospital,p.[ORG_NAME][Pri_Doctor],[RM_Code],[Entered_By],[Entry_Dt]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_CASE_BOOKING] B INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST  P ON B.Hospital=P.ORG_ID WHERE  Member_No='" & txtmemno.Text & "' and Case_Status='SCHEDULED'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE.DataSource = MyDatable
                GDCASE.DataBind()
            End If
            lblProv.Text = "Saved Successfully.."

            HiddenField1.Value = 0

            dtadmin.DbSelectedDate = Date.Now()

            lblcode.Enabled = True
            txtnotes.Enabled = True
            dtadmin.Enabled = True

            txtname.Enabled = True
            txtmemno.Enabled = True
            txtprop.Enabled = True
            cboclient.Enabled = True
            cboProvi.Enabled = True
            cboProvi.Enabled = True

            txtauth.Enabled = True
            'cboclaimtype.Enabled = True



        Catch ex As Exception
            lblProv.Text = ex.Message
        End Try
    End Sub


    Protected Sub GD_BENEFIT_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_BENEFIT.SelectedIndexChanged
        Try
            Dim n1 As String
            n1 = (DirectCast(GD_BENEFIT.SelectedItems(0), GridDataItem)).GetDataKeyValue("BENEFIT").ToString()
            SqlAction = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE  FROM DATA_REPOSITORY_DB.[dbo].[TBL_MEMBER_BAL] WHERE  BENEFIT='" & n1 & "' AND DISPLAY_MEMBERSHIP_NO ='" & txtmemno.Text & "'"
            'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM DATA_REPOSITORY_DB.[dbo].[TBL_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & mem_no & "' AND clause_code_dep='IPD' ORDER BY LIMIT_AMT DESC"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                txtauth.Text = MyDatatable.Rows(0).Item("LIMIT_AMT").ToString()
                lblbenefit.Text = MyDatatable.Rows(0).Item("BENEFIT").ToString()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub RadButton7_Click(sender As Object, e As System.EventArgs) Handles RadButton7.Click
        Try
            MyDBAction.update_Benefit_Pre_auth(lblcode.Text, lblbenefit.Text, txtauth.Text, Session("UserName").ToString, CDate(Date.Now).ToString("yyyy-MM-dd HH:MM"))
            lblsave_1.Text = "Benefit Saved Successfull!"

            Str = "SELECT   [Benefit_Id],[Case_No],[Benefit_Name],[Pre_auth_Amt],[Pre_auth_By],[Pre_auth_dt]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_BENEFIT_PREAUTH] WHERE  Case_No='" & lblcode.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_BENEFIT_1.DataSource = MyDatable
                GD_BENEFIT_1.DataBind()
            End If
        Catch ex As Exception
            lblsave_1.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton2_Click(sender As Object, e As System.EventArgs) Handles RadButton2.Click
        Try
            '    MyDBAction.TRACKING_HPC_COMORB(CDate(Date.Now).ToString("yyyy-MM-dd"), lbldiax.Text, txtmemno.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "", "")

            If txtDiaxnotes.Text <> "" Then
                MyDBAction.TRACKING_HPC_MESSAGES(txtmemno.Text, "ADM", Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtDiaxnotes.Text, "NOTES")
            End If
            '  MyDBAction.update_Diax_Pre_auth(lblcode.Text, lblbenefit.Text, txtauth.Text, Session("UserName").ToString, CDate(Date.Now).ToString("yyyy-MM-dd HH:MM"))
            lbldiax.Text = "Benefit Saved Successfull!"

            SqlAction = "SELECT [Note_id],[Note_Type],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_NOTES] WHERE  Member_No ='" & txtmemno.Text & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If
        Catch ex As Exception
            lbldiax.Text = ex.Message
        End Try
    End Sub

 

    Protected Sub GDCASE_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCASE.SelectedIndexChanged
        Dim n2 As String = ""
      
        Try
            lblcode.Text = (DirectCast(GDCASE.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_No").ToString()

            Load_grid_Code(lblcode.Text)
        Catch ex As Exception
            lblbenefit.Text = ex.Message
        End Try

    End Sub


    Protected Sub RadButton6_Click(sender As Object, e As System.EventArgs) Handles RadButton6.Click
        Try
            MyDBAction.update_Provider_Pre_auth(lblcode.Text, cboCat.Text, lblid.Text, txtauth_1.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"))

            If txtnotes.Text <> "" Then
                MyDBAction.TRACKING_IP_DOC_MESSAGES(lblid.Text, txtmemno.Text, lblCode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text, "DOC")
            End If

            lblProv.Text = "Saved Successful!"
            Load_grid_Code(lblcode.Text)
           
        Catch ex As Exception
            lblProv.Text = ex.Message
        End Try
    End Sub


    Protected Sub RadButton8_Click(sender As Object, e As System.EventArgs) Handles RadButton8.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Try
            'Str = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],S_PLUS_PREM,INV_NO  FROM [MISREPORTS].[dbo].[VW_RENEWAL_ADVICE] WHERE CAT='" & cbocat.SelectedValue & "' AND PERIOD_FROM  BETWEEN '" & CDate(dtmonthfr.DbSelectedDate).ToString("dd-MM-yyyy") & "' AND '" & CDate(dtmonthto.DbSelectedDate).ToString("dd-MM-yyyy") & "' AND POLICY_CODE='KEIN/17/PA693/003485/01'"


            Mytable = Nothing
            Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If Mytable.Rows.Count > 0 Then
                Session("Report_") = Session("Letter")
                'GENERATE_RPT(MyDatable_1)

                Session("PRINT") = "PDF"
                'MyDatable_1 = Nothing
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = (Mytable)
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Mytable = Nothing
                System.Threading.Thread.Sleep(5000)

            Else
                lblLetter.Text = "No Data Found"
                Exit Sub
            End If
 
        Catch ex As Exception
            lblLetter.Text = ex.Message
        End Try
    End Sub

  

    Protected Sub GDLetter_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDLetter.SelectedIndexChanged
        Try
            Dim Id As Integer = 0
            Id = (DirectCast(GDLetter.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()
            Str = " SELECT [Prov_Type]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_PROVIDER_AMT]  WHERE  ID='" & Id & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                Session("Letter") = MyDatable.Rows(0).Item("Prov_Type").ToString()

            End If


        Catch ex As Exception
            lblLetter.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton3_Click1(sender As Object, e As System.EventArgs) Handles RadButton3.Click
        Try
            Dim nt As String
            If chknotify.Checked = True Then
                nt = "YES"
            Else
                nt = "NO"
            End If
            If lblCode.Text = "" Then
                lblnok.Text = "You Must select the Case"
                Exit Sub
            End If

            MyDBAction.update_NOK_Pre_auth(txtmemno.Text, lblcode.Text, txtnokname.Text, cborela.SelectedValue, txtnokmobile.Text, txtemail_nok.Text, nt, CDate(dtnokdate.DbSelectedDate).ToString("yyyy-MM-dd HH:MM"), Session("username"))
            lblnok.Text = "Saved Successful"
            Load_grid_Code(lblcode.Text)
        Catch ex As Exception
            lblnok.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton9_Click(sender As Object, e As System.EventArgs) Handles RadButton9.Click
        Try
            If lblCode.Text = "" Then
                lblnok.Text = "You Must select the Case"
                Exit Sub
            End If
            If cboaction.SelectedValue = "N" Then
                If txtDiaxnotes.Text <> "" Then
                    MyDBAction.IP_SCHEDULE_MESSAGES(txtmemno.Text, lblCode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd HH:MM"), txtnotesadm.Text, cboaction.SelectedValue)
                End If
            Else
                MyDBAction.IP_SCHEDULE_MESSAGES(txtmemno.Text, lblCode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd HH:MM"), txtnotesadm.Text, cboaction.SelectedValue)

            End If
            lblnok.Text = "Saved Successful"
            Load_grid_Code(lblCode.Text)


        Catch ex As Exception
            lblnotes.Text = ex.Message
        End Try
    End Sub
End Class
