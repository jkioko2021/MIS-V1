﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()


            'dtInv.DbSelectedDate = Date.Now()

            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST    ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboprovider
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With

         
            Str = ""
            MyDatatable = Nothing

            'loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name], [Inv_Status],L.ORG_NAME Provider_Name FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] I INNER JOIN  [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST L  ON L.ORG_ID=I.PROVIDER_ID  WHERE Submitted=1 and Discharged=1 and Posted=0  AND [Is_Active]=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
        End If
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
          
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = " SELECT [Ref_No] ,[Invoice_No],Invoice_Dt, [Invoice_Amt],[DoA],[DoD],[Total_Bill],[Cover_Limit],[Overshot],[Admin_Fee],[Pay_N_Invoice],Sage_INv_No,Posting_Dt from  [CRM].[dbo].[TBL_MIS_CRM_PAY_N_I_BILLING] WHERE  Ref_No ='" & STR & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
            End If

            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If


            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INV_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FilePNI.ashx?Id="), id)
    End Sub
     



    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If
            'SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]

            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name], [Inv_Status],L.ORG_NAME Provider_Name FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] I INNER JOIN  [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST L  ON L.ORG_ID=I.PROVIDER_ID  WHERE Member_Name like '%" & Trim(txtsearch.Text) & "%' and  [Is_Active]=1"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name], [Inv_Status],L.ORG_NAME Provider_Name FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] I INNER JOIN  [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST L  ON L.ORG_ID=I.PROVIDER_ID  WHERE Member_No like '%" & Trim(txtsearch.Text) & "%' and  [Is_Active]=1"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name], [Inv_Status],L.ORG_NAME Provider_Name FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] I INNER JOIN  [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST L  ON L.ORG_ID=I.PROVIDER_ID  WHERE Ref_No like '%" & Trim(txtsearch.Text) & "%' and  [Is_Active]=1"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub






     



    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

     
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub

    Protected Sub GDSEARCH_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH_1.SelectedIndexChanged
        Try
          
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            ID = ""

            lblfile.Text = (DirectCast(GDSEARCH_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()

            SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name],Service_Dt, [Inv_Status],PROVIDER_ID,Submit_Dt FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] WHERE Submitted=1 and ref_no='" & lblfile.Text & "'  AND [Is_Active]=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                txtmemno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                cboprovider.SelectedValue = MyDatable.Rows(0).Item("PROVIDER_ID").ToString()
                dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("Submit_Dt").ToString()
                dtservice.DbSelectedDate = MyDatable.Rows(0).Item("Service_Dt").ToString()
            End If

            load_Grid(lblfile.Text)
            SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_IP_CLAIM_DOCS] WHERE  File_No ='" & lblfile.Text & "' and Active=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)


            load_Grid(lblfile.Text)


        Catch ex As Exception

        End Try
    End Sub

 
     
    Protected Sub GDSEARCH_1_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH_1.NeedDataSource

    End Sub
End Class
