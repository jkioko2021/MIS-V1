﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Prem_Statement_Susp.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Corporate  name"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RM_NAME" 
    FilterControlAltText="Filter RM_NAME column" HeaderText="RM_NAME" 
    SortExpression="RM_NAME" UniqueName="RM_NAME">
</telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_ID" 
    FilterControlAltText="Filter PROPOSER_ID column" HeaderText="PROPOSER_ID" 
    SortExpression="PROPOSER_ID" UniqueName="PROPOSER_ID">
</telerik:GridBoundColumn>
                                                        
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="LBLFAMNO" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="Label146" runat="server" style="font-weight: 700" Text="RM"></asp:Label>
                                        :<asp:Label ID="RMNAME" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel1" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td colspan="3">
                                                        <asp:Label ID="Label144" runat="server" Text="Premium Statement"></asp:Label>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1200px">
                                                            <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="ACTION_TYPE" 
                                                                            FilterControlAltText="Filter ACTION_TYPE column" HeaderText="ACTION_TYPE" 
                                                                            SortExpression="ACTION_TYPE" UniqueName="ACTION_TYPE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="TOTAL_MEMBERS" 
                                                                            FilterControlAltText="Filter TOTAL_MEMBERS column" HeaderText="MEMBERS" 
                                                                            SortExpression="TOTAL_MEMBERS" UniqueName="TOTAL_MEMBERS">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                                            FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                                            SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="TRANSACTION_DATE" 
                                                                            FilterControlAltText="Filter TRANSACTION_DATE column" 
                                                                            HeaderText="TRANSACTION_DATE" SortExpression="TRANSACTION_DATE" 
                                                                            UniqueName="TRANSACTION_DATE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="DR" FilterControlAltText="Filter DR column" 
                                                                            HeaderText="DR" SortExpression="DR" UniqueName="DR">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="CR" FilterControlAltText="Filter CR column" 
                                                                            HeaderText="CR" SortExpression="CR" UniqueName="CR">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style17" style="width: 220px">
                                                        <asp:CheckBox ID="chkcurrent" runat="server" Text="Active Policy" />
                                                    </td>
                                                    <td align="right" style="width: 85px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style17" style="width: 220px">
                                                        <asp:CheckBox ID="chkex" runat="server" Text="Excel Version" />
                                                    </td>
                                                    <td align="right" style="width: 85px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style17" style="width: 220px">
                                                        <asp:CheckBox ID="chkdate" runat="server" Text="Policy Period" />
                                                    </td>
                                                    <td align="right" style="width: 85px">
                                                        <asp:Label ID="Label145" runat="server" Font-Bold="True" Text="O/S balance"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadNumericTextBox ID="txtbal" Runat="server" Enabled="False" 
                                                            Skin="Simple">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel24" runat="server">
                                                            <table style="width: 100%">
                                                                <tr>
                                                                    <td style="width: 77px; height: 25px;">
                                                                        <asp:Label ID="Label154" runat="server" Text="Date From"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 25px; width: 86px;">
                                                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" Culture="en-US" 
                                                                            SelectedDate="2022-10-31" Skin="Simple">
                                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                            </Calendar>
                                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                                SelectedDate="2022-10-31">
                                                                            </DateInput>
                                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                        </telerik:RadDatePicker>
                                                                    </td>
                                                                    <td style="height: 25px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 25px; width: 107px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 25px; width: 158px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 25px; width: 796px;">
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 77px; height: 23px;">
                                                                        <asp:Label ID="Label155" runat="server" Text="Date To"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 23px; width: 86px;">
                                                                        <telerik:RadDatePicker ID="dtto" Runat="server" Culture="en-US" 
                                                                            SelectedDate="2022-10-31" Skin="Simple">
                                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                            </Calendar>
                                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                                SelectedDate="2022-10-31">
                                                                            </DateInput>
                                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                        </telerik:RadDatePicker>
                                                                    </td>
                                                                    <td style="height: 23px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 107px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 158px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 796px;">
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 77px; height: 23px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 86px;">
                                                                        <telerik:RadButton ID="btnstatement" runat="server" Skin="Simple" 
                                                                            Text="Print Statement" Width="149px">
                                                                        </telerik:RadButton>
                                                                    </td>
                                                                    <td style="height: 23px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 107px;">
                                                                        <asp:Label ID="Label156" runat="server" Font-Bold="True" Text="Effective Date"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 23px; width: 158px;">
                                                                        <telerik:RadDatePicker ID="dtsus" Runat="server" Culture="en-US" 
                                                                            SelectedDate="2022-10-31" Skin="Simple">
                                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                            </Calendar>
                                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                                SelectedDate="2022-10-31">
                                                                            </DateInput>
                                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                        </telerik:RadDatePicker>
                                                                    </td>
                                                                    <td style="height: 23px; width: 796px;">
                                                                        <telerik:RadButton ID="btnsus" runat="server" Skin="Simple" 
                                                                            Text="Suspension Letter" Width="149px">
                                                                        </telerik:RadButton>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 77px; height: 23px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 86px;">
                                                                        <asp:Label ID="lblid" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 23px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 107px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 158px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 796px;">
                                                                        &nbsp;</td>
                                                                </tr>
                                                            </table>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel20" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            style="margin-bottom: 6px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#999999" colspan="3">
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Report Extract"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; ">
                                                        <asp:Label ID="Label152" runat="server" Font-Bold="True" 
                                                            Text="Outstanding Balances"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="export" 
                                                            Width="200px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>
