﻿Imports System.Data
Imports DocManage.DataManagement
Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO
Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
             
            dtfrom.DbSelectedDate = Date.Now
            dtto.DbSelectedDate = Date.Now

            Str = "SELECT username,employeename FROM EMPLOYEES WHERE DEPARTMENT='CASE MANAGEMENT' AND deleted=0"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboallocate
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("employeename").ToString
                .DataValueField = MyDatatable.Columns("username").ToString
                .DataBind()
            End With
            With cbocare
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("employeename").ToString
                .DataValueField = MyDatatable.Columns("username").ToString
                .DataBind()
            End With
            Str = ""
            MyDatatable = Nothing

            loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT  [ID],[FILE_NO],Service_dt,Memb_Disch_dt,Discharge_DT, [MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Invoice_type,Care_Manager,Discharge_By,Returned_By  FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE Submitted=1  and [Care_Allocate]=0  and [Discharged]=0 AND ACTIVE=1 AND INV_STATUS<>'RETENTION-ISSUE' ORDER BY Submit_dt ASC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DICHARG") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    
    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DICHARG")
        GDSEARCH.DataBind()
    End Sub
    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try
            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If chkdate.Checked = True And chkprov.Checked = False And chkcare.Checked = False Then
                SqlAction = "SELECT  [ID],[FILE_NO],Service_dt,Memb_Disch_dt,Discharge_DT, [MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Invoice_type,Care_Manager,Discharge_By FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE Submitted=1  and [Discharged]=0 AND ACTIVE=1 AND Memb_Disch_dt between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND INV_STATUS<>'RETENTION-ISSUE' "
            ElseIf chkdate.Checked = False And chkprov.Checked = True And chkcare.Checked = False Then
                SqlAction = "SELECT  [ID],[FILE_NO],Service_dt,Memb_Disch_dt,Discharge_DT, [MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Invoice_type,Discharge_By,Care_Manager FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE Submitted=1  and [Discharged]=0 AND ACTIVE=1 AND Provider_Name Like '%" & Trim(txtprovider.Text) & "%' AND INV_STATUS<>'RETENTION-ISSUE'"
            ElseIf chkdate.Checked = True And chkprov.Checked = True And chkcare.Checked = False Then
                SqlAction = "SELECT  [ID],[FILE_NO],Service_dt,Memb_Disch_dt,Discharge_DT, [MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Invoice_type,Discharge_By,Care_Manager FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE Submitted=1  and [Discharged]=0 AND ACTIVE=1 AND Memb_Disch_dt between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Provider_Name Like '%" & Trim(txtprovider.Text) & "%' AND INV_STATUS<>'RETENTION-ISSUE'"
            ElseIf chkcare.Checked = True And chkdate.Checked = False And chkprov.Checked = False Then
                SqlAction = "SELECT  [ID],[FILE_NO],Service_dt,Memb_Disch_dt,Discharge_DT, [MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Invoice_type,Discharge_By,Care_Manager FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE Submitted=1  and [Discharged]=0 AND ACTIVE=1 AND    Care_Manager Like '%" & (cbocare.SelectedValue) & "%' AND INV_STATUS<>'RETENTION-ISSUE'"
            Else
                SqlAction = "SELECT  [ID],[FILE_NO],Service_dt,Memb_Disch_dt,Discharge_DT, [MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Invoice_type,Discharge_By,Care_Manager FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE Submitted=1  and [Discharged]=0 AND ACTIVE=1 AND INV_STATUS<>'RETENTION-ISSUE'"
            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DICHARG") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            lblerr_1.Text = ""
            If cboallocate.SelectedValue = "" Then
                lblerr_1.Text = "Select the Care manager!"
                Exit Sub
            End If
            If txtcomment.Text = "" Then
                lblerr_1.Text = "You must enter short notes!"
                Exit Sub
            End If

            For Each dataItem As GridDataItem In GDSEARCH.MasterTableView.Items
                Dim chkSelect As CheckBox = DirectCast(dataItem.FindControl("chkreturn"), CheckBox)
                If chkSelect.Checked Then
                    Dim ID As String = dataItem.GetDataKeyValue("File_No").ToString()
                    UpdateRecord("UPDATE [dbo].[TBL_MIS_IP_CLAIM_TRACKING] SET   [Care_Allocate]=1,[Care_Manager]='" & cboallocate.SelectedValue & "',[Care_Allocate_Dt]='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Care_Allocate_By='" & Session("username") & "', Inv_Status='CARE_ALLOCATED'  where [File_No]= '" & ID & "'")
                    MyDBAction.TRACKING_IP_CLAIM_MESSAGES(ID, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
                End If
            Next
            lblerr_1.Text = "Submit successfull!"
            lblfile.Text = ""
            'MailSent = SendLoginDetails("Team", Session("email"), Session("cc_email"))

            lblfile.Enabled = False

            lblfile.Text = ""

            txtcomment.Text = ""

            loadGrid()

        Catch ex As Exception
            lblerr_1.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)
    End Sub

    Protected Sub ToggleRowSelection(ByVal sender As Object, ByVal e As EventArgs)
        Dim Total As Decimal

        TryCast(TryCast(sender, CheckBox).NamingContainer, GridItem).Selected = TryCast(sender, CheckBox).Checked
        Dim checkHeader As Boolean = True
        For Each dataItem As GridDataItem In GDSEARCH.MasterTableView.Items
            If Not TryCast(dataItem.FindControl("chkreturn"), CheckBox).Checked Then
                checkHeader = False

                Exit For
            End If

        Next
        Dim headerItem As GridHeaderItem = TryCast(GDSEARCH.MasterTableView.GetItems(GridItemType.Header)(0), GridHeaderItem)
        TryCast(headerItem.FindControl("chkheader"), CheckBox).Checked = checkHeader

    End Sub

    Protected Sub ToggleSelectedState(ByVal sender As Object, ByVal e As EventArgs)
        Dim headerCheckBox As CheckBox = TryCast(sender, CheckBox)

        For Each dataItem As GridDataItem In GDSEARCH.MasterTableView.Items
            TryCast(dataItem.FindControl("chkreturn"), CheckBox).Checked = headerCheckBox.Checked
            dataItem.Selected = headerCheckBox.Checked

        Next
    End Sub
    
    Protected Sub RadButton2_Click(sender As Object, e As System.EventArgs) Handles RadButton2.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String = "IP_Claim_List"
            Session("EXCEL") = "TO EXCEL"
            Dim MyDatable As New Data.DataTable
            Session("DAD_5") = Nothing
            SqlAction = "SELECT [File_No],[Receive_dt],[Service_dt],Memb_Disch_dt,[Claim_Type],[Member_No],[Member_Name],[Proposer],[Provider_Name],[Invoice_No],[Invoice_Amt],[Inv_Status]," & _
                                   "[Entry_Date],[Entered_by],[Submit_dt],Care_Manager,[Discharged], Discharge_dt,discharge_by,[Invoice_type],[Amt_Payable_Ben],[P_I_Amount],[Country],Care_Manager,Care_Allocate_Dt,Care_Allocate_By," & _
                                   "[Payable_Amt] FROM [CRM].[dbo].[TBL_MIS_IP_CLAIM_TRACKING] where ACTIVE=1 and Discharged=0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (MyDatable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            MyDatable = Nothing
            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception
            lblerr_1.Text = ex.Message
        End Try
        'Reportname = ""
    End Sub

  
    Protected Sub GDSEARCH_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        lblfile.Text = ""
        ltEmbed.Text = ""
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        GD_DOCS.DataSource = Nothing
        GD_DOCS.DataBind()
        lblfile.Text = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()

        SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & lblfile.Text & "' ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If

        MyDatable = Nothing
        SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_IP_CLAIM_DOCS] WHERE  File_No ='" & lblfile.Text & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
            MyDatable = Nothing
        Else
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
        End If
        lblfile.Text = ""
    End Sub
    Protected Sub GDSEARCH_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GDSEARCH.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then
            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("Inv_Status")
            If myCell.Text = "RE-ALLOCATE" Then '
                dataItem.BackColor = Drawing.Color.Green
            End If

        End If
    End Sub

    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/File_Claims_IP.ashx?Id="), id)
    End Sub
End Class
