﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Production_Portfolio_RE.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
          <div id="Div_inner">
            <table style="width: 1300" Width="1200px">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4" Width="1200px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="DASH BOARD-PORTFOLIO"></asp:Label>
                    </td>
                </tr>
    <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Width="1200px" Wrap="False">
                                            <table style="width: 100%" Width="1200px">
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        <telerik:RadComboBox ID="cboyear" Runat="server" Height="19px" 
                                                            style="margin-left: 0px" Skin="Outlook">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="2019" Value="2019" />
                                                                <telerik:RadComboBoxItem runat="server" Text="2020" Value="2020" />
                                                                <telerik:RadComboBoxItem runat="server" Text="2021" Value="2021" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="width: 81px">
                                                        <telerik:RadComboBox ID="cboRE" Runat="server" AutoPostBack="True" 
                                                            style="margin-left: 0px" Width="227px" Skin="Outlook">
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td class="style10" style="width: 122px">
                                                        <asp:Label ID="Label87" runat="server" Text="Date From"></asp:Label>
                                                    </td>
                                                    <td style="width: 11px">
                                                        <telerik:RadDatePicker ID="dtDateFrom" Runat="server" AutoPostBack="True" 
                                                            Culture="en-US" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput AutoPostBack="True" DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="width: 151px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        &nbsp;</td>
                                                    <td style="width: 81px">
                                                        &nbsp;</td>
                                                    <td class="style10" style="width: 122px">
                                                        <asp:Label ID="Label88" runat="server" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td style="width: 11px">
                                                        <telerik:RadDatePicker ID="dtDateTo" Runat="server" AutoPostBack="True" 
                                                            Culture="en-US" Skin="Outlook" Width="150px">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput AutoPostBack="True" DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="width: 151px">
                                                        <telerik:RadButton ID="SEARCH" runat="server" Skin="Outlook" Text="View " 
                                                            Width="100px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                     
                                              <telerik:RadTabStrip ID="RadTabStrip1" runat="server" SelectedIndex="5" 
                                                  MultiPageID="RadMultiPage1" Width="1200px" Skin="Outlook">
                                                  <Tabs>
                                                      <telerik:RadTab runat="server" PageViewID="V4" Text="RM's &amp; RE's" 
                                                          SelectedIndex="0">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V5" Text="Corporate List">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V6" Text="Retail List">
                                                      </telerik:RadTab>
                                                  </Tabs>
                                              </telerik:RadTabStrip>
             
                                    </td>
                                </tr>
                <tr>
                    <td class="style8" colspan="4">
                        <asp:Panel ID="Panel20" runat="server" Width="1200px">
                            <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="1200px">
                                <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V4" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label93" runat="server" style="font-weight: 700" 
                                                                Text="PORTFOLIO RM"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel25" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_RM_PORT" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="RM_CODE">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                <ItemStyle Width="50px" />
                                                                            </telerik:GridButtonColumn>
                                                                            <telerik:GridBoundColumn DataField="RM_NAME" 
                                                                                FilterControlAltText="Filter RM_NAME column" HeaderText="NAME" 
                                                                                SortExpression="RM_NAME" UniqueName="RM_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="CLASS_CODE" 
                                                                                FilterControlAltText="Filter CLASS_CODE column" HeaderText="CODE" 
                                                                                SortExpression="CLASS_CODE" UniqueName="CLASS_CODE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label94" runat="server" style="font-weight: 700" 
                                                                Text="MONTH -PORTFOLIO"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel26" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_RM_PORT_1" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="MONTH_FROM" 
                                                                                FilterControlAltText="Filter MONTH_FROM column" HeaderText="MONTH_FROM" 
                                                                                SortExpression="MONTH_FROM" UniqueName="MONTH_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MONTH_TO" 
                                                                                FilterControlAltText="Filter MONTH_TO column" HeaderText="MONTH_TO" 
                                                                                SortExpression="MONTH_TO" UniqueName="MONTH_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_POLICY" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_CNT_POLICY column" HeaderText="CNT_POLICY-MED" 
                                                                                SortExpression="M_CNT_POLICY" UniqueName="M_CNT_POLICY">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_PREM" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_PREM column" HeaderText="PREM-MED" 
                                                                                SortExpression="M_PREM" UniqueName="M_PREM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CNT_LIVES" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                                                SortExpression="M_CNT_LIVES" UniqueName="M_CNT_LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter M_EARNED_PREMIUM column" 
                                                                                HeaderText="EARNED_PREMIUM" SortExpression="M_EARNED_PREMIUM" 
                                                                                UniqueName="M_EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="M_CLAIM_RATIO" DataFormatString="{0:F2} %" 
                                                                                FilterControlAltText="Filter M_CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="M_CLAIM_RATIO" UniqueName="M_CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MED_CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter MED_CLAIMS column" HeaderText="MED_CLAIMS" 
                                                                                SortExpression="MED_CLAIMS" UniqueName="MED_CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V5" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label7" runat="server" style="font-weight: 700" 
                                                                Text="CORP -MEDICAL POLICIES"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_MED_POLICY" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="PROPOSER_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                        
                                                                             
                                                                            <telerik:GridBoundColumn DataField="PREMIUMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                SortExpression="PREMIUMS" UniqueName="PREMIUMS">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="LIVES" 
                                                                                FilterControlAltText="Filter LIVES column" HeaderText="LIVES" 
                                                                                SortExpression="LIVES" UniqueName="LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="EARNED_PREMIUM" DataFormatString="{0:#,#.##}"
                                                                                FilterControlAltText="Filter EARNED_PREMIUM column" HeaderText="EARNED_PREMIUM" 
                                                                                SortExpression="EARNED_PREMIUM" UniqueName="EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="CLAIMS"  DataFormatString="{0:#,#.##}"
                                                                                FilterControlAltText="Filter CLAIMS column" HeaderText="CLAIMS" 
                                                                                SortExpression="CLAIMS" UniqueName="CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                              <telerik:GridBoundColumn DataField="CLAIM_RATIO"  DataFormatString="{0:#,#.##}"
                                                                                FilterControlAltText="Filter CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="CLAIM_RATIO" UniqueName="CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                                  <telerik:GridBoundColumn DataField="AGENT_NAME" 
                                                                                FilterControlAltText="Filter AGENT_NAME column" HeaderText="AGENT_NAME" 
                                                                                SortExpression="AGENT_NAME" UniqueName="AGENT_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <telerik:RadPageView ID="V6" runat="server" Width="1200px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td bgcolor="#999999">
                                                            <asp:Label ID="Label9" runat="server" style="font-weight: 700" 
                                                                Text="RETAIL MEDICAL POLICIES"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel27" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_NON_POLICY" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Outlook" 
                                                                    Width="1200px">
                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="PROPOSER_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                      
                                                                            <telerik:GridBoundColumn DataField="PREMIUMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                SortExpression="PREMIUMS" UniqueName="PREMIUMS">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="LIVES" 
                                                                                FilterControlAltText="Filter LIVES column" HeaderText="LIVES" 
                                                                                SortExpression="LIVES" UniqueName="LIVES">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="EARNED_PREMIUM" 
                                                                                DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter EARNED_PREMIUM column" HeaderText="EARNED_PREMIUM" 
                                                                                SortExpression="EARNED_PREMIUM" UniqueName="EARNED_PREMIUM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="CLAIMS" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter CLAIMS column" HeaderText="CLAIMS" 
                                                                                SortExpression="CLAIMS" UniqueName="CLAIMS">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="CLAIM_RATIO" DataFormatString="{0:#,#.##}" 
                                                                                FilterControlAltText="Filter CLAIM_RATIO column" HeaderText="CLAIM_RATIO" 
                                                                                SortExpression="CLAIM_RATIO" UniqueName="CLAIM_RATIO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="AGENT_NAME" 
                                                                                FilterControlAltText="Filter AGENT_NAME column" HeaderText="AGENT_NAME" 
                                                                                SortExpression="AGENT_NAME" UniqueName="AGENT_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <HeaderStyle Wrap="False" />
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            &nbsp;</td>
                                    </tr>
                                </table>

                            </telerik:RadMultiPage>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        <asp:Label ID="lbltext" runat="server" ForeColor="#CC0000"></asp:Label>
                        <asp:Label ID="lblID" runat="server" ForeColor="#CC0000" Visible="False"></asp:Label>
                        <asp:HiddenField ID="HiddenField1" runat="server" />
                    </td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
           
                            <table style="width: 1200px" width="1200">
                                <tr>
                                    <td bgcolor="#999999" colspan="4">
                                        <asp:Label ID="Label86" runat="server" Text="Report Extract (Debits)"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 159px">
                                        <telerik:RadComboBox ID="cbotype" Runat="server" Skin="Outlook">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" 
                                                    Text="Corporate Medical" Value="CM" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Corporate NonMed" 
                                                    Value="CN" />
                                                <telerik:RadComboBoxItem runat="server" Text="Retail Medical" Value="RM" />
                                                <telerik:RadComboBoxItem runat="server" Text="Retail NonMed" Value="RN" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style9" style="width: 112px">
                                        <telerik:RadButton ID="btnGenerate" runat="server" Skin="Sunset" 
                                            Text="Generate">
                                        </telerik:RadButton>
                                    </td>
                                    <td class="style9" style="width: 14px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 159px">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 112px">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 14px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                            </table>
                     
                        
                            <table width="1200px">
                                <tr>
                                    <td style="width: 159px">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 112px">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 14px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                            </table>
             </div>          
        </ContentTemplate>

    </asp:UpdatePanel>
</asp:Content>

