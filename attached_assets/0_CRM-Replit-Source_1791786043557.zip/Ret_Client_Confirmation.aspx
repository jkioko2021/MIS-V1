﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Ret_Client_Confirmation.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8" colspan="4">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="New Client Confirmation"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 1025px">
                                                    <telerik:RadComboBox ID="cborm" Runat="server" AllowCustomText="True" 
                                                        MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Proposer Name" 
                                                                Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Family Code" 
                                                                Value="F" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Agent" 
                                                                Value="Agent" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 261px">
                                                    &nbsp;</td>
                                                <td style="width: 250px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 261px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" AllowCustomText="True" 
                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Policy Code" Value="F" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Agent" Value="A" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadComboBox ID="cbosearch_1" Runat="server" AllowCustomText="True" 
                                                        MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" 
                                                                Text="Proposer Name" Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Family Code" 
                                                                Value="F" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Agent" 
                                                                Value="Agent" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDProposer" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" Width="100%" 
                                                PageSize="20">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                      <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                   
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter Task_code column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="PROPOSER_DISPLAY_NAME" 
                                                            SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                            </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                    
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left" colspan="4">
                                        <asp:Label ID="Label142" runat="server" Text="Members"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" colspan="4">
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" >
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                  
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" HeaderText="MEMBERSHIP NO" 
                                                            SortExpression="DISPLAY_MEMBERSHIP_NO" UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" 
                                                            HeaderText="MEMBER_NAME" SortExpression="MEMBER_NAME" 
                                                            UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" HeaderText="MEMBER_BIRTH_DATE" 
                                                            SortExpression="MEMBER_BIRTH_DATE" UniqueName="MEMBER_BIRTH_DATE" DataFormatString="{0:dd-MM-yyyy}">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                            FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                            SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                        </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                            FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                            SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" style="width: 119px">
                                        &nbsp;</td>
                                    <td style="width: 179px">
                                        <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        <asp:Label ID="PRD" runat="server" Visible="False"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label139" runat="server" Text="Agent"></asp:Label>
                                    </td>
                                    <td style="width: 179px">
                                        <telerik:RadComboBox ID="cboagent" Runat="server" Skin="Sunset" Width="300px" 
                                            AllowCustomText="True" MarkFirstMatch="True" Enabled="False">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style9" style="width: 109px" align="left">
                                        <asp:Label ID="FAMNO" runat="server"></asp:Label>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left" colspan="4">
                                        <hr />
                                    </td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8">
                                        <asp:Label ID="Label147" runat="server" Text="Confirmations"></asp:Label>
                                    </td>
                                    <td>
                                        <asp:Label ID="Label149" runat="server" 
                                            Text="1.Was Member updated with the right cover"></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        <telerik:RadComboBox ID="cbo_1" Runat="server" Skin="Sunset" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_1" Text="YES" Value="YES" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_1" Text="NO" Value="NO" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Label ID="Label143" runat="server" 
                                            Text="2.Confirmation of Receipt of Documents"></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        <telerik:RadComboBox ID="cbo_2" Runat="server" Skin="Sunset" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_2" Text="YES" Value="YES" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_2" Text="NO" Value="NO" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8">
                                        &nbsp;</td>
                                    <td align="right">
                                        <asp:Panel ID="Panel28" runat="server" BorderStyle="Dotted" BorderWidth="1px" 
                                            Height="100%" Width="243px">
                                            <asp:CheckBoxList ID="chklist" runat="server" Width="225px">
                                            </asp:CheckBoxList>
                                        </asp:Panel>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8" style="width: 119px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Label ID="Label144" runat="server" 
                                            Text="3.Acknowledgement of declaration consent form"></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        <telerik:RadComboBox ID="cbo_3" Runat="server" Skin="Sunset" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_3" Text="YES" Value="YES" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_3" Text="NO" Value="NO" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8" style="width: 119px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Label ID="Label145" runat="server" 
                                            Text="4.Where the terms of  policy clearly explained"></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        <telerik:RadComboBox ID="cbo_4" Runat="server" Skin="Sunset" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_4" Text="YES" Value="YES" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_4" Text="NO" Value="NO" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8" style="width: 119px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Panel ID="Panel30" runat="server" BorderStyle="Dotted" BorderWidth="1px" 
                                            Height="100%" Width="243px">
                                            <asp:CheckBoxList ID="chklist_1" runat="server" Width="225px">
                                            </asp:CheckBoxList>
                                        </asp:Panel>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8" style="width: 119px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Label ID="Label146" runat="server" 
                                            
                                            Text="5.Satisfied with the quality of information provided regarding the policy "></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        <telerik:RadComboBox ID="cbo_5" Runat="server" Skin="Sunset" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_5" Text="YES" Value="YES" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_5" Text="NO" Value="NO" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="right" class="style8" style="width: 119px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Label ID="Label148" runat="server" Text="Follow-up with Member  "></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        <telerik:RadComboBox ID="cbo_6" Runat="server" Skin="Sunset" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_6" Text="NO" Value="NO" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbo_6" Text="YES" 
                                                    Value="YES" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label136" runat="server" Text="Notes"></asp:Label>
                                    </td>
                                    <td align="left" colspan="3" rowspan="3">
                                        <telerik:RadTextBox ID="txtdescr" Runat="server" Font-Size="Large" 
                                            Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                            TextMode="MultiLine" Width="600px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red" Font-Size="Medium"></asp:Label>
                                    </td>
                                    <td class="style9" style="width: 109px">
                                        <telerik:RadButton ID="cmdsave" runat="server" Height="38px" Skin="Sunset" 
                                            Text="Save" Width="152px">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>

