﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            Str = "SELECT DISTINCT [Code],[Descr] FROM [dbo].[TBL_MIS_REIMB_REASONS] WHERE ACTIVE=1" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboreason
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Descr").ToString
                .DataValueField = MyDatatable.Columns("Code").ToString
                .DataBind()
            End With
            Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 and DEPARTMENT='MEMBERSHIP'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbomship
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                .DataValueField = MyDatatable.Columns("username").ToString
                .DataBind()
            End With
          
            Str = "SELECT  [Doc_Code],[Doc_Name] FROM [CRM].[dbo].[TBL_MIS_REIMB_REQUIREMENTS] WHERE Doc_Code IN ('DOC_R11','DOC_R12')"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbodoc
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Doc_Name").ToString
                .DataValueField = MyDatatable.Columns("Doc_Code").ToString
                .DataBind()
            End With
            loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,Claim_Type FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WHERE Submitted=1 AND [Approved]=1 and Ready_To_Process=1 and  [Indexed]=1 and Allocated=1 and Processed=0 and Inv_Status<>'DECLINED' and ACTIVE=1"

        '  SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,Claim_Type FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WHERE Submitted=1 AND [Approved]=1 and Ready_To_Process=1 and  [Indexed]=1 and Allocated=1 and Allocate_To='" & Session("username") & "' and Processed=0 and Inv_Status<>'DECLINED' and ACTIVE=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
       
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""
        Try


            cboreason.SelectedValue = ""
            cboreason.Text = ""
            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT  [ID],[FILE_NO],[RECEIVE_DT],[SERVICE_DT],[CLAIM_TYPE],[MEMBER_NO],MEMBER_NAME,[INVOICE_NO],[INVOICE_AMT],REASON,PROPOSER,email,Mobile_no,entered_By,Bar_code  FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) WHERE File_No ='" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                    dtservice.DbSelectedDate = MyDatable.Rows(0).Item("SERVICE_DT").ToString()
                    txtmobile.Text = MyDatable.Rows(0).Item("Mobile_no").ToString()
                    cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                    txtmemno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                    txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                    txtemail.Text = MyDatable.Rows(0).Item("email").ToString()
                    cboreason.SelectedValue = MyDatable.Rows(0).Item("REASON").ToString()
                    txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER").ToString()
                    lblenteredby.Text = MyDatable.Rows(0).Item("entered_By").ToString()
                    txtbarcode.Text = MyDatable.Rows(0).Item("Bar_code").ToString()
                    load_Grid(lblfile.Text)

                    Str = "SELECT EMAIL FROM employees WHERE username='" & lblenteredby.Text & "'" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    If MyDatatable.Rows.Count > 0 Then
                        Session("email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                        'Session("cc_email") = "relationship-managers@aar.co.ke"
                    Else
                        Str = "SELECT EMAIL FROM SALES.dbo.employees WHERE username='" & lblenteredby.Text & "'" '"
                        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                        If MyDatatable.Rows.Count > 0 Then
                            Session("email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                            'Session("cc_email") = "relationship-managers@aar.co.ke"
                        End If
                    End If

                    txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False
                    dtservice.Enabled = False

                    'txtbarcode.Enabled = False
                    cbotype.Enabled = False
                    txtmemno.Enabled = False

                    txtinv_no.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False

                    txtname.Enabled = False
                    txtinv_no.Enabled = False

                    txtinv_amt.Enabled = False
                    'txtcomment.Enabled = False


                    txtinv_amt.Enabled = False

                    cboreason.Enabled = False

                End If

                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub


    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/File_Claims.ashx?Id="), id)
    End Sub



    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "REIMBURMENT CLAIM" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = cboaction.Text.ToUpper & "-REIMBURMENT:" & txtname.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear, " & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>File No:" & lblfile.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Member Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            lblerr.Text = ""
            Dim inadm As Decimal = 0
            If txtpayable.Text = "" Then
                txtpayable.Text = 0
            End If

            If cboaction.SelectedValue = "" Then
                lblerr.Text = "Select the action!"
                Exit Sub
            End If

            'If txtinv_amt.Text < txtpayable.Text Then
            '    lblerr.Text = "Select the Correct payable amount!"
            '    Exit Sub
            'End If

            inadm = txtinv_amt.Text - txtpayable.Text

            If lblfile.Text = "" Then
                lblerr.Text = "Select the File to Submit!"
                Exit Sub
            End If

            If cboaction.SelectedValue = "D" Or cboaction.SelectedValue = "AP" Then
                SqlAction = "SELECT  File_Name FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE File_No='" & lblfile.Text & "' AND ACTIVE=1 AND Doc_Code IN ('DOC_R11','DOC_R12') AND upload_done=1"
                MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatatable.Rows.Count > 0 Then

                Else
                    lblerr.Text = "You must upload the Decline/Rejection Documents!"
                    Exit Sub
                End If
            End If

            If cboaction.SelectedValue = "A" And txtpayable.Text = 0 Then
                lblerr.Text = "You must enter the payable Amt"
                Exit Sub
            End If
            Session("cc_email") = ""
            'Str = "SELECT EMAIL FROM employees WHERE username='" & Session("username") & "'" '"
            'MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            'If MyDatatable.Rows.Count > 0 Then
            '    Session("cc_email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
            'End If
            'MyDBAction.Claim_Approval(lblfile.Text, CDate(Date.Now).ToString("yyyy-mm-dd"), Session("username"), "DPU", txtcomment.Text, cboaction.SelectedValue)
            If cboaction.SelectedValue = "AF" Then
                UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET RC_Mtiba_No='" & Trim(txtrcno.Text) & "', [Inadmissable_Amt]='" & inadm & "', [Processed]=1,Payable_Amt='" & Trim(txtpayable.Text) & "',Process_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Processed_By='" & Session("username") & "'  ,Inv_Status='PROCESSED'  where [File_No]= '" & lblfile.Text & "'")
                Session("msg") = "Kindly note that the above Reimbursement has been processed for Full payment awaiting audit as per below processing."
            ElseIf cboaction.SelectedValue = "AP" Then
                UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET RC_Mtiba_No='" & Trim(txtrcno.Text) & "', [Inadmissable_Amt]='" & inadm & "', [Processed]=1,Payable_Amt='" & Trim(txtpayable.Text) & "',Process_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Processed_By='" & Session("username") & "'  ,Inv_Status='PROCESSED'  where [File_No]= '" & lblfile.Text & "'")
                Session("msg") = "Kindly note that the above Reimbursement has been processed for Part payment awaiting audit as per below processing.You can download the Part payment letter from MIS"
            ElseIf cboaction.SelectedValue = "D" Then
                UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET  Approved=0,Ready_To_Process=0, [Processed]=0,Payable_Amt='" & Trim(txtpayable.Text) & "',Decline_dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Decline_By='" & Session("username") & "' ,Inv_Status='DECLINED'  where [File_No]= '" & lblfile.Text & "'")
                Session("msg") = "Kindly note that the above Reimbursement has been Declined by the Medical Assesor as Not payable as per below comments.You can download the Decline letter from MIS"
                MyDBAction.Claim_processing(lblfile.Text, CDate(Date.Now).ToString("yyyy-mm-dd"), Session("username"), lblenteredby.Text, txtcomment.Text, cboaction.SelectedValue)
            ElseIf cboaction.SelectedValue = "RI" Then
                UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET  Approved=0,indexed=0,ready_to_process=0, Submitted=0,Returned=1,[Processed]=0,Returned_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Returned_By='" & Session("username") & "' ,Inv_Status='RETURNED INCOMPLETE'  where [File_No]= '" & lblfile.Text & "'")
                MyDBAction.Claim_processing(lblfile.Text, CDate(Date.Now).ToString("yyyy-mm-dd"), Session("username"), lblenteredby.Text, txtcomment.Text, cboaction.SelectedValue)
                Session("msg") = "Kindly note that the above Reimbursement has been returned as Incomplete by the Medical assessor as per below comments"
                'ElseIf cboaction.SelectedValue = "DPU" Then
                '    UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET Allocated=0,Allocate_To='',Approved=0,indexed=0,ready_to_process=0, Submitted=0,Returned=1,[Processed]=0,Payable_Amt=0,Returned_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Returned_By='" & Session("username") & "' ,Inv_Status='RETURNED INCOMPLETE'  where [File_No]= '" & lblfile.Text & "'")
                '    MyDBAction.Claim_processing(lblfile.Text, CDate(Date.Now).ToString("yyyy-mm-dd"), Session("username"), lblenteredby.Text, txtcomment.Text, cboaction.SelectedValue)
                '    Session("msg") = "Kindly note that the above Reimbursement has been returned as Incomplete by the Medical assessor as per below comments"
            ElseIf cboaction.SelectedValue = "MI" Then
                UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET Mship_User='" & cbomship.SelectedValue & "',Mship_Issue=1,Mship_Date='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "', [Processed]=0 ,Inv_Status='MEMBERSHIP ISSUE'  where [File_No]= '" & lblfile.Text & "'")
                Session("msg") = "Kindly note that the above Reimbursement has a Policy issue and has been forwarded to :- '" & cbomship.SelectedValue & "'"
                MyDBAction.Claim_processing(lblfile.Text, CDate(Date.Now).ToString("yyyy-mm-dd"), Session("username"), lblenteredby.Text, txtcomment.Text, cboaction.SelectedValue)
                Session("email") = Nothing
                Str = "SELECT EMAIL FROM employees WHERE username='" & cbomship.SelectedValue & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    Session("email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                End If
            End If
            If txtcomment.Text <> "" Then
                MyDBAction.TRACKING_CLAIM_MESSAGES(lblfile.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
            End If
            Session("to") = lblenteredby.Text

            'MailSent = SendLoginDetails("Team", Session("email"), Session("cc_email"))

            lblerr.Text = "Saved Successfull!"
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            lblfile.Enabled = False
            dtreceive.Enabled = False
            dtservice.Enabled = False
            cboreason.SelectedValue = ""
            cboreason.Text = ""
            txtproposer.Text = ""
            lblfile.Text = ""
            cbotype.Text = ""
            txtmemno.Text = ""
            txtinv_no.Text = ""
            txtcomment.Text = ""
            txtinv_amt.Text = ""
            txtname.Text = ""
            txtinv_no.Text = ""
            txtinv_amt.Text = ""
            txtcomment.Text = ""
            txtinv_amt.Text = ""
            txtemail.Text = ""
            txtmobile.Text = ""
            txtbarcode.Text = ""
            load_Grid(lblfile.Text)
            loadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub btnupload_1_Click(sender As Object, e As System.EventArgs) Handles btnupload_1.Click

        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        'ltEmbed.Text = ""
        Try
            If lblfile.Text = "" Then
                lblerr.Text = "You must Select The file!"
                Exit Sub
            End If

            If FL2.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If cbodoc.Text = "" Then
                lblerr.Text = "You must Select Document title!"
                Exit Sub
            End If

            Dim filePath As String = FL2.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL2.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_File_DOC_LETTER(bytes, filename, contenttype, lblfile.Text, Trim(cbodoc.Text.ToUpper), CDate(Date.Now()).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), cbodoc.SelectedValue)
                'Response.Redirect(Request.Url.AbsoluteUri)


                LBLUPLOAD.ForeColor = System.Drawing.Color.Green

                LBLUPLOAD.Text = "File Uploaded Successfully"

            Else
                LBLUPLOAD.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            load_Grid(lblfile.Text)



        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    Protected Sub GDSEARCH_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GDSEARCH.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then

            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("Claim_Type")
            If myCell.Text = "Funeral" Then
                dataItem.BackColor = Drawing.Color.Red
            End If

        End If
    End Sub
End Class
