﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page

    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            'dttracked.DbSelectedDate = Date.Now()
            dtreceive.Enabled = False

            dtresolved.Enabled = False
            'dtservice.DbSelectedDate = Date.Now()

            '
            Try


                Str = ""
                Str = ""
                Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM  [dbo].[TBL_MIS_PROVIDER_MASTER] ORDER BY ORG_NAME" '"  
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboprovider
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                    .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                    .DataBind()
                End With
                Str = ""
                MyDatatable = Nothing

                Str = "SELECT Emp_code,EmployeeName FROM Employees where Department='CASE MANAGEMENT' and approved=1"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbocareManager
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                    .DataValueField = MyDatatable.Columns("Emp_code").ToString
                    .DataBind()
                End With

                Str = ""


                'Str = "SELECT Emp_Code,EmployeeName FROM Employees where Department='MEMBERSHIP' AND approved=1 ORDER BY EmployeeName" '"
                'MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                'With cbomembership
                '    .Items.Clear()
                '    .DataSource = MyDatatable
                '    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                '    .DataValueField = MyDatatable.Columns("Emp_Code").ToString
                '    .DataBind()
                'End With

                Session("ID") = Nothing
                Str = "SELECT Emp_code FROM Employees where username='" & Session("username") & "'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDatable.Rows.Count > 0 Then
                    Session("ID") = MyDatable.Rows(0).Item("Emp_code").ToString()

                End If
                'Session("ID") = "0547"
                loadGrid(Session("ID"))

            Catch ex As Exception

            End Try
        End If
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

        'ShowGridDetails()
    End Sub
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim tracked As Integer = 0
        Dim resolved As Integer = 0
        'Dim FILENO As String
        Dim app As Integer = 0
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim File_No As String = ""
        Dim File_Y As String = ""

        Dim Proposer_Name As String = ""
        Dim MyDatable_1 As New Data.DataTable
        Dim MailSent As Boolean = False
        Dim receivedate As String


        Try
            If cbostatus.SelectedValue = "Resolved" Then

                MySqlAction = "SELECT  FILE_NO FROM [MISREPORTS].[dbo].[TBL_MIS_IP_QUERIES] WITH (NOLOCK) where FILE_NO ='" & Trim(FILENO.Text) & "'"
                MyDataTable = TryCast(MyDBAction.DBAction(MySqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDataTable.Rows.Count > 0 Then
                    UpdateRecord("UPDATE [MISREPORTS].[dbo].TBL_MIS_IP_QUERIES SET STATUS='" & cbostatus.SelectedValue & "' where FILE_NO= '" & FILENO.Text & "'")
                End If
            End If
            STS = 1
            MyDBAction.RESOLVE_IP_CAREMANAGER(FILENO.Text, Trim(IDlbl.Text), cbostatus.SelectedValue, CDate(dtresolved.DbSelectedDate).ToString("yyyy-MM-dd"), txtcomment.Text, Session("username"), cboqueryto.SelectedValue, txtstaff.Text)
            lblerr.Text = "Updated Successfully!"

            If cboqueryto.SelectedValue <> "" And cbostatus.SelectedValue = "Open" Then
                Session("RecepientEmail") = Nothing
                If txtstaff.Text = "" Then
                    lblerr.Text = "Enter the name of staff!"
                    Exit Sub
                End If

                If cboqueryto.SelectedValue = "IT Query" Then
                    Session("RecepientEmail") = "IThelpdesk@aar.co.ke"
                    File_Y = txtstaff.Text

                ElseIf cboqueryto.SelectedValue = "Membership Query" Then
                    Session("RecepientEmail") = "Computer-operations@aar.co.ke"
                    File_Y = txtstaff.Text
                ElseIf cboqueryto.SelectedValue = "Retention" Then
                    Session("RecepientEmail") = "Relationship-Managers@aar.co.ke"
                    File_Y = txtstaff.Text
                End If
                'Session("RecepientEmail")=

                Str = ""
                MyDatable_1 = Nothing
                Str = "SELECT [FILE_NO],[MEMBER_NO],[PROVIDER_ID],[INVOICE_NO],[INVOICE_AMT],[SERVICE_DT],[RESOLVE_DT] FROM [MISREPORTS].[dbo].[TBL_MIS_IP_QUERIES] WITH (NOLOCK) WHERE File_No='" & FILENO.Text & "'"


                'Session("RecepientEmail") = "jmwaniki@aar.co.ke"


                If Not IsDBNull(Session("RecepientEmail")) Then
                    MyDatable_1 = Nothing
                    MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                    If MyDatable_1.Rows.Count > 0 Then

                        Session("FILE_NO") = MyDatable_1.Rows(0).Item("FILE_NO").ToString() ' row_("Proposer_Name").ToString() '& " " & " {" & CDate(RDDFROM.SelectedDate).ToString("yyyy-MM-dd") & "-" & CDate(RDDATETO.SelectedDate).ToString("yyyy-MM-dd") & "}" ' MyDatable.Rows(0).Item("USER_DISPLAY_NAME").ToString() ' 
                        Session("MEMBER_NO") = MyDatable_1.Rows(0).Item("MEMBER_NO").ToString() ' row_("File_No").ToString()
                        'Session("RECEIVE_DT") = MyDatable_1.Rows(0).Item("RECEIVE_DT").ToString() ' row_("File_No").ToString()
                        Session("SERVICE_DT") = MyDatable_1.Rows(0).Item("SERVICE_DT").ToString() ' row_("Card_Dis_Date").ToString()
                        Session("INVOICE_NO") = MyDatable_1.Rows(0).Item("INVOICE_NO").ToString() 'row_("Card_Dis_To").ToString()
                        Session("INVOICE_AMT") = MyDatable_1.Rows(0).Item("INVOICE_AMT").ToString()

                        Dim MynameIs As String = Session("Proposer_Name")

                        MynameIs = Replace(MynameIs, ".", "")

                        'MailSent = SendLoginDetails(File_Y, Session("RecepientEmail"))
                    End If

                    If Session("MailSent") = True Then
                        'MyDBAction.UPDATE_BUS_EMAIL(Session("File_No"), True)
                        Session("MailSent") = False

                    End If
                End If
                'Str_1 = "SELECT EmployeeName,Email FROM Employees WHERE Emp_Code='" & cborm.SelectedValue & "' "

                '------------------------------------------------------------------------------------------------------------------------------------

            End If

            loadGrid(Session("ID"))
            'loadGrid_OTH(Trim(IDlbl.Text))
            HiddenField1.Value = ""


            dtreceive.DbSelectedDate = Date.Now()

            cboprovider.Enabled = False

            cbocareManager.Enabled = False
            dtreceive.Enabled = False

            dtresolved.Enabled = False

            cboprovider.Text = ""

            cbocareManager.Text = ""
            dtreceive.DbSelectedDate = Date.Now()

            dtresolved.DbSelectedDate = Date.Now()

            txtcomment.Text = ""

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Public Sub loadGrid(ByVal ID As String)
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        'SqlAction = "SELECT [ID],[TENDER_NO],[BOOKING_DATE],[DUE_DATE_TIME],[CORPORATE_NAME] FROM [MISREPORTS].[dbo].[TBL_MIS_TENDER] WITH (NOLOCK) WHERE DUE_DATE_TIME >='" & Date.Now & "' and IS_ACTIVE=1"
        SqlAction = "SELECT MEMBER_NO, FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MGR_ID]   FROM [MISREPORTS].[dbo].[TBL_MIS_IP_OP_TRACKING] WHERE ACTIVE=1 AND STATUS<>'Resolved' and CLAIM_TYPE='IP' AND CARE_MGR_ID ='" & ID & "' ORDER BY ID DESC "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH] WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH]   WITH (NOLOCK) WHERE ACTIVE=1 AND   PROVIDER_NAME Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"
            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH]  WITH (NOLOCK) WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH]  WITH (NOLOCK) WHERE ACTIVE=1 AND   [MEMBER_NO] Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        txtcomment.Enabled = True
        'cbocareManager.Enabled = True

        dtreceive.Enabled = False

        dtresolved.Enabled = False
    End Sub


    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        cbocareManager.SelectedValue = ""
        cbocareManager.Text = ""
        lblerr.Text = ""

        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""


        Session("status_1") = Nothing
        SqlAction = "SELECT [ID],[FILE_NO],[RECEIVE_DT],QUERY_TO_NAME,QUERY_TO,[ALLOCATED_DT], [CARE_MGR_ID],[STATUS],[RESOLVE_DT],PROVIDER_NAME,[PROVIDER_ID],[COMMENT],BARCODE FROM [MISREPORTS].[dbo].[TBL_MIS_IP_OP_TRACKING] WITH (NOLOCK) WHERE ID ='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                IDlbl.Text = MyDatable.Rows(0).Item("ID").ToString()
                FILENO.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                cbostatus.SelectedValue = MyDatable.Rows(0).Item("STATUS").ToString()
                dtresolved.DbSelectedDate = MyDatable.Rows(0).Item("RESOLVE_DT").ToString()
                cboqueryto.SelectedValue = MyDatable.Rows(0).Item("QUERY_TO").ToString()
                txtstaff.Text = MyDatable.Rows(0).Item("QUERY_TO_NAME").ToString()
                cbocareManager.SelectedValue = MyDatable.Rows(0).Item("CARE_MGR_ID").ToString()
                cboprovider.SelectedValue = MyDatable.Rows(0).Item("PROVIDER_ID").ToString()
                txtProvider_Name.Text = MyDatable.Rows(0).Item("PROVIDER_NAME").ToString()
                lblbarcode.Text = MyDatable.Rows(0).Item("BARCODE").ToString()
                txtcomment.Text = MyDatable.Rows(0).Item("COMMENT").ToString()
                dtreceive.Enabled = False
                cbocareManager.Enabled = False
                cboprovider.Enabled = False
                txtcomment.Enabled = False
                txtProvider_Name.Enabled = False
                dtreceive.Enabled = False
                dtresolved.Enabled = False
            End If
            Session("DAD_5") = Nothing



        End If
    End Sub
    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub

    Protected Sub cbostatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbostatus.SelectedIndexChanged

        If cbostatus.SelectedValue = "Resolved" Then
            dtresolved.DbSelectedDate = Date.Now()
        Else
            dtresolved.DbSelectedDate = ""
        End If
    End Sub

End Class
