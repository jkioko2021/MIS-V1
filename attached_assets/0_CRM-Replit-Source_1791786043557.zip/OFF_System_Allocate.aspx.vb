﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                Session("to") = ""
                HiddenField1.Value = 0
                Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 AND Department='CLAIMS'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboallocate
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                    .DataValueField = MyDatatable.Columns("username").ToString
                    .DataBind()
                End With
                Str = "SELECT [Reason_Code],[Reason]  FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM_REASON] WHERE IS_ACTIVE=1" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboReason
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Reason").ToString
                    .DataValueField = MyDatatable.Columns("Reason_Code").ToString
                    .DataBind()
                End With
                LoadGrid()

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub


    Public Sub LoadGrid()
        SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=1 and [Indexed]=1 and Allocated=0 and Is_Active=1 AND Policy_Issue=0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub

    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsub.Click
        Try
            If txtname.Text = "" And cboaction.SelectedValue = "A" Then
                lblerr.Text = "Enter member name!"
                Exit Sub
            End If

            If txtmemno.Text = "" And cboaction.SelectedValue = "A" Then
                lblerr.Text = "Enter member Number!"
                Exit Sub
            End If

            If txtnotes.Text = "" Then
                lblerr.Text = "Enter short Notes!"
                Exit Sub
            End If
           
            If cboaction.SelectedValue = "A" Then
                If cboallocate.SelectedValue = "" Then
                    lblerr.Text = "Select the user!"
                    Exit Sub
                End If

                UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_OFF_SYSTEM]  SET  [Allocated]=1,[Allocated_To]='" & cboallocate.SelectedValue & "',[Allocate_Dt] ='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Inv_Status='ALLOCATED' where [Ref_No]= '" & lblcode.Text & "'")
                Session("msg") = "Kindly note that the above Off-System Documents have been  to you forwarded for Billing.See comments below!"
                Session("to") = cboallocate.Text
                'Session("email") = "aar-claims@aar.co.ke"
            ElseIf cboaction.SelectedValue = "M" Then
                UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_OFF_SYSTEM]  SET Policy_Issue=1,  [Allocate_Dt] ='" & CDate(Date.Now).ToString("yyyy-MM-dd hh:mm") & "',Inv_Status='MSHIP-ISSUE' where [Ref_No]= '" & lblcode.Text & "'")
                Session("msg") = "Kindly note that the above Off-System Documents have been forwarded to Membership to update membership No.See comments below!"
                Session("to") = "Membership Team"
                Session("email") = "computer-operations@aar.co.ke"

            ElseIf cboaction.SelectedValue = "R" Then
                UpdateRecord("UPDATE   [dbo].[TBL_MIS_CRM_OFF_SYSTEM]  SET  [Submitted]=0,[Indexed]=0, Inv_Status='RETURNED-INCOMPLETE'  where [Ref_No]= '" & lblcode.Text & "'")
                Session("msg") = "Kindly note that the above Off-System has been returned as incomplete.See comments below!"
                Session("email") = Session("email_")
                Session("cc_email") = ""
                Session("to") = enteredby
            End If
            MyDBAction.TRACKING_OFF_SYSTEM_MESSAGES(lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd hh:mm"), txtnotes.Text)
            'Session("email") = "jmwaniki@aar.co.ke"

            MailSent = SendLoginDetails(Session("to"), Session("email"), Session("cc_email"))
            lblerr.Text = "Submitted Successfull"
            LoadGrid()
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            ltEmbed.Text = ""
            txtmemno.Text = ""
            txtname.Text = ""
            txtprop.Text = ""
            txtbar.Text = ""
            txtnotes.Text = ""
            ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            HiddenField1.Value = 1
            Dim code As Integer = 0
            Session("email") = ""
            lblcode.Text = ""
            ltEmbed.Text = ""
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()

            code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()

            'code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],Mobile_No,[Member_Name],[Proposer_Name],Invoice_no,Invoice_Amt,Bar_Code, [Provider_ID],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status],Reason  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Id]='" & code & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then

                lblcode.Text = MyDatatable.Rows(0).Item("Ref_No").ToString()
                txtmemno.Text = MyDatatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatatable.Rows(0).Item("Proposer_Name").ToString()
                txtmobile.Text = MyDatatable.Rows(0).Item("Mobile_No").ToString()
                txtamt.Text = MyDatatable.Rows(0).Item("Invoice_Amt").ToString()
                txtinv.Text = MyDatatable.Rows(0).Item("Invoice_no").ToString()
                txtbar.Text = MyDatatable.Rows(0).Item("Bar_Code").ToString()
                cboReason.SelectedValue = MyDatatable.Rows(0).Item("Reason").ToString()
                cboclaimtype.SelectedValue = MyDatatable.Rows(0).Item("Off_Type").ToString()
                load_Grid(lblcode.Text)

                Str = "SELECT EMAIL FROM employees WHERE username='" & cboallocate.Text & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    Session("email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                End If
                Str = "SELECT EMAIL FROM employees WHERE username='" & enteredby.Text & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    Session("email_") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                End If

            End If


            lblcode.Enabled = False
            'txtmemno.Enabled = False
            'txtname.Enabled = False
            'txtprop.Enabled = False
            cboReason.Enabled = False
            'txtmobile.Text = False
            txtinv.Enabled = False
            txtamt.Enabled = False
            cboclaimtype.Enabled = False

        Catch ex As Exception
            lblcode.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDMEMBER.NeedDataSource

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        If cbosearch.SelectedValue = "M" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=1 and [Indexed]=1 AND Member_No LIKE '%" & txtsearch.Text & "%'"

        ElseIf cbosearch.SelectedValue = "N" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=1 and [Indexed]=1 AND Member_Name LIKE '%" & txtsearch.Text & "%'"

        ElseIf cbosearch.SelectedValue = "R" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=1 and [Indexed]=1 AND Ref_No LIKE '%" & txtsearch.Text & "%'"

        End If
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub



    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[Ref_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_OFF_SYS_DOCS] WHERE  Ref_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = Nothing
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[Ref_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM_NOTES] WHERE  Ref_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "OFF-SYSTEM PROCESSING" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "OFF-SYSTEM:" & txtname.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear, " & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Ref No:" & lblcode.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Member Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtnotes.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/Off_Smart.ashx?Id="), id)
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try

            UpdateRecord("UPDATE   [dbo].[TBL_MIS_CRM_OFF_SYSTEM]  SET   [Member_No]='" & Trim(txtmemno.Text.ToUpper) & "',[Mobile_No]='" & Trim(txtmobile.Text) & "',[Member_Name]='" & Trim(txtname.Text.ToUpper) & "',[Proposer_Name]='" & Trim(txtprop.Text.ToUpper) & "'   where [Ref_No]= '" & lblcode.Text & "'")
            lblerr.Text = "Updated Successfull"

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
