﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            Str = "SELECT DISTINCT [Code],[Descr] FROM [dbo].[TBL_MIS_REIMB_REASONS] WHERE ACTIVE=1" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboreason
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Descr").ToString
                .DataValueField = MyDatatable.Columns("Code").ToString
                .DataBind()
            End With


            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""
        Try


            cboreason.SelectedValue = ""
            cboreason.Text = ""
            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT  [ID],[FILE_NO],[RECEIVE_DT],[SERVICE_DT],[CLAIM_TYPE],[MEMBER_NO],MEMBER_NAME,[INVOICE_NO],[INVOICE_AMT],REASON,PROPOSER,email,Mobile_no,entered_By  FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) WHERE File_No ='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                dtservice.DbSelectedDate = MyDatable.Rows(0).Item("SERVICE_DT").ToString()
                txtmobile.Text = MyDatable.Rows(0).Item("Mobile_no").ToString()
                cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                txtmemno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                txtemail.Text = MyDatable.Rows(0).Item("email").ToString()
                cboreason.SelectedValue = MyDatable.Rows(0).Item("REASON").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER").ToString()
                lblenteredby.Text = MyDatable.Rows(0).Item("entered_By").ToString()
                load_Grid(lblfile.Text)


                txtproposer.Enabled = False
                lblfile.Enabled = False
                dtreceive.Enabled = False
                dtservice.Enabled = False

                'txtbarcode.Enabled = False
                cbotype.Enabled = False
                txtmemno.Enabled = False

                txtinv_no.Enabled = False
                'txtcomment.Enabled = False
                txtinv_amt.Enabled = False

                txtname.Enabled = False
                txtinv_no.Enabled = False

                txtinv_amt.Enabled = False
                'txtcomment.Enabled = False


                txtinv_amt.Enabled = False

                cboreason.Enabled = False
            Else
                SqlAction = "SELECT  [ID],[FILE_NO],[RECEIVE_DT],[SERVICE_DT],[CLAIM_TYPE],[MEMBER_NO],MEMBER_NAME,[INVOICE_NO],[INVOICE_AMT],REASON,PROPOSER,email,Mobile_no,entered_By  FROM  [MISREPORTS].[dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) WHERE File_No ='" & ID & "'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then

                    'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                    dtservice.DbSelectedDate = MyDatable.Rows(0).Item("SERVICE_DT").ToString()
                    txtmobile.Text = MyDatable.Rows(0).Item("Mobile_no").ToString()
                    cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                    txtmemno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                    txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                    txtemail.Text = MyDatable.Rows(0).Item("email").ToString()
                    cboreason.SelectedValue = MyDatable.Rows(0).Item("REASON").ToString()
                    txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER").ToString()
                    lblenteredby.Text = MyDatable.Rows(0).Item("entered_By").ToString()
                    load_Grid(lblfile.Text)


                    txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False
                    dtservice.Enabled = False

                    'txtbarcode.Enabled = False
                    cbotype.Enabled = False
                    txtmemno.Enabled = False

                    txtinv_no.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False

                    txtname.Enabled = False
                    txtinv_no.Enabled = False

                    txtinv_amt.Enabled = False
                    'txtcomment.Enabled = False


                    txtinv_amt.Enabled = False

                    cboreason.Enabled = False

                End If
            End If

            Session("DAD_5") = Nothing


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,Allocate_to FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%' and active=1"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,Allocate_to FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%'   and active=1"
            ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,Allocate_to FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%'  and active=1"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,Allocate_to FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%'  and active=1"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                If cbosearch.SelectedValue = "I" Then
                    SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM [MISREPORTS].[dbo].[TBL_MIS_REIMB_TRACKING] WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%'"

                ElseIf cbosearch.SelectedValue = "M" Then
                    SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM [MISREPORTS].[dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%'"
                ElseIf cbosearch.SelectedValue = "F" Then
                    SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM [MISREPORTS].[dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%'"

                End If

                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDSEARCH.DataSource = MyDatable
                    GDSEARCH.DataBind()
                    Session("DAD_5") = MyDatable
                    MyDatable = Nothing
                Else
                    GDSEARCH.DataSource = MyDatable
                    GDSEARCH.DataBind()
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub


    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/File_Claims.ashx?Id="), id)
    End Sub

    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub
End Class
