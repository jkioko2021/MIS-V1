﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="IP_Claim_case_allocate.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="IP CLAIM DISCHARGE"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1183px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 2881px">
                                        &nbsp;</td>
                                    <td style="width: 2073px">
                                        &nbsp;</td>
                                    <td style="width: 2881px">
                                        <asp:CheckBox ID="chkdate" runat="server" Text="Discharge Date" />
                                        &nbsp;<asp:CheckBox ID="chkprov" runat="server" Text="Provider" />
                                        &nbsp;<asp:CheckBox ID="chkcare" runat="server" Text="Care Manager" />
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 2881px">
                                        &nbsp;</td>
                                    <td style="width: 2073px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Date From"></asp:Label>
                                    </td>
                                    <td style="width: 2881px">
                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 2881px">
                                        &nbsp;</td>
                                    <td style="width: 2073px">
                                        <asp:Label ID="Label160" runat="server" style="font-weight: 700" Text="Date To"></asp:Label>
                                    </td>
                                    <td style="width: 2881px">
                                        <telerik:RadDatePicker ID="dtto" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 2881px">
                                        &nbsp;</td>
                                    <td style="width: 2073px">
                                        <asp:Label ID="Label162" runat="server" style="font-weight: 700" 
                                            Text="Care manager"></asp:Label>
                                    </td>
                                    <td style="width: 2881px">
                                        <telerik:RadComboBox ID="cbocare" Runat="server" Skin="Simple" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 2881px">
                                        &nbsp;</td>
                                    <td style="width: 2073px">
                                        <asp:Label ID="Label161" runat="server" style="font-weight: 700" 
                                            Text="Provider Name"></asp:Label>
                                    </td>
                                    <td style="width: 2881px">
                                        <telerik:RadTextBox ID="txtprovider" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 2881px">
                                        &nbsp;</td>
                                    <td style="width: 2073px">
                                        &nbsp;</td>
                                    <td style="width: 2881px">
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1196px">
                            <table style="width: 97%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1190px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" 
                                                Width="100%" PageSize="20">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                     <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="20px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                         <telerik:GridTemplateColumn DataType="System.Boolean" UniqueName="Updated">
                                        <ItemTemplate>
                                            <asp:CheckBox ID="chkreturn" runat="server" AutoPostBack="True" 
                                                OnCheckedChanged="ToggleRowSelection" />
                                        </ItemTemplate>
                                        <HeaderTemplate>
                                            <asp:CheckBox ID="chkheader" runat="server" AutoPostBack="True" 
                                                OnCheckedChanged="ToggleSelectedState" />
                                        </HeaderTemplate>
                                    </telerik:GridTemplateColumn>
                                    
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>

                                                            <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                            SortExpression="File_No" UniqueName="File_No">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Service_dt" 
                                                            FilterControlAltText="Filter Service_dt column" HeaderText="Service_dt" 
                                                            SortExpression="Service_dt" UniqueName="Service_dt">
                                                        </telerik:GridBoundColumn>
                                                          
                                                            <telerik:GridBoundColumn DataField="Memb_Disch_dt" 
                                                            FilterControlAltText="Filter Memb_Disch_dt column" HeaderText="Memb_Disch_dt" 
                                                            SortExpression="Memb_Disch_dt" UniqueName="Memb_Disch_dt">                                                       
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Discharge_DT" 
                                                            FilterControlAltText="Filter Discharge_DT column" HeaderText="Care_Dis_DT" 
                                                            SortExpression="Discharge_DT" UniqueName="Discharge_DT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                          
                                                        <telerik:GridBoundColumn DataField="Invoice_No" 
                                                            FilterControlAltText="Filter Invoice_No column" HeaderText="Invoice_No" 
                                                            SortExpression="Invoice_No" UniqueName="Invoice_No">
                                                            </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Invoice_Amt" DataFormatString="{0:###,##0.0}" 
                                                            FilterControlAltText="Filter Invoice_Amt column" HeaderText="Invoice_Amt" 
                                                            SortExpression="Invoice_Amt" UniqueName="Invoice_Amt">                                                       
                                                        </telerik:GridBoundColumn>
                                                              <telerik:GridBoundColumn DataField="Provider_Name" 
                                                            FilterControlAltText="Filter Provider_Name column" HeaderText="Provider_Name" 
                                                            SortExpression="Provider_Name" UniqueName="Provider_Name">                                                           
                                                        </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Care_Manager" 
                                                            FilterControlAltText="Filter Care_Manager column" HeaderText="Care_Manager" 
                                                            SortExpression="Care_Manager" UniqueName="Care_Manager" ItemStyle-Wrap="False">
                                                                     <ItemStyle Wrap="False" />
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Inv_Status" 
                                                            FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
                                                            SortExpression="Inv_Status" UniqueName="Inv_Status">                                                       
                                                        </telerik:GridBoundColumn>
                                                       
                                                    
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        &nbsp;</td>
                                    <td style="width: 272px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        <asp:Label ID="lblfile" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr style="width: 1194px" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel32" runat="server" Height="100%" Width="1130px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1100px">
                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                            SortExpression="DOC_ID">
                                                                            <ItemTemplate>
                                                                                <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                    CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                            </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                            ScrollBars="Horizontal" Width="1100px">
                                                            <asp:Literal ID="ltEmbed" runat="server" />
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 13px; width: 169px;">
                                        <asp:Label ID="Label152" runat="server" style="font-weight: 700" 
                                            Text="Allocate To"></asp:Label>
                                    </td>
                                    <td style="height: 13px; width: 272px;">
                                        <telerik:RadComboBox ID="cboallocate" Runat="server" Skin="Simple" 
                                            Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 166px; height: 13px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 13px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 13px; width: 169px;">
                                        <asp:Label ID="Label121" runat="server" style="font-weight: 700" 
                                            Text="Comments"></asp:Label>
                                    </td>
                                    <td style="height: 13px; width: 272px;">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 166px; height: 13px;">
                                    </td>
                                    <td style="width: 287px; height: 13px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3" style="height: 39px">
                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="70px" Rows="1" 
                                            Skin="Sunset" TextMode="MultiLine" Width="450px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td style="width: 287px; height: 39px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2" style="height: 39px">
                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Save" 
                                            Width="150px">
                                        </telerik:RadButton>
                                        <asp:Label ID="lblerr_1" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 166px; height: 39px;">
                                        <telerik:RadButton ID="RadButton2" runat="server" Text="Export To Excel">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 287px; height: 39px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1190px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" ItemStyle-Wrap ="True"
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes"> 
                                                            <ItemStyle Wrap="True" />
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
      
    </asp:UpdatePanel>
</asp:Content>


