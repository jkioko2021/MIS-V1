﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    'Dim empcode As String = ""
    Dim AB As Integer
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            HiddenField1.Value = ""
            Session("DAD_5_X") = Nothing
            dtsubmit.DbSelectedDate = Date.Now
            SqlAction = "SELECT CR_No, [CR_Name],[CR_dt],[CR_Status],[Entered_by],[Entry_Date],[CR_priority],System   FROM [dbo].[TBL_MIS_TASK_CR] Where CR_Status='O' AND ACTIVE=1"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_TASKS.DataSource = MyDatable
                GD_TASKS.DataBind()
                Session("DAD_5_X") = MyDatable
                MyDatable = Nothing
            Else
                GD_TASKS.DataSource = MyDatable
                GD_TASKS.DataBind()
            End If
          
        End If
    End Sub
    Protected Sub SEARCH_Click(sender As Object, e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDatable As New Data.DataTable
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT CR_No, [CR_Name],[CR_dt],[CR_Status],[Entered_by],[Entry_Date],[CR_priority],System  FROM [dbo].[TBL_MIS_TASK_CR] Where CR_Name Like '%" & Trim(cbotext.Text) & "%' AND ACTIVE=1"

            ElseIf cbosearch.SelectedValue = "T" Then
                SqlAction = "SELECT CR_No, [CR_Name],[CR_dt],[CR_Status],[Entered_by],[Entry_Date],[CR_priority],System   FROM [dbo].[TBL_MIS_TASK_CR] Where CR_NO Like '%" & Trim(cbotext.Text) & "%' AND ACTIVE=1"
            ElseIf cbosearch.SelectedValue = "S" Then
                SqlAction = "SELECT CR_No, [CR_Name],[CR_dt],[CR_Status],[Entered_by],[Entry_Date],[CR_priority],System   FROM [dbo].[TBL_MIS_TASK_CR] Where System Like '%" & Trim(cbotext.Text) & "%' AND ACTIVE=1"

            Else
                lblerr.Text = "Enter Value ot Search"
                Exit Sub
            End If

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_TASKS.DataSource = MyDatable
                GD_TASKS.DataBind()
                Session("DAD_5_X") = MyDatable
                MyDatable = Nothing
            Else
                GD_TASKS.DataSource = MyDatable
                GD_TASKS.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub loadgrid(ByVal Task_code As String)
        MyDatable = Nothing
        SqlAction = "SELECT [DOC_ID],[CR_NO],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CR_DOCS] WHERE  CR_No ='" & Task_code & "' AND ACTIVE=1"

        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
            MyDatable = Nothing
        Else
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
        End If

    End Sub

    Protected Sub GD_TASKS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_TASKS.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""

            HiddenField1.Value = (DirectCast(GD_TASKS.SelectedItems(0), GridDataItem)).GetDataKeyValue("CR_No").ToString()
            SqlAction = "SELECT [CR_No],[CR_Name],[CR_dt],CR_Status,[CR_Description]  FROM [dbo].[TBL_MIS_TASK_CR] WHERE  CR_No ='" & HiddenField1.Value & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lbltaskno.Text = MyDatable.Rows(0).Item("CR_No").ToString()
                txtdescr.Text = MyDatable.Rows(0).Item("CR_Description").ToString()
                stst = MyDatable.Rows(0).Item("CR_Status").ToString()
                txtdescr.Enabled = False
                txttitle.Enabled = False
                loadgrid(lbltaskno.Text)
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_TASKS_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_TASKS.PageIndexChanged
        GD_TASKS.CurrentPageIndex = e.NewPageIndex
        GD_TASKS.DataSource = Session("DAD_5_X")
        GD_TASKS.DataBind()
    End Sub


    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        Try
            ltEmbed.Text = ""
            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If txttitle.Text = "" Then
                lblerr.Text = "You must enter Document title!"
                Exit Sub
            End If

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            'Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))
            Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))
            Dim app As Integer = 0

            Select Case ext
                Case ".pdf"
                    contenttype = "application/pdf"
                Case ".PDF"
                    contenttype = "application/PDF"
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case Else
                    lblerr.Text = "You must upload a pdf format!"
                    Exit Sub
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_CR_DOCS(bytes, filename, contenttype, lbltaskno.Text, Trim(txttitle.Text.ToUpper), CDate(dtsubmit.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), DOC_ID.Text)
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblerr.ForeColor = System.Drawing.Color.Green

                lblerr.Text = "File Uploaded Successfully"

            Else
                lblerr.Text = "File format not recognised." + " Upload Image/Word/PDF/Excel formats"
            End If
            loadgrid(lbltaskno.Text)

            DOC_ID.Text = ""
            lbltaskno.Text = ""
            txttitle.Text = ""
            dtsubmit.DbSelectedDate = Date.Now

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub View(ByVal sender As Object, ByVal e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "File not Found!"
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileCR.ashx?Id="), id)
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub


    Protected Sub cbosearch_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbosearch.SelectedIndexChanged
        cbotext.Items.Clear()
        If cbosearch.SelectedValue = "S" Then
            Str = "SELECT SYSTEM_NAME,SYSTEM_NAME FROM [TBL_MIS_TASK_SYSTEM]"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbotext
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("SYSTEM_NAME").ToString
                .DataValueField = MyDatatable.Columns("SYSTEM_NAME").ToString
                .DataBind()
            End With
        Else
            cbotext.Items.Clear()
        End If
    End Sub



    Protected Sub GD_DOCS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_DOCS.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""
            ltEmbed.Text = ""
            HiddenField1.Value = (DirectCast(GD_DOCS.SelectedItems(0), GridDataItem)).GetDataKeyValue("DOC_ID").ToString()
            SqlAction = "SELECT [DOC_ID],[CR_NO],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CR_DOCS] WHERE  DOC_ID ='" & HiddenField1.Value & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txttitle.Text = MyDatable.Rows(0).Item("Doc_Title").ToString()
                DOC_ID.Text = MyDatable.Rows(0).Item("DOC_ID").ToString()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_DOCS_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GD_DOCS.NeedDataSource

    End Sub
End Class
