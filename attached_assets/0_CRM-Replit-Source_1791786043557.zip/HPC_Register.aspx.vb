﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                dtdx.DbSelectedDate = Date.Now()
                dtafollow.DbSelectedDate = DateAdd(DateInterval.Month, 1, Date.Now())
             
                Str = "SELECT DISTINCT [Code],[Name]  FROM [dbo].[TBL_MIS_CRM_HPC_DISEASES] ORDER BY Name asc" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbocomor
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Name").ToString
                    .DataValueField = MyDatatable.Columns("Code").ToString
                    .DataBind()
                End With

                Str = " SELECT  [Src_Code],[Src_Name] FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_SOURCE]" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbosrc
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Src_Code").ToString
                    .DataValueField = MyDatatable.Columns("Src_Name").ToString
                    .DataBind()
                End With

                Session("empcode") = Nothing
                Session("agentemail") = Nothing

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL], POLICY_STATUS FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE MEMBER_NAME  LIKE '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME,[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL], POLICY_STATUS FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO like '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDMEMBER.DataSource = Nothing
                GDMEMBER.DataBind()
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
            number = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],GRP_INDV FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO ='" & number & "' order by DISPLAY_MEMBERSHIP_NO"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Member_No='" & txtmemno.Text & "'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDCASE.DataSource = MyDatable
                    GDCASE.DataBind()
                    MyDatable = Nothing
                    HiddenField1.Value = 0
                    cmdsave.Enabled = False
                    lblerr.Text = "Member Already Registered!"

                Else
                    txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                    txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                    cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()
                    txtemail.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_EMAIL").ToString()
                    txtmobile.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()
                End If
              



            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Generate_Task()
        SqlAction = "SELECT ISNULL((MAX(Code_Id)+1),1) NUMBER FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_TRACKING]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblcode.Text = "HPC" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub
    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim adm_status As String = ""
            Dim case_status As String = ""
            Dim updated As Integer = 1
            HiddenField1.Value = 0
            lblerr.Text = ""
            If txtname.Text = "" Then
                lblerr.Text = "You Must Enter the Member name"
                Exit Sub
            End If
            If txtprop.Text = "" Then
                lblerr.Text = "You Must Enter the Proposer name"
                Exit Sub
            End If
            If cboclient.SelectedValue = "" Then
                lblerr.Text = "You Must Select Client Type"
                Exit Sub
            End If

            If HiddenField1.Value = 0 Then
                If chkupdate.Checked = True Then
                    Generate_Task()
                    updated = 0
                Else
                    lblcode.Text = Trim(txtmemno.Text)
                    updated = 1
                End If

                If lblcode.Text = "" Then
                    lblerr.Text = "Enter Membership No!"
                    Exit Sub
                End If

                MyDBAction.HPC_reg(lblcode.Text, Trim(txtname.Text), Trim(txtprop.Text), cboclient.SelectedValue, Trim(txtother.Text), Trim(txtmobile.Text), Trim(txtemail.Text), CDate(dtafollow.DbSelectedDate).ToString("yyyy-MM-dd"), Session("UserName").ToString, 0, updated, cbosrc.SelectedValue)
            Else
                MyDBAction.HPC_reg(lblcode.Text, Trim(txtname.Text), Trim(txtprop.Text), cboclient.SelectedValue, Trim(txtother.Text), Trim(txtmobile.Text), Trim(txtemail.Text), CDate(dtafollow.DbSelectedDate).ToString("yyyy-MM-dd"), Session("UserName").ToString, 1, updated, cbosrc.SelectedValue)
            End If

            If txtnotes.Text <> "" Then
                MyDBAction.TRACKING_HPC_MESSAGES(lblcode.Text, cbocomor.SelectedValue, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text, "NOTES")
            End If
            If cbocomor.SelectedValue <> "" Then
                MyDBAction.TRACKING_HPC_COMORB(CDate(dtdx.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, lblcode.Text, Session("username"), CDate(dtdx.DbSelectedDate).ToString("yyyy-MM-dd"), Trim(txtother.Text), Trim(txtother.Text))
            End If

            Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Member_No='" & lblcode.Text & "'"
            'Str = "SELECT [Case_No] ,[Admission_Dt],[Member_No],[Transfer_To_Provider],[Admission_Status],[Case_Status],[Pre_Auth_Amt],[Entered_by],[Entry_date]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Member_No='" & txtmemno.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE.DataSource = MyDatable
                GDCASE.DataBind()
            End If
            lblerr.Text = "Saved Successfully.."

            HiddenField1.Value = 0
            lblcode.Text = ""
            txtnotes.Text = ""
            dtdx.DbSelectedDate = Date.Now()
            cbocomor.SelectedValue = ""
            txtname.Text = ""
            txtmemno.Text = ""
            txtprop.Text = ""
            txtemail.Text = ""
            txtmobile.Text = ""
            cboclient.SelectedValue = ""
            txtother.Text = ""

            lblcode.Enabled = True
            txtnotes.Enabled = True
            dtdx.Enabled = True
            cbocomor.Enabled = True
            txtname.Enabled = True
            txtmemno.Enabled = True
            txtprop.Enabled = True
            cboclient.Enabled = True
            txtother.Enabled = True

            cmdsave.Enabled = True
            cmdsave.Enabled = True

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
 
End Class
