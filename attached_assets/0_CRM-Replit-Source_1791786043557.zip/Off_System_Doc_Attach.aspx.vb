﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0

                HiddenField1.Value = 0

                Str = "SELECT  [Doc_Code],[Doc_Name]  FROM [CRM].[dbo].[TBL_MIS_REIMB_REQUIREMENTS] where Doc_Code IN ('DOC_R08','DOC_R04','DOC_R02','DOC_R09')"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With chklist
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Doc_Name").ToString
                    .DataValueField = MyDatatable.Columns("Doc_Code").ToString
                    .DataBind()
                End With
                LoadGrid()

                '

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
 
  
    Public Sub LoadGrid()
        SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 and Is_Active=1 AND Entered_By='" & Session("username") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub

    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsub.Click
        Try
            If txtname.Text = "" Then
                lblerr.Text = "Enter member name!"
                Exit Sub
            End If
            If txtmobile.Text = "" And cboclaimtype.SelectedValue = "M" Then
                lblerr.Text = "Enter mobile No."
                Exit Sub
            End If
            If txtnotes.Text = "" Then
                lblerr.Text = "Enter short Notes!"
                Exit Sub
            End If

            SqlAction = "SELECT  File_Name FROM [Doc_Arc_DB].[dbo].[TBL_MIS_OFF_SYS_DOCS] WHERE Ref_No='" & lblcode.Text & "' AND ACTIVE=1 AND Upload_Done=0"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                lblerr.Text = "You must upload the Missing Documents!"
                Exit Sub
            Else
                UpdateRecord("UPDATE   [dbo].[TBL_MIS_CRM_OFF_SYSTEM]  SET [Submitted]=1, [Submit_Dt]='" & CDate(Date.Now).ToString("yyyy-MM-dd hh:mm") & "',[Submit_By]='" & Session("username") & "',  Inv_Status='SUBMITTED'  where [Ref_No]= '" & lblcode.Text & "'")
                MyDBAction.TRACKING_OFF_SYSTEM_MESSAGES(lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd hh:mm"), txtnotes.Text)
                Session("msg") = "Kindly note that the above Off-System Documents have been Received and  forwarded for scanning.See comments below!"

                Session("to") = "DPU Team"

                'Session("email") = "aar-claims@aar.co.ke"
                'Session("email") = "jmwaniki@aar.co.ke"
                'Session("cc_email") = ""
                'Session("Header") = "Submitted-" & txtproposer.Text
                'MailSent = SendLoginDetails("Team", Session("email"), Session("cc_email"))
                lblerr.Text = "Submitted Successfull"

            End If
            LoadGrid()
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            txtmemno.Text = ""
            txtname.Text = ""
            txtprop.Text = ""

            txtnotes.Text = ""


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            HiddenField1.Value = 1
            Dim code As Integer = 0

            lblcode.Text = ""
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()

            code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()

            'code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],Mobile_No,[Member_Name],[Proposer_Name],[Provider_ID],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Id]='" & code & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then

                lblcode.Text = MyDatatable.Rows(0).Item("Ref_No").ToString()
                txtmemno.Text = MyDatatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatatable.Rows(0).Item("Proposer_Name").ToString()
                txtmobile.Text = MyDatatable.Rows(0).Item("Mobile_No").ToString()
                cboclaimtype.SelectedValue = MyDatatable.Rows(0).Item("Off_Type").ToString()

                load_Grid(lblcode.Text)
                SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_OFF_SYS_DOCS] WHERE  Ref_No ='" & lblcode.Text & "' and Active=1"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                chklist.ClearSelection()
                For Each dt2_row As System.Data.DataRow In MyDatable.Rows
                    Dim IT As String = dt2_row("Doc_code").ToString()
                    For i As Integer = 0 To chklist.Items.Count - 1
                        If chklist.Items(i).Value = IT Then
                            chklist.Items(i).Selected = True
                        End If
                    Next

                Next
            End If

       
            
        Catch ex As Exception
            lblcode.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDMEMBER.NeedDataSource

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        If cbosearch.SelectedValue = "M" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 AND Member_No LIKE '%" & txtsearch.Text & "%'"

        ElseIf cbosearch.SelectedValue = "N" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 AND Member_Name LIKE '%" & txtsearch.Text & "%'"

        ElseIf cbosearch.SelectedValue = "R" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 AND Ref_No LIKE '%" & txtsearch.Text & "%'"

        End If
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub

    Protected Sub cmdsave0_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
         
            If lblcode.Text = "" Then
                lblerr.Text = "You Must select the Claim To attach documents!"
                Exit Sub
            End If
            For Each MyItem In chklist.Items
                If MyItem.Selected = True Then
                    MyDBAction.UPLOAD_OFF_SMART(lblcode.Text, MyItem.value, MyItem.TEXT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"))
                    lblerr.Text = "Saved Successfully!"
                    HiddenField1.Value = ""
                End If
            Next
            load_Grid(lblcode.Text)
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If txttitle.Text = "" Then
                lblerr.Text = "You must select Document name!"
                Exit Sub
            End If

            If lblcode.Text = "" Then
                lblerr.Text = "You must enter Select the claim!"
                Exit Sub
            End If
            If Trim(txttitle.Text) = "Provider Invoice" Then
                If txtamt.Text = 0 Then
                    lblerr.Text = "You must enter enter Invoice Amount!"
                    Exit Sub
                End If
               
            End If

           

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".jpeg"
                    contenttype = "image/jpeg"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_Off_Smart_File_CLAIMS(bytes, filename, contenttype, lblcode.Text, Trim(txttitle.Text.ToUpper), CDate(Date.Now()).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), DOC_ID.Text)
                'Response.Redirect(Request.Url.AbsoluteUri)
                UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_OFF_SYSTEM]  SET  [Invoice_no]= '" & txtinv.Text & "',[Invoice_Amt]='" & txtamt.Text & "'  where [Ref_No]= '" & lblcode.Text & "'")

                lblupload.ForeColor = System.Drawing.Color.Green
                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            load_Grid(lblcode.Text)

            DOC_ID.Text = ""
            'lbltaskno.Text = ""
            txttitle.Text = ""


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[Ref_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_OFF_SYS_DOCS] WHERE  Ref_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = Nothing
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[Ref_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM_NOTES] WHERE  Ref_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "OFF-SYSTEM PROCESSING" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "OFF-SYSTEM:" & txtname.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear, " & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Ref No:" & lblcode.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Member Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtnotes.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

 

    Protected Sub GD_DOCS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_DOCS.SelectedIndexChanged
        Try
            Dim stst As String = ""

            'ltEmbed.Text = ""
            stst = (DirectCast(GD_DOCS.SelectedItems(0), GridDataItem)).GetDataKeyValue("DOC_ID").ToString()
            SqlAction = "SELECT [DOC_ID],[Ref_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM  [Doc_Arc_DB].[dbo].[TBL_MIS_OFF_SYS_DOCS] WHERE  DOC_ID ='" & stst & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txttitle.Text = MyDatable.Rows(0).Item("Doc_Title").ToString()
                DOC_ID.Text = MyDatable.Rows(0).Item("DOC_ID").ToString()
            End If
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDMEMBER_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDMEMBER.PageIndexChanged
        GDMEMBER.CurrentPageIndex = e.NewPageIndex
        GDMEMBER.DataSource = Session("MEM_01")
        GDMEMBER.DataBind()
    End Sub
End Class
