﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retail_Renewal_Loading.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%" align="center">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="2">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="RETAIL DATA LOADING"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1196px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 757px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label2" runat="server" Text="Period From"></asp:Label>
                                    </td>
                                    <td style="width: 273px">
                                        <telerik:RadDatePicker ID="DTEXTRFROM" Runat="server" Enabled="False" 
                                            Skin="Sunset">
                                            <calendar skin="Sunset" usecolumnheadersasselectors="False" 
                                                userowheadersasselectors="False" viewselectortext="x">
                                            </calendar>
                                            <dateinput dateformat="dd/MM/yyyy" displaydateformat="dd/MM/yyyy">
                                            </dateinput>
                                            <datepopupbutton hoverimageurl="" imageurl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 757px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label198" runat="server" Text="Period To"></asp:Label>
                                    </td>
                                    <td style="width: 273px">
                                        <telerik:RadDatePicker ID="DTEXTRACTTO" Runat="server" Enabled="False" 
                                            Skin="Sunset">
                                            <calendar skin="Sunset" usecolumnheadersasselectors="False" 
                                                userowheadersasselectors="False" viewselectortext="x">
                                            </calendar>
                                            <dateinput dateformat="dd/MM/yyyy" displaydateformat="dd/MM/yyyy">
                                            </dateinput>
                                            <datepopupbutton hoverimageurl="" imageurl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 757px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label205" runat="server" Text="Policy Code"></asp:Label>
                                    </td>
                                    <td style="width: 273px">
                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="btnsubmit2" runat="server" Skin="Simple" Text="View">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td>
                        <asp:Panel ID="Panel4" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1200px">
                            <table style="width: 100%">
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="Label206" runat="server" style="font-weight: 700" 
                                            Text="Policy Loading"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel37" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH_3" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Policy_Code">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Policy_Code" 
                                                            FilterControlAltText="Filter Policy_Code column" HeaderText="Policy_Code" 
                                                            SortExpression="Policy_Code" UniqueName="Policy_Code">
                                                        </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="Policy_Type" 
                                                            FilterControlAltText="Filter Policy_Type column" HeaderText="Policy_Type" 
                                                            SortExpression="Policy_Type" UniqueName="Policy_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Start_Date" 
                                                            FilterControlAltText="Filter Start_Date column" HeaderText="Start_Date" 
                                                            SortExpression="Start_Date" UniqueName="Start_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="End_Date" 
                                                            FilterControlAltText="Filter End_Date column" HeaderText="End_Date" 
                                                            SortExpression="End_Date" UniqueName="End_Date">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="Data_Date" 
                                                            FilterControlAltText="Filter Data_Date column" HeaderText="Data_Date" 
                                                            SortExpression="Data_Date" UniqueName="Data_Date">
                                                        </telerik:GridBoundColumn>
                                                 
                                                        <telerik:GridBoundColumn DataField="Annual_Premium" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Annual_Premium column" 
                                                            HeaderText="Annual_Premium" ItemStyle-Wrap="False" 
                                                            SortExpression="Annual_Premium" UniqueName="Annual_Premium">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Earned_Premium" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Earned_Premium column" 
                                                            HeaderText="Earned_Premium" SortExpression="Earned_Premium" 
                                                            UniqueName="Earned_Premium">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_Claims_Reported" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter IP_Claims_Reported column" 
                                                            HeaderText="IP_Claims" SortExpression="IP_Claims_Reported" 
                                                            UniqueName="IP_Claims_Reported">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="OP_Claims_Reported" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter OP_Claims_Reported column" 
                                                            HeaderText="OP_Claims" SortExpression="OP_Claims_Reported" 
                                                            UniqueName="OP_Claims_Reported">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="OP_Claims_Reported" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Total_Claims_Reported column" 
                                                            HeaderText="Total_Claims" SortExpression="Total_Claims_Reported" 
                                                            UniqueName="Total_Claims_Reported">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_LR" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Total_LR column" HeaderText="Total_LR" 
                                                            SortExpression="Total_LR" UniqueName="Total_LR">
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="Loading" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Loading column" HeaderText="Loading" 
                                                            SortExpression="Loading" UniqueName="Loading">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="Label202" runat="server" style="font-weight: 700" 
                                            Text="Summary Plan"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH_2" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False"  DataKeyNames="Member_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                      
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="Relation" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                              <telerik:GridBoundColumn DataField="Policy_Type" 
                                                            FilterControlAltText="Filter Policy_Type column" HeaderText="Policy_Type" 
                                                            SortExpression="Policy_Type" UniqueName="Policy_Type">
                                                        </telerik:GridBoundColumn>
                                                             
                                                        <telerik:GridBoundColumn DataField="Policy_Utilization" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Policy_Utilization column" HeaderText="Policy_Utilization" 
                                                            ItemStyle-Wrap="False" SortExpression="Policy_Utilization" UniqueName="Policy_Utilization">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_Utilization" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Member_Utilization column" HeaderText="Member_Utilization" 
                                                            SortExpression="Member_Utilization" UniqueName="Member_Utilization">
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="Contr_to_claims" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Contr_to_claims column" HeaderText="Contr_to_claims" 
                                                            SortExpression="Contr_to_claims" UniqueName="Contr_to_claims">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Ind_Loading" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter Ind_Loading column" HeaderText="Ind_Loading" 
                                                            SortExpression="Ind_Loading" UniqueName="Ind_Loading">
                                                        </telerik:GridBoundColumn>     
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel36" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td style="width: 160px">
                                                        <asp:Label ID="Label203" runat="server" Text="Verification"></asp:Label>
                                                    </td>
                                                    <td class="style20" style="width: 219px">
                                                        <telerik:RadComboBox ID="cborpt" Runat="server" AutoPostBack="True" 
                                                            Skin="Simple" Width="210px">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" Text="0" Value="0" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" 
                                                                    Text="Loading Per Policy" Value="LPP" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" Text="Loading Per Ind" 
                                                                    Value="LPI" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="width: 151px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td bgcolor="#666666" colspan="4">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 160px">
                                                        &nbsp;</td>
                                                    <td class="style20" style="width: 219px">
                                                        <telerik:RadButton ID="btnsubmit1" runat="server" Skin="Simple" 
                                                            Text="Export Data">
                                                        </telerik:RadButton>
                                                        <asp:Label ID="lblerror" runat="server" ForeColor="Red"></asp:Label>
                                                    </td>
                                                    <td style="width: 151px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
      
    </asp:UpdatePanel>
</asp:Content>
