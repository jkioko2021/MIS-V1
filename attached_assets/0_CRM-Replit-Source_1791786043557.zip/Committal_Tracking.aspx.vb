﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class Default2
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim AB As Integer
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("PRINT") = Nothing
            Session("Report_") = Nothing
            Session("EXCEL") = Nothing
            HiddenField1.Value = 0
            DtEff.DbSelectedDate = Date.Now
            DtDue.DbSelectedDate = Date.Now
        End If

    End Sub
    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try
            GDPROP.DataSource = Nothing
            GDPROP.DataBind()
          
            Dim MyDatable As New Data.DataTable
            ' SqlAction = "SELECT[PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"

            SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND POLICY_STATUS='ACTIVE'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                Session("TAT_5") = MyDatable
                RMNAME.Text = MyDatable.Rows(0).Item("RM_NAME").ToString
                MyDatable = Nothing
            Else
                SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND POLICY_STATUS='LAPSED'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDPROP.DataSource = MyDatable
                    GDPROP.DataBind()
                    Session("TAT_5") = MyDatable
                    RMNAME.Text = MyDatable.Rows(0).Item("RM_NAME").ToString
                    MyDatable = Nothing
                Else
                    GDPROP.DataSource = Nothing
                    GDPROP.DataBind()

                End If

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try
            HiddenField1.Value = 0
            GD_COMMIT.DataSource = Nothing
            GD_COMMIT.DataBind()

            Session("FAMILY_NO") = Nothing
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0

            lblID.Text = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()

            SqlAction = "SELECT DISTINCT PROPOSER_DISPLAY_NAME,RM_NAME FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_ID = '" & Trim(lblID.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                'txtrequestby.Text = MyDatable.Rows(0).Item("RM_NAME").ToString()
                RMID.Text = MyDatable.Rows(0).Item("RM_NAME").ToString()
            End If

            SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client]  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE PROPOSER_ID ='" & lblID.Text & "' ORDER BY Commit_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GD_COMMIT.DataSource = MyDatable
                GD_COMMIT.DataBind()
                MyDatable = Nothing
            Else
                GD_COMMIT.DataSource = Nothing
                GD_COMMIT.DataBind()
            End If

            'Session("PROPOSER_ID") = Nothing
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Public Sub LoadGrid(ByVal id As String)
        SqlAction = "SELECT [Note_id],[Notes],[Note_From],[Note_Date],[Note_Type] FROM  [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL_NOTES] WHERE  Ref_No ='" & id & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If
    End Sub

    Protected Sub GD_COMMIT_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_COMMIT.SelectedIndexChanged
        Try
            HiddenField1.Value = 1
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()

            Session("FAMILY_NO") = Nothing
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0

            lblNo.Text = (DirectCast(GD_COMMIT.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()
            SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client],Requested_by,Request  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Ref_No ='" & lblNo.Text & "' ORDER BY Commit_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                txtprem.Text = MyDatable.Rows(0).Item("Premium_Amt").ToString()
                txtpaid.Text = MyDatable.Rows(0).Item("Paid_Amt").ToString()
                txtcomm.Text = MyDatable.Rows(0).Item("OS_Bal_Amt").ToString()
                txtcredit.Text = MyDatable.Rows(0).Item("Credit_Period").ToString()
                DtEff.DbSelectedDate = MyDatable.Rows(0).Item("Effective_Dt").ToString()
                lblNo.Text = MyDatable.Rows(0).Item("Ref_No").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()

                txtmanager.Text = MyDatable.Rows(0).Item("Manager").ToString()
                cboby.SelectedValue = MyDatable.Rows(0).Item("Request").ToString()
                cboname.SelectedValue = MyDatable.Rows(0).Item("Requested_by").ToString()
                SqlAction = "SELECT [Note_id],[Notes],[Note_From],[Note_Date],[Note_Type] FROM  [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL_NOTES] WHERE  Ref_No ='" & lblNo.Text & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = Nothing
                    GDNOTES.DataBind()
                End If
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If

            'Session("PROPOSER_ID") = Nothing
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try

            Dim adm_status As String = ""
            Dim case_status As String = ""
            Dim new_client As Integer = 0
            new_client = 1

            If cbobusiness.SelectedValue = "" Then
                lblerr.Text = "You Must select the Business"
            End If

            lblerr.Text = ""
            If txtcomm.Text = 0 Then
                lblerr.Text = "You Must Enter the Committal Amount"
                Exit Sub
            End If
            If txtproposer.Text = "" Then
                lblerr.Text = "You Must Enter the Proposer name"
                Exit Sub
            End If

            If txtcredit.Text = 0 Then
                lblerr.Text = "You Must Enter the Period"
                Exit Sub
            End If

            If HiddenField1.Value = 0 Then
                Generate_Task()
                MyDBAction.Committal_Tracking(lblID.Text, lblNo.Text, Trim(txtproposer.Text), txtprem.Text, txtpaid.Text, txtcomm.Text, txtcredit.Text, CDate(DtEff.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DtDue.DbSelectedDate).ToString("yyyy-MM-dd"), Trim(cboby.SelectedValue), Trim(txtmanager.Text), cbobusiness.SelectedValue, Session("UserName").ToString, cboname.Text, cbotype.SelectedValue, 0)
            Else
                MyDBAction.Committal_Tracking(lblID.Text, lblNo.Text, Trim(txtproposer.Text), txtprem.Text, txtpaid.Text, txtcomm.Text, txtcredit.Text, CDate(DtEff.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DtDue.DbSelectedDate).ToString("yyyy-MM-dd"), Trim(cboby.SelectedValue), Trim(txtmanager.Text), cbobusiness.SelectedValue, Session("UserName").ToString, cboname.Text, cbotype.SelectedValue, 1)
            End If

            If txtnotes.Text <> "" Then
                MyDBAction.TRACKING_COMMITTAL_MESSAGES(lblNo.Text, txtnotes.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMMITTAL")
            End If

            SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client],Requested_by  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Ref_No ='" & lblNo.Text & "' ORDER BY Commit_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_COMMIT.DataSource = MyDatable
                GD_COMMIT.DataBind()
                MyDatable = Nothing
            Else
                GD_COMMIT.DataSource = Nothing
                GD_COMMIT.DataBind()
            End If

            SqlAction = "SELECT [Note_id],[Notes],[Note_From],[Note_Date],[Note_Type] FROM  [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL_NOTES] WHERE  Ref_No ='" & lblNo.Text & "'  ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If

            lblerr.Text = "Saved Successfully.."
            HiddenField1.Value = 0
            lblNo.Text = ""
            txtproposer.Text = ""
            txtprem.Text = 0
            txtpaid.Text = 0
            txtcomm.Text = 0
            RMID.Text = ""
            cboname.Text = ""
            txtcredit.Text = ""
            cbobusiness.SelectedValue = ""

            txtnotes.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub txtpaid_TextChanged(sender As Object, e As System.EventArgs) Handles txtpaid.TextChanged
        txtcomm.Text = txtprem.Text - txtpaid.Text
    End Sub

    Public Sub Generate_Task()
        SqlAction = "SELECT ISNULL((MAX(Commit_Id)+1),1) NUMBER FROM [dbo].[TBL_MIS_CRM_COMMITTAL]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblNo.Text = "COM" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
            '  lblNo.Text = "REF" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub

    Protected Sub RadButton2_Click(sender As Object, e As System.EventArgs) Handles RadButton2.Click
        HiddenField1.Value = 0
        lblNo.Text = ""
        txtproposer.Text = ""
        txtprem.Text = 0
        txtpaid.Text = 0
        txtcomm.Text = 0
        RMID.Text = ""

        txtcredit.Text = 0
    End Sub
    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String

        lblupload.Text = ""
        'ltEmbed.Text = ""
        Try
            If lblNo.Text = "" Then
                lblerr.Text = "You must Select The file!"
                Exit Sub
            End If
            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0
            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_File_COMMITTAL(bytes, filename, contenttype, lblNo.Text, cbouptype.Text, CDate(Date.Now()).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "", cbouptype.SelectedValue)
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green
                lblupload.Text = "File uploaded successfully"
            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If

            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By],Doc_Ref FROM [Doc_Arc_DB].[dbo].[TBL_MIS_COMMITTAL_DOCS] WHERE  File_No ='" & lblNo.Text & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = Nothing
                GD_DOCS.DataBind()
            End If



        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub

    Protected Sub DtDue_SelectedDateChanged(sender As Object, e As Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs) Handles DtDue.SelectedDateChanged
        Try
            Dim st As Integer
            txtcredit.Text = DateDiff(DateInterval.Day, DtEff.DbSelectedDate, DtDue.DbSelectedDate)
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub txtcredit_TextChanged(sender As Object, e As System.EventArgs) Handles txtcredit.TextChanged
        Try
            Dim IN_1 As Integer = txtcredit.Text
          

            DtDue.DbSelectedDate = DateAdd(DateInterval.Day, IN_1, DtEff.DbSelectedDate())
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub cboby_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboby.SelectedIndexChanged
        cboname.SelectedValue = ""
        cboname.Items.Clear()
        If cboby.SelectedValue = "RM" Then
            Str = "SELECT  DISTINCT [RE_CODE],[RE_NAME]  FROM [CRM].[dbo].[TBL_MIS_CRM_RMS] WHERE  IS_ACTIVE=1" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboname
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_NAME").ToString
                .DataBind()
            End With
        ElseIf cboby.SelectedValue = "BDM" Then
            Str = " select UNIT_CODE,UM_NAME from [COMMISSION].[dbo].[TBL_MIS_SALES_UM]" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboname
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("UM_NAME").ToString
                .DataValueField = MyDatatable.Columns("UM_NAME").ToString
                .DataBind()
            End With
        
        End If
    End Sub
End Class
