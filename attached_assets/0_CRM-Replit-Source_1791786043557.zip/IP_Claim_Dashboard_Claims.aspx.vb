﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing

                dtfrom.DbSelectedDate = Date.Now()
                dtto.DbSelectedDate = Date.Now()
                Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 and department='CLAIMS'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboNAME
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                    .DataValueField = MyDatatable.Columns("username").ToString
                    .DataBind()
                End With

                cboNAME.SelectedValue = Session("username")
                loadGrid_N()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If

    End Sub
    Public Sub loadGrid_N()

        SqlAction = "SELECT [allocate_to],sum([NOT_DISCHARGED])[NOT_DISCHARGED],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_INVOICES])[TOTAL_INVOICES]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CLAIMS] WITH(NOLOCK)   GROUP BY allocate_to"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_0.DataSource = MyDatable
            GDTracking_0.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
        End If

        SqlAction = "SELECT sum([NOT_DISCHARGED])[NOT_DISCHARGED],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_INVOICES])[TOTAL_INVOICES]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CLAIMS] WITH(NOLOCK)"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_1.DataSource = MyDatable
            GDTracking_1.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_1.DataSource = Nothing
            GDTracking_1.DataBind()
        End If
    End Sub




    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try

            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
     
            If chkdate.Checked = True And chkname.Checked = False Then
                SqlAction = "SELECT  [allocate_to],sum([NOT_DISCHARGED])[NOT_DISCHARGED],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_INVOICES])[TOTAL_INVOICES]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CLAIMS] WITH(NOLOCK) WHERE   [Submit_Dt]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY allocate_to"

            ElseIf chkdate.Checked = False And chkname.Checked = True Then
                SqlAction = "SELECT [allocate_to],sum([NOT_DISCHARGED])[NOT_DISCHARGED],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_INVOICES])[TOTAL_INVOICES]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CLAIMS] WITH(NOLOCK) WHERE   allocate_to ='" & cboNAME.SelectedValue & "' GROUP BY allocate_to"

            ElseIf chkdate.Checked = True And chkname.Checked = True Then
                SqlAction = "SELECT [allocate_to],sum([NOT_DISCHARGED])[NOT_DISCHARGED],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_INVOICES])[TOTAL_INVOICES]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CLAIMS] WITH(NOLOCK) WHERE   allocate_to ='" & cboNAME.SelectedValue & "' and Submit_Dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY allocate_to"

            Else
                SqlAction = "SELECT [allocate_to],sum([NOT_DISCHARGED])[NOT_DISCHARGED],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_INVOICES])[TOTAL_INVOICES]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CLAIMS] WITH(NOLOCK) GROUP BY allocate_to"

            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking_0.DataSource = MyDatable
                GDTracking_0.DataBind()
                Session("DAD_T_0") = MyDatable
                MyDatable = Nothing
            Else
                GDTracking_0.DataSource = Nothing
                GDTracking_0.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDTracking_0_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDTracking_0.NeedDataSource

    End Sub


    Protected Sub GDTracking_0_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTracking_0.PageIndexChanged
        GDTracking_0.CurrentPageIndex = e.NewPageIndex
        GDTracking_0.DataSource = Session("DAD_T_0")
        GDTracking_0.DataBind()
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "IP_Claim_List"

        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        SqlAction = "SELECT [File_No],[Receive_dt],[Service_dt],[Claim_Type],[Member_No],[Member_Name],[Proposer],[Provider_Code],[Provider_Name],[Invoice_No],[Invoice_Amt],[Mobile_No],[Email],[Bar_code],[Inv_Status]," & _
                               "[Entry_Date],[Entered_by],[Submitted],[Submitted_By],[Submit_dt],[Discharged],[Discharge_DT],[Discharge_By],[Invoice_type],[Amt_Payable_Ben],[P_I_Amount],[Country],[Ready_To_Process],[Returned],[Returned_Dt],[Returned_By],[Allocated],[Allocate_Dt],[Allocate_To],[Allocate_By]," & _
                               "[Mship_User],[Mship_Issue],[Mship_Date],[Processed],[Process_Dt],[Processed_By],[Payable_Amt],[Inadmissable_Amt],[Audited],[Audit_Dt],[Audit_By],[Posting],[Posting_Date] FROM [CRM].[dbo].[TBL_MIS_IP_CLAIM_TRACKING]   WHERE Submit_dt>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND  Submit_dt<= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "'"
        Session("EXCEL") = "TO EXCEL"
        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
        'Reportname = ""
    End Sub


End Class
