﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Imports System.Configuration

Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim connectionString As String = ""
        lbLERROR.Text = ""
        Session("DA_N") = Nothing
        Dim SqlAction As String = ""
        Dim searchStr As String = ""
        Dim MyDBAction As New DataManagement
        Dim REC_DATE As Date
        Dim MEMBER_ID As String = ""
        Dim Mobile_No As String = ""
        Dim ID_Doc_No As String = ""
        Dim ID_Doc_Type As String = ""
        Dim Email As String = ""
        Dim Pin_No As String = ""
        Dim member_No As String = ""
        Dim mlen As Integer = 0
        GDPROP.DataSource = Nothing
        GDPROP.DataBind()
      
        Try

            If FL1.HasFile Then

                Dim fileName As String = " {" & CDate(Date.Now).ToString("yyyy-MM-dd") & "-" & CDate(Date.Now).ToString("yyyy-MM-dd") & "}" & Path.GetFileName(FL1.PostedFile.FileName)

                Dim fileExtension As String = Path.GetExtension(FL1.PostedFile.FileName)

                Dim fileLocation As String = Server.MapPath("~/EXCEL UPLOADS/" & fileName)

                FL1.SaveAs(fileLocation)


                If fileExtension = ".xls" Then

                    connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""

                ElseIf fileExtension = ".xlsx" Then

                    connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""

                End If
                'dtfrom.DbSelectedDate = Session("CUTOFF_FROM")
                'dtto.DbSelectedDate = 

                Dim con As New OleDbConnection(connectionString)

                Dim cmd As New OleDbCommand()

                cmd.CommandType = System.Data.CommandType.Text

                cmd.Connection = con

                Dim dAdapter As New OleDbDataAdapter(cmd)

                Dim dtExcelRecords As New DataTable()

                con.Open()

                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)

                Dim getExcelSheetName As String = dtExcelSheetName.Rows(0)("Table_Name").ToString()

                cmd.CommandText = "SELECT BREAKUP_ID,	CLAIM_ID,	DISPLAY_MEMBERSHIP_NO,	MEMBER_DISPLAY_NAME,	PROPOSER_NAME,	CLIENT_TYPE,	PERIOD_FROM,	PERIOD_TO,	POLICY_ID,	FUND_MANAGE,	CATEGORY,	AGE,	INVOICE_NO,	PROVIDER_NAME,	CLAIM_AMOUNT,	INVOICE_AMT,	CLAIM_TYPE,	CLAIM_SUB_TYPE,	RECEIVE_DATE,	ADMISSION_DATE,	DISEASE_NAME,	CLAIM_NO,	SERVICE_TYPE,	INWARD_DATE,	BILL_STATUS,	ADMIN FROM [" & getExcelSheetName & "] "

                dAdapter.SelectCommand = cmd

                dAdapter.Fill(dtExcelRecords)

                con.Close()
                Session("DA_N") = dtExcelRecords
                'Bind the DataTable.
             
                GDPROP.DataSource = dtExcelRecords
                GDPROP.DataBind()
                lbLver.Text = dtExcelRecords.Rows.Count()

            End If



        Catch ex As Exception
            lbLERROR.Text = ex.Message
        End Try
    End Sub
    


    Protected Sub GDTracking_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDPROP.PageIndexChanged
        GDPROP.CurrentPageIndex = e.NewPageIndex
        GDPROP.DataSource = Session("DA_N")
        GDPROP.DataBind()
    End Sub
    
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

    End Sub
    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim row As DataRow
        Dim MnuCount As Int16 = 0
        Dim RECEIPT As String = ""
        Dim cn As Integer = 0
        Dim MyDatatable As System.Data.DataTable : Dim Str As String
        Try

            UpdateRecord("DELETE FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_MINET_CLAIMS_REGISTER]")

            If Not Session("DA_N") Is Nothing Then

                For Each row In Session("DA_N").rows

                    MyDBAction.MINET_UPLOAD(row("BREAKUP_ID").ToString, row("CLAIM_ID").ToString, row("DISPLAY_MEMBERSHIP_NO").ToString, row("MEMBER_DISPLAY_NAME").ToString, row("PROPOSER_NAME").ToString, row("CLIENT_TYPE").ToString, row("PERIOD_FROM").ToString, row("PERIOD_TO").ToString, row("POLICY_ID").ToString, row("FUND_MANAGE").ToString, row("CATEGORY").ToString, row("AGE").ToString, row("INVOICE_NO").ToString, row("PROVIDER_NAME").ToString, row("CLAIM_AMOUNT").ToString, row("INVOICE_AMT").ToString, row("CLAIM_TYPE").ToString, row("CLAIM_SUB_TYPE").ToString, row("RECEIVE_DATE").ToString, row("ADMISSION_DATE").ToString, row("DISEASE_NAME").ToString, row("CLAIM_NO").ToString, row("SERVICE_TYPE").ToString, row("INWARD_DATE").ToString, row("BILL_STATUS").ToString, row("ADMIN").ToString, Session("DATE"))
                    'lbL1.Text = Session("DA_N").rows.count()
                Next
                SqlAction = "SELECT count(*)cnt  FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_MINET_CLAIMS_REGISTER] WHERE DATA_DATE='" & Session("DATE") & "'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    lbLs.Text = MyDatable.Rows(0).Item("cnt").ToString()
                End If


                lbLERROR.Text = "UPLOAD SUCCESSFULL"
                Session("DA_N") = Nothing
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()
                Dim audit As New DataManagement
                audit.AddAdminAuditTrail(Session("UserName").ToString, "Claims upload ", "Uploaded Data for Minet claims :- Date Month -  :" & CDate(Date.Now).ToString("yyyy-MM-dd") & ", Name - " & Session("FullNames") & ".", _
            Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)


            Else
                lbLERROR.Text = "Error in uploading"
            End If
        Catch ex As Exception
            lbLERROR.Text = ex.Message
        End Try
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DTDATE.DbSelectedDate = Date.Now()
            Session("DATE") = Nothing
            Session("DA_N") = Nothing
            Session("DATE") = CDate(DTDATE.DbSelectedDate).ToString("yyyy-MM-dd")
           
        End If
       
    End Sub
End Class
