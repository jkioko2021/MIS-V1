﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("PRINT") = Nothing
            Session("Report_") = Nothing
            Session("EXCEL") = Nothing
        End If

    End Sub
    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try
            GDPROP.DataSource = Nothing
            GDPROP.DataBind()
            GDMEM.DataSource = Nothing
            GDMEM.DataBind()
            Dim MyDatable As New Data.DataTable
            ' SqlAction = "SELECT[PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"
        
            SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND POLICY_STATUS='ACTIVE'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                Session("TAT_5") = MyDatable
                RMNAME.Text = MyDatable.Rows(0).Item("RM_NAME").ToString
                MyDatable = Nothing
            Else
                SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND POLICY_STATUS='LAPSED'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDPROP.DataSource = MyDatable
                    GDPROP.DataBind()
                    Session("TAT_5") = MyDatable
                    RMNAME.Text = MyDatable.Rows(0).Item("RM_NAME").ToString
                    MyDatable = Nothing
                Else
                    GDPROP.DataSource = Nothing
                    GDPROP.DataBind()

                End If

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try
            GDMEM.DataSource = Nothing
            GDMEM.DataBind()
            GD_SCHEME.DataSource = Nothing
            GD_SCHEME.DataBind()
            GD_POLICY.DataSource = Nothing
            GD_POLICY.DataBind()
            GD_BENEFIT.DataSource = Nothing
            GD_BENEFIT.DataBind()

            Session("FAMILY_NO") = Nothing
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0

            Session("PROPOSER_ID") = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()

            SqlAction = "SELECT RM_NAME, [PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],FIRST_ENROLLMENT_DATE,[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO,POLICY_STATUS,DATA_DATE FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "'  AND POLICY_STATUS='ACTIVE'  order by DISPLAY_MEMBERSHIP_NO"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEM.DataSource = MyDatable
                GDMEM.DataBind()
                RMNAME.Text = MyDatable.Rows(0).Item("RM_NAME").ToString
                Session("GDMEM") = MyDatable
                'lblid.Text = MyDatable.Rows(0).Item("PROPOSER_ID").ToString
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_FROM").ToString
                dtto.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_UPTO").ToString
                MyDatable = Nothing
            Else
                GDMEM.DataSource = Nothing
                GDMEM.DataBind()
            End If


            SqlAction = "SELECT DISTINCT  [POLICY_CODE], Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR]  FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_STATE.DataSource = MyDatable
                GD_STATE.DataBind()
                Session("STATE_01") = MyDatable
                DR = Convert.ToInt32(MyDatable.Compute("SUM(DR)", String.Empty))
                CR = Convert.ToInt32(MyDatable.Compute("sum(CR)", String.Empty))
                txtbal.Text = DR - CR
                MyDatable = Nothing
            Else
                GD_STATE.DataSource = Nothing
                GD_STATE.DataBind()
            End If

            Str = "SELECT DISTINCT SCHEME_ID, PLAN_NAME,SCHEME_NAME,DATA_DATE FROM  DATA_REPOSITORY_DB.dbo.MASTER_CORPORATES_BENEFITS  WHERE  PROPOSER_ID='" & Session("PROPOSER_ID") & "'"
            'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_SCHEME.DataSource = MyDatable
                GD_SCHEME.DataBind()
                MyDatable = Nothing
            Else
                GD_SCHEME.DataSource = Nothing
                GD_SCHEME.DataBind()
            End If

         



            'Session("PROPOSER_ID") = Nothing
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
  

    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_STATE.PageIndexChanged
        GD_STATE.CurrentPageIndex = e.NewPageIndex
        GD_STATE.DataSource = Session("STATE_01")
        GD_STATE.DataBind()
    End Sub
    Protected Sub GDMEM_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDMEM.PageIndexChanged
        GDMEM.CurrentPageIndex = e.NewPageIndex
        GDMEM.DataSource = Session("GDMEM")
        GDMEM.DataBind()
    End Sub

    Protected Sub btnstatement_Click(sender As Object, e As System.EventArgs) Handles btnstatement.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable

            If chkdate.Checked = True Then
                If chkex.Checked = True Then
                    Session("EXCEL") = "TO EXCEL"
                    Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],  [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing]  WITH(NOLOCK) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(PERIOD_FROM AS DATETIME),126) >= '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and Convert(VarChar(10),CAST(PERIOD_TO AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
                Else
                    Session("PRINT") = "PDF"
                    Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],  [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing]  WITH(NOLOCK) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(PERIOD_FROM AS DATETIME),126) >= '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and Convert(VarChar(10),CAST(PERIOD_TO AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
                End If
            Else
                If chkex.Checked = True Then
                    Session("EXCEL") = "TO EXCEL"
                    Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],  [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing]  WITH(NOLOCK) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
                Else
                    Session("PRINT") = "PDF"
                    Str = "SELECT DISTINCT POLICY_CODE, [PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],  [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WITH(NOLOCK) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
                End If
            End If

            Session("Report_") = "Customer Statement"

            'Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],BALANCE, [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],['0-30 Days'],['31-60 Days'],['61-90 Days'],['91-120 Days'],['121-180 Days'],['181-240 Days'],['241-300 Days'],['301-365 Days'],['Over 365 Days'] FROM [MISREPORTS].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE,REFERENCE_NO"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable

            Session("PRINT") = "PDF"
            Session("Report_") = cboreport.Text

            If cboreport.SelectedValue = "V" Then
                Str = "SELECT [POLICY_CODE]  ,[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[FIRST_ENROLLMENT_DATE],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[MEMBER_PRI_ADD_LINE2],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[UNIT],[BRANCH],[REGION] ,[PERIOD_FROM],[PERIOD_TO],[POLICY_STATUS],[FAMILY_NO]     ,[ID_DOC_NO] ,[DATA_DATE]FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND POLICY_STATUS='ACTIVE'"

            ElseIf cboreport.SelectedValue = "L" Then
                Str = "SELECT [POLICY_CODE]  ,[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[FIRST_ENROLLMENT_DATE],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[MEMBER_PRI_ADD_LINE2],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[UNIT],[BRANCH],[REGION] ,[PERIOD_FROM],[PERIOD_TO],[POLICY_STATUS],[FAMILY_NO]     ,[ID_DOC_NO] ,[DATA_DATE]FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND POLICY_STATUS='LAPSED'"

            ElseIf cboreport.SelectedValue = "T" Then
                Str = "SELECT [POLICY_CODE]  ,[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[FIRST_ENROLLMENT_DATE],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[MEMBER_PRI_ADD_LINE2],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[UNIT],[BRANCH],[REGION] ,[PERIOD_FROM],[PERIOD_TO],[POLICY_STATUS],[FAMILY_NO]     ,[ID_DOC_NO] ,[DATA_DATE]FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND POLICY_STATUS='TERMINATED'"

            End If

          
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GD_SCHEME_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_SCHEME.SelectedIndexChanged
        Try

            Session("SCHEME_ID") = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("SCHEME_ID").ToString()
            Str = "SELECT DISTINCT  PLAN_NAME,SCHEME_NAME,PLAN_TYPE,CLAUSE_DESCRIPTION,MAXIMUM_LIMIT,FUND_MANAGE,DATA_DATE FROM  DATA_REPOSITORY_DB.dbo.MASTER_CORPORATES_BENEFITS WHERE  SCHEME_ID='" & Session("SCHEME_ID") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_BENEFIT.DataSource = MyDatable
                GD_BENEFIT.DataBind()
                MyDatable = Nothing
            Else
                GD_BENEFIT.DataSource = Nothing
                GD_BENEFIT.DataBind()
            End If

            Session("SCHEME_ID") = Nothing
        Catch ex As Exception

        End Try
    End Sub

   
End Class
