﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim emp_code As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0

                Str = "SELECT [Depart_Code],[Department] FROM [AAR_RISK_DB].[dbo].[TBL_MIS_RISK_DEPART]" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbodepart
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Department").ToString
                    .DataValueField = MyDatatable.Columns("Depart_Code").ToString
                    .DataBind()
                End With

                Str = "SELECT [Issue_Code],[Issue_Name]  FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] WHERE ACTIVE=1"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbissue
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Issue_Name").ToString
                    .DataValueField = MyDatatable.Columns("Issue_Code").ToString
                    .DataBind()
                End With
                Session("emp_code") = Nothing
                Str = "SELECT Emp_code FROM employees WHERE username='" & Session("username") & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    Session("emp_code") = MyDatatable.Rows(0).Item("Emp_code").ToString()
                    'Session("emp_code") = "0531"
                End If

                load_grid(Session("emp_code"))

           
                Session("empcode") = Nothing
                Session("agentemail") = Nothing

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub

    Public Sub load_grid(ByVal EMP As String)
        SqlAction = " SELECT  t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To,t.Due_Dt,t.Over_Due   FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where t.Escalated_To='" & EMP & "' and t.[Status]='OPEN'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCOMPL.DataSource = MyDatable
            GDCOMPL.DataBind()
            MyDatable = Nothing
        Else
            GDCOMPL.DataSource = Nothing
            GDCOMPL.DataBind()
        End If
    End Sub
    Public Sub Notes(ByVal STR As String)

        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        GD_DOCS.DataSource = Nothing
        GD_DOCS.DataBind()

        MyDatable = Nothing
        SqlAction = "SELECT [DOC_ID],[Ref_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_COMPLAIN_DOCS] WHERE  [Ref_No] ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
            MyDatable = Nothing
        Else
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
        End If

        SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINTS_NOTES] WHERE  case_No ='" & STR & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If

    
       
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
          
            GDCOMPL.DataSource = Nothing
            GDCOMPL.DataBind()

            SqlAction = "SELECT  t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To,t.Due_Dt,t.Over_Due  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where t.[Case_no]='" & txtsearch.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCOMPL.DataSource = MyDatable
                GDCOMPL.DataBind()
                MyDatable = Nothing
            Else
                GDCOMPL.DataSource = Nothing
                GDCOMPL.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "CLIENT COMPLAINT ESCALATION" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "CLIENT COMPLAINT ESCALATIONest:-" & lblcode.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear:, " & lblesc.Text & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Case No:" & lblcode.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Description--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtdescr.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function



    Protected Sub GDCOMPL_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCOMPL.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            Session("FAMILY_NO") = Nothing
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            ltEmbed.Text = ""
            lblcode.Text = (DirectCast(GDCOMPL.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_no").ToString()
            SqlAction = "SELECT  [Case_no] ,[Summary_of_issue],[Action_Taken],Department,Description  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] where [Case_no]='" & lblcode.Text & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                cbodepart.SelectedValue = MyDatatable.Rows(0).Item("Department").ToString()
                cbissue.SelectedValue = MyDatatable.Rows(0).Item("Summary_of_issue").ToString()
                txtdescr.Text = MyDatatable.Rows(0).Item("Description").ToString()
                cboaction.SelectedValue = MyDatatable.Rows(0).Item("Action_Taken").ToString()
                txtdescr.Enabled = False
                Notes(lblcode.Text)
              
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/Complains.ashx?Id="), id)
    End Sub

    Protected Sub cbodepart_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbodepart.SelectedIndexChanged
        cbissue.Text = ""

        Str = "SELECT [Issue_Code],[Issue_Name]  FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] WHERE ACTIVE=1 AND [Depart_Code]='" & cbodepart.SelectedValue & "'" '"
        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
        With cbissue
            .Items.Clear()
            .DataSource = MyDatatable
            .DataTextField = MyDatatable.Columns("Issue_Name").ToString
            .DataValueField = MyDatatable.Columns("Issue_Code").ToString
            .DataBind()
        End With
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDCOMPL0_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDCOMPL.PageIndexChanged
        GDCOMPL.CurrentPageIndex = e.NewPageIndex
        GDCOMPL.DataSource = Session("DAD0_T")
        GDCOMPL.DataBind()
    End Sub
    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Try
            Try
                Dim adm_status As String = ""
                Dim case_status As String = ""
                HiddenField1.Value = 0
                If lblcode.Text = "" Then
                    lblerr.Text = "Select case No"
                    Exit Sub
                End If

                If chktrans.Checked = True Then
                    UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] SET Action_Taken='" & cboaction.SelectedValue & "', Department='" & cbodepart.SelectedValue & "', Summary_of_issue='" & cbissue.SelectedValue & "'  where [Case_No]='" & lblcode.Text & "'")
                    UpdateRecord("UPDATE [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] SET [Status]='Transfered' where [Case_No]='" & lblcode.Text & "' and [Status]='Open'")
                    MyDBAction.Complaint_Escalate(lblcode.Text, Session("username"), cbissue.SelectedValue, cboaction.SelectedValue, txtdescr.Text, cbodepart.SelectedValue)

                    SqlAction = "SELECT  e.employeename  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To   where t.[Case_no]='" & lblcode.Text & "'"
                    MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                    If MyDatable.Rows.Count > 0 Then
                        lblesc.Text = MyDatable.Rows(0).Item("employeename").ToString()
                    End If
                    lblerr.Text = "Transfered Successfully.. To> '" & lblesc.Text & "'"
                Else
                    UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] SET  TAT=DATEDIFF(HOUR,Date_Received,Date_of_Resolution), Action_Taken='" & cboaction.SelectedValue & "',Status='" & cboaction.SelectedValue & "',Date_of_Resolution='" & CDate(Date.Now()).ToString("yyyy-MM-dd hh:mm") & "'  where [Case_No]='" & lblcode.Text & "'")
                    UpdateRecord("UPDATE [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] SET [Status]='" & cboaction.SelectedValue & "'  where [Case_No]='" & lblcode.Text & "' and [Status]='Open'")
                    lblerr.Text = "Saved Successfully.."
                End If

                If txtcomment.Text <> "" Then
                    MyDBAction.TASK_MESSAGES_COMPLAIN(lblcode.Text, txtcomment.Text, Session("username"), Date.Now(), "COMPLAINTS/QUERY", Session("FAMILY_NO"))
                End If

                If cboaction.SelectedValue = "Escalated" Then
                    Session("cc_email") = Nothing
                    Session("email") = Nothing
                    Str = "SELECT NAME,EMAIL FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] WHERE Case_No='" & lblcode.Text & "'" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    If MyDatatable.Rows.Count > 0 Then
                        Session("EMAIL") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                        lblesc.Text = MyDatatable.Rows(0).Item("NAME").ToString()
                    End If
                    Session("msg") = "Kindly note the below concern that has been escalated to you for action."
                    'Session("email") = Trim(txtescaemail.Text)

                    'Session("cc_email") = "jmwaniki@aar.co.ke"
                    Session("Header") = "CLIENT COMPLAINT/ENQUIRY ESCALATION"
                    '   MailSent = SendLoginDetails(lblesc.Text, Session("email"), "")
                End If

                load_grid(Session("emp_code"))



                HiddenField1.Value = 0
                lblcode.Text = ""
                txtdescr.Text = ""


                ltEmbed.Text = ""
                txtcomment.Text = ""

                lblcode.Enabled = True
                txtdescr.Enabled = True





            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

   
    Protected Sub GDCOMPL_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GDCOMPL.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then

            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("Over_Due")
            If myCell.Text = 1 Then
                dataItem.BackColor = Drawing.Color.Red
            End If
 

        End If
    End Sub
End Class
