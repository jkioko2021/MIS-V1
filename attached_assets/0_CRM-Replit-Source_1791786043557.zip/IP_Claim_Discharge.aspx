﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="IP_Claim_Discharge.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="IP CLAIM DISCHARGE"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1183px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 2958px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Provider" Value="P" />
                                                <telerik:RadComboBoxItem runat="server" Text="Invoice No" Value="I" />
                                                <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td style="width: 5px">
                                        &nbsp;</td>
                                    <td>
                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1196px">
                            <table style="width: 97%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1190px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" 
                                                Width="100%" PageSize="20">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>

                                                            <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                            SortExpression="File_No" UniqueName="File_No">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Submit_dt" 
                                                            FilterControlAltText="Filter Submit_dt column" HeaderText="Submit_dt" 
                                                            SortExpression="Submit_dt" UniqueName="Submit_dt">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="Memb_Disch_dt" 
                                                            FilterControlAltText="Filter Memb_Disch_dt column" HeaderText="Discharge_date" 
                                                            SortExpression="Memb_Disch_dt" UniqueName="Memb_Disch_dt">                                                       
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                                 <telerik:GridBoundColumn DataField="Member_Name" 
                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                            SortExpression="Member_Name" UniqueName="Member_Name" ItemStyle-Wrap="False">
                                                                     <ItemStyle Wrap="False" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_No" 
                                                            FilterControlAltText="Filter Invoice_No column" HeaderText="Invoice_No" 
                                                            SortExpression="Invoice_No" UniqueName="Invoice_No">
                                                            </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Invoice_Amt" DataFormatString="{0:###,##0.0}" 
                                                            FilterControlAltText="Filter Invoice_Amt column" HeaderText="Invoice_Amt" 
                                                            SortExpression="Invoice_Amt" UniqueName="Invoice_Amt">                                                       
                                                        </telerik:GridBoundColumn>
                                                              <telerik:GridBoundColumn DataField="Provider_Name" 
                                                            FilterControlAltText="Filter Provider_Name column" HeaderText="Provider_Name" 
                                                            SortExpression="Provider_Name" UniqueName="Provider_Name">                                                           
                                                        </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="Invoice_type" 
                                                            FilterControlAltText="Filter Invoice_type column" HeaderText="Invoice_type" 
                                                            SortExpression="Invoice_type" UniqueName="Invoice_type">                                                       
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Inv_Status" 
                                                            FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
                                                            SortExpression="Inv_Status" UniqueName="Inv_Status">                                                       
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Discharge_By" 
                                                            FilterControlAltText="Filter Discharge_By column" HeaderText="Discharge_By" 
                                                            SortExpression="Discharge_By" UniqueName="Discharge_By">                                                       
                                                        </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Returned_By" 
                                                            FilterControlAltText="Filter Returned_By column" HeaderText="Returned_By" 
                                                            SortExpression="Returned_By" UniqueName="Returned_By">                                                       
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label102" runat="server" Text="Receive Date"></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadDatePicker ID="dtreceive" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label128" runat="server" Text="Service Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtservice" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label130" runat="server" Text="Bar Code"></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadTextBox ID="txtbarcode" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label126" runat="server" Text="Member No."></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Sunset" Width="250px" 
                                            EmptyMessage="KE123456700">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label154" runat="server" Text="Member Name."></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label105" runat="server" Text="Invoice No"></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadTextBox ID="txtinv_no" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label106" runat="server" Text="Invoice Amt"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadNumericTextBox ID="txtinv_amt" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" 
                                            Text="Corporate"></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label148" runat="server" Text="File Number"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <asp:Label ID="lblfile" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" bgcolor="#999999" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel32" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" Width="1123px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1100px">
                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                            SortExpression="DOC_ID">
                                                                            <ItemTemplate>
                                                                                <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                    CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                            </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                            ScrollBars="Horizontal" Width="1100px">
                                                            <asp:Literal ID="ltEmbed" runat="server" />
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr style="width: 1107px" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label153" runat="server" style="font-weight: 700" 
                                            Text="Invoice Type"></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadComboBox ID="cbotype" Runat="server" Skin="Simple" Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Normal" 
                                                    Value="Normal" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" 
                                                    Text="P &amp; I (Full Pay)" Value="P &amp; I (Full Pay)" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" 
                                                    Text="P &amp; I (Part Pay)" Value="P &amp; I (Part Pay)" />
                                                <telerik:RadComboBoxItem runat="server" Text="Intercompany" 
                                                    Value="Intercompany" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label155" runat="server" style="font-weight: 700" 
                                            Text="Amt Payable(Benefit)"></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadNumericTextBox ID="txtpayable" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label156" runat="server" style="font-weight: 700" 
                                            Text="Amt Payable(P &amp; I)"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txtpayP_I" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        <asp:Label ID="Label158" runat="server" style="font-weight: 700" Text="Country"></asp:Label>
                                    </td>
                                    <td style="width: 272px">
                                        <telerik:RadComboBox ID="cbocountry" Runat="server" MarkFirstMatch="True" 
                                            Skin="Sunset" Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="AIK" Value="AIK" />
                                                <telerik:RadComboBoxItem runat="server" Text="AIT" Value="AIT" />
                                                <telerik:RadComboBoxItem runat="server" Text="AHS" Value="AHS" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 169px">
                                        &nbsp;</td>
                                    <td style="width: 272px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td>
                                        <telerik:RadButton ID="RadButton2" runat="server" Skin="Simple" Text="Update" 
                                            Width="150px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr style="width: 1107px" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel2" runat="server" Width="1127px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td colspan="4" bgcolor="#CCCCCC">
                                                        <asp:Label ID="Label159" runat="server" style="font-weight: 700" 
                                                            Text="Attach Addictional Document"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label149" runat="server" Text="Select"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                        <telerik:RadComboBox ID="cbodoc" Runat="server" MarkFirstMatch="True" 
                                                            Skin="Sunset" Width="250px">
                                                        </telerik:RadComboBox>
                                                        &nbsp;</td>
                                                    <td style="width: 155px; height: 35px;">
                                                        <asp:Label ID="DOC_ID" runat="server" 
                                                            style="font-weight: 700; color: #CC0000; background-color: #FFFFFF" 
                                                            Visible="False"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 51px">
                                                        <asp:Label ID="Label146" runat="server" Text="Document"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                    </td>
                                                    <td style="width: 155px; height: 35px;">
                                                        <asp:Label ID="Label138" runat="server" Text="Upload Date"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                        <telerik:RadDatePicker ID="dtupload" Runat="server" Enabled="False" MinDate="" 
                                                            Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 51px; height: 35px;">
                                                        &nbsp;</td>
                                                    <td style="height: 35px">
                                                        <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" Text="Upload" 
                                                            Width="150px">
                                                        </telerik:RadButton>
                                                        &nbsp;
                                                    </td>
                                                    <td style="width: 155px; height: 35px;">
                                                        &nbsp;</td>
                                                    <td style="height: 35px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4" style="height: 35px;">
                                                        <asp:Label ID="lblupload" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                            ForeColor="Red"></asp:Label>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 13px; width: 169px;">
                                        <asp:Label ID="Label152" runat="server" style="font-weight: 700" 
                                            Text="Action"></asp:Label>
                                    </td>
                                    <td style="height: 13px; width: 272px;">
                                        <telerik:RadComboBox ID="cboallocate" Runat="server" Skin="Simple" 
                                            Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Discharged" Value="D" />
                                                <telerik:RadComboBoxItem runat="server" Text="Retention Issue" Value="R" />
                                                <telerik:RadComboBoxItem runat="server" Text="Return-DPU" Value="DPU" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboallocate" Text="Re-Allocate" 
                                                    Value="RE" />
                                                <telerik:RadComboBoxItem runat="server" Text="Pending-Invoice" Value="PI" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 166px; height: 13px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 13px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 13px; width: 169px;">
                                        <asp:Label ID="Label121" runat="server" style="font-weight: 700" 
                                            Text="Comments"></asp:Label>
                                    </td>
                                    <td style="height: 13px; width: 272px;">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 166px; height: 13px;">
                                    </td>
                                    <td style="width: 287px; height: 13px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3" style="height: 39px">
                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="70px" Rows="1" 
                                            Skin="Sunset" TextMode="MultiLine" Width="450px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td style="width: 287px; height: 39px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2" style="height: 39px">
                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Save" 
                                            Width="150px">
                                        </telerik:RadButton>
                                        <asp:Label ID="lblerr_1" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 166px; height: 39px;">
                                    </td>
                                    <td style="width: 287px; height: 39px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1190px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" ItemStyle-Wrap ="True"
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes"> 
                                                            <ItemStyle Wrap="True" />
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
          <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
          </Triggers>
    </asp:UpdatePanel>
</asp:Content>


