﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page

    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dttracked.DbSelectedDate = Date.Now()
            dtreceive.Enabled = False
            dttracked.Enabled = False
            dtresolved.Enabled = False
            'dtservice.DbSelectedDate = Date.Now()
            loadGrid()
            '
            Str = ""
            Str = ""
            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM  [dbo].[TBL_MIS_PROVIDER_MASTER] ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboprovider
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With
            Str = ""
            MyDatatable = Nothing

            Str = "SELECT Emp_Code,EmployeeName FROM Employees where Department='CASE MANAGEMENT' and approved=1"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbocareManager
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                .DataValueField = MyDatatable.Columns("Emp_Code").ToString
                .DataBind()
            End With

        End If
    End Sub

    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim tracked As Integer = 0
        Dim resolved As Integer = 0
        'Dim FILENO As String
        Dim app As Integer = 0
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim File_No As String = ""
        Dim Proposer_Name As String = ""
        Dim MyDatable_1 As New Data.DataTable
        Dim MailSent As Boolean = False
        Dim receivedate As String
        Try



            STS = 1
            MyDBAction.TRACK_IP_CAREMANAGER(FILENO.Text, Trim(IDlbl.Text), cbocareManager.SelectedValue, CDate(dttracked.DbSelectedDate).ToString("yyyy-MM-dd"), txtcomment.Text, Session("username"))
            lblerr.Text = "Updated Successfully!"



            loadGrid()
            'loadGrid_OTH(Trim(IDlbl.Text))
            HiddenField1.Value = ""
            dtreceive.DbSelectedDate = Date.Now()
            cboprovider.Enabled = False
            'cbocareManager.Enabled = False
            dtreceive.Enabled = False
            dttracked.Enabled = False
            dtresolved.Enabled = False
            cbocareManager.Enabled = True
            cboprovider.Text = ""
            cbocareManager.Text = ""
            dtreceive.DbSelectedDate = Date.Now()
            dttracked.DbSelectedDate = Date.Now()
            dtresolved.DbSelectedDate = Date.Now()

            txtcomment.Text = ""

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub loadGrid_OTH(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH] WHERE ACTIVE=1 AND INVOICE_NO='" & STR & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub

    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        'SqlAction = "SELECT [ID],[TENDER_NO],[BOOKING_DATE],[DUE_DATE_TIME],[CORPORATE_NAME] FROM [MISREPORTS].[dbo].[TBL_MIS_TENDER] WITH (NOLOCK) WHERE DUE_DATE_TIME >='" & Date.Now & "' and IS_ACTIVE=1"
        SqlAction = "SELECT  FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]   FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH] WHERE ACTIVE=1 and CLAIM_TYPE='IP' AND CARE_MGR_ID='' ORDER BY ID DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH] WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH]   WITH (NOLOCK) WHERE ACTIVE=1 AND   PROVIDER_NAME Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"
            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH]  WITH (NOLOCK) WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"
            ElseIf cbosearch.SelectedValue = "C" Then
                SqlAction = "SELECT FILE_NO,[INVOICE_NO],[INVOICE_AMT],[ID],[CARE_MANAGER]  FROM [MISREPORTS].[dbo].[VW_MIS_IP_OP_SEARCH]  WITH (NOLOCK) WHERE ACTIVE=1 AND   CARE_MANAGER Like '%" & Trim(txtsearch.Text) & "%' and CLAIM_TYPE='IP'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        txtcomment.Enabled = True
        cbocareManager.Enabled = True

        dtreceive.Enabled = False
        dttracked.Enabled = False
        dtresolved.Enabled = False
    End Sub


    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        cbocareManager.SelectedValue = ""
        cbocareManager.Text = ""
        lblerr.Text = ""

        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""


        Session("status_1") = Nothing
        SqlAction = "SELECT [ID],[FILE_NO],[RECEIVE_DT],[ALLOCATED_DT],[CARE_MGR_ID],STATUS,PROVIDER_NAME,BARCODE, [RESOLVE_DT],[PROVIDER_ID],[COMMENT],CLAIM_TYPE FROM [MISREPORTS].[dbo].[TBL_MIS_IP_OP_TRACKING] WITH (NOLOCK) WHERE ID ='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                IDlbl.Text = MyDatable.Rows(0).Item("ID").ToString()
                FILENO.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()

                dttracked.DbSelectedDate = MyDatable.Rows(0).Item("ALLOCATED_DT").ToString()
                cbostatus.SelectedValue = MyDatable.Rows(0).Item("STATUS").ToString()
                dtresolved.DbSelectedDate = MyDatable.Rows(0).Item("RESOLVE_DT").ToString()

                cbocareManager.SelectedValue = MyDatable.Rows(0).Item("CARE_MGR_ID").ToString()
                cboprovider.SelectedValue = MyDatable.Rows(0).Item("PROVIDER_ID").ToString()
                txtProvider_Name.Text = MyDatable.Rows(0).Item("PROVIDER_NAME").ToString()
                lblbarcode.Text = MyDatable.Rows(0).Item("BARCODE").ToString()
                cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                txtcomment.Text = MyDatable.Rows(0).Item("COMMENT").ToString()
                dtreceive.Enabled = False
                cbocareManager.Enabled = True
                cboprovider.Enabled = False
                txtcomment.Enabled = False
                txtProvider_Name.Enabled = False

                dtreceive.Enabled = False

                dtresolved.Enabled = False
            End If
            Session("DAD_5") = Nothing



        End If
    End Sub
    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub

    Protected Sub cbocareManager_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbocareManager.SelectedIndexChanged
        dttracked.DbSelectedDate = Date.Now()
    End Sub


    Protected Sub GDSEARCH_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub
End Class
