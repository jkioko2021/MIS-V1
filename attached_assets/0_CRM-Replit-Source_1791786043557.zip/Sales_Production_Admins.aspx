﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Sales_Production_Admins.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
           <div id="Div_inner">
            <table style="width: 1200px">
                <tr>
                    <td align="center" bgcolor="#333333" Width="1200px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="DASH BOARD"></asp:Label>
                    </td>
                </tr>
    <tr>
                                    <td class="style8" style="height: 78px">
                                        <asp:Panel ID="Panel19" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Width="1200px" Wrap="False">
                                            <table style="width: 100%" Width="1200px">
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        &nbsp;</td>
                                                    <td style="width: 81px">
                                                        <telerik:RadComboBox ID="cboregion" Runat="server" Height="19px" Skin="Web20" 
                                                            style="margin-left: 0px">
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td class="style10" style="width: 122px">
                                                        <asp:Label ID="Label87" runat="server" Text="Date From"></asp:Label>
                                                    </td>
                                                    <td style="width: 11px">
                                                        <telerik:RadDatePicker ID="dtDateFrom" Runat="server" 
                                                            Culture="en-US" Skin="Web20">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="width: 151px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        &nbsp;</td>
                                                    <td style="width: 81px">
                                                        &nbsp;</td>
                                                    <td class="style10" style="width: 122px">
                                                        <asp:Label ID="Label88" runat="server" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td style="width: 11px">
                                                        <telerik:RadDatePicker ID="dtDateTo" Runat="server" 
                                                            Culture="en-US" Skin="Web20" Width="150px">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="width: 151px">
                                                        <telerik:RadButton ID="SEARCH" runat="server" Skin="Web20" Text="View " 
                                                            Width="100px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                     
                                              <telerik:RadTabStrip ID="RadTabStrip1" runat="server" SelectedIndex="0" 
                                                  MultiPageID="RadMultiPage1" Width="1200px" Skin="Web20">
                                                  <Tabs>
                                                      <telerik:RadTab runat="server" Text="Regional" Owner="RadTabStrip1" 
                                                          PageViewID="V3" Selected="True" SelectedIndex="1">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V1" Text="Unit">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V6" Text="Per Channel">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V7" 
                                                          Text="Per Market">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" Owner="RadTabStrip1" Text="Per Title">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V2" Text="In-House">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V11" Text="Independent">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" Text="Brokers" PageViewID="V12">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" Text="Banc-Assurance" PageViewID="V13">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V14" Text="Customer Service">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V15" Text="New Business">
                                                      </telerik:RadTab>
                                                      <telerik:RadTab runat="server" PageViewID="V16" Text="Renewal Business">
                                                      </telerik:RadTab>
                                                  </Tabs>
                                              </telerik:RadTabStrip>
             
                                    </td>
                                </tr>
                <tr>
                    <td class="style8">
                        <asp:Panel ID="Panel20" runat="server" Width="1200px">
                            <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="1200px">
                                <telerik:RadPageView ID="V1" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label89" runat="server" style="font-weight: 700" Text="BDM -YTD"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel16" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GDSEARCH_U" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="35" Skin="Web20" 
                                                        Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="UNIT_CODE">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="UM_NAME" 
                                                                    FilterControlAltText="Filter UM_NAME column" HeaderText="UM_NAME" 
                                                                    SortExpression="UM_NAME" UniqueName="UM_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="UNIT_NAME" 
                                                                    FilterControlAltText="Filter UNIT_NAME column" HeaderText="UNIT_NAME" 
                                                                    SortExpression="UNIT_NAME" UniqueName="UNIT_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="MEDICAL NEW(B)" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_MED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_MED column" HeaderText="MEDICAL NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW_MED" UniqueName="ACTUAL_NEW_MED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NONMEDICAL(B)" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_NONMED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_NONMED column" 
                                                                    HeaderText="NONMED_NEW(A)" SortExpression="ACTUAL_NEW_NONMED" 
                                                                    UniqueName="ACTUAL_NEW_NONMED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_BUDGET column" HeaderText="NEW BUDGET" 
                                                                    SortExpression="NEW_BUDGET" UniqueName="NEW_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW column" HeaderText="NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW" UniqueName="ACTUAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_BUDGET" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_BUDGET column" HeaderText="RENEWAL BUDGET" 
                                                                    SortExpression="RENEWAL_BUDGET" UniqueName="RENEWAL_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_RENEW column" HeaderText="RENEWAL(A)" 
                                                                    SortExpression="ACTUAL_RENEW" UniqueName="ACTUAL_RENEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter MONTH_BUDGET column" HeaderText="MONTH BUDGET(B)" 
                                                                    SortExpression="MONTH_BUDGET" UniqueName="MONTH_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_PROD" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_PROD column" HeaderText="MONTH PROD(A)" 
                                                                    SortExpression="ACTUAL_PROD" UniqueName="ACTUAL_PROD">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter NEW_PERC column" HeaderText="% NEW" 
                                                                    HtmlEncode="false" SortExpression="NEW_PERC" UniqueName="NEW_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter RENEWAL_PERC column" HeaderText="% RENEWAL" 
                                                                    HtmlEncode="false" SortExpression="RENEWAL_PERC" UniqueName="RENEWAL_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PERC_PRODUCTION" 
                                                                    DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter PERC_PRODUCTION column" HeaderText="PRODUCTION" 
                                                                    HtmlEncode="false" SortExpression="PERC_PRODUCTION" 
                                                                    UniqueName="PERC_PRODUCTION">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="DEFICIT" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter DEFICIT column" HeaderText="DEFICIT" 
                                                                    SortExpression="DEFICIT" UniqueName="DEFICIT">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <SelectedItemStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label90" runat="server" style="font-weight: 700" 
                                                    Text="MONTH PRODUCTION"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel18" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GDSEARCH_U_1" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Web20" 
                                                        Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="MONTH_FROM">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                      <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_FROM" 
                                                                    FilterControlAltText="Filter MONTH_FROM column" HeaderText="MONTH_FROM" 
                                                                    SortExpression="MONTH_FROM" UniqueName="MONTH_FROM">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_TO" 
                                                                    FilterControlAltText="Filter MONTH_TO column" HeaderText="MONTH_TO" 
                                                                    SortExpression="MONTH_TO" UniqueName="MONTH_TO">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="MEDICAL NEW(B)" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_MED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_MED column" HeaderText="MEDICAL NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW_MED" UniqueName="ACTUAL_NEW_MED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NONMEDICAL(B)" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_NONMED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_NONMED column" 
                                                                    HeaderText="NONMED_NEW(A)" SortExpression="ACTUAL_NEW_NONMED" 
                                                                    UniqueName="ACTUAL_NEW_NONMED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_BUDGET column" HeaderText="NEW BUDGET" 
                                                                    SortExpression="NEW_BUDGET" UniqueName="NEW_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW column" HeaderText="NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW" UniqueName="ACTUAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_BUDGET" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_BUDGET column" HeaderText="RENEWAL BUDGET" 
                                                                    SortExpression="RENEWAL_BUDGET" UniqueName="RENEWAL_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_RENEW column" HeaderText="RENEWAL(A)" 
                                                                    SortExpression="ACTUAL_RENEW" UniqueName="ACTUAL_RENEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter MONTH_BUDGET column" HeaderText="MONTH BUDGET(B)" 
                                                                    SortExpression="MONTH_BUDGET" UniqueName="MONTH_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_PROD" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_PROD column" HeaderText="MONTH PROD(A)" 
                                                                    SortExpression="ACTUAL_PROD" UniqueName="ACTUAL_PROD">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter NEW_PERC column" HeaderText="% NEW" 
                                                                    HtmlEncode="false" SortExpression="NEW_PERC" UniqueName="NEW_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter RENEWAL_PERC column" HeaderText="% RENEWAL" 
                                                                    HtmlEncode="false" SortExpression="RENEWAL_PERC" UniqueName="RENEWAL_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PERC_PRODUCTION" 
                                                                    DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter PERC_PRODUCTION column" HeaderText="PRODUCTION" 
                                                                    HtmlEncode="false" SortExpression="PERC_PRODUCTION" 
                                                                    UniqueName="PERC_PRODUCTION">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="DEFICIT" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter DEFICIT column" HeaderText="DEFICIT" 
                                                                    SortExpression="DEFICIT" UniqueName="DEFICIT">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                <telerik:RadPageView ID="V3" runat="server" Width="1200px" Selected="True">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label2" runat="server" style="font-weight: 700" 
                                                    Text="REGIONAL MANAGER -YTD"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel24" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GDSEARCH_R" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Web20" 
                                                        Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="R_CODE">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="RM_NAME" 
                                                                    FilterControlAltText="Filter RM_NAME column" HeaderText="RM_NAME" 
                                                                    SortExpression="RM_NAME" UniqueName="RM_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="REGION_NAME" 
                                                                    FilterControlAltText="Filter REGION_NAME column" HeaderText="REGION_NAME" 
                                                                    SortExpression="REGION_NAME" UniqueName="REGION_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="MEDICAL NEW(B)" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_MED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_MED column" HeaderText="MEDICAL NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW_MED" UniqueName="ACTUAL_NEW_MED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NONMEDICAL(B)" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_NONMED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_NONMED column" 
                                                                    HeaderText="NONMED_NEW(A)" SortExpression="ACTUAL_NEW_NONMED" 
                                                                    UniqueName="ACTUAL_NEW_NONMED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_BUDGET column" HeaderText="NEW BUDGET" 
                                                                    SortExpression="NEW_BUDGET" UniqueName="NEW_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW column" HeaderText="NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW" UniqueName="ACTUAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_BUDGET" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_BUDGET column" HeaderText="RENEWAL BUDGET" 
                                                                    SortExpression="RENEWAL_BUDGET" UniqueName="RENEWAL_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_RENEW column" HeaderText="RENEWAL(A)" 
                                                                    SortExpression="ACTUAL_RENEW" UniqueName="ACTUAL_RENEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter MONTH_BUDGET column" HeaderText="MONTH BUDGET(B)" 
                                                                    SortExpression="MONTH_BUDGET" UniqueName="MONTH_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_PROD" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_PROD column" HeaderText="MONTH PROD(A)" 
                                                                    SortExpression="ACTUAL_PROD" UniqueName="ACTUAL_PROD">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter NEW_PERC column" HeaderText="% NEW" 
                                                                    HtmlEncode="false" SortExpression="NEW_PERC" UniqueName="NEW_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter RENEWAL_PERC column" HeaderText="% RENEWAL" 
                                                                    HtmlEncode="false" SortExpression="RENEWAL_PERC" UniqueName="RENEWAL_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PERC_PRODUCTION" 
                                                                    DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter PERC_PRODUCTION column" HeaderText="PRODUCTION" 
                                                                    HtmlEncode="false" SortExpression="PERC_PRODUCTION" 
                                                                    UniqueName="PERC_PRODUCTION">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="DEFICIT" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter DEFICIT column" HeaderText="DEFICIT" 
                                                                    SortExpression="DEFICIT" UniqueName="DEFICIT">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <SelectedItemStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label92" runat="server" style="font-weight: 700" 
                                                    Text="Month Production"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel23" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GDSEARCH_R_1" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="12" Skin="Web20" 
                                                        Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="MONTH_FROM">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_FROM" 
                                                                    FilterControlAltText="Filter MONTH_FROM column" HeaderText="MONTH_FROM" 
                                                                    SortExpression="MONTH_FROM" UniqueName="MONTH_FROM">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_TO" 
                                                                    FilterControlAltText="Filter MONTH_TO column" HeaderText="MONTH_TO" 
                                                                    SortExpression="MONTH_TO" UniqueName="MONTH_TO">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="MEDICAL NEW(B)" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_MED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_MED column" HeaderText="MEDICAL NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW_MED" UniqueName="ACTUAL_NEW_MED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NONMEDICAL(B)" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW_NONMED" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW_NONMED column" 
                                                                    HeaderText="NONMED_NEW(A)" SortExpression="ACTUAL_NEW_NONMED" 
                                                                    UniqueName="ACTUAL_NEW_NONMED">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_BUDGET column" HeaderText="NEW BUDGET" 
                                                                    SortExpression="NEW_BUDGET" UniqueName="NEW_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW column" HeaderText="NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW" UniqueName="ACTUAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_BUDGET" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_BUDGET column" HeaderText="RENEWAL BUDGET" 
                                                                    SortExpression="RENEWAL_BUDGET" UniqueName="RENEWAL_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_RENEW column" HeaderText="RENEWAL(A)" 
                                                                    SortExpression="ACTUAL_RENEW" UniqueName="ACTUAL_RENEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter MONTH_BUDGET column" HeaderText="MONTH BUDGET(B)" 
                                                                    SortExpression="MONTH_BUDGET" UniqueName="MONTH_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_PROD" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_PROD column" HeaderText="MONTH PROD(A)" 
                                                                    SortExpression="ACTUAL_PROD" UniqueName="ACTUAL_PROD">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter NEW_PERC column" HeaderText="% NEW" 
                                                                    HtmlEncode="false" SortExpression="NEW_PERC" UniqueName="NEW_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter RENEWAL_PERC column" HeaderText="% RENEWAL" 
                                                                    HtmlEncode="false" SortExpression="RENEWAL_PERC" UniqueName="RENEWAL_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PERC_PRODUCTION" 
                                                                    DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter PERC_PRODUCTION column" HeaderText="PRODUCTION" 
                                                                    HtmlEncode="false" SortExpression="PERC_PRODUCTION" 
                                                                    UniqueName="PERC_PRODUCTION">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="DEFICIT" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter DEFICIT column" HeaderText="DEFICIT" 
                                                                    SortExpression="DEFICIT" UniqueName="DEFICIT">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <SelectedItemStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                   <telerik:RadPageView ID="V6" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label5" runat="server" style="font-weight: 700" 
                                                    Text="PRODUCTION PER CHANNEL"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GD_CHANNEL_0" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="12" Skin="Web20" Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="CHANNEL_NAME">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>

                                                                <telerik:GridBoundColumn DataField="CHANNEL_NAME" 
                                                                    FilterControlAltText="Filter CHANNEL_NAME column" HeaderText="CHANNEL" 
                                                                    SortExpression="CHANNEL_NAME" UniqueName="CHANNEL_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="NEW_MEDICAL" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NEW_NON_MEDICAL" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="TOTAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_NEW column" HeaderText="TOTAL_NEW" 
                                                                    SortExpression="TOTAL_NEW" UniqueName="TOTAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="RENEWAL_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_MEDICAL column" HeaderText="RENEWAL_MEDICAL" 
                                                                    SortExpression="RENEWAL_MEDICAL" UniqueName="RENEWAL_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_NONMEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_NONMEDICAL column" HeaderText="RENEWAL_NONMEDICAL" 
                                                                    SortExpression="RENEWAL_NONMEDICAL" UniqueName="RENEWAL_NONMEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="TOTAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_RENEW column" HeaderText="TOTAL_RENEW" 
                                                                    SortExpression="TOTAL_RENEW" UniqueName="TOTAL_RENEW">
                                                                </telerik:GridBoundColumn>                                                              
                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_PREMIUM column" HeaderText="TOTAL_PREMIUM" 
                                                                    SortExpression="TOTAL_PREMIUM" UniqueName="TOTAL_PREMIUM">
                                                                </telerik:GridBoundColumn>
                                                                                                                           
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                &nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                  <telerik:RadPageView ID="V7" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label8" runat="server" style="font-weight: 700" 
                                                    Text="PRODUCTION PER MARKET"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel5" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GD_MARKET_0" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="12" Skin="Web20" Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="MARKET_NAME">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>                                                              
                                                                <telerik:GridBoundColumn DataField="MARKET_NAME" 
                                                                    FilterControlAltText="Filter MARKET_NAME column" HeaderText="MARKET_NAME" 
                                                                    SortExpression="MARKET_NAME" UniqueName="MARKET_NAME">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="NEW_MEDICAL" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NEW_NON_MEDICAL" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="TOTAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_NEW column" HeaderText="TOTAL_NEW" 
                                                                    SortExpression="TOTAL_NEW" UniqueName="TOTAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="RENEWAL_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_MEDICAL column" HeaderText="RENEWAL_MEDICAL" 
                                                                    SortExpression="RENEWAL_MEDICAL" UniqueName="RENEWAL_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_NONMEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_NONMEDICAL column" HeaderText="RENEWAL_NONMEDICAL" 
                                                                    SortExpression="RENEWAL_NONMEDICAL" UniqueName="RENEWAL_NONMEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="TOTAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_RENEW column" HeaderText="TOTAL_RENEW" 
                                                                    SortExpression="TOTAL_RENEW" UniqueName="TOTAL_RENEW">
                                                                </telerik:GridBoundColumn>                                                              
                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_PREMIUM column" HeaderText="TOTAL_PREMIUM" 
                                                                    SortExpression="TOTAL_PREMIUM" UniqueName="TOTAL_PREMIUM">
                                                                </telerik:GridBoundColumn>
                                                                                                                           
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                 <telerik:RadPageView ID="V8" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label10" runat="server" style="font-weight: 700" 
                                                    Text="PRODUCTION PER TITLE"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GD_TITLE_0" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="TITLE_NAME">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                          
                                                                <telerik:GridBoundColumn DataField="TITLE_NAME" 
                                                                    FilterControlAltText="Filter TITLE_NAME column" HeaderText="TITLE_NAME" 
                                                                    SortExpression="TITLE_NAME" UniqueName="TITLE_NAME">
                                                                </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="NEW_MEDICAL" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NEW_NON_MEDICAL" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="TOTAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_NEW column" HeaderText="TOTAL_NEW" 
                                                                    SortExpression="TOTAL_NEW" UniqueName="TOTAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="RENEWAL_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_MEDICAL column" HeaderText="RENEWAL_MEDICAL" 
                                                                    SortExpression="RENEWAL_MEDICAL" UniqueName="RENEWAL_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_NONMEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_NONMEDICAL column" HeaderText="RENEWAL_NONMEDICAL" 
                                                                    SortExpression="RENEWAL_NONMEDICAL" UniqueName="RENEWAL_NONMEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="TOTAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_RENEW column" HeaderText="TOTAL_RENEW" 
                                                                    SortExpression="TOTAL_RENEW" UniqueName="TOTAL_RENEW">
                                                                </telerik:GridBoundColumn>                                                              
                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_PREMIUM column" HeaderText="TOTAL_PREMIUM" 
                                                                    SortExpression="TOTAL_PREMIUM" UniqueName="TOTAL_PREMIUM">
                                                                </telerik:GridBoundColumn>                                                         
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                &nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                 <telerik:RadPageView ID="V2" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label1" runat="server" style="font-weight: 700" 
                                                    Text="IN HOUSE "></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel21" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="GDSEARCH_Y" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="25" Skin="Web20" 
                                                        Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="USER_ID">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="AGENT_NAME" 
                                                                    FilterControlAltText="Filter AGENT_NAME column" HeaderText="AGENT_NAME" 
                                                                    SortExpression="AGENT_NAME" UniqueName="AGENT_NAME">
                                                                </telerik:GridBoundColumn>
                                                            
                                                                
                                                                <telerik:GridBoundColumn DataField="NEW_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_BUDGET column" HeaderText="NEW BUDGET" 
                                                                    SortExpression="NEW_BUDGET" UniqueName="NEW_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_NEW column" HeaderText="NEW(A)" 
                                                                    SortExpression="ACTUAL_NEW" UniqueName="ACTUAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_BUDGET" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_BUDGET column" HeaderText="RENEWAL BUDGET" 
                                                                    SortExpression="RENEWAL_BUDGET" UniqueName="RENEWAL_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_RENEW column" HeaderText="RENEWAL(A)" 
                                                                    SortExpression="ACTUAL_RENEW" UniqueName="ACTUAL_RENEW">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="MONTH_BUDGET" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter MONTH_BUDGET column" HeaderText="MONTH BUDGET(B)" 
                                                                    SortExpression="MONTH_BUDGET" UniqueName="MONTH_BUDGET">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="ACTUAL_PROD" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter ACTUAL_PROD column" HeaderText="MONTH PROD(A)" 
                                                                    SortExpression="ACTUAL_PROD" UniqueName="ACTUAL_PROD">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="NEW_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter NEW_PERC column" HeaderText="% NEW" 
                                                                    HtmlEncode="false" SortExpression="NEW_PERC" UniqueName="NEW_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_PERC" DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter RENEWAL_PERC column" HeaderText="% RENEWAL" 
                                                                    HtmlEncode="false" SortExpression="RENEWAL_PERC" UniqueName="RENEWAL_PERC">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PERC_PRODUCTION" 
                                                                    DataFormatString="{0:F2} %" 
                                                                    FilterControlAltText="Filter PERC_PRODUCTION column" HeaderText="PRODUCTION" 
                                                                    HtmlEncode="false" SortExpression="PERC_PRODUCTION" 
                                                                    UniqueName="PERC_PRODUCTION">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="DEFICIT" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter DEFICIT column" HeaderText="DEFICIT" 
                                                                    SortExpression="DEFICIT" UniqueName="DEFICIT">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                &nbsp;</td>
                                        </tr>
                                            <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>

                                </telerik:RadPageView>
                                  <telerik:RadPageView ID="V11" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label13" runat="server" style="font-weight: 700" 
                                                    Text="INDEPENDENT AGENTS"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel10" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="RD_IND" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="AGENT_ID">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="USER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter USER_DISPLAY_NAME column" HeaderText="USER_DISPLAY_NAME" 
                                                                    SortExpression="USER_DISPLAY_NAME" UniqueName="USER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="NEW_MEDICAL" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NEW_NON_MEDICAL" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="TOTAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_NEW column" HeaderText="TOTAL_NEW" 
                                                                    SortExpression="TOTAL_NEW" UniqueName="TOTAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="RENEWAL_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_MEDICAL column" HeaderText="RENEWAL_MEDICAL" 
                                                                    SortExpression="RENEWAL_MEDICAL" UniqueName="RENEWAL_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_NONMEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_NONMEDICAL column" HeaderText="RENEWAL_NONMEDICAL" 
                                                                    SortExpression="RENEWAL_NONMEDICAL" UniqueName="RENEWAL_NONMEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="TOTAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_RENEW column" HeaderText="TOTAL_RENEW" 
                                                                    SortExpression="TOTAL_RENEW" UniqueName="TOTAL_RENEW">
                                                                </telerik:GridBoundColumn>                                                              
                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_PREMIUM column" HeaderText="TOTAL_PREMIUM" 
                                                                    SortExpression="TOTAL_PREMIUM" UniqueName="TOTAL_PREMIUM">
                                                                </telerik:GridBoundColumn>                                                         
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                &nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                <telerik:RadPageView ID="V12" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label15" runat="server" style="font-weight: 700" 
                                                    Text="BROKERS"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="RD_BROKER" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="AGENT_ID">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                 <telerik:GridBoundColumn DataField="USER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter USER_DISPLAY_NAME column" HeaderText="USER_DISPLAY_NAME" 
                                                                    SortExpression="USER_DISPLAY_NAME" UniqueName="USER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="NEW_MEDICAL" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NEW_NON_MEDICAL" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="TOTAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_NEW column" HeaderText="TOTAL_NEW" 
                                                                    SortExpression="TOTAL_NEW" UniqueName="TOTAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="RENEWAL_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_MEDICAL column" HeaderText="RENEWAL_MEDICAL" 
                                                                    SortExpression="RENEWAL_MEDICAL" UniqueName="RENEWAL_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_NONMEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_NONMEDICAL column" HeaderText="RENEWAL_NONMEDICAL" 
                                                                    SortExpression="RENEWAL_NONMEDICAL" UniqueName="RENEWAL_NONMEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="TOTAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_RENEW column" HeaderText="TOTAL_RENEW" 
                                                                    SortExpression="TOTAL_RENEW" UniqueName="TOTAL_RENEW">
                                                                </telerik:GridBoundColumn>                                                              
                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_PREMIUM column" HeaderText="TOTAL_PREMIUM" 
                                                                    SortExpression="TOTAL_PREMIUM" UniqueName="TOTAL_PREMIUM">
                                                                </telerik:GridBoundColumn>                                                         
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                &nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                <telerik:RadPageView ID="V13" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label17" runat="server" style="font-weight: 700" 
                                                    Text="BANCASSURANCE"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="RD_BANC" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="AGENT_ID">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="USER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter USER_DISPLAY_NAME column" HeaderText="USER_DISPLAY_NAME" 
                                                                    SortExpression="USER_DISPLAY_NAME" UniqueName="USER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="NEW_MEDICAL" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NEW_NON_MEDICAL" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="TOTAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_NEW column" HeaderText="TOTAL_NEW" 
                                                                    SortExpression="TOTAL_NEW" UniqueName="TOTAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="RENEWAL_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_MEDICAL column" HeaderText="RENEWAL_MEDICAL" 
                                                                    SortExpression="RENEWAL_MEDICAL" UniqueName="RENEWAL_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_NONMEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_NONMEDICAL column" HeaderText="RENEWAL_NONMEDICAL" 
                                                                    SortExpression="RENEWAL_NONMEDICAL" UniqueName="RENEWAL_NONMEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="TOTAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_RENEW column" HeaderText="TOTAL_RENEW" 
                                                                    SortExpression="TOTAL_RENEW" UniqueName="TOTAL_RENEW">
                                                                </telerik:GridBoundColumn>                                                              
                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_PREMIUM column" HeaderText="TOTAL_PREMIUM" 
                                                                    SortExpression="TOTAL_PREMIUM" UniqueName="TOTAL_PREMIUM">
                                                                </telerik:GridBoundColumn>                                                         
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                &nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                                <telerik:RadPageView ID="V14" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label19" runat="server" style="font-weight: 700" 
                                                    Text="DIRECT SALES"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel22" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="RD_DI" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="AGENT_ID">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="USER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter USER_DISPLAY_NAME column" HeaderText="USER_DISPLAY_NAME" 
                                                                    SortExpression="USER_DISPLAY_NAME" UniqueName="USER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="NEW_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_MEDICAL column" HeaderText="NEW_MEDICAL" 
                                                                    SortExpression="NEW_MEDICAL" UniqueName="NEW_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="NEW_NON_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter NEW_NON_MEDICAL column" HeaderText="NEW_NON_MEDICAL" 
                                                                    SortExpression="NEW_NON_MEDICAL" UniqueName="NEW_NON_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="TOTAL_NEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_NEW column" HeaderText="TOTAL_NEW" 
                                                                    SortExpression="TOTAL_NEW" UniqueName="TOTAL_NEW">
                                                                </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="RENEWAL_MEDICAL" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_MEDICAL column" HeaderText="RENEWAL_MEDICAL" 
                                                                    SortExpression="RENEWAL_MEDICAL" UniqueName="RENEWAL_MEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="RENEWAL_NONMEDICAL" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter RENEWAL_NONMEDICAL column" HeaderText="RENEWAL_NONMEDICAL" 
                                                                    SortExpression="RENEWAL_NONMEDICAL" UniqueName="RENEWAL_NONMEDICAL">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="TOTAL_RENEW" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_RENEW column" HeaderText="TOTAL_RENEW" 
                                                                    SortExpression="TOTAL_RENEW" UniqueName="TOTAL_RENEW">
                                                                </telerik:GridBoundColumn>                                                              
                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" 
                                                                    DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter TOTAL_PREMIUM column" HeaderText="TOTAL_PREMIUM" 
                                                                    SortExpression="TOTAL_PREMIUM" UniqueName="TOTAL_PREMIUM">
                                                                </telerik:GridBoundColumn>                                                         
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999">
                                                &nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                        <telerik:RadPageView ID="V15" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label21" runat="server" style="font-weight: 700" 
                                                    Text="NEW BUSINESS"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel26" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="RD_NEW" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="100" Skin="Web20" 
                                                        Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                 <telerik:GridBoundColumn DataField="USER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter USER_DISPLAY_NAME column" 
                                                                    HeaderText="AGENT NAME" SortExpression="USER_DISPLAY_NAME" 
                                                                    UniqueName="USER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                    HeaderText="PROPOSER NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                    UniqueName="PROPOSER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>                                                             
                                                                <telerik:GridBoundColumn DataField="BUSINESS" 
                                                                    FilterControlAltText="Filter BUSINESS column" HeaderText="BUSINESS" 
                                                                    SortExpression="BUSINESS" UniqueName="BUSINESS">
                                                                </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="BUSINESS_TYPE" 
                                                                    FilterControlAltText="Filter BUSINESS_TYPE column" HeaderText="BUSINESS_TYPE" 
                                                                    SortExpression="BUSINESS_TYPE" UniqueName="BUSINESS_TYPE">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PREMIUM" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter PREMIUM column" HeaderText="PREMIUM" 
                                                                    SortExpression="PREMIUM" UniqueName="PREMIUM">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                                        <telerik:RadPageView ID="V16" runat="server" Width="1200px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999">
                                                <asp:Label ID="Label22" runat="server" style="font-weight: 700" 
                                                    Text="RENEWAL"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Panel ID="Panel27" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="1200px">
                                                    <telerik:RadGrid ID="RD_REN" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="100" Skin="Web20" 
                                                        Width="1200px">
                                                        <MasterTableView AutoGenerateColumns="False">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                               <telerik:GridBoundColumn DataField="USER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter USER_DISPLAY_NAME column" 
                                                                    HeaderText="AGENT NAME" SortExpression="USER_DISPLAY_NAME" 
                                                                    UniqueName="USER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                    FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                    HeaderText="PROPOSER NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                    UniqueName="PROPOSER_DISPLAY_NAME">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="BUSINESS_TYPE" 
                                                                    FilterControlAltText="Filter BUSINESS_TYPE column" HeaderText="BUSINESS_TYPE" 
                                                                    SortExpression="BUSINESS_TYPE" UniqueName="BUSINESS_TYPE">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="BUSINESS" 
                                                                    FilterControlAltText="Filter BUSINESS column" HeaderText="BUSINESS" 
                                                                    SortExpression="BUSINESS" UniqueName="BUSINESS">
                                                                </telerik:GridBoundColumn>
                                                          
                                                                <telerik:GridBoundColumn DataField="PREMIUM" DataFormatString="{0:#,#.##}" 
                                                                    FilterControlAltText="Filter PREMIUM column" HeaderText="PREMIUM" 
                                                                    SortExpression="PREMIUM" UniqueName="PREMIUM">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <HeaderStyle Wrap="False" />
                                                        <ItemStyle Wrap="False" />
                                                        <PagerStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                    </table>
                                </telerik:RadPageView>
                            </telerik:RadMultiPage>

                        </asp:Panel>
                    </td>
                </tr>
                  <tr>
                    <td>
                      
                        <asp:Label ID="lblCODE" runat="server" ForeColor="#CC0000" Visible="False"></asp:Label>
                      </td>
                </tr>
                <tr>
                    <td>
                        <asp:Label ID="lbltext" runat="server" ForeColor="#CC0000"></asp:Label>
                    </td>
                </tr>

            </table>
             <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Width="1200px" Wrap="False">
                                            <table style="width: 61%">
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        &nbsp;</td>
                                                    <td style="width: 81px">
                                                        &nbsp;</td>
                                                    <td class="style10" bgcolor="#999999" colspan="3">
                                                        <asp:Label ID="Label93" runat="server" style="font-weight: 700" 
                                                            Text="Report Export"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style11" style="width: 115px">
                                                        &nbsp;</td>
                                                    <td style="width: 81px">
                                                        &nbsp;</td>
                                                    <td class="style10" style="width: 264px">
                                                        <asp:Label ID="Label91" runat="server" Text="Report Name"></asp:Label>
                                                    </td>
                                                    <td style="width: 173px">
                                                        <telerik:RadComboBox ID="cbosear" Runat="server" Skin="Web20" 
                                                            style="margin-left: 0px" Width="227px">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" Text="Regional" 
                                                                    Value="RM" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" Text="Unit Production" 
                                                                    Value="BDM" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Tracked Business" Value="TB" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" 
                                                                    Text="Production-Channel" Value="C" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" 
                                                                    Text="Production-Market" Value="M" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" Text="Production-Title" 
                                                                    Value="T" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" 
                                                                    Text="INHouse Production" Value="I" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" 
                                                                    Text="Independent Production" Value="IND" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" 
                                                                    Text="Brokers Production" Value="BRK" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" Text="BANC-Assurance" 
                                                                    Value="BANC" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" 
                                                                    Text="Debits-Invoice Date" Value="D" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbosear" 
                                                                    Text="Debits-Production" Value="P" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Portifolio" Value="PL" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Tracked Business" Value="TB" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="width: 151px">
                                                        <telerik:RadButton ID="btnGenerate" runat="server" Skin="Web20" 
                                                            Text="Export To Excel">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                        </div>
        </ContentTemplate>

    </asp:UpdatePanel>
</asp:Content>

