﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
'Imports Microsoft.Office.Interop.Word
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Configuration

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyDatatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim Str As String = ""
    Dim empcode As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            DTactivity.DbSelectedDate = Date.Now()
            dtfrom.DbSelectedDate = Date.Now()
            DTto.DbSelectedDate = Date.Now()
            Session("D_INTRO_1") = Nothing
            Session("D_MEM_1") = Nothing
            Session("ACT_01") = Nothing
            Str = ""
     
            Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                'Session("emp_code") = "0104"
            Else
                lblerr.Text = "You are not authorized to view this page"
                Exit Sub
            End If

            Str = "SELECT  [ACTIVITY_CODE],[ACTIVITY_NAME]  FROM CRM.[dbo].[TBL_MIS_RET_ACTIVITY] where TASK='S'"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboactivity
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ACTIVITY_NAME").ToString
                .DataValueField = MyDatatable.Columns("ACTIVITY_CODE").ToString
                .DataBind()

            End With

            MyDatatable = Nothing


            loadGrid()

        End If
    End Sub

    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        MyDatable = Nothing
        SqlAction = "SELECT   [PROPOSER_DISPLAY_NAME],[PERIOD_FROM],[PERIOD_TO],[ACT_DUE_DATE] FROM [CRM].[dbo].[VW_MIS_CRM_50_DUE] WHERE (MONTH([ACT_DUE_DATE])=MONTH(GETDATE())) AND [RM_CODE]='" & Session("emp_code") & "' AND PERIOD_TO>=GETDATE()"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_50_0.DataSource = MyDatable
            GD_50_0.DataBind()
            Session("GD_50") = MyDatable
            MyDatable = Nothing
        Else
            GD_50_0.DataSource = MyDatable
            GD_50_0.DataBind()
        End If

        MyDatable = Nothing
        SqlAction = "SELECT   [PROPOSER_DISPLAY_NAME],[PERIOD_FROM],[PERIOD_TO],[ACT_DUE_DATE] FROM [CRM].[dbo].[VW_MIS_CRM_20_DUE] WHERE (MONTH([ACT_DUE_DATE])=MONTH(GETDATE())) AND [RM_CODE]='" & Session("emp_code") & "' AND PERIOD_TO>=GETDATE()"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_20_0.DataSource = MyDatable
            GD_20_0.DataBind()
            Session("GD_50") = MyDatable
            MyDatable = Nothing
        Else
            GD_20_0.DataSource = MyDatable
            GD_20_0.DataBind()
        End If

        MyDatable = Nothing
        SqlAction = "SELECT   [PROPOSER_DISPLAY_NAME],[PERIOD_FROM],[PERIOD_TO],[ACT_DUE_DATE] FROM [CRM].[dbo].[VW_MIS_CRM_5_DUE] WHERE (MONTH([ACT_DUE_DATE])=MONTH(GETDATE())) AND [RM_CODE]='" & Session("emp_code") & "' AND PERIOD_TO>=GETDATE()"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_5_0.DataSource = MyDatable
            GD_5_0.DataBind()
            Session("GD_50") = MyDatable
            MyDatable = Nothing
        Else
            GD_5_0.DataSource = MyDatable
            GD_5_0.DataBind()
        End If
        MyDatable = Nothing
        SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_50M] WHERE [RM_CODE]='" & Session("emp_code") & "' AND PERIOD_TO>=GETDATE()"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_50.DataSource = MyDatable
            GD_50.DataBind()
            Session("GD_50") = MyDatable
            MyDatable = Nothing
        Else
            GD_50.DataSource = MyDatable
            GD_50.DataBind()
        End If

        SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_20M] WHERE [RM_CODE]='" & Session("emp_code") & "' AND (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE()))"
        '   SqlAction = "SELECT CORPORATE_ID, PROPOSER_DISPLAY_NAME,PREMIUMS,LIVES,EXP_TOTAL_ACT,CNT_SERVICE_MTG,CNT_HEALTH_TKS,CNT_COURT_VISITS,MED_CAMP,CNT_OTHER_ACT,CNT_ACTIVITIES,SPONSORSHIP,PERC_ACTIVITIES FROM [TBL_MIS_RET_CORP_GWP_20M]  WHERE [RM_CODE]='" & Session("emp_code") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_20.DataSource = MyDatable
            GD_20.DataBind()
            Session("GD_20") = MyDatable
            MyDatable = Nothing
        Else
            GD_20.DataSource = MyDatable
            GD_20.DataBind()
        End If

        SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_5M] WHERE [RM_CODE]='" & Session("emp_code") & "' AND (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE()))"
        ' SqlAction = "SELECT CORPORATE_ID, PROPOSER_DISPLAY_NAME,PREMIUMS,LIVES,EXP_TOTAL_ACT,CNT_SERVICE_MTG,CNT_HEALTH_TKS,CNT_COURT_VISITS,MED_CAMP,CNT_OTHER_ACT,CNT_ACTIVITIES,SPONSORSHIP,PERC_ACTIVITIES FROM [TBL_MIS_RET_CORP_GWP_5M]  WHERE [RM_CODE]='" & Session("emp_code") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_5.DataSource = MyDatable
            GD_5.DataBind()
            Session("GD_5") = MyDatable
            MyDatable = Nothing
        Else
            GD_5.DataSource = MyDatable
            GD_5.DataBind()
        End If
        SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_1M] WHERE [RM_CODE]='" & Session("emp_code") & "' AND (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE()))"
        ' SqlAction = "SELECT CORPORATE_ID, PROPOSER_DISPLAY_NAME,PREMIUMS,LIVES,EXP_TOTAL_ACT,CNT_SERVICE_MTG,CNT_HEALTH_TKS,CNT_COURT_VISITS,MED_CAMP,CNT_OTHER_ACT,CNT_ACTIVITIES,SPONSORSHIP,PERC_ACTIVITIES FROM [TBL_MIS_RET_CORP_GWP_1M]  WHERE [RM_CODE]='" & Session("emp_code") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_1.DataSource = MyDatable
            GD_1.DataBind()
            Session("GD_1") = MyDatable
            MyDatable = Nothing
        Else
            GD_1.DataSource = MyDatable
            GD_1.DataBind()
        End If

        SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_M] WHERE [RM_CODE]='" & Session("emp_code") & "' AND (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE()))"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_M.DataSource = MyDatable
            GD_M.DataBind()
            Session("GD_M") = MyDatable
            MyDatable = Nothing
        Else
            GD_M.DataSource = MyDatable
            GD_M.DataBind()
        End If

        SqlAction = "SELECT    [FROM_DT],[TO_DT],[RE_CODE],[RE_NAME],[CLASS_CODE],[TOT_CORP_COUNT],[EXP_CNT_ACTIVITY],[ACT_CNT_ACTIVITY],[PERC_PERF],[NSM_CODE]  FROM [CRM].[dbo].[TBL_MIS_CRM_ACT_PRODUCTION] WHERE [RE_CODE]='" & Session("emp_code") & "' AND YEAR(FROM_DT)=YEAR(GETDATE())"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_PROD.DataSource = MyDatable
            GD_PROD.DataBind()
            'Session("GD_M") = MyDatable
            MyDatable = Nothing
        Else
            GD_PROD.DataSource = MyDatable
            GD_PROD.DataBind()
        End If

    End Sub
    Public Sub LOAD_ACTIVITY(ByVal ID As String)
        SqlAction = "SELECT  [ACTIVITY_ID],[CORPORATE_ID],[ACT_CODE],[ACT_DUE_DATE],[ACT_PERIOD],[ACT_NAME],[ACT_DATE],[ACT_MINUTES],[FILE_NAME],[PERIOD_FROM],[PERIOD_TO],[ACTIVITY_NAME]  FROM [CRM].[dbo].[VW_RETENTION_ACTIVITY_REV] WHERE CORPORATE_ID='" & ID & "' AND ACT_DUE_DATE>=GETDATE() AND   ACT_PERIOD='" & lblIQ.Text & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
            Session("ACT_01") = MyDatable
            MyDatable = Nothing
        Else
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
        End If
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GD_50.SelectedIndexChanged
        Dim ID As String = ""
        ltEmbed.Text = ""
        Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
        cboactivity.SelectedValue = ""
        cboactivity.Text = ""
        ID = (DirectCast(GD_50.SelectedItems(0), GridDataItem)).GetDataKeyValue("CORPORATE_ID").ToString()
        Dim SqlAction As String = ""
        Session("status_1") = Nothing

        SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,MOBILE_NO,CONTACT_PERSON, [PERIOD_FROM],[PERIOD_TO],Q1_FROM,[Q1_TO_DATE],Q2_FROM,[Q2_TO],Q3_FROM,[Q3_TO],Q4_FROM,[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_50M] WHERE  [CORPORATE_ID]='" & ID & "'"

        '    SqlAction = "SELECT CORPORATE_ID, PROPOSER_DISPLAY_NAME,PREMIUMS,[CONTACT_PERSON],[MOBILE_NO], LIVES,EXP_TOTAL_ACT,CNT_SERVICE_MTG,CNT_HEALTH_TKS,CNT_COURT_VISITS,MED_CAMP,CNT_OTHER_ACT,CNT_ACTIVITIES,SPONSORSHIP,PERC_ACTIVITIES FROM [TBL_MIS_RET_CORP_GWP_50M]  WHERE [CORPORATE_ID]='" & ID & "'"

        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
            lblcontact.Text = MyDatable.Rows(0).Item("MOBILE_NO").ToString()
            lblcontactperson.Text = MyDatable.Rows(0).Item("CONTACT_PERSON").ToString()
            'dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
            'DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()
            lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
            'txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
            dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("Q1_FROM").ToString()
            DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

            Dim Q1_FROM = MyDatable.Rows(0).Item("Q1_FROM").ToString()
            Dim Q1_TO_DATE = MyDatable.Rows(0).Item("Q1_TO_DATE").ToString()
            Dim Q2_FROM = MyDatable.Rows(0).Item("Q2_FROM").ToString()
            Dim Q2_TO = MyDatable.Rows(0).Item("Q2_TO").ToString()
            Dim Q3_FROM = MyDatable.Rows(0).Item("Q3_FROM").ToString()
            Dim Q3_TO = MyDatable.Rows(0).Item("Q3_TO").ToString()
            Dim Q4_FROM = MyDatable.Rows(0).Item("Q4_FROM").ToString()
            Dim Q4_TO = MyDatable.Rows(0).Item("Q4_TO").ToString()
            Select Case CURDATE
                Case Q1_FROM To Q1_TO_DATE
                    lblIQ.Text = "Q1"
                Case Q2_FROM To Q2_TO
                    lblIQ.Text = "Q2"
                Case Q3_FROM To Q3_TO
                    lblIQ.Text = "Q3"
                Case Q4_FROM To Q4_TO
                    lblIQ.Text = "Q4"
            End Select
            LOAD_ACTIVITY(lblID.Text)
        End If
        'HiddenField1.Value = 1



        dtfrom.Enabled = False
        DTto.Enabled = False

    End Sub
  
    Protected Sub GD_50_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_50.PageIndexChanged
        GD_50.CurrentPageIndex = e.NewPageIndex
        GD_50.DataSource = Session("GD_50")
        GD_50.DataBind()
    End Sub
    Protected Sub GD_20_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_20.PageIndexChanged
        GD_20.CurrentPageIndex = e.NewPageIndex
        GD_20.DataSource = Session("GD_20")
        GD_20.DataBind()
    End Sub
    Protected Sub GD_5_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_5.PageIndexChanged
        GD_5.CurrentPageIndex = e.NewPageIndex
        GD_5.DataSource = Session("GD_5")
        GD_5.DataBind()
    End Sub
    Protected Sub GD_1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_1.PageIndexChanged
        GD_1.CurrentPageIndex = e.NewPageIndex
        GD_1.DataSource = Session("GD_1")
        GD_1.DataBind()
    End Sub
    Protected Sub GD_M_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_M.PageIndexChanged
        GD_M.CurrentPageIndex = e.NewPageIndex
        GD_M.DataSource = Session("GD_M")
        GD_M.DataBind()
    End Sub
    Protected Sub RD_ACTIVITY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_ACTIVITY.PageIndexChanged
        RD_ACTIVITY.CurrentPageIndex = e.NewPageIndex
        RD_ACTIVITY.DataSource = Session("ACT_01")
        RD_ACTIVITY.DataBind()
    End Sub
    

    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0


        Dim FILENO As String

        If cboactivity.SelectedValue = "" Then
            lblerr.Text = "You must select an activity"
            Exit Sub
        End If
        If FL1.PostedFile.FileName = "" Then
            lblerr.Text = "You must upload a reference pdf file!"
            Exit Sub
        End If

        Dim filePath As String = FL1.PostedFile.FileName

        Dim filename As String = Path.GetFileName(filePath)

        Dim ext As String = Path.GetExtension(filename)

        Dim contenttype As String = String.Empty

        Dim fs As Stream = FL1.PostedFile.InputStream

        Dim br As New BinaryReader(fs)

        'Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))
        Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))
        Dim app As Integer = 0
        Try

            If ext <> ".pdf" Or ext <> ".PDF" Then
                lblerr.Text = "You must attach a pdf document"
                'Exit Sub
            End If
            Select Case ext
                Case ".pdf"
                    contenttype = "application/pdf"
                Case ".PDF"
                    contenttype = "application/PDF"
                    Exit Select
                Case Else
                    lblerr.Text = "You must upload a pdf format!"
                    Exit Sub

            End Select

            If contenttype <> String.Empty Then

                Dim fileLocation As String = ""
                
                MyDBAction.Retention_Register_corp_rev(bytes, filename, contenttype, "", lblID.Text, cboactivity.SelectedValue, CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd"), "", Session("username"), txtcomment.Text, fileLocation, lblIACT.Text)
                
                lblerr.ForeColor = System.Drawing.Color.Green
                lblerr.Text = "File Uploaded Successfully"

            Else
                filename = ""
                'MyDBAction.Retention_Register_corp(bytes, filename, contenttype, "", lblID.Text, cboactivity.SelectedValue, CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd"), "", Session("username"), txtcomment.Text, "", CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"))

                lblerr.ForeColor = System.Drawing.Color.Red
                lblerr.Text = "data Saved Successfully"
                lblerr.Text = "File format not recognised." + " Upload Image/PDF"

            End If

            LOAD_ACTIVITY(lblID.Text)

            'loadGrid()

            lblID.Text = ""

            cboactivity.SelectedValue = ""
            dtfrom.DbSelectedDate = ""
            DTto.DbSelectedDate = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

    Private Sub deleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try
            RD_ACTIVITY.DataSource = Nothing
            RD_ACTIVITY.DataBind()
            GD_50.DataSource = Nothing
            GD_50.DataBind()
            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            SqlAction = "SELECT  [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES],FILE_NAME  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE PROPOSER_DISPLAY_NAME Like '%" & Trim(txtsearch.Text) & "%' AND [RM_CODE]='" & Session("emp_code") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                RD_ACTIVITY.DataSource = MyDatable
                RD_ACTIVITY.DataBind()
                Session("ACT_01") = MyDatable
                MyDatable = Nothing


            Else
                RD_ACTIVITY.DataSource = MyDatable
                RD_ACTIVITY.DataBind()
            End If

        Catch ex As Exception
            lblcontact.Text = ex.Message
        End Try
    End Sub

    Protected Sub View(ByVal sender As Object, ByVal e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""800px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""http://get.adobe.com/reader/"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileVB.ashx?Id="), id)
    End Sub



    Protected Sub DTactivity_SelectedDateChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs) Handles DTactivity.SelectedDateChanged
        If DTactivity.DbSelectedDate < DateAdd(DateInterval.Day, -7, Date.Now()) Or DTactivity.DbSelectedDate > Date.Now() Then

            DTactivity.DbSelectedDate = Date.Now
            lblerr.Text = "Activity date can only be within 7 days from the activity date!"

        Else
            lblerr.Text = ""
        End If

    End Sub

    Protected Sub RD_ACTIVITY_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles RD_ACTIVITY.SelectedIndexChanged
        Try
            ltEmbed.Text = ""
            Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
            cboactivity.SelectedValue = ""
            cboactivity.Text = ""
            lblIACT.Text = (DirectCast(RD_ACTIVITY.SelectedItems(0), GridDataItem)).GetDataKeyValue("ACTIVITY_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing
            SqlAction = "SELECT  [ACTIVITY_ID],[CORPORATE_ID],[ACT_CODE],[ACT_DUE_DATE] FROM [CRM].[dbo].[TBL_MIS_RET_CORP_ACTIVITY_REV] WHERE ACTIVITY_ID='" & lblIACT.Text & "' and  CORPORATE_ID='" & lblID.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                cboactivity.SelectedValue = MyDatable.Rows(0).Item("ACT_CODE").ToString()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GD_20_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_20.SelectedIndexChanged
        Try
            Dim ID As String = ""
            ltEmbed.Text = ""
            Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
            cboactivity.SelectedValue = ""
            cboactivity.Text = ""
            ID = (DirectCast(GD_20.SelectedItems(0), GridDataItem)).GetDataKeyValue("CORPORATE_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing

            SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,MOBILE_NO,CONTACT_PERSON, [PERIOD_FROM],[PERIOD_TO],Q1_FROM,[Q1_TO_DATE],Q2_FROM,[Q2_TO],Q3_FROM,[Q3_TO],Q4_FROM,[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_20M] WHERE  [CORPORATE_ID]='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                lblcontact.Text = MyDatable.Rows(0).Item("MOBILE_NO").ToString()
                lblcontactperson.Text = MyDatable.Rows(0).Item("CONTACT_PERSON").ToString()
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

                Dim Q1_FROM = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                Dim Q1_TO_DATE = MyDatable.Rows(0).Item("Q1_TO_DATE").ToString()
                Dim Q2_FROM = MyDatable.Rows(0).Item("Q2_FROM").ToString()
                Dim Q2_TO = MyDatable.Rows(0).Item("Q2_TO").ToString()
                Dim Q3_FROM = MyDatable.Rows(0).Item("Q3_FROM").ToString()
                Dim Q3_TO = MyDatable.Rows(0).Item("Q3_TO").ToString()
                Dim Q4_FROM = MyDatable.Rows(0).Item("Q4_FROM").ToString()
                Dim Q4_TO = MyDatable.Rows(0).Item("Q4_TO").ToString()
                Select Case CURDATE
                    Case Q1_FROM To Q1_TO_DATE
                        lblIQ.Text = "Q1"
                    Case Q2_FROM To Q2_TO
                        lblIQ.Text = "Q2"
                    Case Q3_FROM To Q3_TO
                        lblIQ.Text = "Q3"
                    Case Q4_FROM To Q4_TO
                        lblIQ.Text = "Q4"
                End Select
                LOAD_ACTIVITY(lblID.Text)
            End If
            'HiddenField1.Value = 1



            dtfrom.Enabled = False
            DTto.Enabled = False
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_5_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_5.SelectedIndexChanged
        Try
            Dim ID As String = ""
            ltEmbed.Text = ""
            Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
            cboactivity.SelectedValue = ""
            cboactivity.Text = ""
            ID = (DirectCast(GD_5.SelectedItems(0), GridDataItem)).GetDataKeyValue("CORPORATE_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing

            SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,MOBILE_NO,CONTACT_PERSON, [PERIOD_FROM],[PERIOD_TO],Q1_FROM,[Q1_TO_DATE],Q2_FROM,[Q2_TO],Q3_FROM,[Q3_TO],Q4_FROM,[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_5M] WHERE  [CORPORATE_ID]='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                lblcontact.Text = MyDatable.Rows(0).Item("MOBILE_NO").ToString()
                lblcontactperson.Text = MyDatable.Rows(0).Item("CONTACT_PERSON").ToString()
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

                Dim Q1_FROM = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                Dim Q1_TO_DATE = MyDatable.Rows(0).Item("Q1_TO_DATE").ToString()
                Dim Q2_FROM = MyDatable.Rows(0).Item("Q2_FROM").ToString()
                Dim Q2_TO = MyDatable.Rows(0).Item("Q2_TO").ToString()
                Dim Q3_FROM = MyDatable.Rows(0).Item("Q3_FROM").ToString()
                Dim Q3_TO = MyDatable.Rows(0).Item("Q3_TO").ToString()
                Dim Q4_FROM = MyDatable.Rows(0).Item("Q4_FROM").ToString()
                Dim Q4_TO = MyDatable.Rows(0).Item("Q4_TO").ToString()
                Select Case CURDATE
                    Case Q1_FROM To Q1_TO_DATE
                        lblIQ.Text = "Q1"
                    Case Q2_FROM To Q2_TO
                        lblIQ.Text = "Q2"
                    Case Q3_FROM To Q3_TO
                        lblIQ.Text = "Q3"
                    Case Q4_FROM To Q4_TO
                        lblIQ.Text = "Q4"
                End Select
                LOAD_ACTIVITY(lblID.Text)
            End If
          
            dtfrom.Enabled = False
            DTto.Enabled = False
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_1.SelectedIndexChanged
        Try
            Dim ID As String = ""
            ltEmbed.Text = ""
            Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
            cboactivity.SelectedValue = ""
            cboactivity.Text = ""
            ID = (DirectCast(GD_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("CORPORATE_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing

            SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,MOBILE_NO,CONTACT_PERSON, [PERIOD_FROM],[PERIOD_TO],Q1_FROM,[Q1_TO_DATE],Q2_FROM,[Q2_TO],Q3_FROM,[Q3_TO],Q4_FROM,[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_1M] WHERE  [CORPORATE_ID]='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                lblcontact.Text = MyDatable.Rows(0).Item("MOBILE_NO").ToString()
                lblcontactperson.Text = MyDatable.Rows(0).Item("CONTACT_PERSON").ToString()
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

                Dim Q1_FROM = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                Dim Q1_TO_DATE = MyDatable.Rows(0).Item("Q1_TO_DATE").ToString()
                Dim Q2_FROM = MyDatable.Rows(0).Item("Q2_FROM").ToString()
                Dim Q2_TO = MyDatable.Rows(0).Item("Q2_TO").ToString()
                Dim Q3_FROM = MyDatable.Rows(0).Item("Q3_FROM").ToString()
                Dim Q3_TO = MyDatable.Rows(0).Item("Q3_TO").ToString()
                Dim Q4_FROM = MyDatable.Rows(0).Item("Q4_FROM").ToString()
                Dim Q4_TO = MyDatable.Rows(0).Item("Q4_TO").ToString()
                Select Case CURDATE
                    Case Q1_FROM To Q1_TO_DATE
                        lblIQ.Text = "Q1"
                    Case Q2_FROM To Q2_TO
                        lblIQ.Text = "Q2"
                    Case Q3_FROM To Q3_TO
                        lblIQ.Text = "Q3"
                    Case Q4_FROM To Q4_TO
                        lblIQ.Text = "Q4"
                End Select
                LOAD_ACTIVITY(lblID.Text)
            End If
            'HiddenField1.Value = 1



            dtfrom.Enabled = False
            DTto.Enabled = False
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_M_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_M.SelectedIndexChanged
        Try
            Dim ID As String = ""
            ltEmbed.Text = ""
            Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
            cboactivity.SelectedValue = ""
            cboactivity.Text = ""
            ID = (DirectCast(GD_M.SelectedItems(0), GridDataItem)).GetDataKeyValue("CORPORATE_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing

            SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,MOBILE_NO,CONTACT_PERSON, [PERIOD_FROM],[PERIOD_TO],Q1_FROM,[Q1_TO_DATE],Q2_FROM,[Q2_TO],Q3_FROM,[Q3_TO],Q4_FROM,[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP_GWP_M] WHERE  [CORPORATE_ID]='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                lblcontact.Text = MyDatable.Rows(0).Item("MOBILE_NO").ToString()
                lblcontactperson.Text = MyDatable.Rows(0).Item("CONTACT_PERSON").ToString()
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

                Dim Q1_FROM = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                Dim Q1_TO_DATE = MyDatable.Rows(0).Item("Q1_TO_DATE").ToString()
                Dim Q2_FROM = MyDatable.Rows(0).Item("Q2_FROM").ToString()
                Dim Q2_TO = MyDatable.Rows(0).Item("Q2_TO").ToString()
                Dim Q3_FROM = MyDatable.Rows(0).Item("Q3_FROM").ToString()
                Dim Q3_TO = MyDatable.Rows(0).Item("Q3_TO").ToString()
                Dim Q4_FROM = MyDatable.Rows(0).Item("Q4_FROM").ToString()
                Dim Q4_TO = MyDatable.Rows(0).Item("Q4_TO").ToString()
                Select Case CURDATE
                    Case Q1_FROM To Q1_TO_DATE
                        lblIQ.Text = "Q1"
                    Case Q2_FROM To Q2_TO
                        lblIQ.Text = "Q2"
                    Case Q3_FROM To Q3_TO
                        lblIQ.Text = "Q3"
                    Case Q4_FROM To Q4_TO
                        lblIQ.Text = "Q4"
                End Select
                LOAD_ACTIVITY(lblID.Text)
            End If
            'HiddenField1.Value = 1



            dtfrom.Enabled = False
            DTto.Enabled = False
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
