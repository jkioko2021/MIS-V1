﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Committal_Tracking.aspx.vb" Inherits="Default2" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Corporate  name"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                     
                                                          <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                            FilterControlAltText="Filter POLICY_STATUS column" HeaderText="POLICY_STATUS" 
                                                            SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel2" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td style="width: 157px">
                                                        &nbsp;</td>
                                                    <td class="style17" style="width: 256px">
                                                        <asp:CheckBox ID="chknew" runat="server" Text="New Client" />
                                                    </td>
                                                    <td style="width: 131px">
                                                        <asp:Label ID="Label161" runat="server" Text="Effective Date"></asp:Label>
                                                    </td>
                                                    <td style="width: 192px">
                                                        <telerik:RadDatePicker ID="DtEff" Runat="server" Skin="Simple">
                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px">
                                                        <asp:Label ID="Label153" runat="server" Text="Proposer Name"></asp:Label>
                                                    </td>
                                                    <td class="style17" style="width: 256px">
                                                        <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Simple" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td style="width: 131px">
                                                        <asp:Label ID="Label164" runat="server" Text="Business"></asp:Label>
                                                    </td>
                                                    <td style="width: 192px">
                                                        <telerik:RadComboBox ID="cbobusiness" Runat="server" Skin="Simple">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Medical" Value="M" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Non-Medical" Value="N" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px; height: 26px">
                                                        <asp:Label ID="Label154" runat="server" Text="Premium Amount"></asp:Label>
                                                    </td>
                                                    <td class="style17" style="width: 256px">
                                                        <telerik:RadNumericTextBox ID="txtprem" Runat="server" Culture="en-US" 
                                                            Skin="Simple" Value="0" Width="125px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td style="height: 26px; width: 131px">
                                                        <asp:Label ID="Label166" runat="server" Text="Type"></asp:Label>
                                                    </td>
                                                    <td style="height: 26px; width: 192px">
                                                        <telerik:RadComboBox ID="cbotype" Runat="server" Skin="Simple">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="PDC" 
                                                                    Value="PDC" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="COM" 
                                                                    Value="COM" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="height: 26px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px">
                                                        <asp:Label ID="Label156" runat="server" Text="Paid Amount"></asp:Label>
                                                    </td>
                                                    <td class="style17" style="width: 256px">
                                                        <telerik:RadNumericTextBox ID="txtpaid" Runat="server" Culture="en-US" 
                                                            Skin="Simple" Value="0" Width="125px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td style="width: 131px">
                                                        &nbsp;</td>
                                                    <td style="width: 192px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px">
                                                        <asp:Label ID="Label155" runat="server" Text="Committal Amount"></asp:Label>
                                                    </td>
                                                    <td class="style17" style="width: 256px">
                                                        <telerik:RadNumericTextBox ID="txtcomm" Runat="server" Culture="en-US" 
                                                            Skin="Simple" Value="0" Width="125px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td style="width: 131px">
                                                        &nbsp;</td>
                                                    <td style="width: 192px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px">
                                                        <asp:Label ID="Label158" runat="server" Text="Credit Period"></asp:Label>
                                                    </td>
                                                    <td class="style17" style="width: 256px">
                                                        <telerik:RadNumericTextBox ID="txtcredit" Runat="server" AutoPostBack="True" 
                                                            Culture="en-US" DataType="System.Int16" Skin="Simple" Value="0" Width="125px">
                                                            <NumberFormat DecimalDigits="0" />
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td style="width: 131px">
                                                        <asp:Label ID="Label163" runat="server" Text="Due date"></asp:Label>
                                                    </td>
                                                    <td style="width: 192px">
                                                        <telerik:RadDatePicker ID="DtDue" Runat="server" Skin="Simple" 
                                                            AutoPostBack="True">
                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                AutoPostBack="True">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px; height: 26px;">
                                                        <asp:Label ID="Label159" runat="server" Text="Requested By"></asp:Label>
                                                    </td>
                                                    <td class="style17" style="width: 256px; height: 26px;">
                                                        <telerik:RadComboBox ID="cboby" Runat="server" Skin="Simple" 
                                                            AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" />
                                                                <telerik:RadComboBoxItem runat="server" Text="RM" Value="RM" />
                                                                <telerik:RadComboBoxItem runat="server" Text="BDM" Value="BDM" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="width: 131px; height: 26px;">
                                                        <asp:Label ID="Label165" runat="server" Text="Name"></asp:Label>
                                                    </td>
                                                    <td style="height: 26px">
                                                        <telerik:RadComboBox ID="cboname" Runat="server" Skin="Simple" Width="200px">
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="height: 26px">
                                                        </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px">
                                                        &nbsp;</td>
                                                    <td class="style17" style="width: 256px">
                                                        &nbsp;</td>
                                                    <td style="width: 131px">
                                                        <asp:Label ID="Label160" runat="server" Text="Manager"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="txtmanager" Runat="server" Skin="Simple" Width="200px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px; height: 26px">
                                                        <asp:Label ID="Label162" runat="server" Text="Notes"></asp:Label>
                                                    </td>
                                                    <td colspan="2" rowspan="2">
                                                        <telerik:RadTextBox ID="txtnotes" Runat="server" Height="70px" Skin="Simple" 
                                                            Width="350px" Rows="1" TextMode="MultiLine">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td style="width: 192px; height: 26px">
                                                        <asp:Label ID="RMID" runat="server" style="font-weight: 700" Text="RM"></asp:Label>
                                                        :<asp:Label ID="RMNAME" runat="server" style="font-weight: 700"></asp:Label>
                                                    </td>
                                                    <td style="height: 26px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px; height: 26px">
                                                        &nbsp;</td>
                                                    <td style="width: 192px; height: 26px">
                                                        &nbsp;</td>
                                                    <td style="height: 26px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px; height: 33px">
                                                    </td>
                                                    <td colspan="2" style="height: 33px">
                                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Save " 
                                                            Width="150px">
                                                        </telerik:RadButton>
                                                        &nbsp;<telerik:RadButton ID="RadButton2" runat="server" Skin="Simple" Text="New" 
                                                            Width="150px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td style="width: 192px; height: 33px">
                                                        <asp:Label ID="lblNo" runat="server" ForeColor="Red"></asp:Label>
                                                    </td>
                                                    <td style="height: 33px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 157px; height: 26px">
                                                        &nbsp;</td>
                                                    <td colspan="2">
                                                        &nbsp;</td>
                                                    <td style="width: 192px; height: 26px">
                                                        &nbsp;</td>
                                                    <td style="height: 26px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="5">
                                                        <asp:Panel ID="Panel21" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1169px">
                                                            <telerik:RadGrid ID="GD_COMMIT" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No"> 
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                     <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                                        </telerik:GridBoundColumn>
                                                                             <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                            FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                            SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                        </telerik:GridBoundColumn>
                                                                           <telerik:GridBoundColumn DataField="OS_Bal_Amt"  DataFormatString="{0:###,###.##}" 
                                                                            FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="OS_Bal_Amt" 
                                                                            SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                        </telerik:GridBoundColumn>
                                                                               <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                            FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                            SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                        </telerik:GridBoundColumn>                                                                            
                                                                        <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                            SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Due_Dt" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                            SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Requested_by" 
                                                                            FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                            SortExpression="Requested_by" UniqueName="Requested_by">
                                                                        </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                                    
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Note_From" UniqueName="Note_From">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 25px;" colspan="4">
                                        <asp:Panel ID="Panel31" runat="server">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label147" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <telerik:RadComboBox ID="cbouptype" Runat="server" Skin="Simple">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbouptype" 
                                                                    Text="COMMITAL LETTER" Value="COM" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbouptype" Text="PDC" 
                                                                    Value="PDC" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                        <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" Text="Upload">
                                                        </telerik:RadButton>
                                                        <asp:Label ID="lblupload" runat="server" Font-Size="Medium"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel32" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1134px">
                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                  
                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4" style="height: 25px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblID" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
      <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
          </Triggers>
    </asp:UpdatePanel>
</asp:Content>

