﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Reimbursement_TAT.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="TAT-REIMBURSEMENT"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1102px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 2958px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td style="width: 5px">
                                        <telerik:RadDatePicker ID="dtto" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" Skin="Simple" 
                                            style="margin-left: 0px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbosearch" Text="2020" 
                                                    Value="2020" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbosearch" Text="2021" 
                                                    Value="2021" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" Skin="Simple" 
                            Width="1100px" MultiPageID="RadMultiPage1" SelectedIndex="0">
                            <Tabs>
                                <telerik:RadTab runat="server" PageViewID="V1" Text="Overall" Selected="True" 
                                    SelectedIndex="0">
                                </telerik:RadTab>
                                <telerik:RadTab runat="server" PageViewID="V2" Text="Med Assessor" 
                                    SelectedIndex="1">
                                </telerik:RadTab>
                            </Tabs>
                        </telerik:RadTabStrip>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="1100px">
                            <telerik:RadPageView ID="V1" runat="server" Selected="True">
                                <asp:Panel ID="Panel18" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                    Height="100%" style="font-weight: 700" Width="1121px">
                                    <table style="width: 99%">
                                        <tr>
                                            <td class="style8" colspan="4">
                                                <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="99%">
                                                    <telerik:RadGrid ID="GDYR" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" PageSize="50" Skin="Sunset" Width="100%">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Year">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridBoundColumn DataField="Year" 
                                                                    FilterControlAltText="Filter Year column" HeaderText="Year" 
                                                                    SortExpression="Year" UniqueName="Year">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Doc_ver_Tat" 
                                                                    FilterControlAltText="Filter Doc_ver_Tat column" HeaderText="Doc_ver_Tat" 
                                                                    SortExpression="Doc_ver_Tat" UniqueName="Doc_ver_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="idx_Tat" 
                                                                    FilterControlAltText="Filter idx_Tat column" HeaderText="idx_Tat" 
                                                                    SortExpression="idx_Tat" UniqueName="idx_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Allocate_Tat" 
                                                                    FilterControlAltText="Filter Allocate_Tat column" HeaderText="Allocate_Tat" 
                                                                    SortExpression="Allocate_Tat" UniqueName="Allocate_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Process_Tat" 
                                                                    FilterControlAltText="Filter Process_Tat column" HeaderText="Process_Tat" 
                                                                    SortExpression="Process_Tat" UniqueName="Process_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Audit_Tat" 
                                                                    FilterControlAltText="Filter Audit_Tat column" HeaderText="Audit_Tat" 
                                                                    SortExpression="Audit_Tat" UniqueName="Audit_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Posting_Tat" 
                                                                    FilterControlAltText="Filter Posting_Tat column" HeaderText="Posting_Tat" 
                                                                    SortExpression="Posting_Tat" UniqueName="Posting_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Sign_Tat" 
                                                                    FilterControlAltText="Filter Sign_Tat column" HeaderText="Sign_Tat" 
                                                                    SortExpression="Sign_Tat" UniqueName="Sign_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Dispatch_Tat" 
                                                                    FilterControlAltText="Filter Dispatch_Tat column" HeaderText="Dispatch_Tat" 
                                                                    SortExpression="Dispatch_Tat" UniqueName="Dispatch_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="overal_Tat" 
                                                                    FilterControlAltText="Filter overal_Tat column" HeaderText="overal_Tat" 
                                                                    SortExpression="overal_Tat" UniqueName="overal_Tat">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8" colspan="4">
                                                <asp:Label ID="Label75" runat="server" style="font-weight: 700" Text="MONTH"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8" colspan="4">
                                                <asp:Panel ID="Panel20" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="99%">
                                                    <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="50" Skin="Sunset" 
                                                        Width="100%">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Year">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridBoundColumn DataField="Year" 
                                                                    FilterControlAltText="Filter Year column" HeaderText="Year" 
                                                                    SortExpression="Year" UniqueName="Year">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Mon" 
                                                                    FilterControlAltText="Filter Mon column" HeaderText="Mon" SortExpression="Mon" 
                                                                    UniqueName="Mon">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Doc_ver_Tat" 
                                                                    FilterControlAltText="Filter Doc_ver_Tat column" HeaderText="Doc_ver_Tat" 
                                                                    SortExpression="Doc_ver_Tat" UniqueName="Doc_ver_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="idx_Tat" 
                                                                    FilterControlAltText="Filter idx_Tat column" HeaderText="idx_Tat" 
                                                                    SortExpression="idx_Tat" UniqueName="idx_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Allocate_Tat" 
                                                                    FilterControlAltText="Filter Allocate_Tat column" HeaderText="Allocate_Tat" 
                                                                    SortExpression="Allocate_Tat" UniqueName="Allocate_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Process_Tat" 
                                                                    FilterControlAltText="Filter Process_Tat column" HeaderText="Process_Tat" 
                                                                    SortExpression="Process_Tat" UniqueName="Process_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Audit_Tat" 
                                                                    FilterControlAltText="Filter Audit_Tat column" HeaderText="Audit_Tat" 
                                                                    SortExpression="Audit_Tat" UniqueName="Audit_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Posting_Tat" 
                                                                    FilterControlAltText="Filter Posting_Tat column" HeaderText="Posting_Tat" 
                                                                    SortExpression="Posting_Tat" UniqueName="Posting_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Sign_Tat" 
                                                                    FilterControlAltText="Filter Sign_Tat column" HeaderText="Sign_Tat" 
                                                                    SortExpression="Sign_Tat" UniqueName="Sign_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Dispatch_Tat" 
                                                                    FilterControlAltText="Filter Dispatch_Tat column" HeaderText="Dispatch_Tat" 
                                                                    SortExpression="Dispatch_Tat" UniqueName="Dispatch_Tat">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="overal_Tat" 
                                                                    FilterControlAltText="Filter overal_Tat column" HeaderText="overal_Tat" 
                                                                    SortExpression="overal_Tat" UniqueName="overal_Tat">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8" style="height: 39px;">
                                                <asp:Label ID="lblerr0" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                            </td>
                                            <td class="style8" style="width: 166px; height: 39px;">
                                                &nbsp;</td>
                                            <td style="width: 287px; height: 39px;">
                                            </td>
                                            <td class="style8">
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </telerik:RadPageView>
                             <telerik:RadPageView ID="V2" runat="server">
                                <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                    Height="100%" style="font-weight: 700" Width="1121px">
                                    <table style="width: 99%">
                                        <tr>
                                            <td class="style8">
                                                <asp:Panel ID="Panel4" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="100%">
                                                    <telerik:RadGrid ID="GDMED" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="allocate_to">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                             <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="Yr" 
                                                                    FilterControlAltText="Filter Yr column" HeaderText="Year" 
                                                                    SortExpression="Yr" UniqueName="Yr">
                                                                </telerik:GridBoundColumn>                                                          
                                                                <telerik:GridBoundColumn DataField="allocate_to" 
                                                                    FilterControlAltText="Filter allocate_to column" HeaderText="allocate_to" 
                                                                    SortExpression="allocate_to" UniqueName="allocate_to">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Process_Tat" 
                                                                    FilterControlAltText="Filter Process_Tat column" HeaderText="Process_Tat" 
                                                                    SortExpression="Process_Tat" UniqueName="Process_Tat">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <ItemStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <asp:Label ID="Label1" runat="server" style="font-weight: 700" Text="MONTH"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <asp:Panel ID="Panel21" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="100%">
                                                    <telerik:RadGrid ID="GDMED_1" runat="server" AllowPaging="True" 
                                                        CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                        <MasterTableView AutoGenerateColumns="False">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridBoundColumn DataField="Yr" FilterControlAltText="Filter Yr column" 
                                                                    HeaderText="Year" SortExpression="Yr" UniqueName="Yr">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Mon" 
                                                                    FilterControlAltText="Filter Mon column" HeaderText="Mon" SortExpression="Mon" 
                                                                    UniqueName="Mon">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="allocate_to" 
                                                                    FilterControlAltText="Filter allocate_to column" HeaderText="allocate_to" 
                                                                    SortExpression="allocate_to" UniqueName="allocate_to">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Process_Tat" 
                                                                    FilterControlAltText="Filter Process_Tat column" HeaderText="Process_Tat" 
                                                                    SortExpression="Process_Tat" UniqueName="Process_Tat">
                                                                </telerik:GridBoundColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <ItemStyle Wrap="False" />
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                &nbsp;</td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </telerik:RadPageView>
                        </telerik:RadMultiPage>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
   
    </asp:UpdatePanel>
</asp:Content>
