﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retail_Corp_Activity.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table>
                <tr>
                    <td align="center" bgcolor="#333333" style="height: 44px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="ACTIVITY TRACKING"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1235px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 3043px; font-weight: 700;">
                                        <asp:Panel ID="Panel21" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td style="width: 851px">
                                                        &nbsp;</td>
                                                    <td>
                                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Sunset" Width="225px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="search" runat="server" Skin="Simple" Text="Search">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: 700;">
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="0" Skin="Outlook" Width="1200px">
                                            <Tabs>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V1" 
                                                    Selected="True" SelectedIndex="0" Text="GWP &gt;=50m">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V2" 
                                                    Text="GWP 20M-49.9M">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V4" Text="GWP 5M-19.9M">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V5" Text="GWP 1M-1.49">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V6" Text="GWP 0M-1M">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V3" Text="Activity view">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 3043px; font-weight: 700;">
                                        <telerik:RadMultiPage ID="RadMultiPage1" runat="server" style="margin-top: 0px" 
                                            Width="1200px">
                                            <telerik:RadPageView ID="V1" runat="server" Selected="True"><table style="width: 100%"><tr><td><asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                Height="100%" style="font-weight: 700" Width="1200px"><table style="width: 99%"><tr><td class="style8"><asp:Label ID="Label149" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                                                Text="Above 50M"></asp:Label></td></tr>
                                                    <tr>
                                                        <td class="style8">
                                                            <asp:Panel ID="Panel28" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_50_0" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="CORPORATE_ID">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                         
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            
                                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="ACT_DUE_DATE" 
                                                                                FilterControlAltText="Filter ACT_DUE_DATE column" HeaderText="ACT_DUE_DATE" 
                                                                                ItemStyle-Wrap="False" SortExpression="ACT_DUE_DATE" UniqueName="ACT_DUE_DATE">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>                                                                                                                                               
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8">
                                                            &nbsp;</td>
                                                    </tr>
                                                    <tr><td class="style8"><asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                                                                Width="1200px"><telerik:RadGrid ID="GD_50" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                    GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%"><MasterTableView AutoGenerateColumns="False" DataKeyNames="CORPORATE_ID"><CommandItemSettings ExportToPdfText="Export to PDF" /><RowIndicatorColumn FilterControlAltText="Filter RowIndicator column"></RowIndicatorColumn><ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column"></ExpandCollapseColumn><Columns><telerik:GridButtonColumn CommandName="Select" 
                                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                                UniqueName="Select"><HeaderStyle ForeColor="Blue" Width="100px" /><ItemStyle Width="100px" /></telerik:GridButtonColumn><telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PREMIUMS" 
                                                                                                 DataFormatString="{0:#,#.##}" 
                                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PREMIUMS" UniqueName="PREMIUMS">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM"><ItemStyle Wrap="False" />
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q1_TO_DATE" 
                                                                                                FilterControlAltText="Filter Q1_TO_DATE column" HeaderText="Q1_TO_DATE" 
                                                                                                ItemStyle-Wrap="False" SortExpression="Q1_TO_DATE" UniqueName="Q1_TO_DATE"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q2_TO" 
                                                                                                FilterControlAltText="Filter Q2_TO column" HeaderText="Q2_TO" 
                                                                                                ItemStyle-Wrap="False" SortExpression="Q2_TO" UniqueName="Q2_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q3_TO" 
                                                                                                FilterControlAltText="Filter Q3_TO column" HeaderText="Q3_TO" 
                                                                                                ItemStyle-Wrap="False" SortExpression="Q3_TO" UniqueName="Q3_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q4_TO" 
                                                                                                FilterControlAltText="Filter Q4_TO column" HeaderText="Q4_TO" 
                                                                                                ItemStyle-Wrap="False" SortExpression="Q4_TO" UniqueName="Q4_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="CNT_ACTIVITIES" DataType="System.Int32" 
                                                                                                FilterControlAltText="Filter CNT_ACTIVITIES column" HeaderText="CNT_ACTIVITIES" 
                                                                                                SortExpression="CNT_ACTIVITIES" UniqueName="CNT_ACTIVITIES"></telerik:GridBoundColumn></Columns><EditFormSettings><EditColumn FilterControlAltText="Filter EditCommandColumn column"></EditColumn></EditFormSettings></MasterTableView><PagerStyle Wrap="False" /><FilterMenu EnableImageSprites="False"></FilterMenu><HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default"></HeaderContextMenu></telerik:RadGrid></asp:Panel></td></tr></table></asp:Panel></td></tr></table></telerik:RadPageView>
                                            <telerik:RadPageView ID="V2" runat="server"><table style="width: 100%"><tr><td><asp:Label ID="Label150" runat="server" Font-Bold="True" 
                                                                Text="GWP 20M-49.9M" Font-Size="Medium"></asp:Label></td></tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1200px">
                                                            <telerik:RadGrid ID="GD_20_0" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                            HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                            SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                      
                                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                            ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                            ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="ACT_DUE_DATE" 
                                                                            FilterControlAltText="Filter ACT_DUE_DATE column" HeaderText="ACT_DUE_DATE" 
                                                                            ItemStyle-Wrap="False" SortExpression="ACT_DUE_DATE" UniqueName="ACT_DUE_DATE">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr><td><asp:Panel ID="Panel24" runat="server" 
                                                                Height="100%" Width="1200px" ScrollBars="Both"><telerik:RadGrid ID="GD_20" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%"><MasterTableView AutoGenerateColumns="False" DataKeyNames="CORPORATE_ID"><CommandItemSettings ExportToPdfText="Export to PDF" /><RowIndicatorColumn FilterControlAltText="Filter RowIndicator column"></RowIndicatorColumn><ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column"></ExpandCollapseColumn><Columns><telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select"><HeaderStyle ForeColor="Blue" Width="100px" /><ItemStyle Width="100px" /></telerik:GridButtonColumn><telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PREMIUMS" 
                                                                                                 DataFormatString="{0:#,#.##}" 
                                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PREMIUMS" UniqueName="PREMIUMS"></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" FilterControlAltText="Filter PERIOD_FROM column" 
                                                                                HeaderText="PERIOD_FROM" ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" 
                                                                                UniqueName="PERIOD_FROM"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" 
                                                                                UniqueName="PERIOD_TO" DataFormatString="{0:yyyy-MM-dd}"></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q1_TO_DATE" 
                                                                                FilterControlAltText="Filter Q1_TO_DATE column" HeaderText="Q1_TO_DATE" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q1_TO_DATE" UniqueName="Q1_TO_DATE"><ItemStyle Wrap="False" /><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q2_TO" 
                                                                                FilterControlAltText="Filter Q2_TO column" HeaderText="Q2_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q2_TO" 
                                                                                UniqueName="Q2_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q3_TO" 
                                                                                FilterControlAltText="Filter Q3_TO column" HeaderText="Q3_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q3_TO" 
                                                                                UniqueName="Q3_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q4_TO" 
                                                                                FilterControlAltText="Filter Q4_TO column" HeaderText="Q4_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q4_TO" 
                                                                                UniqueName="Q4_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="CNT_ACTIVITIES" 
                                                                                FilterControlAltText="Filter CNT_ACTIVITIES column" 
                                                                                HeaderText="CNT_ACTIVITIES" SortExpression="CNT_ACTIVITIES" 
                                                                                UniqueName="CNT_ACTIVITIES" DataType="System.Int32"></telerik:GridBoundColumn></Columns><EditFormSettings><EditColumn FilterControlAltText="Filter EditCommandColumn column"></EditColumn></EditFormSettings></MasterTableView><PagerStyle Wrap="False" /><FilterMenu EnableImageSprites="False"></FilterMenu><HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default"></HeaderContextMenu></telerik:RadGrid></asp:Panel></td></tr></table></telerik:RadPageView>
                                            <telerik:RadPageView ID="V4" runat="server"><table style="width: 100%"><tr><td><asp:Label ID="Label1" runat="server" Font-Bold="True" 
                                                                Text="GWP 5M-19.9M" Font-Size="Medium"></asp:Label></td></tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1200px">
                                                            <telerik:RadGrid ID="GD_5_0" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                            HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                            SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                       
                                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                            ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                            ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="ACT_DUE_DATE" 
                                                                            FilterControlAltText="Filter ACT_DUE_DATE column" HeaderText="ACT_DUE_DATE" 
                                                                            ItemStyle-Wrap="False" SortExpression="ACT_DUE_DATE" UniqueName="ACT_DUE_DATE">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr><td><asp:Panel ID="Panel25" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px"><telerik:RadGrid ID="GD_5" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%"><MasterTableView AutoGenerateColumns="False" DataKeyNames="CORPORATE_ID"><CommandItemSettings ExportToPdfText="Export to PDF" /><RowIndicatorColumn FilterControlAltText="Filter RowIndicator column"></RowIndicatorColumn><ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column"></ExpandCollapseColumn><Columns><telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select"><HeaderStyle ForeColor="Blue" Width="100px" /><ItemStyle Width="100px" /></telerik:GridButtonColumn><telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PREMIUMS" 
                                                                                                 DataFormatString="{0:#,#.##}" 
                                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PREMIUMS" UniqueName="PREMIUMS"></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q1_TO_DATE" 
                                                                                FilterControlAltText="Filter Q1_TO_DATE column" HeaderText="Q1_TO_DATE" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q1_TO_DATE" UniqueName="Q1_TO_DATE"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q2_TO" 
                                                                                FilterControlAltText="Filter Q2_TO column" HeaderText="Q2_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q2_TO" UniqueName="Q2_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q3_TO" 
                                                                                FilterControlAltText="Filter Q3_TO column" HeaderText="Q3_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q3_TO" UniqueName="Q3_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q4_TO" 
                                                                                FilterControlAltText="Filter Q4_TO column" HeaderText="Q4_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q4_TO" UniqueName="Q4_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="CNT_ACTIVITIES" DataType="System.Int32" 
                                                                                FilterControlAltText="Filter CNT_ACTIVITIES column" HeaderText="CNT_ACTIVITIES" 
                                                                                SortExpression="CNT_ACTIVITIES" UniqueName="CNT_ACTIVITIES"></telerik:GridBoundColumn></Columns><EditFormSettings><EditColumn FilterControlAltText="Filter EditCommandColumn column"></EditColumn></EditFormSettings></MasterTableView><PagerStyle Wrap="False" /><FilterMenu EnableImageSprites="False"></FilterMenu><HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default"></HeaderContextMenu></telerik:RadGrid></asp:Panel></td></tr></table></telerik:RadPageView>
                                            <telerik:RadPageView ID="V5" runat="server"><table style="width: 100%"><tr><td><asp:Label ID="Label2" runat="server" Font-Bold="True" 
                                                                Text="GWP 1M-4.9M" Font-Size="Medium"></asp:Label></td></tr><tr><td><asp:Panel ID="Panel26" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px"><telerik:RadGrid ID="GD_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%"><MasterTableView AutoGenerateColumns="False" DataKeyNames="CORPORATE_ID"><CommandItemSettings ExportToPdfText="Export to PDF" /><RowIndicatorColumn FilterControlAltText="Filter RowIndicator column"></RowIndicatorColumn><ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column"></ExpandCollapseColumn><Columns><telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select"><HeaderStyle ForeColor="Blue" Width="100px" /><ItemStyle Width="100px" /></telerik:GridButtonColumn><telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PREMIUMS" 
                                                                                                 DataFormatString="{0:#,#.##}" 
                                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PREMIUMS" UniqueName="PREMIUMS"></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q1_TO_DATE" 
                                                                                FilterControlAltText="Filter Q1_TO_DATE column" HeaderText="Q1_TO_DATE" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q1_TO_DATE" UniqueName="Q1_TO_DATE"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q2_TO" 
                                                                                FilterControlAltText="Filter Q2_TO column" HeaderText="Q2_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q2_TO" UniqueName="Q2_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q3_TO" 
                                                                                FilterControlAltText="Filter Q3_TO column" HeaderText="Q3_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q3_TO" UniqueName="Q3_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q4_TO" 
                                                                                FilterControlAltText="Filter Q4_TO column" HeaderText="Q4_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q4_TO" UniqueName="Q4_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="CNT_ACTIVITIES" DataType="System.Int32" 
                                                                                FilterControlAltText="Filter CNT_ACTIVITIES column" HeaderText="CNT_ACTIVITIES" 
                                                                                SortExpression="CNT_ACTIVITIES" UniqueName="CNT_ACTIVITIES"></telerik:GridBoundColumn></Columns><EditFormSettings><EditColumn FilterControlAltText="Filter EditCommandColumn column"></EditColumn></EditFormSettings></MasterTableView><PagerStyle Wrap="False" /><FilterMenu EnableImageSprites="False"></FilterMenu><HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default"></HeaderContextMenu></telerik:RadGrid></asp:Panel></td></tr></table></telerik:RadPageView>
                                            <telerik:RadPageView ID="V6" runat="server"><table style="width: 100%"><tr><td><asp:Label ID="Label3" runat="server" Font-Bold="True" 
                                                                Text="GWP 0M-1M" Font-Size="Medium"></asp:Label></td></tr><tr><td><asp:Panel ID="Panel27" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px"><telerik:RadGrid ID="GD_M" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%"><MasterTableView AutoGenerateColumns="False" DataKeyNames="CORPORATE_ID"><CommandItemSettings ExportToPdfText="Export to PDF" /><RowIndicatorColumn FilterControlAltText="Filter RowIndicator column"></RowIndicatorColumn><ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column"></ExpandCollapseColumn><Columns><telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select"><HeaderStyle ForeColor="Blue" Width="100px" /><ItemStyle Width="100px" /></telerik:GridButtonColumn><telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PREMIUMS" 
                                                                                                 DataFormatString="{0:#,#.##}" 
                                                                                                FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUMS" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PREMIUMS" UniqueName="PREMIUMS"></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q1_TO_DATE" 
                                                                                FilterControlAltText="Filter Q1_TO_DATE column" HeaderText="Q1_TO_DATE" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q1_TO_DATE" UniqueName="Q1_TO_DATE"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q2_TO" 
                                                                                FilterControlAltText="Filter Q2_TO column" HeaderText="Q2_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q2_TO" UniqueName="Q2_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q3_TO" 
                                                                                FilterControlAltText="Filter Q3_TO column" HeaderText="Q3_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q3_TO" UniqueName="Q3_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="Q4_TO" 
                                                                                FilterControlAltText="Filter Q4_TO column" HeaderText="Q4_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q4_TO" UniqueName="Q4_TO"><ItemStyle Wrap="False" /></telerik:GridBoundColumn><telerik:GridBoundColumn DataField="CNT_ACTIVITIES" DataType="System.Int32" 
                                                                                FilterControlAltText="Filter CNT_ACTIVITIES column" HeaderText="CNT_ACTIVITIES" 
                                                                                SortExpression="CNT_ACTIVITIES" UniqueName="CNT_ACTIVITIES"></telerik:GridBoundColumn></Columns><EditFormSettings><EditColumn FilterControlAltText="Filter EditCommandColumn column"></EditColumn></EditFormSettings></MasterTableView><PagerStyle Wrap="False" /><FilterMenu EnableImageSprites="False"></FilterMenu><HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default"></HeaderContextMenu></telerik:RadGrid></asp:Panel></td></tr>
                                                                                </table>
                                                                                </telerik:RadPageView>
                                                                                     <telerik:RadPageView ID="V3" runat="server"><table style="width: 100%"><tr><td>
                                                                                         <asp:Label ID="Label4" runat="server" Font-Bold="True" 
                                                                Text="ACTIVITY DASHBOARD" Font-Size="Medium"></asp:Label></td></tr><tr><td><asp:Panel ID="Panel1" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px"><telerik:RadGrid ID="GD_PROD" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="50" Skin="Simple" Width="100%">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="FROM_DT">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select"                                                                                UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                <ItemStyle Width="100px"/>
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="FROM_DT"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter FROM_DT column" 
                                                                                HeaderText="FROM_DT" ItemStyle-Wrap="False" 
                                                                                SortExpression="FROM_DT" UniqueName="FROM_DT">
                                                                                <ItemStyle Wrap="False"/>
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="TO_DT"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter TO_DT column" 
                                                                                HeaderText="TO_DT" ItemStyle-Wrap="False" 
                                                                                SortExpression="TO_DT" UniqueName="TO_DT">
                                                                                <ItemStyle Wrap="False"/>
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="TOT_CORP_COUNT"                                                                                
                                                                            FilterControlAltText="Filter TOT_CORP_COUNT column" HeaderText="TOT_CORP_COUNT" 
                                                                            ItemStyle-Wrap="False" SortExpression="TOT_CORP_COUNT" UniqueName="TOT_CORP_COUNT">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="EXP_CNT_ACTIVITY"                                                                                
                                                                                FilterControlAltText="Filter EXP_CNT_ACTIVITY column" HeaderText="EXP_CNT_ACTIVITY" 
                                                                                ItemStyle-Wrap="False" SortExpression="EXP_CNT_ACTIVITY" UniqueName="EXP_CNT_ACTIVITY"><ItemStyle Wrap="False" />
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ACT_CNT_ACTIVITY"                                                                              
                                                                                FilterControlAltText="Filter ACT_CNT_ACTIVITY column" HeaderText="ACT_CNT_ACTIVITY" 
                                                                                ItemStyle-Wrap="False" SortExpression="ACT_CNT_ACTIVITY" UniqueName="ACT_CNT_ACTIVITY"><ItemStyle Wrap="False" />
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERC_PERF" 
                                                                                FilterControlAltText="Filter PERC_PERF column" HeaderText="PERC_PERF" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERC_PERF" UniqueName="PERC_PERF"><ItemStyle Wrap="False" />
                                                                                </telerik:GridBoundColumn>                                                                              
                                                                                </Columns><EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                                </EditFormSettings>
                                                                                </MasterTableView>
                                                                                <PagerStyle Wrap="False" />
                                                                                <FilterMenu EnableImageSprites="False">
                                                                                </FilterMenu>
                                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                </HeaderContextMenu>
                                                                                </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                                </td></tr>
                                                                                </table>
                                                                                </telerik:RadPageView>
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: 700;">
                                        <asp:Panel ID="Panel19" runat="server" BorderStyle="Solid" BorderWidth="1px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Label ID="Label154" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                            Text="Activities"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Panel ID="Panel23" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1200px">
                                                            <telerik:RadGrid ID="RD_ACTIVITY" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="50" Skin="Simple" 
                                                                Width="100%">
                                                                <%-- ' [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]--%>
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="ACTIVITY_ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                          <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                <ItemStyle Width="100px" />
                                                                            </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="ACTIVITY_ID" DataType="System.Decimal" 
                                                                            FilterControlAltText="Filter ACTIVITY_ID column" HeaderText="ACTIVITY_ID" 
                                                                            ReadOnly="True" SortExpression="ID" UniqueName="ACTIVITY_ID">
                                                                        </telerik:GridBoundColumn>                                                                
                                                                        <telerik:GridBoundColumn DataField="ACTIVITY_NAME" 
                                                                            FilterControlAltText="Filter ACTIVITY_NAME column" HeaderText="ACTIVITY_NAME" 
                                                                            ItemStyle-Wrap="False" SortExpression="ACTIVITY_NAME" 
                                                                            UniqueName="ACTIVITY_NAME">
                                                                        </telerik:GridBoundColumn>
                                                                               <telerik:GridBoundColumn DataField="ACT_DUE_DATE" 
                                                                            FilterControlAltText="Filter ACT_DUE_DATE column" HeaderText="DUE_DATE" 
                                                                            ItemStyle-Wrap="False" SortExpression="ACT_DUE_DATE" UniqueName="ACT_DUE_DATE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="ACT_DATE" 
                                                                            FilterControlAltText="Filter ACT_DATE column" HeaderText="ACTIVITY_DATE" 
                                                                            ItemStyle-Wrap="False" SortExpression="ACT_DATE" UniqueName="ACT_DATE">
                                                                        </telerik:GridBoundColumn>                                                                      
                                                                        <telerik:GridBoundColumn DataField="FILE_NAME" 
                                                                            FilterControlAltText="Filter FILE_NAME column" HeaderText="FILE_NAME" 
                                                                            ItemStyle-Wrap="False" SortExpression="FILE_NAME" UniqueName="FILE_NAME">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="#" 
                                                                            SortExpression="TicketID">
                                                                            <ItemTemplate>
                                                                                <asp:LinkButton ID="lnkView0" runat="server" 
                                                                                    CommandArgument='<%# Eval("ACTIVITY_ID") %>' OnClick="View" Text="View"></asp:LinkButton>
                                                                            </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label161" runat="server" Text="Contact Person"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        <asp:Label ID="lblcontactperson" runat="server"></asp:Label>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label163" runat="server" Text="Mobile No."></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <asp:Label ID="lblcontact" runat="server"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label155" runat="server" Text="Period From"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" MinDate="" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label156" runat="server" Text="Period To"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="DTto" Runat="server" MinDate="" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label157" runat="server" Text="Activity"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        <telerik:RadComboBox ID="cboactivity" Runat="server" AccessibilityMode="True" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label158" runat="server" Text="Activity date"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="DTactivity" Runat="server" AutoPostBack="True" 
                                                            MinDate="" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput AutoPostBack="True" DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="lblID" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        &nbsp;</td>
                                                    <td class="style8" style="width: 166px">
                                                        &nbsp;</td>
                                                    <td style="width: 287px">
                                                        <asp:Label ID="lblIQ" runat="server" ForeColor="Red" Font-Size="Small"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="lblIACT" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        <asp:Label ID="Label159" runat="server" Text="Minutes"></asp:Label>
                                                    </td>
                                                    <td class="style8" colspan="2">
                                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8">
                                                        &nbsp;</td>
                                                    <td style="width: 169px">
                                                        <asp:Label ID="Label160" runat="server" Text="Notes"></asp:Label>
                                                    </td>
                                                    <td class="style8" colspan="2" rowspan="2">
                                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="90px" 
                                                            Skin="Outlook" TextMode="MultiLine" Width="350px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8">
                                                        &nbsp;</td>
                                                    <td style="width: 169px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="2">
                                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <telerik:RadButton ID="cmdsave" runat="server" Height="37px" Skin="Simple" 
                                                            Text="Save" Width="179px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td style="width: 287px">
                                                        &nbsp;&nbsp;<asp:HiddenField ID="HiddenField3" runat="server" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <hr />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                            ScrollBars="Horizontal" Width="1116px">
                                                            <asp:Literal ID="ltEmbed" runat="server" />
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                </table>
              
  
        </ContentTemplate>
                          <Triggers>
        <asp:PostBackTrigger ControlID = "cmdsave" />

    </Triggers>
          </asp:UpdatePanel>
</asp:Content>

