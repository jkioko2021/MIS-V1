﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retail_Member_info.aspx.vb" Inherits="_Default" %>


<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1162px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label153" runat="server" style="font-weight: 700" 
                                                            Text="Client Type"></asp:Label>
                                                    </td>
                                                    <td style="width: 271px">
                                                        <telerik:RadComboBox ID="cbotype" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="Retail" Value="R" 
                                                                    Owner="cbotype" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Corporate/SME" Value="C" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="height: 36px">
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" Text="Select"></asp:Label>
                                                    </td>
                                                    <td style="width: 271px; height: 36px">
                                                        <telerik:RadComboBox ID="cbosearch" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="Family Code" Value="F" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Member Name" Value="M" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="height: 36px">
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" EmptyMessage="KE/AK 00000" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td style="height: 36px">
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td style="height: 36px">
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="FAMILY_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT" 
                                                            FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                            SortExpression="AGENT" UniqueName="AGENT">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel14" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GDMEM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" 
                                                    DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" HeaderText="DOB" 
                                                            SortExpression="MEMBER_BIRTH_DATE" UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="FIRST_ENROLLMENT_DATE" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter FIRST_ENROLLMENT_DATE column" HeaderText="JOIN DT" 
                                                            SortExpression="FIRST_ENROLLMENT_DATE" UniqueName="FIRST_ENROLLMENT_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="POLICY_VALID_UPTO" UniqueName="POLICY_VALID_UPTO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                            FilterControlAltText="Filter POLICY_STATUS column" HeaderText="POLICY_STATUS" 
                                                            SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                        </telerik:GridBoundColumn>

                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                            FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                            SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                            FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                            SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                            FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                            SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="ID_DOC_NO" 
                                                            FilterControlAltText="Filter ID_DOC_NO column" HeaderText="ID_DOC_NO" 
                                                            SortExpression="ID_DOC_NO" UniqueName="ID_DOC_NO">
                                                        </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="CARD_TYPE" 
                                                            FilterControlAltText="Filter CARD_TYPE column" HeaderText="CARD" 
                                                            SortExpression="CARD_TYPE" UniqueName="CARD_TYPE">
                                                        </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="INTG_CODE" 
                                                            FilterControlAltText="Filter INTG_CODE column" HeaderText="INTG_CODE" 
                                                            SortExpression="INTG_CODE" UniqueName="INTG_CODE">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="LBLID" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="RMNAME" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="5" Skin="Office2007">
                                            <Tabs>
                                                <telerik:RadTab runat="server" PageViewID="V5" Text="Benefit Listing">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V6" 
                                                    Text="Medical-Policies">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V7" 
                                                    Text="Non-Medical Policies">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V3" Text="Claims-Reimbursement">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V8" Text="eOX Claims">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V4" Text="CCA Claims" 
                                                    Selected="True">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server">
                                            <telerik:RadPageView ID="V3" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel2" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel16" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_CLAIMS" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                  <telerik:GridBoundColumn DataField="File_No" 
                                                                                    FilterControlAltText="Filter File_No column" 
                                                                                    HeaderText="File_No" SortExpression="File_No" 
                                                                                    UniqueName="File_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Invoice_No" 
                                                                                    FilterControlAltText="Filter Invoice_No column" 
                                                                                    HeaderText="Invoice_No" SortExpression="INVOICE_NO" 
                                                                                    UniqueName="Invoice_No">
                                                                                </telerik:GridBoundColumn>
                                                                                     <telerik:GridBoundColumn DataField="Invoice_Amt" 
                                                                                    FilterControlAltText="Filter Invoice_Amt column" HeaderText="Invoice_Amt" 
                                                                                    SortExpression="Invoice_Amt" UniqueName="Invoice_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Service_dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Service_dt column" HeaderText="Service_dt" 
                                                                                    SortExpression="Service_dt" UniqueName="Service_dt">
                                                                                </telerik:GridBoundColumn>                                                                              
                                                                                <telerik:GridBoundColumn DataField="Claim_Type" 
                                                                                    FilterControlAltText="Filter Claim_Type column" HeaderText="Claim_Type" 
                                                                                    SortExpression="Claim_Type" UniqueName="Claim_Type">
                                                                                </telerik:GridBoundColumn>
                                                                              
                                                                                   <telerik:GridBoundColumn DataField="Inv_Status" 
                                                                                    FilterControlAltText="Filter Inv_Status column" HeaderText="Status" 
                                                                                    SortExpression="Inv_Status" UniqueName="Inv_Status">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V5" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel5" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_BENEFIT" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                          
                                                                                <telerik:GridBoundColumn DataField="BENEFIT" 
                                                                                    FilterControlAltText="Filter BENEFIT column" HeaderText="BENEFIT" 
                                                                                    SortExpression="BENEFIT" UniqueName="BENEFIT">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="LIMIT_AMT"  DataFormatString="{0:### ##0.0}"                                                                                   
                                                                                    FilterControlAltText="Filter LIMIT_AMT column" HeaderText="LIMIT_AMT" 
                                                                                    SortExpression="LIMIT_AMT" UniqueName="LIMIT_AMT">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="CONSUMED"  DataFormatString="{0:### ##0.0}"                                                                                   
                                                                                    FilterControlAltText="Filter CONSUMED column" HeaderText="CONSUMED" 
                                                                                    SortExpression="CONSUMED" UniqueName="CONSUMED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="BALANCE"  DataFormatString="{0:### ##0.0}"                                                                                   
                                                                                    FilterControlAltText="Filter BALANCE column" HeaderText="BALANCE" 
                                                                                    SortExpression="BALANCE" UniqueName="BALANCE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="WAITING_PERIOD" 
                                                                                    FilterControlAltText="Filter WAITING_PERIOD column" HeaderText="WAITING_PERIOD" 
                                                                                    SortExpression="WAITING_PERIOD" UniqueName="WAITING_PERIOD">
                                                                                </telerik:GridBoundColumn>
                                                                                      <telerik:GridBoundColumn DataField="FUND_MANAGE" 
                                                                                    FilterControlAltText="Filter FUND_MANAGE column" HeaderText="FUND_MANAGE" 
                                                                                    SortExpression="FUND_MANAGE" UniqueName="FUND_MANAGE">
                                                                                </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                                                    FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA DATE" 
                                                                                    SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel21" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_BENEFIT_Clap" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="SUB_BENEFIT" 
                                                                                    FilterControlAltText="Filter SUB_BENEFIT column" HeaderText="SUB_BENEFIT" 
                                                                                    SortExpression="SUB_BENEFIT" UniqueName="SUB_BENEFIT">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="LIMIT" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter LIMIT column" HeaderText="LIMIT" 
                                                                                    SortExpression="LIMIT" UniqueName="LIMIT">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CONSUMED" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter CONSUMED column" HeaderText="CONSUMED" 
                                                                                    SortExpression="CONSUMED" UniqueName="CONSUMED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="BALANCE" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter BALANCE column" HeaderText="BALANCE" 
                                                                                    SortExpression="BALANCE" UniqueName="BALANCE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="WAITING_PERIOD" 
                                                                                    FilterControlAltText="Filter WAITING_PERIOD column" HeaderText="WAITING_PERIOD" 
                                                                                    SortExpression="WAITING_PERIOD" UniqueName="WAITING_PERIOD">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="FUND_TYPE" 
                                                                                    FilterControlAltText="Filter FUND_TYPE column" HeaderText="FUND_TYPE" 
                                                                                    SortExpression="FUND_TYPE" UniqueName="FUND_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Shared_Unshared" 
                                                                                    FilterControlAltText="Filter Shared_Unshared column" HeaderText="COVER_TYPE" 
                                                                                    SortExpression="Shared_Unshared" UniqueName="Shared_Unshared">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                                                    FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA DATE" 
                                                                                    SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="Label147" runat="server" Font-Bold="True" Text="Data As at"></asp:Label>
                                                            </td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V6" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel4" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label148" runat="server" Font-Bold="True" 
                                                                    Text="PREVIOUS POLICY HISTRY"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_POLICY" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="FromDt"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter FromDt column" HeaderText="PERIOD FROM" 
                                                                                    SortExpression="FromDt" UniqueName="FromDt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ToDt"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter ToDt column" HeaderText="PERIOD TO" 
                                                                                    SortExpression="ToDt" UniqueName="ToDt">
                                                                                </telerik:GridBoundColumn>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                                    FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME NAME" 
                                                                                    SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="SOURCE" 
                                                                                    FilterControlAltText="Filter SOURCE column" HeaderText="SOURCE" 
                                                                                    SortExpression="SOURCE" UniqueName="SOURCE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                              <telerik:RadPageView ID="V7" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel8" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label1" runat="server" Font-Bold="True" 
                                                                    Text="NON-MEDICAL POLICY"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel10" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="RD_NONMED" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="Commence"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Commence column" HeaderText="DATE FROM" 
                                                                                    SortExpression="Commence" UniqueName="Commence">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Expiring"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Expiring column" HeaderText="PERIOD TO" 
                                                                                    SortExpression="Expiring" UniqueName="Expiring">
                                                                                </telerik:GridBoundColumn>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="Class_Name" 
                                                                                    FilterControlAltText="Filter Class_Name column" HeaderText="CLASS" 
                                                                                    SortExpression="Class_Name" UniqueName="Class_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Sum_Insured" 
                                                                                    FilterControlAltText="Filter Sum_Insured column" HeaderText="SUM INSURED" 
                                                                                    SortExpression="Sum_Insured" UniqueName="Sum_Insured">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Agency" 
                                                                                    FilterControlAltText="Filter Agency column" HeaderText="AGENT" 
                                                                                    SortExpression="Agency" UniqueName="Agency">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V8" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel1" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label2" runat="server" Font-Bold="True" 
                                                                    Text="MEDICAL CLAIMS HISTRY"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="RD_CLAIMS" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                      <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                                    FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" HeaderText="Member_No" 
                                                                                    SortExpression="DISPLAY_MEMBERSHIP_NO" UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                     <telerik:GridBoundColumn DataField="CLAIM_NO" 
                                                                                    FilterControlAltText="Filter CLAIM_NO column" HeaderText="Claim_No" 
                                                                                    SortExpression="CLAIM_NO" UniqueName="CLAIM_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                
                                                                                       <telerik:GridBoundColumn DataField="ADMISSION_DATE" 
                                                                                    FilterControlAltText="Filter ADMISSION_DATE column" HeaderText="Service_date" 
                                                                                    SortExpression="ADMISSION_DATE" UniqueName="ADMISSION_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                                     <telerik:GridBoundColumn DataField="DISCHARGE_DATE" 
                                                                                    FilterControlAltText="Filter DISCHARGE_DATE column" HeaderText="Discharge_date" 
                                                                                    SortExpression="DISCHARGE_DATE" UniqueName="DISCHARGE_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="INVOICE_AMT" 
                                                                                    FilterControlAltText="Filter INVOICE_AMT column" HeaderText="Amount" 
                                                                                    SortExpression="INVOICE_AMT" UniqueName="INVOICE_AMT">
                                                                                </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="CLAIM_SUB_TYPE"  
                                                                                    FilterControlAltText="Filter CLAIM_SUB_TYPE column" HeaderText="Claim_Type" 
                                                                                    SortExpression="CLAIM_SUB_TYPE" UniqueName="CLAIM_SUB_TYPE">
                                                                                </telerik:GridBoundColumn>    
                                                                                <telerik:GridBoundColumn DataField="PROVIDER_NAME"  
                                                                                    FilterControlAltText="Filter PROVIDER_NAME column" HeaderText="Provider" 
                                                                                    SortExpression="PROVIDER_NAME" UniqueName="PROVIDER_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="BILL_STATUS"  
                                                                                    FilterControlAltText="Filter BILL_STATUS column" HeaderText="Status" 
                                                                                    SortExpression="BILL_STATUS" UniqueName="BILL_STATUS">
                                                                                </telerik:GridBoundColumn>                                                                             
                                                                              <telerik:GridBoundColumn DataField="SERVER_NAME" 
                                                                                    FilterControlAltText="Filter SERVER_NAME column" HeaderText="Source" 
                                                                                    SortExpression="SERVER_NAME" UniqueName="SERVER_NAME">
                                                                                </telerik:GridBoundColumn>

                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                               
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel20" runat="server" BorderStyle="Solid" BorderWidth="1px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#999999" colspan="4">
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="MEMBER NOTES"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px">
                                                        <asp:Label ID="Label152" runat="server" Font-Bold="True" Text="Note Type"></asp:Label>
                                                    </td>
                                                    <td style="width: 168px">
                                                        <telerik:RadComboBox ID="cbonote" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbonote" Text="Enquiry" 
                                                                    Value="Enquiry" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cbonote" Text="Complain" 
                                                                    Value="Complain" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px">
                                                        <asp:Label ID="Label151" runat="server" Font-Bold="True" Text="Note"></asp:Label>
                                                    </td>
                                                    <td colspan="2" rowspan="2">
                                                        <telerik:RadTextBox ID="txtnote" Runat="server" Height="100px" 
                                                            TextMode="MultiLine" Width="500px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px">
                                                        &nbsp;</td>
                                                    <td colspan="2">
                                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" 
                                                            Text=" Save Note">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>

