﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO
Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0

                HiddenField1.Value = 0

                Str = "SELECT [Reason_Code],[Reason]  FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM_REASON] WHERE IS_ACTIVE=1" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboReason
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Reason").ToString
                    .DataValueField = MyDatatable.Columns("Reason_Code").ToString
                    .DataBind()
                End With

                LoadGrid()

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
    Public Sub LoadGrid()
        SqlAction = "SELECT  [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status],Mobile_no  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE   Is_Active=1 order by Ref_No desc"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub
    Protected Sub GDMEMBER_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDMEMBER.PageIndexChanged
        GDMEMBER.CurrentPageIndex = e.NewPageIndex
        GDMEMBER.DataSource = Session("MEM_01")
        GDMEMBER.DataBind()
    End Sub
 

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            HiddenField1.Value = 1
            Dim code As Integer = 0

            lblcode.Text = ""
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()

            code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()

            'code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],Mobile_no,New_Member, [Member_Name],[Proposer_Name],[Provider_ID],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Id]='" & code & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then

                lblcode.Text = MyDatatable.Rows(0).Item("Ref_No").ToString()
              
                cboReason.SelectedValue = MyDatatable.Rows(0).Item("Reason").ToString()
                cboclaimtype.SelectedValue = MyDatatable.Rows(0).Item("Off_Type").ToString()

                chknew.Checked = MyDatatable.Rows(0).Item("New_Member").ToString()

                SqlAction = "SELECT [Note_id],[Ref_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM_NOTES] WHERE  Ref_No ='" & lblcode.Text & "' ORDER BY  Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = Nothing
                    GDNOTES.DataBind()
                End If
            End If

            lblcode.Enabled = False
          
            cboclaimtype.Enabled = False

            chknew.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

 

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        If cbosearch.SelectedValue = "M" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status],Mobile_no  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE   Member_No LIKE '%" & txtsearch.Text & "%' and Is_Active=1"

        ElseIf cbosearch.SelectedValue = "N" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status],Mobile_no  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE   Member_Name LIKE '%" & txtsearch.Text & "%' and Is_Active=1"

        ElseIf cbosearch.SelectedValue = "R" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status],Mobile_no  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE   Ref_No LIKE '%" & txtsearch.Text & "%' and Is_Active=1"
        ElseIf cbosearch.SelectedValue = "MN" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status],Mobile_no  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE   Mobile_no LIKE '%" & txtsearch.Text & "%' and Is_Active=1"

        End If
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

        'ShowGridDetails()
    End Sub
    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDMEMBER.DeleteCommand

        Try
            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("Id").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM] SET Is_Active=0  WHERE Id='" & HiddenField1.Value.ToString & "'")
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Off System Tracking Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
            Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            LoadGrid()

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
End Class
