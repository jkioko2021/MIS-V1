﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            Str = "SELECT DISTINCT [Code],[Descr] FROM [dbo].[TBL_MIS_REIMB_REASONS] WHERE ACTIVE=1" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboreason
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Descr").ToString
                .DataValueField = MyDatatable.Columns("Code").ToString
                .DataBind()
            End With

            loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT [amc_id],[amc_tracking_code],[amc_name],[amc_aik_number],[amc_email],[amc_phone],[amc_claim_amount],[amc_service_date],[amc_invoice_number],[amc_claim_reason] FROM [DATA_REPOSITORY_DB].[dbo].[app_member_claims] where claim_picked=0"

        'SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,Claim_Type FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WHERE Submitted=1 AND [Approved]=0 and Ready_To_Process=1 and   (Is_appeal=0) and Inv_Status<>'DECLINED' and ACTIVE=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[TRACKING_CODE],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_PORTAL_CLAIMS_DOCS] WHERE  TRACKING_CODE ='" & STR & "' ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""
        ltEmbed.Text = ""
        Try


            cboreason.SelectedValue = ""
            cboreason.Text = ""
            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("amc_tracking_code").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT [amc_id],[amc_tracking_code],[amc_name],[amc_aik_number],[amc_email],[amc_phone],[amc_claim_amount],[amc_service_date],[amc_invoice_number],[amc_claim_reason],[amc_date] FROM [DATA_REPOSITORY_DB].[dbo].[app_member_claims] WHERE amc_tracking_code ='" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    lblfile.Text = MyDatable.Rows(0).Item("amc_tracking_code").ToString()
                    dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("amc_date").ToString()
                    dtservice.DbSelectedDate = MyDatable.Rows(0).Item("amc_service_date").ToString()
                    'txtmobile.Text = MyDatable.Rows(0).Item("Mobile_no").ToString()
                    'cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                    txtmemno.Text = MyDatable.Rows(0).Item("amc_aik_number").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("amc_name").ToString()
                    txtinv_no.Text = MyDatable.Rows(0).Item("amc_invoice_number").ToString()
                    txtinv_amt.Text = MyDatable.Rows(0).Item("amc_claim_amount").ToString()
                    txtemail.Text = MyDatable.Rows(0).Item("amc_email").ToString()
                    'cboreason.SelectedValue = MyDatable.Rows(0).Item("REASON").ToString()
                    'txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER").ToString()
                    'lblenteredby.Text = MyDatable.Rows(0).Item("entered_By").ToString()
                    load_Grid(lblfile.Text)

                    'Str = "SELECT EMAIL FROM employees WHERE username='" & lblenteredby.Text & "'" '"
                    'MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    'If MyDatatable.Rows.Count > 0 Then
                    '    Session("cc_email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                    '    'Session("email_CC") = "relationship-managers@aar.co.ke"
                    'Else
                    '    Str = "SELECT EMAIL FROM SALES.dbo.employees WHERE username='" & lblenteredby.Text & "'" '"
                    '    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    '    If MyDatatable.Rows.Count > 0 Then
                    '        Session("cc_email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                    '        'Session("email_CC") = "relationship-managers@aar.co.ke"cc_email
                    '    End If
                    'End If
                    txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False
                    dtservice.Enabled = False
                    'txtbarcode.Enabled = False
                    cbotype.Enabled = False
                    txtmemno.Enabled = False
                    txtinv_no.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False
                    txtname.Enabled = False
                    txtinv_no.Enabled = False
                    txtinv_amt.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False
                    cboreason.Enabled = False

                End If

                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%' and Submitted=1 and Approved=0 AND Ready_To_Process=1"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%'  and Submitted=1 and Approved=0  AND Ready_To_Process=1"
            ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%'  and Submitted=1 and Approved=0  AND Ready_To_Process=1"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%'  and Submitted=1 and Approved=0  AND Ready_To_Process=1"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub
    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/File_Claims_Portal.ashx?Id="), id)
    End Sub
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean
        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "REIMBURMENT PROCESSING" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "APPROVAL:" & txtname.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear, " & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>File No:" & lblfile.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Member Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            If lblfile.Text = "" Then
                lblerr.Text = "Select the File to Submit!"
                Exit Sub
            End If
            If txtcomment.Text = "" Then
                lblerr.Text = "You must enter short notes!"
                Exit Sub
            End If
          
            MyDBAction.Claim_Approval(lblfile.Text, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"), "DPU", txtcomment.Text, "A")

            UpdateRecord("UPDATE [DATA_REPOSITORY_DB].[dbo].[app_member_claims] SET claim_picked=1,Claim_Pick_By='" & Session("username") & "',Claim_Pick_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',amc_status='SUBMITTED'  where [amc_tracking_code]= '" & lblfile.Text & "'")
            MyDBAction.TRACKING_CLAIM_MESSAGES(lblfile.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
            Session("msg") = "Kindly note that the above Reimbursement Documents have been Verified and  forwarded for scanning.See comments below!"

            Session("to") = "DPU Team"
            'Session("email") = Session("cc_email")
            'Session("cc_email") = Session("email")
            Session("email") = "aar-claims@aar.co.ke"
            'Session("cc_email") = "emwangi@aar.co.ke"
            'Session("email") = "jmwaniki@aar.co.ke"
            'Session("cc_email") = ""
            'Session("Header") = "Submitted-" & txtproposer.Text
            MailSent = SendLoginDetails("Team", Session("email"), Session("cc_email"))

            lblerr.Text = "Saved Successfull!"
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            ltEmbed.Text = ""
            lblfile.Enabled = False
            dtreceive.Enabled = False
            dtservice.Enabled = False
            cboreason.SelectedValue = ""
            cboreason.Text = ""
            txtproposer.Text = ""
            lblfile.Text = ""
            cbotype.Text = ""
            txtmemno.Text = ""
            txtinv_no.Text = ""
            txtcomment.Text = ""
            txtinv_amt.Text = ""
            txtname.Text = ""
            txtinv_no.Text = ""
            txtinv_amt.Text = ""
            txtcomment.Text = ""
            txtinv_amt.Text = ""
            txtemail.Text = ""
            txtmobile.Text = ""
            load_Grid(lblfile.Text)
            loadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub
   
    Protected Sub RadButton3_Click(sender As Object, e As System.EventArgs) Handles RadButton3.Click

        lblfile.Enabled = True
        dtreceive.Enabled = True
        dtservice.Enabled = True
        'txtbarcode.Enabled = True
        cbotype.Enabled = True
        txtmemno.Enabled = True

        txtinv_no.Enabled = True
        txtcomment.Enabled = True
        txtinv_amt.Enabled = True
        cboreason.Enabled = True
        txtname.Enabled = True
        txtinv_no.Enabled = True
        txtinv_amt.Enabled = True
        txtcomment.Enabled = True
        txtproposer.Enabled = True

        txtinv_amt.Enabled = True
    End Sub

    Protected Sub RadButton2_Click(sender As Object, e As System.EventArgs) Handles RadButton2.Click

        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        'Dim PROCESSED As Integer = 0
        'Dim TO_FINANCE As Integer = 0
        Dim FILENO As String
        Dim app As Integer = 0
        Dim Member_no As String


        Dim receivedate As String
        Try

            If cbotype.SelectedValue = "" Then
                lblerr.Text = "You have not selected the benefit type!"
                Exit Sub
            End If
            If txtinv_no.Text = "" Then
                lblerr.Text = "You have not captured the Invoice No!"
                Exit Sub
            End If
            If txtinv_amt.Text = 0 Then
                lblerr.Text = "You have not captured the Invoice Amount!"
                Exit Sub
            End If
            If txtemail.Text = "" Then
                lblerr.Text = "You must enter EMAIL address"
                Exit Sub
            End If
            If txtmemno.Text = "" Then
                lblerr.Text = "You have not captured the Member Number"
                Exit Sub
            End If
            If txtmobile.Text = "" Then
                lblerr.Text = "You have not captured the Mobile Number"
                Exit Sub
            End If

            If (Len(txtmemno.Text) < 4 Or Len(txtmemno.Text) > 12) Then
                lblerr.Text = "You have not captured the correct member no!"
                Exit Sub
            End If

            
            If txtmobile.Text = 0 Then
                lblerr.Text = "Ensure you Enter the correct  Primary Mobile no!"
                Exit Sub
            End If

            MyDBAction.Register_REIMB(lblfile.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtservice.DbSelectedDate).ToString("yyyy-MM-dd"), cbotype.SelectedValue, Trim(txtmemno.Text), Trim(txtname.Text), Trim(txtinv_no.Text), txtinv_amt.Text, Session("username"), 0, cboreason.SelectedValue, Trim(txtproposer.Text), Trim(txtmobile.Text), Trim(txtemail.Text))
            lblerr.Text = "Updated Successfully!"
            loadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
