﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="File_request.aspx.vb" Inherits="_Default" %>

<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
<asp:UpdatePanel ID="UpdatePanel1" runat="server">

            <ContentTemplate>


                <table style="width: 92%">
                    <tr>
                        <td align="center">
                            <asp:Label ID="Label61" runat="server" Font-Bold="True" Text="FILE REQUEST"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td align="left">
                            <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                Width="878px">
                                <table style="width: 100%">
                                    <tr>
                                        <td style="width: 500px">
                                            <asp:Label ID="Label77" runat="server" style="font-weight: 700" 
                                                Text="Search By"></asp:Label>
                                        </td>
                                        <td>
                                            <telerik:RadComboBox ID="cbosearch" Runat="server" Skin="Office2007">
                                                <Items>
                                                    <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                    <telerik:RadComboBoxItem runat="server" Text="File No" Value="F" />
                                                    <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                    <telerik:RadComboBoxItem runat="server" Text="User" Value="U" />
                                                    <telerik:RadComboBoxItem runat="server" Text="Released Files" Value="R" />
                                                </Items>
                                            </telerik:RadComboBox>
                                        </td>
                                        <td>
                                            <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Office2007" 
                                                Width="250px">
                                            </telerik:RadTextBox>
                                        </td>
                                        <td>
                                            <telerik:RadButton ID="SEARCH" runat="server" Skin="Simple" Text="Search">
                                            </telerik:RadButton>
                                        </td>
                                    </tr>
                                </table>
                            </asp:Panel>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table style="width: 69%">
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" style="font-weight: 700" Width="883px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Panel ID="Panel4" runat="server" Width="870px" ScrollBars="Both" 
                                                            Height="100%">
                                                            <telerik:RadGrid ID="GDALLOC" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Width="100%" PageSize="20" Skin="Sunset">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Req_NO">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                         <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="Req_No" 
                                                                            FilterControlAltText="Filter Req_No column" HeaderText="Req_No" 
                                                                            SortExpression="Req_No" UniqueName="Req_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                            FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                            SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Request_Date" 
                                                                            FilterControlAltText="Filter Request_Date column" HeaderText="Request_Date" 
                                                                            SortExpression="Request_Date" UniqueName="Request_Date">
                                                                        </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Requested_By" 
                                                                            FilterControlAltText="Filter Requested_By column" HeaderText="Requested_By" 
                                                                            SortExpression="Requested_By" UniqueName="Requested_By">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                              
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 134px">
                                                        <asp:Label ID="Label74" runat="server" Text="Member No"></asp:Label>
                                                    </td>
                                                    <td style="width: 263px">
                                                        <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Sunset">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td class="style8" style="width: 161px">
                                                        <asp:Label ID="Label72" runat="server" Text="Proposer Name"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 134px">
                                                        &nbsp;</td>
                                                    <td style="width: 263px">
                                                        <asp:CheckBox ID="chkrequest" runat="server" 
                                                            Text="Request File" AutoPostBack="True" />
                                                    </td>
                                                    <td class="style8" style="width: 161px">
                                                        <asp:Label ID="Label62" runat="server" Text="Request Date"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="dtreq" Runat="server" MinDate="" Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 134px">
                                                        &nbsp;</td>
                                                    <td style="width: 263px">
                                                        &nbsp;</td>
                                                    <td class="style8" style="width: 161px">
                                                        <asp:Label ID="Label79" runat="server" Text="Return Date"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="dtreturn" Runat="server" MinDate="" Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 134px">
                                                        <asp:Label ID="Label78" runat="server" Text="Req NO."></asp:Label>
                                                    </td>
                                                    <td style="width: 263px">
                                                        <asp:Label ID="lblfileno" runat="server"></asp:Label>
                                                    </td>
                                                    <td class="style8" style="width: 161px">
                                                        &nbsp;</td>
                                                    <td style="width: 287px" rowspan="4">
                                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="55px" Skin="Sunset" 
                                                            TextMode="MultiLine" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 134px">
                                                        &nbsp;</td>
                                                    <td style="width: 263px">
                                                        &nbsp;</td>
                                                    <td class="style8" style="width: 161px">
                                                        <asp:Label ID="Label71" runat="server" Text="Comment"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 134px">
                                                        &nbsp;</td>
                                                    <td style="width: 263px">
                                                        <asp:CheckBox ID="chktrans" runat="server" Text="Transfer &amp; Move File" 
                                                            AutoPostBack="True" />
                                                    </td>
                                                    <td class="style8" style="width: 161px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 134px">
                                                        <asp:Label ID="Label80" runat="server" Text="Transfer To"></asp:Label>
                                                    </td>
                                                    <td style="width: 263px">
                                                        <telerik:RadComboBox ID="cbotransfer" Runat="server" Width="250px">
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td class="style8" style="width: 161px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="3">
                                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadButton ID="cmdsave" runat="server" Skin="Sunset" Text="Save" 
                                                            Width="80px" Height="34px">
                                                        </telerik:RadButton>
                                                        &nbsp;&nbsp;
                                                        <telerik:RadButton ID="cmdedit" runat="server" Skin="Sunset" Text="Edit" 
                                                            Width="80px">
                                                        </telerik:RadButton>
                                                        &nbsp;
                                                        <telerik:RadButton ID="cmdnew" runat="server" Skin="Sunset" Text="Add New" 
                                                            Width="89px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            &nbsp;</td>
                    </tr>
                </table>

            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>

