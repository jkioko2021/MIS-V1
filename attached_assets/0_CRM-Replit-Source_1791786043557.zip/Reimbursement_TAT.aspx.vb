﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtfrom.DbSelectedDate = Date.Now()
            dtto.DbSelectedDate = Date.Now()

            loadGrid()


            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing


        SqlAction = "SELECT [Year], avg(Doc_ver_Tat)Doc_ver_Tat, avg(idx_Tat)idx_Tat, avg(Allocate_Tat)Allocate_Tat, avg(Process_Tat)Process_Tat, avg(Audit_Tat)Audit_Tat, avg(Posting_Tat)Posting_Tat, avg(Sign_Tat)Sign_Tat, avg(Dispatch_Tat)Dispatch_Tat,  avg(overal_Tat)overal_Tat FROM [CRM].[dbo].[TBL_MIS_REIMB_TAT_SUMMARY] WHERE YEAR=YEAR(GETDATE()) GROUP BY [Year] "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDYR.DataSource = MyDatable
            GDYR.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDYR.DataSource = MyDatable
            GDYR.DataBind()
        End If

        SqlAction = "SELECT [Year],Mon, avg(Doc_ver_Tat)Doc_ver_Tat, avg(idx_Tat)idx_Tat, avg(Allocate_Tat)Allocate_Tat, avg(Process_Tat)Process_Tat, avg(Audit_Tat)Audit_Tat, avg(Posting_Tat)Posting_Tat, avg(Sign_Tat)Sign_Tat, avg(Dispatch_Tat)Dispatch_Tat,  avg(overal_Tat)overal_Tat FROM [CRM].[dbo].[TBL_MIS_REIMB_TAT_SUMMARY] WHERE YEAR=YEAR(GETDATE()) GROUP BY [Year],Mon "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If

        SqlAction = "SELECT  Yr, allocate_to, avg(Process_Tat)Process_Tat   FROM [TBL_MIS_REIMB_TAT_DET] WHERE YR=YEAR(GETDATE()) GROUP BY Yr,  allocate_to "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDMED.DataSource = MyDatable
            GDMED.DataBind()
            Session("DAD_6") = MyDatable
            MyDatable = Nothing
        Else
            GDMED.DataSource = MyDatable
            GDMED.DataBind()
        End If

        SqlAction = "SELECT  Yr,Mon, allocate_to, avg(Process_Tat)Process_Tat   FROM [TBL_MIS_REIMB_TAT_DET] WHERE YR=YEAR(GETDATE()) and Mon=month(GETDATE()) GROUP BY Yr,Mon,  allocate_to "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMED_1.DataSource = MyDatable
            GDMED_1.DataBind()
            Session("DAD_6") = MyDatable
            MyDatable = Nothing
        Else
            GDMED_1.DataSource = MyDatable
            GDMED_1.DataBind()
        End If
    End Sub

    Protected Sub SEARCH_Click(sender As Object, e As System.EventArgs) Handles SEARCH.Click
        Try
            SqlAction = "SELECT [Year],Mon, avg(Doc_ver_Tat)Doc_ver_Tat, avg(idx_Tat)idx_Tat, avg(Allocate_Tat)Allocate_Tat, avg(Process_Tat)Process_Tat, avg(Audit_Tat)Audit_Tat, avg(Posting_Tat)Posting_Tat, avg(Sign_Tat)Sign_Tat, avg(Dispatch_Tat)Dispatch_Tat,  avg(overal_Tat)overal_Tat FROM [CRM].[dbo].[TBL_MIS_REIMB_TAT_SUMMARY] WHERE YEAR=YEAR(GETDATE()) and Mon between '" & Month(dtfrom.DbSelectedDate) & "' and '" & Month(dtto.DbSelectedDate) & "' GROUP BY [Year],Mon"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If

            SqlAction = "SELECT [Year],  avg(Doc_ver_Tat)Doc_ver_Tat, avg(idx_Tat)idx_Tat, avg(Allocate_Tat)Allocate_Tat, avg(Process_Tat)Process_Tat, avg(Audit_Tat)Audit_Tat, avg(Posting_Tat)Posting_Tat, avg(Sign_Tat)Sign_Tat, avg(Dispatch_Tat)Dispatch_Tat,  avg(overal_Tat)overal_Tat FROM [CRM].[dbo].[TBL_MIS_REIMB_TAT_SUMMARY] WHERE YEAR=YEAR(GETDATE()) and Mon between '" & Month(dtfrom.DbSelectedDate) & "' and '" & Month(dtto.DbSelectedDate) & "' GROUP BY [Year] "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDYR.DataSource = MyDatable
                GDYR.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDYR.DataSource = MyDatable
                GDYR.DataBind()
            End If

            SqlAction = "SELECT  Yr,  allocate_to, avg(Process_Tat)Process_Tat   FROM [TBL_MIS_REIMB_TAT_DET] WHERE YR=YEAR(GETDATE()) and Mon between '" & Month(dtfrom.DbSelectedDate) & "' and '" & Month(dtto.DbSelectedDate) & "' GROUP BY Yr,  allocate_to  "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMED.DataSource = MyDatable
                GDMED.DataBind()
                Session("DAD_6") = MyDatable
                MyDatable = Nothing
            Else
                GDMED.DataSource = MyDatable
                GDMED.DataBind()
            End If
     
        Catch ex As Exception

        End Try
    End Sub

   

    Protected Sub GDMED_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMED.SelectedIndexChanged
        Try
            ID = (DirectCast(GDMED.SelectedItems(0), GridDataItem)).GetDataKeyValue("allocate_to").ToString()
            Dim SqlAction As String = ""
            SqlAction = "SELECT  Yr,Mon, allocate_to, avg(Process_Tat)Process_Tat   FROM [TBL_MIS_REIMB_TAT_DET] WHERE YR=YEAR(GETDATE()) and Mon between '" & Month(dtfrom.DbSelectedDate) & "' and '" & Month(dtto.DbSelectedDate) & "' and allocate_to='" & ID & "' GROUP BY Yr,  allocate_to,Mon "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMED_1.DataSource = MyDatable
                GDMED_1.DataBind()
                Session("DAD_6") = MyDatable
                MyDatable = Nothing
            Else
                GDMED_1.DataSource = MyDatable
                GDMED_1.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
