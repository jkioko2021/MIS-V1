﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail

'Imports Microsoft.Office.Interop
'Imports System.Windows.Forms

Imports Microsoft.VisualBasic
Imports System
'Imports Microsoft.Office.Interop.Excel
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports Microsoft.Office.Interop
Imports System.Windows.Forms
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadGrid()
            dtreq.DbSelectedDate = Date.Now
            dtreturn.DbSelectedDate = Date.Now
            dtreturn.Enabled = False
            dtreq.Enabled = False
            cbotransfer.Text = ""


        End If
    End Sub
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim req As Integer = 0
        Dim rec As Integer = 0
        Dim trans As Integer = 0
        Dim FILENO As String
        Dim SqlAction As String = ""
        Dim main As String = ""
        main = Right(LTrim(RTrim(txtmemno.Text)), 2)

        'If main <> "00" Then
        '    'lblerr.Text = "Request File using Main Member Code e.g KE1234500"
        '    'Exit Sub
        'End If
        'Dim FILENO As String = "C-" & RandomString(4)

        Dim receivedate As String
        Try

            If chkrequest.Checked = False Then
                lblerr.Text = "Check the Request file option"
                Exit Sub
            End If

            If chkrequest.Checked = True Then
                req = 1
            Else
                req = 0
            End If



            If chktrans.Checked = True Then
                trans = 1
            Else
                trans = 0
            End If

            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim DEPART As String = ""

            SqlAction = "SELECT Department from Employees WHERE username= '" & Session("UserName").ToString & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                DEPART = MyDatable.Rows(0).Item("Department").ToString()
            End If


            If HiddenField1.Value = "" Then
                If txtmemno.Text <> "" Then
                    SqlAction = "SELECT [Member_No],Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE File_Requested=1 AND  File_Returned<>1 AND File_Active=1 AND Member_No='" & LTrim(RTrim(txtmemno.Text)) & "'"
                    MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                    If MyDatable.Rows.Count > 0 Then
                        lblerr.Text = "File in use by : " & MyDatable.Rows(0).Item("Requested_By").ToString() & ""
                        Exit Sub
                    End If
                End If


                Dim RandomClass As New Random()
                'Dim RandomNumber = RandomClass.Next(1, 99999)
                'FILENO = "C-" & RandomNumber
                Dim RandomNumber As Long = Now.Day & Now.Month & Now.Hour & Now.Minute & Now.Second
                FILENO = "AAR-" & "F" & "-" & RandomNumber

                STS = 0
                MyDBAction.TRACK_FILE_REQ(FILENO, DEPART, txtmemno.Text, txtname.Text, req, CDate(dtreq.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtreturn.DbSelectedDate).ToString("yyyy-MM-dd"), txtcomment.Text, Session("FullNames").ToString, Session("UserName").ToString, trans, cbotransfer.SelectedValue, "0", STS)

                If DEPART = "CASE MANAGEMENT" Then
                    Request_K(FILENO)
                End If

                lblfileno.Text = FILENO
                lblerr.Text = "Saved Successfully!"
                txtmemno.Text = ""
                txtname.Text = ""
                txtcomment.Text = ""
                cmdsave.Enabled = False
            Else
                STS = 1
                MyDBAction.TRACK_FILE_REQ(lblfileno.Text, DEPART, txtmemno.Text, txtname.Text, req, CDate(dtreq.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtreturn.DbSelectedDate).ToString("yyyy-MM-dd"), txtcomment.Text, Session("FullNames").ToString, Session("UserName").ToString, trans, cbotransfer.SelectedValue, Session("UserName").ToString, STS)
                lblerr.Text = "Updated Successfully!"
                lblfileno.Text = FILENO
                lblerr.Text = "Updated Successfully!"
                txtmemno.Text = ""
                txtname.Text = ""
                txtcomment.Text = ""
                chkrequest.Checked = False
                cmdedit.Enabled = False

            End If
            LoadGrid()
            HiddenField1.Value = ""

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Private Sub LoadGrid()
        Dim SqlAction As String = ""
        Dim searchStr As String = ""
        Dim MyDBAction As New DataManagement
        Session("DAT2") = Nothing
        SqlAction = "SELECT [Req_NO],[Member_No],[Proposer_Name],Request_Date,Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE File_Requested=1 AND  File_Returned<>1 AND Requested_By='" & Session("FullNames").ToString & "'  AND File_Active=1 order by Request_Date Desc"

        Dim MyDatable As New Data.DataTable
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDALLOC.DataSource = MyDatable
            GDALLOC.DataBind()
            Session("DAT2") = MyDatable
            MyDatable = Nothing
        Else
            GDALLOC.DataSource = MyDatable
            GDALLOC.DataBind()
        End If


    End Sub


    Protected Sub cmdnew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdnew.Click
        HiddenField1.Value = ""
        lblfileno.Text = ""
        lblerr.Text = ""
        txtmemno.Text = ""
        txtname.Text = ""
        txtcomment.Text = ""
        chktrans.Checked = False
        cmdsave.Enabled = True
        chkrequest.Checked = False

        txtmemno.Enabled = True
        txtname.Enabled = True
        dtreq.Enabled = True
        txtcomment.Enabled = True
        cmdsave.Enabled = True
        cmdedit.Enabled = True
        chkrequest.Enabled = True
        cbotransfer.Enabled = False
        chktrans.Enabled = False

    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Dim SqlAction As String = ""
        Dim searchStr As String = ""
        Dim MyDBAction As New DataManagement

        If cbosearch.SelectedValue = "M" Then
            SqlAction = "SELECT [Req_NO],[Member_No],[Proposer_Name],Request_Date,Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE file_Returned=0 and  File_Requested=1 AND Member_No  Like '%" & Trim(txtsearch.Text) & "%'"

        ElseIf cbosearch.SelectedValue = "F" Then
            SqlAction = "SELECT [Req_NO],[Member_No],[Proposer_Name],Request_Date,Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE file_Returned=0 and  File_Requested=1   AND Req_NO  Like '%" & Trim(txtsearch.Text) & "%'"

        ElseIf cbosearch.SelectedValue = "U" Then
            SqlAction = "SELECT [Req_NO],[Member_No],[Proposer_Name],Request_Date,Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE file_Returned=0  and  File_Requested=1 AND Requested_By  Like '%" & Trim(txtsearch.Text) & "%'"
        ElseIf cbosearch.SelectedValue = "P" Then
            SqlAction = "SELECT [Req_NO],[Member_No],[Proposer_Name],Request_Date,Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE file_Returned=0  and  File_Requested=1 AND Proposer_Name  Like '%" & Trim(txtsearch.Text) & "%'"
        ElseIf cbosearch.SelectedValue = "D" Then
            SqlAction = "SELECT [Req_NO],[Member_No],[Proposer_Name],Request_Date,Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST WITH (NOLOCK) WHERE file_Returned=0  and  File_Requested=1 AND Department  Like '%" & Trim(txtsearch.Text) & "%'"
        ElseIf cbosearch.SelectedValue = "R" Then
            SqlAction = "SELECT [Req_NO],[Member_No],[Proposer_Name],Request_Date,Requested_By  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE file_Returned=0 and  File_Requested=1 AND File_Released=1"

        End If


        Dim MyDatable As New Data.DataTable
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDALLOC.DataSource = MyDatable
            GDALLOC.DataBind()
            Session("DAT2") = MyDatable
            MyDatable = Nothing
        Else
            GDALLOC.DataSource = MyDatable
            GDALLOC.DataBind()
        End If

    End Sub

    Protected Sub chkrequest_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkrequest.CheckedChanged
        If chkrequest.Checked = True Then
            dtreturn.DbSelectedDate = DateAdd(DateInterval.Day, 14, dtreq.DbSelectedDate)
        End If
    End Sub

    Private Sub Request_K(ByVal fileno As String)
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Str_1 As String = ""
        Dim Str_2 As String = ""
        Dim MyDatable_1 As DataTable = Nothing
        Dim MailSent As Boolean = False
        Str = "SELECT Req_No,Member_No,Proposer_Name,Request_Date,Exp_Return_Date,Requested_By FROM [MISREPORTS].[dbo].TBL_FILE_REQUEST WITH (NOLOCK) WHERE Req_No ='" & fileno & "'"

        '------------------------------------------------------------------------------------------------------------------------------------
        MyDatable = Nothing
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            For Each row_ As DataRow In MyDatable.Rows
                Session("Member_Number") = row_("Member_No").ToString() ' row_("Proposer_Name").ToString() '& " " & " {" & CDate(RDDFROM.SelectedDate).ToString("yyyy-MM-dd") & "-" & CDate(RDDATETO.SelectedDate).ToString("yyyy-MM-dd") & "}" ' MyDatable.Rows(0).Item("USER_DISPLAY_NAME").ToString() ' 
                Session("Req_No") = row_("Req_No").ToString() ' row_("File_No").ToString()
                Session("Proposer_Name") = row_("Proposer_Name").ToString() ' row_("Card_Dis_Date").ToString()
                Session("Request_Date") = row_("Request_Date").ToString() 'row_("Card_Dis_To").ToString()
                Session("Exp_Return_Date") = row_("Exp_Return_Date").ToString()
                Session("Requested_By") = row_("Requested_By").ToString()


                Str_1 = "SELECT Email,EmployeeName FROM Employees WITH (NOLOCK) WHERE EmployeeName='" & Session("Requested_By") & "'"
                MailSent = Send_Reminder_Details(Session("EmployeeName"), Session("RecepientEmail"))


            Next

        End If

    End Sub
    Private Function Send_Reminder_Details(ByVal EmployeeName As String, ByVal RecepientEmail As String) As Boolean

        Dim MailSent As Boolean = False

        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""

        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""


        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011

            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()
            MessageSubject = "File Request-Case Management" & "-" & txtmemno.Text
            ''---Decrypt data


        Catch ex As Exception

        End Try


        Try

            Dim strHTML As New StringBuilder

            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("</tr>")
            strHTML = strHTML.Append("<tr>")
            strHTML = strHTML.Append("<td colspan='3'>")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Att: Filling Room")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Kindly,Note that the below file is Required Urgently to facilitate member admission.")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------Member Details-----------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Req No       : " & Session("Req_No") & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Member Number: " & Session("Member_Number") & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Proposer Name:" & Session("Proposer_Name") & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Req Date     :" & Session("Request_Date") & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Due Date     :" & Session("Exp_Return_Date") & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Comment      :  " & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("---------------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")

            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, "registry@aar.co.ke", EmployeeName, LoginFromEmail, LoginDisplayName, "")

            'MailSent = mymail.SendNotification2(path, MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName)

            Session("MailSent") = MailSent

        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False

        End Try

        Return MailSent
    End Function

    Protected Sub GDALLOC_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDALLOC.NeedDataSource

    End Sub

    Protected Sub GDALLOC_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDALLOC.PageIndexChanged
        GDALLOC.CurrentPageIndex = e.NewPageIndex
        GDALLOC.DataSource = Session("DAT2")
        GDALLOC.DataBind()
    End Sub

    Protected Sub GDALLOC_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDALLOC.SelectedIndexChanged

        lblfileno.Text = ""
        lblfileno.Text = (DirectCast(GDALLOC.SelectedItems(0), GridDataItem)).GetDataKeyValue("Req_NO").ToString()

        Dim SqlAction As String = ""
        'Dim searchStr As String = ""
        'Dim MyDBAction As New DataManagement

        'Session("Application") = Nothing

        SqlAction = "SELECT [Req_NO],Department, [Member_No],File_Retrieved,[Proposer_Name],Request_Date,Requested_By,[File_Requested],[Request_Date],Is_Transfer,exp_Return_Date,[File_Released],[File_Returned],[Return_Date],Released_DATE,department,Comment  FROM [MISREPORTS].[dbo].[TBL_FILE_REQUEST] WITH (NOLOCK) WHERE Req_NO= '" & lblfileno.Text & "'"


        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then


            txtmemno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
            txtname.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()

            chkrequest.Checked = MyDatable.Rows(0).Item("File_Requested").ToString()
            dtreq.DbSelectedDate = MyDatable.Rows(0).Item("Request_Date").ToString()
            dtreturn.DbSelectedDate = MyDatable.Rows(0).Item("exp_Return_Date").ToString()
            txtcomment.Text = MyDatable.Rows(0).Item("Comment").ToString()
            chktrans.Checked = MyDatable.Rows(0).Item("Is_Transfer").ToString()

        End If


        txtmemno.Enabled = False
        txtname.Enabled = False
        dtreq.Enabled = False
        txtcomment.Enabled = False
        cmdsave.Enabled = False
        cmdedit.Enabled = True
        chkrequest.Enabled = False
        cbotransfer.Enabled = False
        chktrans.Enabled = False



    End Sub


    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        cbotransfer.Enabled = True
        cmdsave.Enabled = True
        txtcomment.Enabled = True
        chktrans.Enabled = True
    End Sub

    Protected Sub chktrans_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chktrans.CheckedChanged
        If chktrans.Checked = True Then


            Str = ""
            Str = ""
            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT EmployeeName FROM dbo.employees WITH (NOLOCK)  WHERE  department IS NOT NULL" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbotransfer

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                .DataValueField = MyDatatable.Columns("EmployeeName").ToString
                .DataBind()

            End With
            MyDatatable = Nothing
        Else
            cbotransfer.Text = ""
        End If

    End Sub
End Class
