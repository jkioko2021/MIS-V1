﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Refund_Status.aspx.vb" Inherits="_Default" %>


<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="REFUND STATUS" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td align="right" colspan="4">
                                                    <asp:Panel ID="Panel31" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 192px">
                                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                                </td>
                                                                <td style="width: 143px">
                                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" AllowCustomText="True" 
                                                                        MarkFirstMatch="True" Skin="Web20" Width="190px">
                                                                        <Items>
                                                                            <telerik:RadComboBoxItem runat="server" Text="Ref No" Value="F" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                                        </Items>
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td style="width: 266px">
                                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Web20" Width="250px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3">
                                                    <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTrackingRef" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="Refund_No">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                                    <telerik:GridBoundColumn DataField="Refund_No" 
                                                                        FilterControlAltText="Filter Receive_dt column" HeaderText="Refund_No" 
                                                                        SortExpression="Refund_No" UniqueName="Refund_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Client_Type" 
                                                                        FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                        SortExpression="Client_Type" UniqueName="Client_Type">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Request_Dt" 
                                                                        FilterControlAltText="Filter Request_Dt column" HeaderText="Request_Dt" 
                                                                        SortExpression="Request_Dt" UniqueName="Request_Dt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Payee_Name" 
                                                                        FilterControlAltText="Filter Payee_Name column" HeaderText="Payee_Name" 
                                                                        SortExpression="Payee_Name" UniqueName="Payee_Name">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Amount_Paid" 
                                                                        FilterControlAltText="Filter Amount_Paid column" HeaderText="Amount_Paid" 
                                                                        SortExpression="Amount_Paid" UniqueName="Amount_Paid">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Refund_Amt" 
                                                                        FilterControlAltText="Filter Refund_Amt column" HeaderText="Refund_Amt" 
                                                                        SortExpression="Refund_Amt" UniqueName="Refund_Amt">
                                                                    </telerik:GridBoundColumn>                                                                  
                                                                    <telerik:GridBoundColumn DataField="Refund_Status" 
                                                                        FilterControlAltText="Filter Refund_Status column" HeaderText="Refund_Status" 
                                                                        SortExpression="Refund_Status" UniqueName="Refund_Status">
                                                                    </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="Refund_Type" 
                                                                        FilterControlAltText="Filter Refund_Type column" HeaderText="Refund_Type" 
                                                                        SortExpression="Refund_Type" UniqueName="Refund_Type">
                                                                    </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="Allocate_To" 
                                                                        FilterControlAltText="Filter Allocate_To column" HeaderText="Allocated_to" 
                                                                        SortExpression="Allocate_To" UniqueName="Allocate_To">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Entered_By" 
                                                                        FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                        SortExpression="Entered_By" UniqueName="Entered_By">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="FILE_NO" runat="server" Font-Bold="True" Font-Size="Small" 
                                                        style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    &nbsp;</td>
                                                <td style="width: 264px">
                                                    <asp:Label ID="lblclient" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Label ID="lblREfT" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 187px; height: 41px;">
                                                    <asp:Label ID="Label159" runat="server" Font-Size="Medium" Text="Refund No"></asp:Label>
                                                </td>
                                                <td style="height: 41px">
                                                    <asp:Label ID="RefNo" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                                <td style="width: 174px; height: 41px;">
                                                    <asp:Label ID="lblprop" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red" Visible="False"></asp:Label>
                                                </td>
                                                <td style="height: 41px">
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <hr />
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1136px">
                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            SortExpression="File_No" UniqueName="File_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Ref" 
                                                            FilterControlAltText="Filter Doc_Ref column" HeaderText="Doc_Ref" 
                                                            SortExpression="Doc_Ref" UniqueName="Doc_Ref">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                            SortExpression="DOC_ID">
                                                            <ItemTemplate>
                                                                <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                    CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                            </ItemTemplate>
                                                        </telerik:GridTemplateColumn>
                                                        <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                            ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                            Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                            <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                            <ItemStyle CssClass="ButtonColumn" />
                                                        </telerik:GridButtonColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                        ScrollBars="Horizontal" Width="1134px">
                                                        <asp:Literal ID="ltEmbed" runat="server" />
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px; height: 26px;">
                                                    <asp:Label ID="Label167" runat="server" Text="Processed By"></asp:Label>
                                                </td>
                                                <td style="height: 26px">
                                                    <asp:Label ID="lblprocessedby" runat="server"></asp:Label>
                                                </td>
                                                <td style="height: 26px">
                                                </td>
                                                <td style="width: 193px; height: 26px;">
                                                </td>
                                                <td style="height: 26px">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px">
                                                    <asp:Label ID="Label152" runat="server" Text="Entered By"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblenteredby" runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1129px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                         
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Notes_by" UniqueName="Notes_by">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>

            </asp:UpdatePanel>
</asp:Content>


