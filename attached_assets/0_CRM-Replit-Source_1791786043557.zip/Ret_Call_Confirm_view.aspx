﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Ret_Call_Confirm_view.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8" colspan="4">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="New Client Confirmation"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 1025px">
                                                    <telerik:RadComboBox ID="cborm" Runat="server" AllowCustomText="True" 
                                                        MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Proposer Name" 
                                                                Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Family Code" 
                                                                Value="F" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Agent" 
                                                                Value="Agent" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 261px">
                                                    &nbsp;</td>
                                                <td style="width: 250px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 261px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" AllowCustomText="True" 
                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Policy Code" Value="F" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Agent" Value="A" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadComboBox ID="cbosearch_1" Runat="server" AllowCustomText="True" 
                                                        MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" 
                                                                Text="Proposer Name" Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Family Code" 
                                                                Value="F" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Agent" 
                                                                Value="Agent" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDProposer" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" Width="100%" 
                                                PageSize="20">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                      <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                   
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter Task_code column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="PROPOSER_DISPLAY_NAME" 
                                                            SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                            </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                    
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left" colspan="4">
                                        <asp:Label ID="Label142" runat="server" Text="Members"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" colspan="4">
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" >
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                  
                                                        <telerik:GridBoundColumn DataField="Confirm_Call_Code" 
                                                            FilterControlAltText="Filter Confirm_Call_Code column" HeaderText="Call_Code" 
                                                            SortExpression="Confirm_Call_Code" UniqueName="Confirm_Call_Code">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Confirm_Call_By" 
                                                            FilterControlAltText="Filter Confirm_Call_By column" 
                                                            HeaderText="Call_By" SortExpression="Confirm_Call_By" 
                                                            UniqueName="Confirm_Call_By">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Confirm_Call_Date" 
                                                            FilterControlAltText="Filter Confirm_Call_Date column" HeaderText="Call_Date" 
                                                            SortExpression="Confirm_Call_Date" UniqueName="Confirm_Call_Date">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Correct_Cover" 
                                                            FilterControlAltText="Filter Correct_Cover column" HeaderText="Cover is ok" 
                                                            SortExpression="Correct_Cover" UniqueName="Correct_Cover">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Welcome_Package" 
                                                            FilterControlAltText="Filter Welcome_Package column" HeaderText="Welcome Package" 
                                                            SortExpression="Welcome_Package" UniqueName="Welcome_Package">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Ack_Consent" 
                                                            FilterControlAltText="Filter Ack_Consent column" HeaderText="Ack Consent" 
                                                            SortExpression="Ack_Consent" UniqueName="Ack_Consent">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="Policy_Terms_Exp" 
                                                            FilterControlAltText="Filter Policy_Terms_Exp column" HeaderText="Policy Terms Explained" 
                                                            SortExpression="Policy_Terms_Exp" UniqueName="Policy_Terms_Exp">
                                                        </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="Satisfied_with_info" 
                                                            FilterControlAltText="Filter Satisfied_with_info column" HeaderText="Satisfied" 
                                                            SortExpression="Satisfied_with_info" UniqueName="Satisfied_with_info">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" style="width: 119px">
                                        <asp:Label ID="Label136" runat="server" Text="Notes"></asp:Label>
                                    </td>
                                    <td style="width: 179px">
                                        <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td align="left" class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        <asp:Label ID="PRD" runat="server" Visible="False"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left" colspan="4">
                                        <hr />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left" colspan="4">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            SortExpression="Note_Date" UniqueName="Note_Date" ItemStyle-Width="50">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            SortExpression="Note_Type" UniqueName="Note_Type" ItemStyle-Width="50">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            SortExpression="Notes_by" UniqueName="Notes_by" ItemStyle-Width="50">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red" Font-Size="Medium"></asp:Label>
                                    </td>
                                    <td class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>


