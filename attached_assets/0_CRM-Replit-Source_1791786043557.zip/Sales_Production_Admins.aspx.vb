﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String = ""
    Dim region_code As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Session("RD_BANC") = Nothing
            Session("RD_BROKER") = Nothing
            Session("RD_IND_1") = Nothing
            Session("SEARCH_Y") = Nothing
            Session("INV") = Nothing

            Str = "SELECT Emp_Code FROM	employees  WHERE   username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                'empcode = "0487"

                Str = "SELECT  Region_Code FROM [COMMISSION].[dbo].[TBL_MIS_ADMINS] WHERE  Is_Active=1 AND MIS_Emp_Code='" & empcode & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    region_code = MyDatatable.Rows(0).Item("Region_Code").ToString()
                End If

            Else
                lbltext.Text = "You are not authorized to view this page"
                Exit Sub
            End If


            Str = "SELECT REGION_CODE,REGION_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_REGION WHERE    REGION_CODE ='" & region_code & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboregion
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("REGION_NAME").ToString
                .DataValueField = MyDatatable.Columns("REGION_CODE").ToString
                .DataBind()
            End With
            SqlAction = "SELECT  MIN([DATE_FROM])DATE_FROM,MIN([DATE_TO])DATE_TO FROM [SALES].[dbo].[TBL_MIS_PROD_MONTHS] WHERE  [MONTH_CLOSED] =0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then

                dtDateFrom.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_FROM")).ToString("yyyy-MM-dd")
                dtDateTo.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()

                'Session("DTFROM") = CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd")
                'Session("DTTO") = CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd")

            End If



            SqlAction = "SELECT  MIN([DATE_FROM])DATE_FROM,MIN([DATE_TO])DATE_TO FROM [SALES].[dbo].[TBL_MIS_PROD_MONTHS] WHERE   [MONTH_CLOSED] =0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then

                dtDateFrom.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_FROM")).ToString("yyyy-MM-dd")
                dtDateTo.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()

                'Session("DTFROM") = CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd")
                'Session("DTTO") = CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd")


            End If
            'LOADGRID()
        End If
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        'SELECT [MONTH_FROM],[MONTH_TO],[NEW_BUDGET],[RENEWAL_BUDGET],[MONTH_BUDGET],[UNIT_NAME],UNIT_CODE,BRANCH_CODE,R_CODE  FROM [SALES].[dbo].[vw_UM_BUDGET] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='U001'

        GDSEARCH_U.DataSource = Nothing
        GDSEARCH_U.DataBind()
        GDSEARCH_R.DataSource = Nothing
        GDSEARCH_R.DataBind()
        GD_CHANNEL_0.DataSource = Nothing
        GD_CHANNEL_0.DataBind()
        GD_MARKET_0.DataSource = Nothing
        GD_MARKET_0.DataBind()
        GD_TITLE_0.DataSource = Nothing
        GD_TITLE_0.DataBind()
        GDSEARCH_Y.DataSource = Nothing
        GDSEARCH_Y.DataBind()

        GDSEARCH_U_1.DataSource = Nothing
        GDSEARCH_U_1.DataBind()
        RD_IND.DataSource = Nothing
        RD_IND.DataBind()
        RD_BROKER.DataSource = Nothing
        RD_BROKER.DataBind()
        RD_BANC.DataSource = Nothing
        RD_BANC.DataBind()

        RD_NEW.DataSource = Nothing
        RD_NEW.DataBind()
        RD_REN.DataSource = Nothing
        RD_REN.DataBind()

        GD_CHANNEL_0.DataSource = Nothing
        GD_CHANNEL_0.DataBind()
        GD_TITLE_0.DataSource = Nothing
        GD_TITLE_0.DataBind()
        GD_MARKET_0.DataSource = Nothing
        GD_MARKET_0.DataBind()

        RD_DI.DataSource = Nothing
        RD_DI.DataBind()

        lblCODE.Text = ""
        Try

            SqlAction = "SELECT UM_ID,UM_NAME,[UNIT_NAME],UNIT_CODE,  SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([ACTUAL_NEW_MED])[ACTUAL_NEW_MED],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([ACTUAL_NEW_NONMED])[ACTUAL_NEW_NONMED], SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM SALES.[dbo].[vw_SALES_UNIT_SUMMARY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND R_CODE='" & cboregion.SelectedValue & "' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [UNIT_NAME],UM_NAME,UM_ID,YEAR([MONTH_FROM]),[UNIT_NAME],UNIT_CODE ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_U.DataSource = MyDatable
                GDSEARCH_U.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_U.DataSource = Nothing
                GDSEARCH_U.DataBind()
            End If

            SqlAction = "SELECT [RM_ID],[RM_NAME],REGION_NAME,R_CODE,  SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([ACTUAL_NEW_MED])[ACTUAL_NEW_MED],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([ACTUAL_NEW_NONMED])[ACTUAL_NEW_NONMED], SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM SALES.[dbo].[vw_SALES_REGION_SUMMARY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND R_CODE='" & cboregion.SelectedValue & "' AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY R_CODE, [RM_ID],[RM_NAME],REGION_NAME,YEAR([MONTH_FROM]) ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_R.DataSource = MyDatable
                GDSEARCH_R.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_R.DataSource = Nothing
                GDSEARCH_R.DataBind()
            End If




            SqlAction = "SELECT [CHANNEL_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_CHANNEL] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [CHANNEL_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_TYPE,SUM(MEDICAL)MEDICAL,SUM([NON-MED])[NON-MED],SUM(NEW)NEW,SUM(RENEWAL)RENEWAL,SUM(TOTAL_PREMIUMS)TOTAL_PREMIUMS FROM [dbo].[VW_SALES_PRODUTION_PER_CHANNEL] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  YEAR(INVOICE_DATE)='" & cboyear.SelectedValue & "' GROUP BY AGENT_TYPE  ORDER BY SUM(TOTAL_PREMIUMS) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_CHANNEL_0.DataSource = MyDatable
                GD_CHANNEL_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_CHANNEL_0.DataSource = Nothing
                GD_CHANNEL_0.DataBind()
            End If

            SqlAction = "SELECT [TITLE_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_TITLE] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [TITLE_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_TITLE_0.DataSource = MyDatable
                GD_TITLE_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_TITLE_0.DataSource = Nothing
                GD_TITLE_0.DataBind()
            End If
            SqlAction = "SELECT [MARKET_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_MARKET] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [MARKET_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_MARKET_0.DataSource = MyDatable
                GD_MARKET_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_MARKET_0.DataSource = Nothing
                GD_MARKET_0.DataBind()
            End If


            SqlAction = "SELECT USER_ID,AGENT_NAME, UNIT_CODE, SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM SALES.dbo.[TBL_SALES_AGENT_SUMMARY_MTD] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY UNIT_CODE,USER_ID,AGENT_NAME ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GDSEARCH_Y.DataSource = MyDatable
                GDSEARCH_Y.DataBind()
                Session("SEARCH_Y") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_Y.DataSource = Nothing
                GDSEARCH_Y.DataBind()
            End If

            'SELECT  [AGENT_ID],[USER_DISPLAY_NAME],[UNIT_CODE],[REGION_CODE],[AGENT_TYPE],[MONTH_FROM],[MONTH_TO],[NEW_MEDICAL],[NEW_NON_MEDICAL],[RENEWAL_MEDICAL],[RENEWAL_NONMEDICAL],[TOTAL_RENEW],[TOTAL_NEW],[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY]

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND  AGENT_TYPE='INDEPENDENT' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_IND.DataSource = MyDatable
                RD_IND.DataBind()
                Session("RD_IND_1") = MyDatable
                MyDatable = Nothing
            Else
                RD_IND.DataSource = Nothing
                RD_IND.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='BROKER' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BROKER.DataSource = MyDatable
                RD_BROKER.DataBind()
                Session("RD_BROKER") = MyDatable
                MyDatable = Nothing
            Else
                RD_BROKER.DataSource = Nothing
                RD_BROKER.DataBind()
            End If

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "'  AND AGENT_TYPE='BANCASSURANCE' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BANC.DataSource = MyDatable
                RD_BANC.DataBind()
                Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_BANC.DataSource = Nothing
                RD_BANC.DataBind()
            End If


            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND   AGENT_TYPE='DIRECT_SALES' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_DI.DataSource = MyDatable
                RD_DI.DataBind()
                'Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_DI.DataSource = Nothing
                RD_DI.DataBind()
            End If
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND   CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "'  AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If


        Catch ex As Exception
            lbltext.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDSEARCH_U_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH_U.PageIndexChanged
        GDSEARCH_U.CurrentPageIndex = e.NewPageIndex
        GDSEARCH_U.DataSource = Session("S_1")
        GDSEARCH_U.DataBind()
    End Sub


    Protected Sub GDSEARCH_U_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH_U.SelectedIndexChanged
        Dim USER_ID As String = ""
        lblCODE.Text = ""
        GDSEARCH_Y.DataSource = Nothing
        GDSEARCH_Y.DataBind()

        GDSEARCH_U_1.DataSource = Nothing
        GDSEARCH_U_1.DataBind()
        RD_IND.DataSource = Nothing
        RD_IND.DataBind()
        RD_BROKER.DataSource = Nothing
        RD_BROKER.DataBind()
        RD_BANC.DataSource = Nothing
        RD_BANC.DataBind()

        GD_CHANNEL_0.DataSource = Nothing
        GD_CHANNEL_0.DataBind()
        GD_MARKET_0.DataSource = Nothing
        GD_MARKET_0.DataBind()
        GD_TITLE_0.DataSource = Nothing
        GD_TITLE_0.DataBind()
        GDSEARCH_Y.DataSource = Nothing
        GDSEARCH_Y.DataBind()


        RD_IND.DataSource = Nothing
        RD_IND.DataBind()
        RD_BROKER.DataSource = Nothing
        RD_BROKER.DataBind()
        RD_BANC.DataSource = Nothing
        RD_BANC.DataBind()

        RD_DI.DataSource = Nothing
        RD_DI.DataBind()
        Try
            USER_ID = (DirectCast(GDSEARCH_U.SelectedItems(0), GridDataItem)).GetDataKeyValue("UNIT_CODE").ToString()
            lblCODE.Text = USER_ID
            SqlAction = "SELECT [UM_ID],[UM_NAME],[UNIT_CODE],[UNIT_NAME],[MONTH_FROM],[MONTH_TO],[NEW_MEDICAL],[ACTUAL_NEW_MED],[NEW_NON_MEDICAL],[ACTUAL_NEW_NONMED],[NEW_BUDGET],[ACTUAL_NEW],[RENEWAL_BUDGET],[ACTUAL_RENEW],[MONTH_BUDGET],[ACTUAL_PROD],[DEFICIT],[PERC_PRODUCTION],[NEW_PERC],[RENEWAL_PERC]  FROM [SALES].[dbo].[vw_SALES_UNIT_SUMMARY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & USER_ID & "'  AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_U_1.DataSource = MyDatable
                GDSEARCH_U_1.DataBind()
                MyDatable = Nothing
            Else
                GDSEARCH_U_1.DataSource = Nothing
                GDSEARCH_U_1.DataBind()
            End If


            SqlAction = "SELECT USER_ID,AGENT_NAME, UNIT_CODE, SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM SALES.dbo.[TBL_SALES_AGENT_SUMMARY_MTD] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & USER_ID & "' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY UNIT_CODE,USER_ID,AGENT_NAME ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GDSEARCH_Y.DataSource = MyDatable
                GDSEARCH_Y.DataBind()
                Session("SEARCH_Y") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_Y.DataSource = Nothing
                GDSEARCH_Y.DataBind()
            End If

            'SELECT  [AGENT_ID],[USER_DISPLAY_NAME],[UNIT_CODE],[REGION_CODE],[AGENT_TYPE],[MONTH_FROM],[MONTH_TO],[NEW_MEDICAL],[NEW_NON_MEDICAL],[RENEWAL_MEDICAL],[RENEWAL_NONMEDICAL],[TOTAL_RENEW],[TOTAL_NEW],[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY]

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND   UNIT_CODE='" & USER_ID & "' AND AGENT_TYPE='INDEPENDENT' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_IND.DataSource = MyDatable
                RD_IND.DataBind()
                Session("RD_IND_1") = MyDatable
                MyDatable = Nothing
            Else
                RD_IND.DataSource = Nothing
                RD_IND.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "'  AND UNIT_CODE='" & USER_ID & "' AND AGENT_TYPE='BROKER' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BROKER.DataSource = MyDatable
                RD_BROKER.DataBind()
                Session("RD_BROKER") = MyDatable
                MyDatable = Nothing
            Else
                RD_BROKER.DataSource = Nothing
                RD_BROKER.DataBind()
            End If

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "'  AND UNIT_CODE='" & USER_ID & "' AND AGENT_TYPE='BANCASSURANCE' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BANC.DataSource = MyDatable
                RD_BANC.DataBind()
                Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_BANC.DataSource = Nothing
                RD_BANC.DataBind()
            End If

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND   UNIT_CODE='" & USER_ID & "' AND AGENT_TYPE='DIRECT_SALES' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_DI.DataSource = MyDatable
                RD_DI.DataBind()
                'Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_DI.DataSource = Nothing
                RD_DI.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & USER_ID & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "'  AND UNIT_CODE='" & USER_ID & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If

        Catch ex As Exception
            lbltext.Text = ex.Message
        End Try

    End Sub

    Protected Sub GDSEARCH_R_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH_R.SelectedIndexChanged
        'Dim R_CODE As String = ""
        GDSEARCH_R_1.DataSource = Nothing
        GDSEARCH_R_1.DataBind()
        Try

            lblCODE.Text = (DirectCast(GDSEARCH_R.SelectedItems(0), GridDataItem)).GetDataKeyValue("R_CODE").ToString()
            SqlAction = "SELECT [R_CODE],[RM_NAME],REGION_NAME,[MONTH_FROM],[MONTH_TO],[NEW_MEDICAL],[ACTUAL_NEW_MED],[NEW_NON_MEDICAL],[ACTUAL_NEW_NONMED],[NEW_BUDGET],[ACTUAL_NEW],[RENEWAL_BUDGET],[ACTUAL_RENEW],[MONTH_BUDGET],[ACTUAL_PROD],[DEFICIT],[PERC_PRODUCTION],[NEW_PERC],[RENEWAL_PERC]  FROM [SALES].[dbo].[vw_SALES_REGION_SUMMARY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  R_CODE='" & cboregion.SelectedValue & "' AND R_CODE='" & lblCODE.Text & "'  AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_R_1.DataSource = MyDatable
                GDSEARCH_R_1.DataBind()
                MyDatable = Nothing
            Else
                GDSEARCH_R_1.DataSource = Nothing
                GDSEARCH_R_1.DataBind()
            End If

            SqlAction = "SELECT UM_ID,UM_NAME,[UNIT_NAME],UNIT_CODE,  SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([ACTUAL_NEW_MED])[ACTUAL_NEW_MED],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([ACTUAL_NEW_NONMED])[ACTUAL_NEW_NONMED], SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM SALES.[dbo].[vw_SALES_UNIT_SUMMARY] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND   MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [UNIT_NAME],UM_NAME,UM_ID,YEAR([MONTH_FROM]),[UNIT_NAME],UNIT_CODE ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_U.DataSource = MyDatable
                GDSEARCH_U.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_U.DataSource = Nothing
                GDSEARCH_U.DataBind()
            End If

            SqlAction = "SELECT [CHANNEL_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_CHANNEL] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [CHANNEL_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_TYPE,SUM(MEDICAL)MEDICAL,SUM([NON-MED])[NON-MED],SUM(NEW)NEW,SUM(RENEWAL)RENEWAL,SUM(TOTAL_PREMIUMS)TOTAL_PREMIUMS FROM [dbo].[VW_SALES_PRODUTION_PER_CHANNEL] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  R_CODE='" & cboregion.SelectedValue & "' AND  YEAR(INVOICE_DATE)='" & cboyear.SelectedValue & "' GROUP BY AGENT_TYPE  ORDER BY SUM(TOTAL_PREMIUMS) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_CHANNEL_0.DataSource = MyDatable
                GD_CHANNEL_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_CHANNEL_0.DataSource = Nothing
                GD_CHANNEL_0.DataBind()
            End If

            SqlAction = "SELECT [TITLE_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_TITLE] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [TITLE_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_TITLE_0.DataSource = MyDatable
                GD_TITLE_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_TITLE_0.DataSource = Nothing
                GD_TITLE_0.DataBind()
            End If
            SqlAction = "SELECT [MARKET_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_MARKET] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [MARKET_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_MARKET_0.DataSource = MyDatable
                GD_MARKET_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_MARKET_0.DataSource = Nothing
                GD_MARKET_0.DataBind()
            End If


            SqlAction = "SELECT USER_ID,AGENT_NAME, UNIT_CODE, SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM SALES.dbo.[TBL_SALES_AGENT_SUMMARY_MTD] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY UNIT_CODE,USER_ID,AGENT_NAME ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GDSEARCH_Y.DataSource = MyDatable
                GDSEARCH_Y.DataBind()
                Session("DAD_X") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_Y.DataSource = Nothing
                GDSEARCH_Y.DataBind()
            End If


            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='INDEPENDENT'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_IND.DataSource = MyDatable
                RD_IND.DataBind()
                Session("RD_IND_1") = MyDatable
                MyDatable = Nothing
            Else
                RD_IND.DataSource = Nothing
                RD_IND.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='BROKER'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BROKER.DataSource = MyDatable
                RD_BROKER.DataBind()
                Session("RD_BROKER") = MyDatable
                MyDatable = Nothing
            Else
                RD_BROKER.DataSource = Nothing
                RD_BROKER.DataBind()
            End If

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='BANCASSURANCE' AND   MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BANC.DataSource = MyDatable
                RD_BANC.DataBind()
                Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_BANC.DataSource = Nothing
                RD_BANC.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='DIRECT_SALES'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_DI.DataSource = MyDatable
                RD_DI.DataBind()
                'Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_DI.DataSource = Nothing
                RD_DI.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND REGION_CODE='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "'  AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If


        Catch ex As Exception

        End Try

    End Sub

    Protected Sub GD_CHANNEL_0_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GD_CHANNEL_0.SelectedIndexChanged
        Dim CHANNEL_NAME As String = ""

        lblCODE.Text = ""
        Try
            CHANNEL_NAME = (DirectCast(GD_CHANNEL_0.SelectedItems(0), GridDataItem)).GetDataKeyValue("CHANNEL_NAME").ToString()
            lblCODE.Text = CHANNEL_NAME

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='INDEPENDENT' AND   MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_IND.DataSource = MyDatable
                RD_IND.DataBind()
                Session("RD_IND_1") = MyDatable
                MyDatable = Nothing
            Else
                RD_IND.DataSource = Nothing
                RD_IND.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='BROKER' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BROKER.DataSource = MyDatable
                RD_BROKER.DataBind()
                Session("RD_BROKER") = MyDatable
                MyDatable = Nothing
            Else
                RD_BROKER.DataSource = Nothing
                RD_BROKER.DataBind()
            End If

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='BANCASSURANCE'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BANC.DataSource = MyDatable
                RD_BANC.DataBind()
                Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_BANC.DataSource = Nothing
                RD_BANC.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='DIRECT_SALES'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_DI.DataSource = MyDatable
                RD_DI.DataBind()
                'Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_DI.DataSource = Nothing
                RD_DI.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='" & CHANNEL_NAME & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='" & CHANNEL_NAME & "'  AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If

        Catch ex As Exception
            lbltext.Text = ex.Message
        End Try
    End Sub


    Protected Sub GD_MARKET_0_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GD_MARKET_0.SelectedIndexChanged
        Dim MARKET As String = ""
        Dim CODE As String = ""

        Try
            MARKET = (DirectCast(GD_MARKET_0.SelectedItems(0), GridDataItem)).GetDataKeyValue("MARKET_NAME").ToString()
            lblCODE.Text = MARKET
            SqlAction = "SELECT  [CODE] ,[NAME]  FROM [SALES].[dbo].[TBL_MIS_MARKET] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND NAME='" & MARKET & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                CODE = MyDatable.Rows(0).Item("CODE").ToString()
            End If
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND PLAN_CODE='" & Trim(CODE) & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND PLAN_CODE='" & Trim(CODE) & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If


        Catch ex As Exception
            lbltext.Text = ex.Message
        End Try
    End Sub




    Protected Sub GDSEARCH_R_1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH_R_1.SelectedIndexChanged
        Dim R_date As String
        GD_CHANNEL_0.DataSource = Nothing
        GD_CHANNEL_0.DataBind()
        RD_REN.DataSource = Nothing
        RD_REN.DataBind()
        RD_NEW.DataSource = Nothing
        RD_NEW.DataBind()
        GD_TITLE_0.DataSource = Nothing
        GD_TITLE_0.DataBind()
        GD_MARKET_0.DataSource = Nothing
        GD_MARKET_0.DataBind()

        RD_DI.DataSource = Nothing
        RD_DI.DataBind()
        Try
            R_date = (DirectCast(GDSEARCH_R_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("MONTH_FROM").ToString()

            SqlAction = "SELECT [CHANNEL_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_CHANNEL] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND R_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "' GROUP BY [CHANNEL_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_TYPE,SUM(MEDICAL)MEDICAL,SUM([NON-MED])[NON-MED],SUM(NEW)NEW,SUM(RENEWAL)RENEWAL,SUM(TOTAL_PREMIUMS)TOTAL_PREMIUMS FROM [dbo].[VW_SALES_PRODUTION_PER_CHANNEL] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  YEAR(INVOICE_DATE)='" & cboyear.SelectedValue & "' GROUP BY AGENT_TYPE  ORDER BY SUM(TOTAL_PREMIUMS) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_CHANNEL_0.DataSource = MyDatable
                GD_CHANNEL_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_CHANNEL_0.DataSource = Nothing
                GD_CHANNEL_0.DataBind()
            End If

            SqlAction = "SELECT [TITLE_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_TITLE] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND R_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "' GROUP BY [TITLE_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_TITLE_0.DataSource = MyDatable
                GD_TITLE_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_TITLE_0.DataSource = Nothing
                GD_TITLE_0.DataBind()
            End If
            SqlAction = "SELECT [MARKET_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_MARKET] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND R_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "' GROUP BY [MARKET_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_MARKET_0.DataSource = MyDatable
                GD_MARKET_0.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_MARKET_0.DataSource = Nothing
                GD_MARKET_0.DataBind()
            End If


            SqlAction = "SELECT USER_ID,AGENT_NAME, UNIT_CODE, SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM SALES.dbo.[TBL_SALES_AGENT_SUMMARY_MTD] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND R_CODE='" & lblCODE.Text & "' AND  MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "'  GROUP BY UNIT_CODE,USER_ID,AGENT_NAME ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GDSEARCH_Y.DataSource = MyDatable
                GDSEARCH_Y.DataBind()
                Session("DAD_X") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_Y.DataSource = Nothing
                GDSEARCH_Y.DataBind()
            End If


            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='INDEPENDENT' AND REGION_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_IND.DataSource = MyDatable
                RD_IND.DataBind()
                Session("RD_IND_1") = MyDatable
                MyDatable = Nothing
            Else
                RD_IND.DataSource = Nothing
                RD_IND.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='BROKER' AND REGION_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BROKER.DataSource = MyDatable
                RD_BROKER.DataBind()
                Session("RD_BROKER") = MyDatable
                MyDatable = Nothing
            Else
                RD_BROKER.DataSource = Nothing
                RD_BROKER.DataBind()
            End If


            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='BANCASSURANCE' AND REGION_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BANC.DataSource = MyDatable
                RD_BANC.DataBind()
                Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_BANC.DataSource = Nothing
                RD_BANC.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_TYPE='DIRECT_SALES' AND REGION_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & CDate(R_date).ToString("yyyy-MM-dd") & "'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_DI.DataSource = MyDatable
                RD_DI.DataBind()
                'Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_DI.DataSource = Nothing
                RD_DI.DataBind()
            End If

            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND PLAN_CODE='" & Trim(CODE) & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND REGION_CODE='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(R_date).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND PLAN_CODE='" & Trim(CODE) & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND REGION_CODE='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(R_date).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If

        Catch ex As Exception
            lbltext.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDSEARCH_Y_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH_Y.PageIndexChanged
        GDSEARCH_Y.CurrentPageIndex = e.NewPageIndex
        GDSEARCH_Y.DataSource = Session("SEARCH_Y")
        GDSEARCH_Y.DataBind()
    End Sub
    Protected Sub RD_IND_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_IND.PageIndexChanged
        RD_IND.CurrentPageIndex = e.NewPageIndex
        RD_IND.DataSource = Session("RD_IND_1")
        RD_IND.DataBind()
    End Sub
    Protected Sub RD_BROKER_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_BROKER.PageIndexChanged
        RD_BROKER.CurrentPageIndex = e.NewPageIndex
        RD_BROKER.DataSource = Session("RD_BROKER")
        RD_BROKER.DataBind()
    End Sub

    Protected Sub RD_BANC_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_BANC.PageIndexChanged
        RD_BANC.CurrentPageIndex = e.NewPageIndex
        RD_BANC.DataSource = Session("RD_BANC")
        RD_BANC.DataBind()
    End Sub
    Protected Sub RD_NEW_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_NEW.PageIndexChanged
        RD_NEW.CurrentPageIndex = e.NewPageIndex
        RD_NEW.DataSource = Session("INV_REN")
        RD_NEW.DataBind()
    End Sub
    Protected Sub RD_RENEW_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_REN.PageIndexChanged
        RD_NEW.CurrentPageIndex = e.NewPageIndex
        RD_NEW.DataSource = Session("INV")
        RD_NEW.DataBind()
    End Sub

    Protected Sub GDSEARCH_R_1_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH_R_1.NeedDataSource

    End Sub







    Protected Sub GDSEARCH_Y_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH_Y.SelectedIndexChanged
        Try
            Dim AGENT As String
            lblCODE.Text = ""
            AGENT = (DirectCast(GDSEARCH_Y.SelectedItems(0), GridDataItem)).GetDataKeyValue("USER_ID").ToString()
            lblCODE.Text = AGENT

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  CUTOFF_FROM_DT>='" & CDate(R_date).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  REGION_CODE='" & cboregion.SelectedValue & "' AND AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  CUTOFF_FROM_DT>='" & CDate(R_date).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If



        Catch ex As Exception
            lbltext.Text = ex.Message
        End Try
    End Sub





    Protected Sub GDSEARCH_U_1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH_U_1.SelectedIndexChanged
        Try
            GD_CHANNEL_0.DataSource = Nothing
            GD_CHANNEL_0.DataBind()
            GD_MARKET_0.DataSource = Nothing
            GD_MARKET_0.DataBind()
            GD_TITLE_0.DataSource = Nothing
            GD_TITLE_0.DataBind()
            GDSEARCH_Y.DataSource = Nothing
            GDSEARCH_Y.DataBind()
            RD_REN.DataSource = Nothing
            RD_REN.DataBind()
            RD_NEW.DataSource = Nothing
            RD_NEW.DataBind()

            RD_IND.DataSource = Nothing
            RD_IND.DataBind()
            RD_BROKER.DataSource = Nothing
            RD_BROKER.DataBind()
            RD_BANC.DataSource = Nothing
            RD_BANC.DataBind()

            Dim PERIOD As String
            PERIOD = (DirectCast(GDSEARCH_U_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("MONTH_FROM").ToString()

            SqlAction = "SELECT USER_ID,AGENT_NAME, UNIT_CODE, SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM [TBL_SALES_AGENT_SUMMARY_MTD] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & PERIOD & "' GROUP BY UNIT_CODE,USER_ID,AGENT_NAME ORDER BY PERC_PRODUCTION DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GDSEARCH_Y.DataSource = MyDatable
                GDSEARCH_Y.DataBind()
                Session("SEARCH_Y") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_Y.DataSource = Nothing
                GDSEARCH_Y.DataBind()
            End If

            'SELECT  [AGENT_ID],[USER_DISPLAY_NAME],[UNIT_CODE],[REGION_CODE],[AGENT_TYPE],[MONTH_FROM],[MONTH_TO],[NEW_MEDICAL],[NEW_NON_MEDICAL],[RENEWAL_MEDICAL],[RENEWAL_NONMEDICAL],[TOTAL_RENEW],[TOTAL_NEW],[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY]

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & PERIOD & "'  AND AGENT_TYPE='INDEPENDENT'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_IND.DataSource = MyDatable
                RD_IND.DataBind()
                Session("RD_IND_1") = MyDatable
                MyDatable = Nothing
            Else
                RD_IND.DataSource = Nothing
                RD_IND.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & PERIOD & "'  AND AGENT_TYPE='BROKER'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BROKER.DataSource = MyDatable
                RD_BROKER.DataBind()
                Session("RD_BROKER") = MyDatable
                MyDatable = Nothing
            Else
                RD_BROKER.DataSource = Nothing
                RD_BROKER.DataBind()
            End If

            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & PERIOD & "'  AND AGENT_TYPE='BANCASSURANCE'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_BANC.DataSource = MyDatable
                RD_BANC.DataBind()
                Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_BANC.DataSource = Nothing
                RD_BANC.DataBind()
            End If
            SqlAction = "SELECT [AGENT_ID],[USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND MONTH_FROM ='" & PERIOD & "'  AND AGENT_TYPE='DIRECT_SALES'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_DI.DataSource = MyDatable
                RD_DI.DataBind()
                'Session("RD_BANC") = MyDatable
                MyDatable = Nothing
            Else
                RD_DI.DataSource = Nothing
                RD_DI.DataBind()
            End If

            '   SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND CUTOFF_FROM_DT ='" & PERIOD & "'  ORDER BY PREMIUM DESC"

            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND UNIT_CODE='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub RD_DI_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RD_DI.NeedDataSource

    End Sub

    Protected Sub RD_DI_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RD_DI.SelectedIndexChanged
        Dim AGENT As String
        lblCODE.Text = ""
        AGENT = (DirectCast(RD_DI.SelectedItems(0), GridDataItem)).GetDataKeyValue("AGENT_ID").ToString()
        lblCODE.Text = AGENT

        Try
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "'  AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' ORDER BY PREMIUM DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub RD_BANC_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RD_BANC.SelectedIndexChanged
        Dim AGENT As String
        lblCODE.Text = ""
        AGENT = (DirectCast(RD_BANC.SelectedItems(0), GridDataItem)).GetDataKeyValue("AGENT_ID").ToString()
        lblCODE.Text = AGENT

        Try
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "'  AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' ORDER BY PREMIUM DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub RD_BROKER_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RD_BROKER.SelectedIndexChanged
        Dim AGENT As String
        lblCODE.Text = ""
        AGENT = (DirectCast(RD_BROKER.SelectedItems(0), GridDataItem)).GetDataKeyValue("AGENT_ID").ToString()
        lblCODE.Text = AGENT

        Try
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "'  AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' ORDER BY PREMIUM DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub RD_IND_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RD_IND.SelectedIndexChanged
        Dim AGENT As String
        lblCODE.Text = ""
        AGENT = (DirectCast(RD_IND.SelectedItems(0), GridDataItem)).GetDataKeyValue("AGENT_ID").ToString()
        lblCODE.Text = AGENT

        Try
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "'  AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' ORDER BY PREMIUM DESC"
            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='NEW' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NEW.DataSource = MyDatable
                RD_NEW.DataBind()
                Session("INV") = MyDatable
                MyDatable = Nothing
            Else
                RD_NEW.DataSource = Nothing
                RD_NEW.DataBind()
            End If

            SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            'SqlAction = "SELECT AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,SUM(PREMIUM)PREMIUM,BUSINESS,BUSINESS_TYPE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE AGENT_ID='" & lblCODE.Text & "' AND CUTOFF_FROM_DT>='" & CDate(PERIOD).ToString("yyyy-MM-dd") & "' AND BUSINESS_TYPE='RENEWAL' GROUP BY AGENT_ID, USER_DISPLAY_NAME, PROPOSER_DISPLAY_NAME,BUSINESS,BUSINESS_TYPE  ORDER BY SUM(PREMIUM) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_REN.DataSource = MyDatable
                RD_REN.DataBind()
                Session("INV_REN") = MyDatable
                MyDatable = Nothing
            Else
                RD_REN.DataSource = Nothing
                RD_REN.DataBind()
            End If
        Catch ex As Exception

        End Try

    End Sub
    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = ""
        Try
            Session("EXCEL") = "TO EXCEL"


            If cbosear.SelectedValue = "BDM" Then
                SqlAction = "SELECT UM_NAME,[UNIT_NAME],  SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([ACTUAL_NEW_MED])[ACTUAL_NEW_MED],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([ACTUAL_NEW_NONMED])[ACTUAL_NEW_NONMED], SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM [dbo].[vw_SALES_UNIT_SUMMARY] WHERE R_CODE='" & cboregion.SelectedValue & "' and  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [UNIT_NAME],UM_NAME,UM_ID,YEAR([MONTH_FROM]),[UNIT_NAME]"
                Reportname = "BDM-YTD As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "RM" Then
                SqlAction = "SELECT [RM_NAME],REGION_NAME,  SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([ACTUAL_NEW_MED])[ACTUAL_NEW_MED],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([ACTUAL_NEW_NONMED])[ACTUAL_NEW_NONMED], SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM [dbo].[vw_SALES_REGION_SUMMARY] WHERE R_CODE='" & cboregion.SelectedValue & "' and  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [RM_ID],[RM_NAME],REGION_NAME,YEAR([MONTH_FROM])"
                Reportname = "RM-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""

            ElseIf cbosear.SelectedValue = "C" Then
                SqlAction = "SELECT [CHANNEL_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_CHANNEL] WHERE R_CODE='" & cboregion.SelectedValue & "' and  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [CHANNEL_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
                Reportname = "CHANNEL-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""


            ElseIf cbosear.SelectedValue = "M" Then
                SqlAction = "SELECT [MARKET_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_MARKET] WHERE MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [MARKET_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
                Reportname = "MARKET-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""

            ElseIf cbosear.SelectedValue = "T" Then
                SqlAction = "SELECT [TITLE_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_TITLE] WHERE  R_CODE='" & cboregion.SelectedValue & "' and MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [TITLE_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
                Reportname = "TITLE-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "I" Then
                SqlAction = "SELECT AGENT_NAME, UNIT_CODE, SUM([NEW_BUDGET])[NEW_BUDGET], SUM([ACTUAL_NEW])[ACTUAL_NEW],SUM([RENEWAL_BUDGET])[RENEWAL_BUDGET],SUM([ACTUAL_RENEW])[ACTUAL_RENEW],SUM([MONTH_BUDGET])[MONTH_BUDGET],SUM([ACTUAL_PROD])[ACTUAL_PROD],SUM([DEFICIT])[DEFICIT],(SUM([ACTUAL_RENEW])/NULLIF(SUM([RENEWAL_BUDGET]),0))*100 RENEWAL_PERC,(SUM([ACTUAL_NEW])/NULLIF(SUM([NEW_BUDGET]),0))*100  NEW_PERC,(SUM([ACTUAL_PROD])/NULLIF(SUM([MONTH_BUDGET]),0))*100 [PERC_PRODUCTION]  FROM [TBL_SALES_AGENT_SUMMARY_MTD] WHERE  R_CODE='" & cboregion.SelectedValue & "' AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY UNIT_CODE,AGENT_NAME ORDER BY PERC_PRODUCTION DESC"
                Reportname = "IN_HSE-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "IND" Then
                SqlAction = "SELECT (SELECT TOP 1 UM_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_UM WHERE UNIT_CODE=S.UNIT_CODE)UM_NAME, [USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] S WHERE  AGENT_TYPE='INDEPENDENT'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME],UNIT_CODE ORDER BY SUM(TOTAL_PREMIUM) DESC"

                'SqlAction = "SELECT [USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE  AGENT_TYPE='INDEPENDENT' AND REGION_CODE='" & cboregion.SelectedValue & "' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
                Reportname = "IND-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "BRK" Then
                SqlAction = "SELECT  (SELECT TOP 1 UM_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_UM WHERE UNIT_CODE=S.UNIT_CODE)UM_NAME, [USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] S WHERE  AGENT_TYPE='BROKER'  AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY [AGENT_ID],[USER_DISPLAY_NAME],UNIT_CODE ORDER BY SUM(TOTAL_PREMIUM) DESC"

                'SqlAction = "SELECT [USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE AGENT_TYPE='BROKER' AND REGION_CODE='" & cboregion.SelectedValue & "' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
                Reportname = "BKR-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "BANC" Then
                SqlAction = "SELECT [USER_DISPLAY_NAME],SUM([NEW_MEDICAL])[NEW_MEDICAL],SUM([NEW_NON_MEDICAL])[NEW_NON_MEDICAL],SUM([RENEWAL_MEDICAL])[RENEWAL_MEDICAL],SUM([RENEWAL_NONMEDICAL])[RENEWAL_NONMEDICAL],SUM([TOTAL_RENEW])[TOTAL_RENEW],SUM([TOTAL_NEW])[TOTAL_NEW],SUM([TOTAL_PREMIUM])[TOTAL_PREMIUM]  FROM [SALES].[dbo].[TBL_SALES_SUMMARY_AGENCY] WHERE AGENT_TYPE='BANCASSURANCE' AND REGION_CODE='" & cboregion.SelectedValue & "' AND MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY [USER_DISPLAY_NAME] ORDER BY SUM(TOTAL_PREMIUM) DESC"
                Reportname = "BANC-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "D" Then
                SqlAction = "SELECT  PROPOSER_DISPLAY_NAME,INVOICE_NO,convert(varchar, INVOICE_DATE_2, 23) INVOICE_DATE ,SUM(PREMIUM)PREMIUM,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,convert(varchar, PERIOD_FROM, 23) PERIOD_FROM,convert(varchar, PERIOD_TO, 23)PERIOD_TO,UNIT_MGR,BRANCH,BRANCH_MGR,REGIONAL_MANAGER,AGENT_TYPE,PLAN_CODE,INVOICE_GEN_FROM FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE REGION_CODE='" & cboregion.SelectedValue & "' AND INVOICE_DATE_2>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND INVOICE_DATE_2<='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,INVOICE_DATE_2,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,PERIOD_FROM,PERIOD_TO,UNIT_MGR,BRANCH,BRANCH_MGR,REGIONAL_MANAGER,AGENT_TYPE,PLAN_CODE,INVOICE_GEN_FROM ORDER BY UNIT_MGR"
                Reportname = "DEBITS As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "P" Then
                SqlAction = "SELECT  PROPOSER_DISPLAY_NAME,INVOICE_NO,convert(varchar, INVOICE_DATE, 23) INVOICE_DATE ,SUM(PREMIUM)PREMIUM,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,convert(varchar, PERIOD_FROM, 23) PERIOD_FROM,convert(varchar, PERIOD_TO, 23)PERIOD_TO,UNIT_MGR,BRANCH,BRANCH_MGR,REGIONAL_MANAGER,AGENT_TYPE,PLAN_CODE,INVOICE_GEN_FROM  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE REGION_CODE='" & cboregion.SelectedValue & "' AND INVOICE_DATE>='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND INVOICE_DATE<='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,PERIOD_FROM,PERIOD_TO,UNIT_MGR,BRANCH,BRANCH_MGR,REGIONAL_MANAGER,AGENT_TYPE,PLAN_CODE,INVOICE_GEN_FROM ORDER BY UNIT_MGR"
                Reportname = "OPS_PROD-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "R" Then
                SqlAction = "SELECT PROPOSER_DISPLAY_NAME,BUSINESS_TYPE,INVOICE_NO,INVOICE_DATE,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,PREMIUM,REC_AMOUNT,USER_DISPLAY_NAME,BUSINESS FROM TBL_MIS_SALES_COMMISSIONS WHERE PREM_RECEIPT_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND REGION_CODE ='" & cboregion.SelectedValue & "'"
                Reportname = "Receipts-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "PL" Then
                SqlAction = "SELECT [PROPOSER_DISPLAY_NAME],[PERIOD_FROM],[PERIOD_TO],[AGENCY_CODE],[GRP_INDV],[PREMIUMS],[LIVES],[CLAIMS],[POLICY_STATUS],[USER_DISPLAY_NAME],CLAIM_RATIO,[AGENT_TYPE],UM_MANAGER  FROM [SALES].[dbo].[TBL_MIS_PROPOSER_PREMIUMS] WHERE POLICY_STATUS='ACTIVE' AND REGION_CODE ='" & cboregion.SelectedValue & "'"
                Reportname = "Portfolio-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            ElseIf cbosear.SelectedValue = "TB" Then
                SqlAction = "SELECT [File_No],[Business_Type],[Proposer_Name],[Client_Type],[AGENT_NAME],[REGION_CODE],[Premium],[Benefit],[Receive_dt],[Allocated_to],[Allocate_Dt],[File_Status],[Entered_By],convert(date,[Entry_Date])Entry_Date,[Business]  FROM [SALES].[dbo].[vw_MIS_Tracked_Business] where Business_Type_2 in ('A','N','R','RT') AND PREMIUM<>0  AND REGION_CODE ='" & cboregion.SelectedValue & "' AND ENTRY_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                Reportname = "Tracked-As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""

            End If

            Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception
            lbltext.Text = ex.Message
        End Try
    End Sub
End Class
