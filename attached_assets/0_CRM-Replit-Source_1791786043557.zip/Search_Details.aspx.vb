﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail

'Imports Microsoft.Office.Interop
'Imports System.Windows.Forms

Imports Microsoft.VisualBasic
Imports System
'Imports Microsoft.Office.Interop.Excel
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports Microsoft.Office.Interop
Imports System.Windows.Forms
Partial Class Default2
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

       
        Dim SqlAction As String = ""
        Dim searchStr As String = ""
        Dim MyDBAction As New DataManagement

            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Population],Status  FROM MISREPORTS.dbo.TBL_MIS_CORPORATE_TRACKING WHERE Proposer_Name Like '%" & Trim(txtsearch.Text) & "%'"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Population],Status  FROM MISREPORTS.dbo.TBL_MIS_CORPORATE_TRACKING WHERE Member_No Like '%" & Trim(txtsearch.Text) & "%'"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Population],Status  FROM MISREPORTS.dbo.TBL_MIS_CORPORATE_TRACKING WHERE File_No Like '%" & Trim(txtsearch.Text) & "%'"
            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DADT") = MyDatable
                MyDatable = Nothing


            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex

        '= MyDatable
        GDSEARCH.DataSource = Session("DADT")
        GDSEARCH.DataBind()
    End Sub


    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim SqlAction As String = ""

        Dim MyDBAction As New DataManagement
        Dim MyDatable As New Data.DataTable

        txtfile.Text = ""
        txtfile.Text = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()


        SqlAction = "SELECT Membership_comments, [File_No],[Business_Type],[Proposer_Name],[Type],[Receive_Date],[Mem_Receive_date],[Receive_From],[Agent],[Benefit],[Population],[Premium],[Status],[Returned],[Comment],[Returned_To]," & _
            "[Date_returned],[Return_rec_date],[Assigned_To],[Date_assigned],[Card_activated],[Policy_Code],[Members_updated],[Card_requested],Card_Rec,Card_Dis,[Card_Req_Date],Policy_Doc_Gen, No_of_Cards_Req,[Card_Rec_Date],[No_of_Cards_Rec],[Card_Dis_Date],[Card_Dis_To],[Policy_Doc_Gen],[Policy_Date_Gen],[Policy_Date_Disp],[Policy_Disp_To], Closed,To_Filing,Filed ,Policy_Dispatched,[Reg_comments],[Entered_by],[EntryDate]" & _
                    "FROM MISREPORTS.dbo.TBL_MIS_CORPORATE_TRACKING where File_No ='" & txtfile.Text & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                'Session("Application") = MyDatable
                'myDataTable.Rows(0).Field(Of String)(0)
                txtfile.Text = MyDatable.Rows(0).Item("File_No").ToString()

                chkrequest.Checked = MyDatable.Rows(0).Item("Card_requested").ToString()
                chkreceived.Checked = MyDatable.Rows(0).Item("Card_Rec").ToString()
                chkdispatched.Checked = MyDatable.Rows(0).Item("Card_Dis").ToString()
                chkpolicydoc.Checked = MyDatable.Rows(0).Item("Policy_Doc_Gen").ToString()

                dtcardrecdate.DbSelectedDate = MyDatable.Rows(0).Item("Card_Rec_Date").ToString()
                dtcardreqdate.DbSelectedDate = MyDatable.Rows(0).Item("Card_Req_Date").ToString()
                dtcarddispdate.DbSelectedDate = MyDatable.Rows(0).Item("Card_Dis_Date").ToString()
                txtcarddisto.Text = MyDatable.Rows(0).Item("Card_Dis_To").ToString()
                'txtpolicygen.Text = MyDatable.Rows(0).Item("Policy_Doc_Gen").ToString()
                dtpoligendate.DbSelectedDate = MyDatable.Rows(0).Item("Policy_Date_Gen").ToString()
                txtpolicydisto.Text = MyDatable.Rows(0).Item("Policy_Disp_To").ToString()
                txtOther_Comments.Text = MyDatable.Rows(0).Item("Reg_comments").ToString()
                txtaction.Text = MyDatable.Rows(0).Item("Business_Type").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                txttype.Text = MyDatable.Rows(0).Item("Type").ToString()
                cboagent.SelectedValue = MyDatable.Rows(0).Item("Agent").ToString()
                txtReceiveFrom.Text = MyDatable.Rows(0).Item("Receive_From").ToString()
                dtmem_rec.DbSelectedDate = MyDatable.Rows(0).Item("Mem_Receive_date").ToString()
                'txtagent.Text = MyDatable.Rows(0).Item("Agent").ToString()
                txtbenefit.Text = MyDatable.Rows(0).Item("Benefit").ToString()
                txtpopulation.Text = MyDatable.Rows(0).Item("Population").ToString()
                txtpremium.Text = MyDatable.Rows(0).Item("Premium").ToString()
                txtreturned.Text = MyDatable.Rows(0).Item("Returned").ToString()
                txtcomment.Text = MyDatable.Rows(0).Item("Membership_comments").ToString()
                txtreturnedto.Text = MyDatable.Rows(0).Item("Returned_To").ToString()
                dtreturndate.DbSelectedDate = MyDatable.Rows(0).Item("Date_returned").ToString()
                dtreturnRec.DbSelectedDate = MyDatable.Rows(0).Item("Return_rec_date").ToString()
                txtallocatedto.Text = MyDatable.Rows(0).Item("Assigned_To").ToString()
                dtallocated.DbSelectedDate = MyDatable.Rows(0).Item("Date_assigned").ToString()
                txtcardactivate.Text = MyDatable.Rows(0).Item("Card_activated").ToString()
                lblstatus.Text = MyDatable.Rows(0).Item("Status").ToString()
                Session("DEL") = MyDatable.Rows(0).Item("Business_Type").ToString()
                chkfiling.Checked = MyDatable.Rows(0).Item("To_Filing").ToString()
                chkupdated.Checked = MyDatable.Rows(0).Item("Closed").ToString()
                chkfiled.Checked = MyDatable.Rows(0).Item("Filed").ToString()
                chkpolicydisp.Checked = MyDatable.Rows(0).Item("Policy_Dispatched").ToString()

                ' Closed,To_Filing,Filed
            End If

        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then



            txtfile.Enabled = False
            'txtpolicydisto.Text = MyDatable.Rows(0).Item("Policy_Code").ToString()
            chkrequest.Enabled = False
            chkreceived.Enabled = False
            chkdispatched.Enabled = False
            chkpolicydoc.Enabled = False
            dtcardrecdate.Enabled = False
            dtcardreqdate.Enabled = False
            dtcarddispdate.Enabled = False
            txtcarddisto.Enabled = False
            'txtpolicygen.Enabled = False
            dtpoligendate.Enabled = False
            txtpolicydisto.Enabled = False
            txtOther_Comments.Enabled = False
            txtaction.Enabled = False
            txtproposer.Enabled = False
            txttype.Enabled = False
            cboagent.Enabled = False
            txtReceiveFrom.Enabled = False
            dtmem_rec.Enabled = False

            txtbenefit.Enabled = False
            txtpopulation.Enabled = False
            txtpremium.Enabled = False
            txtreturned.Enabled = False
            txtcomment.Enabled = False
            txtreturnedto.Enabled = False
            dtreturndate.Enabled = False
            dtreturnRec.Enabled = False
            txtallocatedto.Enabled = False
            dtallocated.Enabled = False
            txtcardactivate.Enabled = False
            lblstatus.Enabled = False

            dtpolidispdate.Enabled = False
            chkfiled.Enabled = False
            chkupdated.Enabled = False
            chkfiling.Enabled = False
            chkpolicydisp.Enabled = False

            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK)  WHERE  ACTIVE=1 ORDER BY AGENT_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboagent

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()

            End With
            MyDatatable = Nothing
        End If
    End Sub

    Protected Sub GDSEARCH_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub
End Class
