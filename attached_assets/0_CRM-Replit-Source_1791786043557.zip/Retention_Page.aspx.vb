﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class Default2
    Inherits System.Web.UI.Page
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim SqlAction As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        MyDatatable = Nothing

        Str = ""
        If Not IsPostBack Then

            dtackrec.DbSelectedDate = Date.Now()


            Str = ""
            Str = ""

            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM dbo.TBL_MIS_SALES_AGENTS  WHERE  ACTIVE=1 ORDER BY AGENT_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboagent

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()

            End With
            Str = "SELECT Emp_Code,EmployeeName FROM Employees WHERE Department='RETENTION' AND approved=1 ORDER BY EmployeeName" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboretention

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                .DataValueField = MyDatatable.Columns("Emp_Code").ToString
                .DataBind()

            End With
            Session("ID") = Nothing
            Str = "SELECT Emp_Code FROM Employees where username='" & Session("username") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                Session("ID") = "0097" ' MyDatable.Rows(0).Item("EmployeeID").ToString()
            End If

            LoadGrid(Session("ID"))

            MyDatatable = Nothing
        End If


    End Sub



    Protected Sub BTNUPDATE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BTNUPDATE.Click
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyDatable_1 As New Data.DataTable
        Dim Ret_ACK As Integer = 0
        Dim sts As Integer = 0
        Try

            If chkack.Checked = False Then

                lbler.Text = "Policy ack not Marked!"
                Exit Sub
            End If



            If chkack.Checked = True Then
                Ret_ACK = 1
            End If

        

            MyDBAction.UPDATE_RETENTION_DOC(file.Text, Ret_ACK, CDate(dtackrec.DbSelectedDate).ToString("yyyy-MM-dd"), cboretention.SelectedValue)

            sts = 0
            lbler.Text = "Saved Successfully!"
            LoadGrid(ID)

            file.Text = ""
            txtproposer.Text = ""
            cbotype.SelectedValue = ""
            cboagent.Text = ""
            txtaction.Text = ""
            chkack.Checked = False
       
            txtOther_Comments.Text = ""
            lblstatus.Text = ""
        Catch ex As Exception
            lbler.Text = ex.Message
        End Try


    End Sub


    Protected Sub chkpolicydoc_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkack.CheckedChanged
        If chkack.Checked = True Then
            'dtcardrecdate.DbSelectedDate = Date.Now
            dtackrec.DbSelectedDate = Date.Now
            dtackrec.Enabled = False
        End If
    End Sub

    

    Public Sub LoadGrid(ByVal id As String)
        Str = ""
        Try
            Session("DAD_4") = Nothing

            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            SqlAction = "SELECT [File_No],[Proposer_Name],[Assigned_To],Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WHERE  Ret_Ack=0 and Tracked_To_Ret_officer='" & id & "'  ORDER BY Ret_Officer_Ack_DT Desc"


            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_4") = MyDatable
                MyDatable = Nothing


            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_4")
        GDSEARCH.DataBind()
    End Sub


    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged

        Try
            Dim SqlAction As String = ""

            Dim MyDBAction As New DataManagement
            Dim MyDatable As New Data.DataTable

            file.Text = ""
            file.Text = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()



            Dim STATUS As String = ""
            lblstatus.Text = ""

            SqlAction = "SELECT Ret_Officer_allocate_DT,Ret_Ack, [File_No],status,Policy_Dispatched,[Business_Type],agent,[Proposer_Name],[Type], [Policy_Doc_Gen],[Policy_Date_Gen],[Policy_Date_Disp],[Policy_Disp_To],[Membership_Comments]" & _
                    "FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) where File_No ='" & file.Text & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    file.Text = MyDatable.Rows(0).Item("File_No").ToString()
                    txtproposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                    cbotype.SelectedValue = MyDatable.Rows(0).Item("Type").ToString()
                    cboagent.SelectedValue = MyDatable.Rows(0).Item("Agent").ToString()
                    txtaction.Text = MyDatable.Rows(0).Item("Business_Type").ToString()
                    chkack.Checked = MyDatable.Rows(0).Item("Policy_Dispatched").ToString()
                    dtpolidispdate.DbSelectedDate = MyDatable.Rows(0).Item("Policy_Date_Disp").ToString()
                    chkack.Checked = MyDatable.Rows(0).Item("Ret_Ack").ToString()
                    dtackrec.DbSelectedDate = MyDatable.Rows(0).Item("Ret_Officer_allocate_DT").ToString()
                    'dtackrec.DbSelectedDate = MyDatable.Rows(0).Item("Policy_Date_Gen").ToString()
                    txtOther_Comments.Text = MyDatable.Rows(0).Item("Membership_Comments").ToString()
                    lblstatus.Text = MyDatable.Rows(0).Item("status").ToString()
                End If
            End If


            txtproposer.Enabled = False
            cbotype.Enabled = False
            cboagent.Enabled = False
            txtaction.Enabled = False

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_4") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Assigned_To],Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE Proposer_Name Like '%" & Trim(txtsearch.Text) & "%' and Closed=1 AND Policy_Doc_Gen=1"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Assigned_To],Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE Member_No Like '%" & Trim(txtsearch.Text) & "%' and Closed=1 AND Policy_Doc_Gen=1"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Assigned_To],Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE File_No Like '%" & Trim(txtsearch.Text) & "%' and Closed=1 AND Policy_Doc_Gen=1"
            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_4") = MyDatable
                MyDatable = Nothing


            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub
End Class
