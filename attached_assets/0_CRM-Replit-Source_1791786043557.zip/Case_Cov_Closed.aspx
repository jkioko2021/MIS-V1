﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Case_Cov_Closed.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#CC0000" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8" style="height: 523px">
                                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" Width="1151px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#CCCCCC">
                                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                                            Text="Closed cases"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="center">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                                </td>
                                                                <td style="width: 238px">
                                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                                        Skin="Sunset" Width="190px">
                                                                        <Items>
                                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Case No" Value="C" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Provider" Value="P" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Member Name" Value="N" />
                                                                        </Items>
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td style="width: 260px">
                                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" Width="250px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td style="width: 238px">
                                                                    <asp:Label ID="lblno" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td style="width: 260px">
                                                                    <asp:Label ID="lbldp" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1140px">
                                                            <telerik:RadGrid ID="GDCASE" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Outlook" Width="100%" PageSize="20">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_No">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                            <ItemStyle Width="50px" />
                                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="Case_No" 
                                                                            FilterControlAltText="Filter Case_No column" HeaderText="Case_No" 
                                                                            SortExpression="Case_No" UniqueName="Case_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Name" 
                                                                            SortExpression="Member_Name" UniqueName="Member_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Admission_Dt" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter Admission_Dt column" HeaderText="Admission_Date" 
                                                                            SortExpression="Admission_Dt" UniqueName="Admission_Dt">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Prov_name" 
                                                                            FilterControlAltText="Filter Prov_name column" HeaderText="Provider" 
                                                                            SortExpression="Prov_name" UniqueName="Prov_name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Case_Status" 
                                                                            FilterControlAltText="Filter Case_Status column" HeaderText="Case_Status" 
                                                                            SortExpression="Case_Status" UniqueName="Case_Status">
                                                                        </telerik:GridBoundColumn>
                                                                               <telerik:GridBoundColumn DataField="Admission_Status" 
                                                                            FilterControlAltText="Filter Admission_Status column" HeaderText="Adm_Status" 
                                                                            SortExpression="Admission_Status" UniqueName="Admission_Status">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Pre_Auth_Amt" DataFormatString="{0:### ##0.0}"
                                                                            FilterControlAltText="Filter Pre_Auth_Amt column" HeaderText="Auth_Amt" 
                                                                            SortExpression="Pre_Auth_Amt" UniqueName="Pre_Auth_Amt">
                                                                        </telerik:GridBoundColumn>
                                                                          <telerik:GridBoundColumn DataField="Total_Actual_Cost"  DataFormatString="{0:### ##0.0}"
                                                                            FilterControlAltText="Filter Total_Actual_Cost column" HeaderText="Actual_Cost" 
                                                                            SortExpression="Total_Actual_Cost" UniqueName="Total_Actual_Cost">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Entered_by" 
                                                                            FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                            SortExpression="Entered_by" UniqueName="Entered_by">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="lblprov" runat="server" Font-Size="Large" ForeColor="Red" 
                                                            Visible="False"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel10" runat="server">
                                                            <table style="width: 100%">
                                                                <tr>
                                                                    <td style="width: 139px">
                                                                        <asp:Label ID="Label20" runat="server" Text="Case Status"></asp:Label>
                                                                    </td>
                                                                    <td>
                                                                        <telerik:RadComboBox ID="cboreopen" Runat="server" Skin="Outlook">
                                                                            <Items>
                                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreopen" />
                                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreopen" Text="Re-Open" 
                                                                                    Value="Open" />
                                                                            </Items>
                                                                        </telerik:RadComboBox>
                                                                    </td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 139px">
                                                                        <asp:Label ID="Label21" runat="server" Text="Status  Date"></asp:Label>
                                                                    </td>
                                                                    <td>
                                                                        <telerik:RadDatePicker ID="dtreopen" Runat="server" Skin="Outlook">
                                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                            </Calendar>
                                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                            </DateInput>
                                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                        </telerik:RadDatePicker>
                                                                    </td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="height: 13px; width: 139px">
                                                                        <asp:Label ID="Label22" runat="server" Text="Notes"></asp:Label>
                                                                    </td>
                                                                    <td colspan="2" rowspan="2">
                                                                        <telerik:RadTextBox ID="txtclosenote" Runat="server" Font-Size="Large" 
                                                                            Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                            TextMode="MultiLine" Width="500px">
                                                                        </telerik:RadTextBox>
                                                                    </td>
                                                                    <td style="height: 13px">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 139px">
                                                                        &nbsp;</td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="height: 42px; width: 139px">
                                                                        <asp:Label ID="lblreopcase" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 42px">
                                                                        <telerik:RadButton ID="RadButton1" runat="server" Height="38px" Skin="Sunset" 
                                                                            Text="Save" Width="113px">
                                                                        </telerik:RadButton>
                                                                        &nbsp;<asp:Label ID="lblerrreop" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 42px">
                                                                    </td>
                                                                    <td style="height: 42px">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="4">
                                                                        &nbsp;</td>
                                                                </tr>
                                                            </table>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="left" colspan="4">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left">
                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" 
                                            Text="Member Notes"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%" PageSize="20">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                       
                                                        <telerik:GridBoundColumn DataField="Note_date"  DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            SortExpression="Note_date" 
                                                            UniqueName="Note_date" ItemStyle-Width="100">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            SortExpression="Note_From" UniqueName="Note_From" ItemStyle-Width="100">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" 
                                                            HeaderText="Note_Type " SortExpression="Note_Type" 
                                                            UniqueName="Note_Type">
                                                             <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>                                                           
                                                           <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" 
                                                            HeaderText="Notes" SortExpression="Notes" 
                                                            UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                       
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="True" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="lblErr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>


