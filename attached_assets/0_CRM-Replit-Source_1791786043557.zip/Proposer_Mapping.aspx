﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Proposer_Mapping.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC" colspan="4">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="LINK POLICIES" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" colspan="4">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td style="width: 754px" align="right" colspan="2">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" Skin="Web20" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="N" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Policy Code" Value="P" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 264px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Web20" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search" Skin="Simple">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 754px" colspan="2">
                                                    <asp:Label ID="LBLID" runat="server" Font-Bold="True"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    &nbsp;</td>
                                                <td style="width: 264px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTracking" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>                                                                  
                                                                    <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                        FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                        SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                        FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="PROPOSER_DISPLAY_NAME" 
                                                                        SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="MAPPING_CODE" 
                                                                        FilterControlAltText="Filter MAPPING_CODE column" HeaderText="MAPPING_CODE" 
                                                                        SortExpression="MAPPING_CODE" UniqueName="MAPPING_CODE">
                                                                    </telerik:GridBoundColumn>
                                                                  
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5" style="height: 34px">
                                                    <telerik:RadButton ID="btnadd" runat="server" Text="Add" Width="200px" 
                                                        Skin="Simple">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Label ID="Label174" runat="server" Font-Bold="True" Text="Pair Info"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel32" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GD_Pay" runat="server" AllowPaging="True" CellSpacing="0" 
                                                            GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                            <telerik:GridTemplateColumn DataType="System.Boolean" UniqueName="Updated">
                                        <ItemTemplate>
                                            <asp:CheckBox ID="chkreturn" runat="server" AutoPostBack="True" 
                                                OnCheckedChanged="ToggleRowSelection" />
                                        </ItemTemplate>
                                        <HeaderTemplate>
                                            <asp:CheckBox ID="chkheader" runat="server" AutoPostBack="True" 
                                                OnCheckedChanged="ToggleSelectedState" />
                                        </HeaderTemplate>
                                    </telerik:GridTemplateColumn>
                                                                          <telerik:GridBoundColumn DataField="POLICY_CODE" 
             FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
             SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
         </telerik:GridBoundColumn>
         <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
             FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="PROPOSER_DISPLAY_NAME" 
             SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
         </telerik:GridBoundColumn>
   <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
       ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
       Resizable="false" Text="Delete" UniqueName="DeleteColumn">
       <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
       <ItemStyle CssClass="ButtonColumn" />
   </telerik:GridButtonColumn>

                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="height: 31px; width: 754px;">
                                                    <asp:Label ID="Label175" runat="server" Font-Bold="True" Text="Mapping Code"></asp:Label>
                                                </td>
                                                <td style="height: 31px; width: 754px;">
                                                    <telerik:RadTextBox ID="txtid" Runat="server" Skin="Web20" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td style="height: 31px"></td>
                                                <td style="height: 31px"></td>
                                                <td style="height: 31px"></td>
                                            </tr>
                                            <tr>
                                                <td style="height: 31px; width: 754px;">
                                                    <asp:Label ID="Label176" runat="server" Font-Bold="True" Text="Proposer Name"></asp:Label>
                                                </td>
                                                <td style="height: 31px; width: 754px;">
                                                    <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Web20" Width="300px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td style="height: 31px">&nbsp;</td>
                                                <td style="height: 31px">&nbsp;</td>
                                                <td style="height: 31px">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="height: 14px; width: 754px;">&nbsp;</td>
                                                <td style="height: 14px; width: 754px;">
                                                    <telerik:RadButton ID="btngen" runat="server" Skin="Simple" Text="Link Policies" Width="200px">
                                                    </telerik:RadButton>
                                                </td>
                                                <td colspan="2" style="height: 14px">
                                                    <asp:Label ID="lblno" runat="server" Font-Bold="True"></asp:Label>
                                                </td>
                                                <td style="height: 14px">&nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" Width="1128px">
                                            <telerik:RadGrid ID="GDMapped" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                  
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MAPPING_CODE" FilterControlAltText="Filter MAPPING_CODE column" HeaderText="MAPPING_CODE" SortExpression="MAPPING_CODE" UniqueName="MAPPING_CODE">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 33px">&nbsp;</td>
                                    <td style="height: 33px">
                                        <asp:CheckBox ID="chkRefresh" runat="server" Text="Update Statement" />
                                    </td>
                                    <td style="height: 33px">
                                        <telerik:RadButton ID="btngen0" runat="server" Skin="Simple" Text="Update Statement" Width="200px">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="height: 33px">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 41px" colspan="4">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        &nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
       
            </asp:UpdatePanel>
</asp:Content>

