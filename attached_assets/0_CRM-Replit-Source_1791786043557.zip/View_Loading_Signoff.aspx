﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="View_Loading_Signoff.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table>
                <tr>
                    <td align="center" bgcolor="#333333" style="height: 44px; width: 1461px;">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="Loading Verification"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="left" style="width: 1461px">
                        &nbsp;</td>
                </tr>
                </table>

                       <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                Width="1008px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td style="width: 3043px; font-weight: 700;">
                                                            <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                                                Text="Search By"></asp:Label>
                                                        </td>
                                                        <td style="width: 384px">
                                                            &nbsp;</td>
                                                        <td>
                                                            &nbsp;</td>
                                                        <td>
                                                            &nbsp;</td>
                                                        <td>
                                                            &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 3043px; font-weight: 700;">
                                                            <asp:Label ID="Label160" runat="server" style="font-weight: 700" 
                                                                Text="Renewal Period"></asp:Label>
                                                        </td>
                                                        <td style="width: 384px">
                                                            <telerik:RadDatePicker ID="dtF_1" Runat="server" Skin="Web20">
                                                                <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                        <td>
                                                            <telerik:RadDatePicker ID="DTt_1" Runat="server" Skin="Web20" Width="150px">
                                                                <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                        <td>
                                                            <telerik:RadButton ID="txtSEARCH" runat="server" Text="Search">
                                                            </telerik:RadButton>
                                                        </td>
                                                        <td>
                                                            &nbsp;</td>
                                                    </tr>
                                                </table>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                Height="100%" style="font-weight: 700" Width="1010px">
                                                <table style="width: 99%">
                                                    <tr>
                                                        <td class="style8" colspan="4">
                                                            <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1001px">
                                                                <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" Skin="Simple" 
                                                                    Width="100%">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                                                                                                     <telerik:GridBoundColumn DataField="ID" DataType="System.Decimal" 
                                                                                FilterControlAltText="Filter ID column" HeaderText="ID" ReadOnly="True" 
                                                                                SortExpression="ID" UniqueName="ID">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                                FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                                ItemStyle-Wrap="False" SortExpression="MEMBER_NO" 
                                                                                UniqueName="MEMBER_NO">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="RELATION" 
                                                                                FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                FilterControlAltText="Filter POLICY_VALID_FROM column" HeaderText="POLICY_VALID_FROM" 
                                                                                ItemStyle-Wrap="False" SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>

                                                                            <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                FilterControlAltText="Filter POLICY_VALID_UPTO column" HeaderText="POLICY_VALID_UPTO" 
                                                                                SortExpression="POLICY_VALID_UPTO" UniqueName="POLICY_VALID_UPTO">
                                                                            </telerik:GridBoundColumn>
                                                                      
                                                                       <telerik:GridBoundColumn DataField="LOADING_RATE" 
                                                                                FilterControlAltText="Filter LOADING_RATE column" HeaderText="LOADING_RATE" 
                                                                                SortExpression="LOADING_RATE" UniqueName="LOADING_RATE">
                                                                            </telerik:GridBoundColumn>

                                                                             <telerik:GridBoundColumn DataField="OP_LIMIT" 
                                                                                FilterControlAltText="Filter OP_LIMIT column" HeaderText="OP_LIMIT" 
                                                                                SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                                            </telerik:GridBoundColumn>

                                                                             <telerik:GridBoundColumn DataField="IP_LIMIT" 
                                                                                FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP_LIMIT" 
                                                                                SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                                            </telerik:GridBoundColumn>

                                                                              <telerik:GridBoundColumn DataField="PRESENT_IP" 
                                                                                FilterControlAltText="Filter PRESENT_IP column" HeaderText="PRESENT_IP" 
                                                                                SortExpression="PRESENT_IP" UniqueName="PRESENT_IP">
                                                                            </telerik:GridBoundColumn>

                                                                             <telerik:GridBoundColumn DataField="PRESENT_OP" 
                                                                                FilterControlAltText="Filter PRESENT_OP column" HeaderText="PRESENT_OP" 
                                                                                SortExpression="PRESENT_OP" UniqueName="PRESENT_OP">
                                                                            </telerik:GridBoundColumn>

                                                                                 <telerik:GridBoundColumn DataField="IP_RATE" 
                                                                                FilterControlAltText="Filter IP_RATE column" HeaderText="IP_RATE" 
                                                                                SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                                            </telerik:GridBoundColumn>

                                                                             <telerik:GridBoundColumn DataField="OP_RATE" 
                                                                                FilterControlAltText="Filter OP_RATE column" HeaderText="OP_RATE" 
                                                                                SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                                            </telerik:GridBoundColumn>
                                                                    
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 194px">
                                                            <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                        </td>
                                                        <td>
                                                            &nbsp;</td>
                                                        <td class="style8" style="width: 166px">
                                                            &nbsp;</td>
                                                        <td style="width: 287px">
                                                            &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8">
                                                            &nbsp;</td>
                                                        <td>
                                                            <asp:CheckBox ID="chkLoading" runat="server" Text="Loading Complete" />
                                                        </td>
                                                        <td class="style8" colspan="2">
                                                            <telerik:RadButton ID="cmdsave" runat="server" Height="37px" Skin="Simple" 
                                                                Text="Save" Width="100px">
                                                            </telerik:RadButton>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" colspan="2">
                                                            <telerik:RadButton ID="btnverexpo" runat="server" Skin="Simple" 
                                                                Text="Export List" Width="218px">
                                                            </telerik:RadButton>
                                                        </td>
                                                        <td class="style8" style="width: 166px">
                                                            &nbsp;</td>
                                                        <td style="width: 287px">
                                                            &nbsp;&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" colspan="4" style="height: 6px">
                                                            <asp:HiddenField ID="HiddenField1" runat="server" />
                                                        </td>
                                                    </tr>
                                                   
                                                          
                                                </table>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                </table>
    

              
  
        </ContentTemplate>
                       
          </asp:UpdatePanel>
</asp:Content>
