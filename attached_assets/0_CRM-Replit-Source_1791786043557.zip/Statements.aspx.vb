﻿Imports DocManage.DataManagement
Imports System.Data
Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail

Imports System.Data.Odbc

Imports System
Imports System.Collections
Imports System.Configuration
Imports Microsoft.VisualBasic

Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports Microsoft.Office.Interop
Imports System.Windows.Forms

Partial Class Default2
    Inherits System.Web.UI.Page
    Private MyReportViewing As ReportDocument
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        MyDatatable = Nothing
        If Not IsPostBack Then
            Session("SelectionFormula") = Nothing
            Session("EXCEL") = Nothing
            Session("Reportname") = Nothing
            Session("PRINT") = ""

          
            dtfrom.DbSelectedDate = Session("CUTOFF_FROM")
            dtto.DbSelectedDate = Session("CUTOFF_TO")

            Str = ""
            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM [COMMISSION].dbo.TBL_MIS_SALES_AGENTS  WHERE  ACTIVE=1 ORDER BY AGENT_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With CBOagents

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()

            End With
            MyDatatable = Nothing

            Str = ""
            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT BRANCH_CODE,BRANCH_NAME FROM [COMMISSION].dbo.TBL_MIS_SALES_BRANCH" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With CBOBRANCH

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("BRANCH_NAME").ToString
                .DataValueField = MyDatatable.Columns("BRANCH_CODE").ToString
                .DataBind()

            End With
            MyDatatable = Nothing

            Str = ""
            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT DISTINCT UM_ID,UM_NAME FROM [COMMISSION].dbo.TBL_MIS_SALES_UM WHERE ACTIVE=1  AND IS_BDM=1"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With CBOUM

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("UM_NAME").ToString
                .DataValueField = MyDatatable.Columns("UM_ID").ToString
                .DataBind()

            End With
            MyDatatable = Nothing
            Str = ""

            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT  BM_ID,BM_NAME FROM [COMMISSION].dbo.TBL_MIS_SALES_BM  "
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With CBOBM

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("BM_NAME").ToString
                .DataValueField = MyDatatable.Columns("BM_ID").ToString
                .DataBind()

            End With
            MyDatatable = Nothing

            'SELECT USER_CODE,USER_DISPLAY_NAME FROM dbo.tbl_rpt_Intermediaries_Report_Listing
            Str = "SELECT  RM_ID,RM_NAME FROM [COMMISSION].dbo.TBL_MIS_SALES_RM  "
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With CBORM

                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RM_NAME").ToString
                .DataValueField = MyDatatable.Columns("RM_ID").ToString
                .DataBind()

            End With
            MyDatatable = Nothing
        End If
    End Sub

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click
        Dim SqlAction As String = ""
        Dim searchStr As String = ""
        Dim MyDBAction As New DataManagement
        Dim StrQuery As String = ""
        Dim Str_1 As String = ""
        Dim Str_E As String = ""
        Dim Reportname As String = ""
        Dim SelectionFormula As String = ""
        Dim MyDatable As New Data.DataTable
        Dim MyDatable_E As New Data.DataTable
        Dim MyDatable_1 As New Data.DataTable
        Session("Reportname") = ""
        Session("DA") = ""
        Session("FrmDT") = dtfrom.DbSelectedDate
        Session("ToDt") = dtto.DbSelectedDate
        Try
            If rdapprove_2.SelectedValue = "SA" Then
                If chkBranch.Checked = True Then
                    Session("Report_") = "Statement-Commission Per Branch"
                    Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,COMMISSION,INCENTIVE_NEW,INCENTIVE_RENEWAL,DR_CR,TAX_RATE,PLAN_CODE,I_RATE,O_RATE,SALES_TAX,RECEIPT_AMOUNT,MED_RATE,NON_MED_RATE,MAR_RATE,MIN_PROD,MAX_INC_NEW,MAX_INC_RENEW FROM [COMMISSION].dbo.TBL_COMMISSION_CALC WHERE HIER_TYPE IN ('SA')  AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "'  AND APPROVER_1=1 AND APPROVER_2=1"
                    'SqlAction = "SELECT  sum([COMMISSION])[COMMISSION], sum([OVER_RIDES_NEW])OVER_RIDES_NEW, sum([OVER_RIDES_RENEWAL])OVER_RIDES_RENEWAL, sum([INCENTIVE_NEW])INCENTIVE_NEW,sum([INCENTIVE_RENEWAL])INCENTIVE_RENEWAL FROM dbo.[TBL_COMMISSION_CALC] WHERE  HIER_TYPE IN ('SA') AND  PREM_RECEIPT_DATE BETWEEN '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND BRANCH ='" & CBOBRANCH.SelectedValue & "' AND APPROVER_1=1 AND APPROVER_2=1"

                End If
            ElseIf rdapprove_2.SelectedValue = "OV" Then
                If chkBranch.Checked = True Then
                    Session("Report_") = "Statement-Overide Branch"
                    Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,OVER_RIDES_RENEWAL,OVER_RIDES_NEW,OVERRIDE_RET_NEW,OVERRIDE_SME_NEW,OVERRIDE_CORP_NEW,DR_CR,TAX_RATE,O_RATE,O_RENEW,SALES_TAX,RECEIPT_AMOUNT,PLAN_CODE FROM [COMMISSION].dbo.TBL_COMMISSION_CALC WHERE HIER_TYPE IN ('UM','BM','RM') AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "'  AND APPROVER_1=1 AND APPROVER_2=1"
                    'SqlAction = "SELECT  sum([COMMISSION])[COMMISSION], sum([OVER_RIDES_NEW])OVER_RIDES_NEW, sum([OVER_RIDES_RENEWAL])OVER_RIDES_RENEWAL, sum([INCENTIVE_NEW])INCENTIVE_NEW,sum([INCENTIVE_RENEWAL])INCENTIVE_RENEWAL FROM dbo.[TBL_COMMISSION_CALC] WHERE HIER_TYPE IN ('UM','BM','RM') AND   PREM_RECEIPT_DATE BETWEEN '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND BRANCH ='" & CBOBRANCH.SelectedValue & "' AND APPROVER_1=1 AND APPROVER_2=1"

                End If
            ElseIf rdapprove_2.SelectedValue = "EN" Then
                Session("EXCEL") = "TO EXCEL"
                Session("Report_") = "Statement-Emails Not Send"
                Str = "SELECT DISTINCT USER_DISPLAY_NAME,BRANCH,EMAIL FROM [COMMISSION].dbo.VW_EMAIL_NOT_SEND WHERE (EMAIL_SEND <> 1) AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "'"

            ElseIf rdapprove_2.SelectedValue = "ES" Then
                Session("Report_") = "Statement-Emails Send"
                Session("EXCEL") = "TO EXCEL"
                Str = "SELECT DISTINCT USER_DISPLAY_NAME,BRANCH,EMAIL FROM [COMMISSION].dbo.VW_EMAIL_NOT_SEND WHERE (EMAIL_SEND = 1) AND  CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "'"
            ElseIf rdapprove_2.SelectedValue = "SC" Then
                Session("Report_") = "Statement-Comments"
                Session("EXCEL") = "TO EXCEL"
                Str = "SELECT USER_DISPLAY_NAME,PROPOSER_NAME,PREM_RECEIPT_NO,BUSINESS,RECEIPT_AMOUNT,COMMENTS FROM [COMMISSION].dbo.TBL_COMMISSION_CALC WHERE COMMENTS IS NOT NULL AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "'"

            End If

            If chkbm.Checked = True Then
                Session("Report_") = "Statement-BDM"
                SqlAction = "SELECT  sum([COMMISSION])[COMMISSION], sum([OVER_RIDES_NEW])OVER_RIDES_NEW, sum([OVER_RIDES_RENEWAL])OVER_RIDES_RENEWAL, sum([INCENTIVE_NEW])INCENTIVE_NEW,sum([INCENTIVE_RENEWAL])INCENTIVE_RENEWAL FROM [COMMISSION].dbo.[TBL_COMMISSION_CALC]  WHERE  USER_ID ='" & CBOBM.SelectedValue & "' AND APPROVER_1=1 AND APPROVER_2=1"
                Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,OVER_RIDES_RENEWAL,OVER_RIDES_NEW,OVERRIDE_RET_NEW,OVERRIDE_SME_NEW,OVERRIDE_CORP_NEW,DR_CR,TAX_RATE,O_RATE,O_RENEW,SALES_TAX,RECEIPT_AMOUNT,PLAN_CODE,DEDUCTIONS FROM [COMMISSION].dbo.TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('BM')  AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND USER_ID ='" & CBOBM.SelectedValue & "' AND APPROVER_1=1 AND APPROVER_2=1"

            ElseIf chkrm.Checked = True Then
                Session("Report_") = "Statement-RM"
                SqlAction = "SELECT  sum([COMMISSION])[COMMISSION], sum([OVER_RIDES_NEW])OVER_RIDES_NEW, sum([OVER_RIDES_RENEWAL])OVER_RIDES_RENEWAL, sum([INCENTIVE_NEW])INCENTIVE_NEW,sum([INCENTIVE_RENEWAL])INCENTIVE_RENEWAL FROM [COMMISSION].dbo.[TBL_COMMISSION_CALC]  WHERE  APPROVER_1=1 AND APPROVER_2=1"
                Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,OVER_RIDES_RENEWAL,OVER_RIDES_NEW,OVERRIDE_RET_NEW,OVERRIDE_SME_NEW,OVERRIDE_CORP_NEW,DR_CR,TAX_RATE,O_RATE,O_RENEW,SALES_TAX,RECEIPT_AMOUNT,PLAN_CODE,DEDUCTIONS FROM [COMMISSION].dbo.TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('RM')  AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVER_1=1 AND APPROVER_2=1 AND USER_ID ='" & CBORM.SelectedValue & "' "

            ElseIf chkum.Checked = True Then
                Session("Report_") = "Statement-UM"
                SqlAction = "SELECT  sum([COMMISSION])[COMMISSION], sum([OVER_RIDES_NEW])OVER_RIDES_NEW, sum([OVER_RIDES_RENEWAL])OVER_RIDES_RENEWAL, sum([INCENTIVE_NEW])INCENTIVE_NEW,sum([INCENTIVE_RENEWAL])INCENTIVE_RENEWAL FROM [CRM].dbo.[TBL_COMMISSION_CALC]  WHERE  USER_ID ='" & CBOUM.SelectedValue & "' AND APPROVER_1=1 AND APPROVER_2=1"
                Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,OVER_RIDES_RENEWAL, OVER_RIDES_NEW,OVERRIDE_RET_NEW,OVERRIDE_SME_NEW,OVERRIDE_CORP_NEW,DR_CR,TAX_RATE,O_RATE,O_RENEW,SALES_TAX,RECEIPT_AMOUNT,PLAN_CODE,DEDUCTIONS FROM [CRM].dbo.TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('UM')  AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND USER_ID ='" & CBOUM.SelectedValue & "' AND APPROVER_1=1 AND APPROVER_2=1"
            ElseIf chkagents.Checked = True Then
                Session("Report_") = "Statement-SA_1"
                SqlAction = "SELECT  sum([COMMISSION])[COMMISSION], sum([OVER_RIDES_NEW])OVER_RIDES_NEW, sum([OVER_RIDES_RENEWAL])OVER_RIDES_RENEWAL, sum([INCENTIVE_NEW])INCENTIVE_NEW,sum([INCENTIVE_RENEWAL])INCENTIVE_RENEWAL FROM [CRM].dbo.[TBL_COMMISSION_CALC]  WHERE  USER_ID ='" & CBOagents.SelectedValue & "' AND APPROVER_1=1 AND APPROVER_2=1"
                Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,COMMISSION,INCENTIVE_NEW,INCENTIVE_RENEWAL,DR_CR,TAX_RATE,PLAN_CODE,I_RATE,O_RATE,SALES_TAX,RECEIPT_AMOUNT,MED_RATE,NON_MED_RATE FROM [CRM].dbo.TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('SA')  AND CUTOFF_FROM_DT>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND CUTOFF_TO_DT <= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVER_1=1 AND APPROVER_2=1   AND USER_ID ='" & CBOagents.SelectedValue & "' "

            End If

            'Session("Application") = Nothing
            If SqlAction <> "" Then
                MyDatable_1 = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then
                    'Session("Application") = MyDatable
                    'myDataTable.Rows(0).Field(Of String)(0)
                    txtcomm.Text = MyDatable_1.Rows(0).Item("COMMISSION").ToString()
                    txtovernew.Text = MyDatable_1.Rows(0).Item("OVER_RIDES_NEW").ToString()
                    txtoverrenew.Text = MyDatable_1.Rows(0).Item("OVER_RIDES_RENEWAL").ToString()
                    txtincenew.Text = MyDatable_1.Rows(0).Item("INCENTIVE_NEW").ToString()
                    txtincerenew.Text = MyDatable_1.Rows(0).Item("INCENTIVE_RENEWAL").ToString()
                End If

            End If

            Session("PRINT") = "PDF"
            If Str <> "" Then

                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                'Session("DA_G") = MyDatable

                'If MyDatable_1.Rows.Count > 0 Then

                'MyDatable_1 = Nothing
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing

                'Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                'Mytable = TryCast(MyDBAction.eoxegen(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                System.Threading.Thread.Sleep(5000)
            End If
            MyDatable = Nothing
            Session("EXCEL") = Nothing

        Catch ex As Exception

        End Try


    End Sub

    'Protected Sub RadButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton2.Click
    '    Dim Str As String = "" : Dim Mytable As DataTable = Nothing
    '    Dim Str_1 As String = ""
    '    Dim Str_2 As String = ""
    '    Dim MyDatable_1 As DataTable = Nothing
    '    Dim Str_Live As String = ""

    '    Session("EMPNAME") = Nothing
    '    Session("FrmDT") = dtfrom.DbSelectedDate
    '    Session("ToDt") = dtto.DbSelectedDate
    '    Session("RecepientEmail") = ""
    '    Session("MailSent") = False
    '    Try


    '    If chkemail.Checked = True Then

    '            Exit Sub
    '        If chkbm.Checked = True And CBOBM.Text = "" Then
    '                Str_1 = "SELECT BM_ID,BM_NAME,BRANCH_NAME,EMAIL,BR_CODE FROM VW_MIS_BM_LISTING WHERE BRANCH_NAME IS NOT NULL"

    '            '------------------------------------------------------------------------------------------------------------------------------------
    '            MyDatable = Nothing
    '            MyDatable = TryCast(MyDBAction.DBAction(Str_1, DataManagement.DBActionType.DataTable), Data.DataTable)
    '            If MyDatable.Rows.Count > 0 Then

    '                For Each row As DataRow In MyDatable.Rows
    '                        Session("RecepientEmail") = row("EMAIL")
    '                        Session("EMPNAME") = row("BM_NAME").ToString()
    '                        Session("BRANCH_NAME") = "BRANCH MANAGERS\" & row("BRANCH_NAME").ToString() ' MyDatable.Rows(0).Item("BRANCH_NAME").ToString() '
    '                        Session("NAME") = row("BM_NAME").ToString() & " " & " {" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "-" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "}" ' MyDatable.Rows(0).Item("USER_DISPLAY_NAME").ToString() ' 

    '                        MyDatable_1 = Nothing
    '                        Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,OVER_RIDES_NEW,OVER_RIDES_RENEWAL,DR_CR,TAX_RATE,I_NEW,I_RENEW,O_NEW,O_RENEW,SALES_TAX,RECEIPT_AMOUNT FROM TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('BM')  AND PREM_RECEIPT_DATE BETWEEN'" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVER_1=1 AND APPROVER_2=1 AND USER_ID ='" & row("BM_ID") & "' AND EMAIL_SEND<>1 "
    '                        Session("Report_") = "Statement-BDM"
    '                        Session("EXPORT_TYPE") = "PDF"

    '                        If Not IsDBNull(Session("RecepientEmail")) Then
    '                            MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
    '                            If MyDatable_1.Rows.Count > 0 Then
    '                                GENERATE_RPT(MyDatable_1)
    '                                If Session("MailSent") = True Then
    '                                    MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("BM_ID"), True, "")
    '                                    Session("MailSent") = False
    '                                Else
    '                                    'MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("RM_ID"), False)
    '                                    lblstate.Text = "Email already send for user " & row("BM_NAME").ToString() & ""

    '                                End If

    '                            End If

    '                            MyDatable_1 = Nothing
    '                            Str_2 = "SELECT BRANCH_NAME,USER_DISPLAY_NAME,PROPOSER_NAME,BUSINESS_TYPE, PREM_RECEIPT_NO,PREMIUM,ACTUAL_AMT ,COMMISSION,INCENTIVE_NEW,INCENTIVE_RENEWAL, OVER_RIDES_NEW,OVER_RIDES_RENEWAL,BUSINESS,DR_CR,TAX_RATE,I_NEW,I_RENEW,O_NEW,O_RENEW,SALES_TAX,RECEIPT_AMOUNT FROM TBL_COMMISSION_CALC WHERE BRANCH='" & row("BR_CODE") & "' AND APPROVER_2=1 AND PREM_RECEIPT_DATE BETWEEN'" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVER_1=1 AND APPROVER_2=1 AND HIER_TYPE ='SA'"

    '                            MyDatable_1 = TryCast(MyDBAction.DBAction(Str_2, DataManagement.DBActionType.DataTable), Data.DataTable)
    '                            If MyDatable_1.Rows.Count > 0 Then
    '                                Session("Report_") = "Branch Summary"
    '                                Session("EXPORT_TYPE") = "EXCEL"
    '                                Session("NAME") = row("BM_NAME").ToString() & "-" & Session("Report_") & " " & " {" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "-" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "}" ' MyDatable.Rows(0).Item("USER_DISPLAY_NAME").ToString() ' 

    '                                GENERATE_RPT(MyDatable_1)
    '                            End If


    '                        End If

    '                    Next
    '            End If

    '        ElseIf chkum.Checked = True And CBOUM.Text = "" Then
    '                    Str_1 = "SELECT UM_ID,UM_NAME,BRANCH_NAME,EMAIL FROM dbo.VW_MIS_UM_LISTING WHERE ACTIVE=1" '  AND USER_ID ='" & CBOagents.SelectedValue & "' "

    '            '------------------------------------------------------------------------------------------------------------------------------------
    '            MyDatable = Nothing
    '            MyDatable = TryCast(MyDBAction.DBAction(Str_1, DataManagement.DBActionType.DataTable), Data.DataTable)
    '            If MyDatable.Rows.Count > 0 Then

    '                For Each row As DataRow In MyDatable.Rows

    '                        Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,OVER_RIDES_NEW,OVER_RIDES_RENEWAL,DR_CR,TAX_RATE,I_NEW,I_RENEW,O_NEW,O_RENEW,SALES_TAX,RECEIPT_AMOUNT FROM TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('UM')  AND PREM_RECEIPT_DATE BETWEEN'" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVER_1=1 AND APPROVER_2=1 AND USER_ID ='" & row("UM_ID") & "' AND EMAIL_SEND<>1 "
    '                    Session("Report_") = "Statement-UM"
    '                        Session("EXPORT_TYPE") = "PDF"

    '                    MyDatable_1 = Nothing
    '                    MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
    '                    Session("EMPNAME") = row("UM_NAME").ToString()
    '                        Session("RecepientEmail") = row("EMAIL")
    '                        If Not IsDBNull(Session("RecepientEmail")) Then
    '                            Session("BRANCH_NAME") = "UNIT MANAGERS\" & row("BRANCH_NAME").ToString() ' MyDatable.Rows(0).Item("BRANCH_NAME").ToString() '
    '                            Session("NAME") = row("UM_NAME").ToString() & " " & " {" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "-" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "}" ' MyDatable.Rows(0).Item("USER_DISPLAY_NAME").ToString() ' 
    '                            GENERATE_RPT(MyDatable_1)
    '                            If Session("MailSent") = True Then
    '                                MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("UM_ID"), True, "")
    '                            Else
    '                                'MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("RM_ID"), False)
    '                                lblstate.Text = "Email already send for user " & row("UM_NAME").ToString() & ""

    '                            End If
    '                        End If
    '                Next

    '            End If

    '        ElseIf chkrm.Checked = True And CBORM.Text = "" Then
    '            Str_1 = "SELECT RM_ID,RM_NAME,EMAIL FROM TBL_MIS_SALES_RM WHERE ACTIVE=1" '  AND USER_ID ='" & CBOagents.SelectedValue & "' "

    '            '------------------------------------------------------------------------------------------------------------------------------------
    '            MyDatable = Nothing
    '            MyDatable = TryCast(MyDBAction.DBAction(Str_1, DataManagement.DBActionType.DataTable), Data.DataTable)
    '            If MyDatable.Rows.Count > 0 Then

    '                For Each row As DataRow In MyDatable.Rows

    '                        Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,COMMISSION,INCENTIVE_NEW,INCENTIVE_RENEWAL,DR_CR,TAX_RATE,PLAN_CODE,I_RATE,O_RATE,SALES_TAX,RECEIPT_AMOUNT,MED_RATE,NON_MED_RATE,MAR_RATE,MIN_PROD,MAX_INC_NEW,MAX_INC_RENEW FROM TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('RM')  AND PREM_RECEIPT_DATE BETWEEN'" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVER_1=1 AND APPROVER_2=1 AND USER_ID ='" & row("RM_ID") & "' AND EMAIL_SEND<>1 "
    '                        Session("Report_") = "Statement-RM"
    '                        Session("EXPORT_TYPE") = "PDF"
    '                    ' EMAIL DETAILS
    '                    Session("RecepientEmail") = row("EMAIL")
    '                        If Not IsDBNull(Session("RecepientEmail")) Then


    '                            MyDatable_1 = Nothing
    '                            MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
    '                            Session("EMPNAME") = row("RM_NAME").ToString()
    '                            Session("BRANCH_NAME") = "REGIONAL MANAGERS" ' MyDatable.Rows(0).Item("BRANCH_NAME").ToString() '
    '                            Session("NAME") = row("RM_NAME").ToString() & " " & " {" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "-" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "}" ' MyDatable.Rows(0).Item("USER_DISPLAY_NAME").ToString() ' 
    '                            GENERATE_RPT(MyDatable_1)
    '                            If Session("MailSent") = True Then
    '                                MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("RM_ID"), True, "")
    '                            Else
    '                                'MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("RM_ID"), False)
    '                                lblstate.Text = "Email already send for user " & row("RM_NAME").ToString() & ""

    '                            End If
    '                        End If
    '                Next

    '            End If
    '        ElseIf chkagents.Checked = True Then

    '            If chkBranch.Checked = True Then
    '                    Str_1 = "SELECT USER_ID,AGENT_NAME,BRANCH_NAME,EMAIL FROM VW_MIS_AGENTS_LISTING WHERE ACTIVE=1 AND BRANCH_CODE ='" & CBOBRANCH.SelectedValue & "'" ' AND  EMAIL  LIKE '%@aar%'"
    '                    'Str_1 = "SELECT USER_ID,AGENT_NAME,BRANCH_NAME,EMAIL FROM VW_MIS_AGENTS_LISTING WHERE ACTIVE=1 AND BRANCH_CODE ='" & Session("branch") & "' AND USER_ID='2014031014393258482676240' "

    '                    '2014031014393258482676240
    '            Else
    '                Str_1 = "SELECT USER_ID,AGENT_NAME,BRANCH_NAME,EMAIL FROM VW_MIS_AGENTS_LISTING WHERE ACTIVE=1 ORDER BY BRANCH_NAME" '  AND USER_ID ='" & CBOagents.SelectedValue & "' "

    '            End If

    '            '------------------------------------------------------------------------------------------------------------------------------------
    '            MyDatable = Nothing
    '            MyDatable = TryCast(MyDBAction.DBAction(Str_1, DataManagement.DBActionType.DataTable), Data.DataTable)
    '            If MyDatable.Rows.Count > 0 Then

    '                For Each row As DataRow In MyDatable.Rows
    '                        Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,COMMISSION,INCENTIVE_NEW,INCENTIVE_RENEWAL,DR_CR,TAX_RATE,PLAN_CODE,I_RATE,O_RATE,SALES_TAX,RECEIPT_AMOUNT,MED_RATE,NON_MED_RATE,MAR_RATE,MIN_PROD,MAX_INC_NEW,MAX_INC_RENEW FROM TBL_COMMISSION_CALC WHERE HIER_TYPE IN ('SA')  AND  PREM_RECEIPT_DATE BETWEEN'" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND USER_ID ='" & row("USER_ID") & "' AND APPROVER_1=1 AND APPROVER_2=1 AND EMAIL_SEND<>1 "

    '                    'Str = "SELECT BRANCH_NAME, BUSINESS, USER_DISPLAY_NAME, PROPOSER_NAME,PREM_RECEIPT_NO,PREM_RECEIPT_DATE,BUSINESS_TYPE, PREMIUM,ACTUAL_AMT,COMMISSION,OVER_RIDES_NEW,OVER_RIDES_RENEWAL,INCENTIVE_NEW,INCENTIVE_RENEWAL FROM TBL_COMMISSION_CALC WHERE  HIER_TYPE IN ('SA')  AND PREM_RECEIPT_DATE BETWEEN'" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVER_1=1 AND APPROVER_2=1   AND USER_ID ='" & row("USER_ID") & "' "

    '                        Session("Report_") = "Statement-SA"
    '                        Session("EXPORT_TYPE") = "PDF"

    '                        Session("RecepientEmail") = row("EMAIL")
    '                        If Not IsDBNull(Session("RecepientEmail")) Then
    '                            MyDatable_1 = Nothing
    '                            MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
    '                            Session("EMPNAME") = row("AGENT_NAME").ToString()
    '                            Session("BRANCH_NAME") = "SALES AGENTS\" & row("BRANCH_NAME").ToString() ' MyDatable.Rows(0).Item("BRANCH_NAME").ToString() '
    '                            Session("NAME") = row("AGENT_NAME").ToString() & " " & " {" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "-" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "}" ' MyDatable.Rows(0).Item("USER_DISPLAY_NAME").ToString() ' 
    '                            GENERATE_RPT(MyDatable_1)

    '                            If Session("MailSent") = True Then
    '                                MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("USER_ID"), True, "")
    '                            Else
    '                                'MyDBAction.ENROLL_UPDATE_EMAIL(CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd"), CDate(dtto.SelectedDate).ToString("yyyy-MM-dd"), row("RM_ID"), False)
    '                                lblstate.Text = "Email already send for user " & row("AGENT_NAME").ToString() & ""

    '                            End If
    '                        End If

    '                    Next

    '            End If

    '        End If
    '    Else


    '    End If


    '    Catch ex As Exception
    '        MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
    '    End Try






    'End Sub


    Public Sub GENERATE_RPT(ByVal Mytable As DataTable)
        Dim Str As String = ""
        'Dim Mytable As DataTable = Nothing
        Dim Str_1 As String = ""
        Dim MyDatable_1 As DataTable = Nothing

        If Mytable.Rows.Count > 0 Then
            'If MyDatable_1.Rows.Count > 0 Then

            'MyDatable_1 = Nothing
            Session("Mytable") = Nothing
            Session("Reportname") = Nothing

            'Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'Mytable = TryCast(MyDBAction.eoxegen(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Session("Report_")
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing

            'System.Threading.Thread.Sleep(5000)
            ShowReport()
        End If

    End Sub

    Private Sub ShowReport()
        Try
            Dim MailSent As Boolean = False
            Dim rpt As New ReportDocument
            Dim rpt_excel As New ReportDocument
            Dim tbs As Tables = Nothing
            Dim tb As Table = Nothing
            Dim cInfo As New ConnectionInfo
            Dim Reportpath As String
            'Dim MyDataTable As New Data.DataTable("crb_individuals")
            Dim MyDBAction As New DataManagement
            Dim Reportname As String = ""
            Dim EnctryptionAlgorith As String = "rijndael"
            Dim CryptographyFactory As New DocManagementSecurity.CryptoFactory()
            Dim Cryptographer As DocManagementSecurity.ICrypto = CryptographyFactory.MakeCryptographer(EnctryptionAlgorith)

            Dim DecryptedStr As String = Cryptographer.Decrypt(WebConfigurationManager.ConnectionStrings("COMMISSION").ConnectionString)

            If Not Session("Reportname") Is Nothing Then

                '--------------------------------------------------------------

                Reportname = Session("Reportname")
                Session("ReportTitle") = Reportname
                Session("Company") = "AAR INSURANCE"
                'Dim ExportedReports As String = Server.MapPath("GeneratedReports\" & Replace(Session("FullNames"), " ", "_"))
                Dim ExportedReports As String = Server.MapPath("GeneratedReports\" & Replace(Session("BRANCH_NAME"), " ", "_"))

                Reportpath = Server.MapPath("~\Reports") & "\" & Reportname & ".rpt"
                rpt.Load(Reportpath)
                'rpt.SetParameterValue("@DISPLAY_MEMBERSHIP_NO", Session("MemberNo"))
                'crViewer.ReportSource = rpt
                rpt.SetDataSource(Session("Mytable"))


                tbs = rpt.Database.Tables


                Dim cn As New Data.Odbc.OdbcConnection(DecryptedStr)
                For Each tb In tbs
                    With cInfo
                        .ServerName = WebConfigurationManager.AppSettings("ReportServerName")
                        .Password = WebConfigurationManager.AppSettings("ReportPassword")
                        .UserID = WebConfigurationManager.AppSettings("ReportUsername")
                        '.DatabaseName = cn.Database
                        .DatabaseName = WebConfigurationManager.AppSettings("ReportdatbaseName")
                    End With
                    Dim lInfo As TableLogOnInfo = tb.LogOnInfo
                    lInfo.ConnectionInfo = cInfo
                    tb.ApplyLogOnInfo(lInfo)
                Next
                Dim str As String = String.Empty

                '/////////////////////////////////////
                'If Not Session("DISPLAY_MEMBERSHIP_NO") Is Nothing Then
                '    rpt.DataDefinition.RecordSelectionFormula = "left({Member_Account_Details;1.DISPLAY_MEMBERSHIP_NO},Len({Member_Account_Details;1.DISPLAY_MEMBERSHIP_NO})-2)='" & Session("DISPLAY_MEMBERSHIP_NO") & "'"
                'End If


                If Session("ReportTitle") IsNot Nothing Then
                    rpt.DataDefinition.FormulaFields("ReportTitle").Text = "'" & Session("ReportTitle") & "'"
                End If
                If Session("Company") IsNot Nothing Then
                    rpt.DataDefinition.FormulaFields("Company").Text = "'" & Session("Company") & "'"
                End If

                If Session("FrmDT") IsNot Nothing And Session("ToDt") IsNot Nothing Then
                    rpt.DataDefinition.FormulaFields("FrmDT").Text = "'" & Session("FrmDT") & "'"
                    rpt.DataDefinition.FormulaFields("ToDt").Text = "'" & Session("ToDt") & "'"
                End If
                'If Session("FrmDT") IsNot Nothing And Session("ToDt") IsNot Nothing Then
                '    rpt.DataDefinition.FormulaFields("FrmDT").Text = "'" & Session("FrmDT") & "'"
                '    rpt.DataDefinition.FormulaFields("ToDt").Text = "'" & Session("ToDt") & "'"
                'End If
                'rpt.SetDataSource(myDS)

                'CrystalReportViewer1.ReportSource = rpt







                Dim DiskOpts As CrystalDecisions.Shared.DiskFileDestinationOptions = New CrystalDecisions.Shared.DiskFileDestinationOptions
                rpt.ExportOptions.ExportDestinationType = CrystalDecisions.[Shared].ExportDestinationType.DiskFile
                rpt.ExportOptions.ExportFormatType = CrystalDecisions.[Shared].ExportFormatType.PortableDocFormat


                'Dim MynameIs As String = Replace(Now.TimeOfDay.ToString, ":", "") 'Replace(Session("RptToPrint"), ".rpt", "")
                Dim MynameIs As String = Session("NAME")
                MynameIs = Replace(MynameIs, ".", "")
                'MynameIs = Replace(MynameIs, " ", "")
                If Not Directory.Exists(ExportedReports) Then
                    Directory.CreateDirectory(ExportedReports)
                End If

                If Session("EXPORT_TYPE") = "PDF" Then
                    DiskOpts.DiskFileName = ExportedReports & "\" & MynameIs & ".PDF"

                    rpt.ExportOptions.DestinationOptions = DiskOpts
                    rpt.Export()
                    Dim Path As String = ExportedReports & "\" & MynameIs & ".PDF"
                    rpt.Refresh()
                    rpt.Close()
                    MailSent = SendLoginDetails(Session("EMPNAME"), Path, Session("RecepientEmail"))

                Else
                    rpt.ExportOptions.ExportFormatType = CrystalDecisions.[Shared].ExportFormatType.Excel
                    DiskOpts.DiskFileName = ExportedReports & "\" & MynameIs & ".xls"

                    rpt.ExportOptions.DestinationOptions = DiskOpts
                    rpt.Export()
                    Dim Path As String = ExportedReports & "\" & MynameIs & ".xls"
                    rpt.Refresh()
                    rpt.Close()
                    MailSent = SendLoginDetails(Session("EMPNAME"), Path, Session("RecepientEmail"))

                End If

                Session("Reportname") = Nothing
                Session("ReportTitle") = Nothing
                Session("SelectionFormula") = Nothing
                Session("EXCEL") = Nothing
                'Response.Redirect(Path, False)



            End If

        Catch ex As Exception

            MyDBAction.DoLogs("Class==ShowReport.vb: Private Sub ShowReport()" & " : Error : " & ex.Message)
        End Try
    End Sub

   

    'Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
    '    ShowReport()
    'End Sub



    Private Sub ReleaseObject(ByVal o As Object)
        Try
            While (System.Runtime.InteropServices.Marshal.ReleaseComObject(o) > 0)
            End While
        Catch
        Finally
            o = Nothing
        End Try
    End Sub
    

    Protected Sub CBOBRANCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles CBOBRANCH.SelectedIndexChanged
        Session("branch") = ""
        Session("branch") = CBOBRANCH.SelectedValue

    End Sub

    Private Function SendLoginDetails(ByVal EmployeeName As String, ByVal path As String, ByVal RecepientEmail As String) As Boolean

        Dim MailSent As Boolean = False

        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""

        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""



        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011

            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()
            MessageSubject = System.Configuration.ConfigurationManager.AppSettings("Subject").Trim()
            ''---Decrypt data


        Catch ex As Exception

        End Try


        Try

            Dim strHTML As New StringBuilder


            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 468px'>")
            strHTML = strHTML.Append("<tr>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("</tr>")
            strHTML = strHTML.Append("<tr>")
            strHTML = strHTML.Append("<td colspan='3'>")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'>DEAR " & EmployeeName & ",")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("RE:STATEMENT.")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("Attached is your monthly Statement for the period between; " & Session("FrmDT") & " and " & Session("ToDT") & ".")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("For further queries and clarification contact Membership Accountant.")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY.")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")

            Dim mymail As New Emailing
            MailSent = mymail.SendNotification(path, MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName)

            'MailSent = mymail.SendNotification2(path, MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName)


            Session("MailSent") = MailSent

        Catch ex As Exception
            MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False

        End Try

        Return MailSent
    End Function
End Class
