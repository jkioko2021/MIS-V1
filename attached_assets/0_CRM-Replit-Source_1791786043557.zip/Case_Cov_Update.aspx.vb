﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False



    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            dtdxdate.DbSelectedDate = Date.Now()

            dtcost.DbSelectedDate = Date.Now()
            DtNotes.DbSelectedDate = Date.Now()
            dtstatus.DbSelectedDate = Date.Now()
            dthomests.DbSelectedDate = Date.Now()

            dtresults.DbSelectedDate = Date.Now()
            Str = "SELECT DISTINCT [Code],[Name]  FROM [dbo].[TBL_MIS_CRM_COV_COMORB] ORDER BY CODE" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbocomor
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Name").ToString
                .DataValueField = MyDatatable.Columns("Code").ToString
                .DataBind()
            End With

            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME]  FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboProvi
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With
            LoadGrid_M()
          
        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            lblno.Text = ""
            lblcode.Text = ""
            lblprov.Text = ""
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
        
            GDCASE_HOME.DataSource = Nothing
            GDCASE_HOME.DataBind()

            If cbosearch.SelectedValue = "M" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) LEFT JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Member_No='" & Trim(txtsearch.Text) & "' AND R.Claim_Type='IP' and R.Case_Status='Open'"
            ElseIf cbosearch.SelectedValue = "C" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) LEFT JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Case_No='" & Trim(txtsearch.Text) & "'  AND R.Claim_Type='IP' and R.Case_Status='Open'"
            ElseIf cbosearch.SelectedValue = "P" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) LEFT JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE P.ORG_NAME LIKE '%" & Trim(txtsearch.Text) & "%'  AND R.Claim_Type='IP' and R.Case_Status='Open'"
            ElseIf cbosearch.SelectedValue = "N" Then
                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) LEFT JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Member_Name LIKE '%" & Trim(txtsearch.Text) & "%'  AND R.Claim_Type='IP' and R.Case_Status='Open'"

            End If

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE.DataSource = MyDatable
                GDCASE.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDCASE.DataSource = Nothing
                GDCASE.DataBind()

            End If
            loadGrid(txtsearch.Text)
        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdsavecom_Click(sender As Object, e As System.EventArgs) Handles cmdsavecom.Click
        Try

            If txtnotesCorm.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(lblno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotesCorm.Text, "COM-NOTES")
            End If
            If cbocomor.SelectedValue <> "" Then
                MyDBAction.TRACKING_COV_COMORB(CDate(dtdxdate.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, lblno.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), lblcode.Text)
            End If

            lblCOMM.Text = "Record updated successfull."
            txtnotesCorm.Text = ""
            dtdxdate.DbSelectedDate = Date.Now()
            cbocomor.SelectedValue = ""
            cbocomor.Text = ""
            loadGrid(lblno.Text)

        Catch ex As Exception
            lblCOMM.Text = ex.Message
        End Try
    End Sub
    Public Sub LoadGrid_M()
        Str = "SELECT R.Case_No, R.Admission_Dt,R.Admission_Status,R.Claim_No, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE  R.Case_Status='Open'  AND R.Claim_Type='IP' order by R.Case_No  desc"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCASE.DataSource = MyDatable
            GDCASE.DataBind()
            Session("DAD0_T") = MyDatable
            MyDatable = Nothing
        Else
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
        End If

        SqlAction = "SELECT R.Case_No, R.Admission_Dt,R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Case_Status='Open' and R.Admission_Status ='Discharged' and R.Claim_Type='IP' order by Discharge_Date DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCASE_HOME.DataSource = MyDatable
            GDCASE_HOME.DataBind()
            Session("DAD1_T") = MyDatable
            MyDatable = Nothing
        Else
            GDCASE_HOME.DataSource = Nothing
            GDCASE_HOME.DataBind()
        End If
      
    End Sub
    Public Sub loadGrid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        GDCOMORM.DataSource = Nothing
        GDCOMORM.DataBind()
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        GDRESULTS.DataSource = Nothing
        GDRESULTS.DataBind()
        GDCOST.DataSource = Nothing
        GDCOST.DataBind()
        
        GDCASE_HOME.DataSource = Nothing
        GDCASE_HOME.DataBind()
        Try
            SqlAction = "SELECT R.Case_No, R.Admission_Dt,R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt,P.ORG_NAME Prov_Name FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Case_Status='Open' and R.Admission_Status ='Discharged' AND R.Member_No='" & STR & "'  and R.Claim_Type='IP'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE_HOME.DataSource = MyDatable
                GDCASE_HOME.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDCASE_HOME.DataSource = Nothing
                GDCASE_HOME.DataBind()
            End If

         

         
            MyDatable = Nothing
            SqlAction = ""
            SqlAction = "SELECT  M.Case_No, M.Member_No, C.Name, M.Id, M.Entered_By,M.Dx_Date FROM   dbo.TBL_MIS_CRM_COV_MEMBER_COMORB M INNER JOIN  dbo.TBL_MIS_CRM_COV_COMORB C ON M.Comorb_code = C.Code WHERE  Member_No ='" & STR & "' order by M.Id desc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCOMORM.DataSource = MyDatable
                GDCOMORM.DataBind()
                MyDatable = Nothing
            Else
                GDCOMORM.DataSource = MyDatable
                GDCOMORM.DataBind()
            End If
            'cost
            MyDatable = Nothing
            SqlAction = ""
            SqlAction = "SELECT [Case_Code],[Cost_Code],[Cost_Date] ,[Cost_Amount],[Entered_By]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_COSTS] WHERE  Case_Code ='" & lblcode.Text & "' ORDER BY Cost_Date DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCOST.DataSource = MyDatable
                GDCOST.DataBind()
                MyDatable = Nothing
            Else
                GDCOST.DataSource = Nothing
                GDCOST.DataBind()
            End If

            MyDatable = Nothing
            SqlAction = ""
            SqlAction = "SELECT ID, [Member_No],[Case_No],[Test_date] ,[Test_Result],[Entered_By]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_MEMBER_RESULTS] WHERE  Member_No ='" & lblno.Text & "' ORDER BY Test_date DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDRESULTS.DataSource = MyDatable
                GDRESULTS.DataBind()
                MyDatable = Nothing
            Else
                GDRESULTS.DataSource = Nothing
                GDRESULTS.DataBind()
            End If
            'Notes
            SqlAction = ""
            SqlAction = "SELECT [Note_id],[Note_Type],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_NOTES] WHERE  Member_No ='" & STR & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDCASE_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCASE.SelectedIndexChanged
        Try
            lblno.Text = ""
            lblcode.Text = ""
            lblCaseH.Text = ""
            lbldp.Text = ""
            txtclaimno.Text = ""
            GDCOMORM.DataSource = Nothing
            GDCOMORM.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            lblcode.Text = (DirectCast(GDCASE.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_No").ToString()
            Str = "SELECT [Case_No] ,Claim_No,Claim_Type,Admission_Dt, [Member_No],Member_Name,Proposer_Name,Client_Type,Transfer_To_Provider,[Pre_Auth_Amt],[Total_Actual_Cost],[Transfer_To_Provider],Facility_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Case_No='" & Trim(lblcode.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                lblprov.Text = MyDatable.Rows(0).Item("Transfer_To_Provider").ToString()
                txtauth.Text = MyDatable.Rows(0).Item("Pre_Auth_Amt").ToString()
                txtactual.Text = MyDatable.Rows(0).Item("Total_Actual_Cost").ToString()
                txtclaimno.Text = MyDatable.Rows(0).Item("Claim_No").ToString()
                lbldp.Text = MyDatable.Rows(0).Item("Claim_No").ToString()

                dtadmin.DbSelectedDate = MyDatable.Rows(0).Item("Admission_Dt").ToString()
                cboclaimtype.SelectedValue = MyDatable.Rows(0).Item("Claim_Type").ToString()
                txtmemno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                cboclient.SelectedValue = MyDatable.Rows(0).Item("Client_Type").ToString()
                cboProvi.SelectedValue = MyDatable.Rows(0).Item("Transfer_To_Provider").ToString()
                cboprovtype.SelectedValue = MyDatable.Rows(0).Item("Facility_Type").ToString()
                txtDPno.Text = MyDatable.Rows(0).Item("Claim_No").ToString()
                loadGrid(lblno.Text)


            End If
            lblcode.Enabled = False

            dtadmin.Enabled = False
            cbocomor.Enabled = False
            txtname.Enabled = False
            txtmemno.Enabled = False
            txtprop.Enabled = False
            cboclient.Enabled = False
            cboProvi.Enabled = False
            cboprovtype.Enabled = False
            txtauth.Enabled = False
            cboclaimtype.Enabled = False

            cmdsave.Enabled = False
            cmdsave.Enabled = True
        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub

   

    Protected Sub btncost_Click(sender As Object, e As System.EventArgs) Handles btncost.Click
        Try
            If txtcost.Text = "" Or txtcost.Text = 0 Then
                lblerrcost.Text = "You Must enter Cost."
                Exit Sub
            End If
            If lblcode.Text = "" Then
                lblerrcost.Text = "You Must Select Case no"
                Exit Sub
            End If
            If txtcostnotes.Text = "" Then
                lblerrcost.Text = "You Must Enter Short Notes"
                Exit Sub
            End If
            If cbocost.SelectedValue = "" Then
                lblerrcost.Text = "You Must Select Cost Type"
                Exit Sub
            End If

            If txtcostnotes.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(lblno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcostnotes.Text, "COST-NOTES")
            End If
            If cbocost.SelectedValue <> "" Then
                MyDBAction.TRACKING_COV_COST(lblcode.Text, lblprov.Text, cbocost.SelectedValue, CDate(dtcost.DbSelectedDate).ToString("yyyy-MM-dd"), txtauth.Text, txtcost.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcostnotes.Text)
            End If
            lblerrcost.Text = "Cost updated successfull."
            lblprov.Text = ""
            cbocost.SelectedValue = ""
            txtactual.Text = 0
            txtcost.Text = 0

            Str = "SELECT  [Total_Actual_Cost]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Case_No='" & Trim(lblcode.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txtactual.Text = MyDatable.Rows(0).Item("Total_Actual_Cost").ToString()
            End If
 
            loadGrid(lblno.Text)
        Catch ex As Exception
            lblerrcost.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnnotes_Click(sender As Object, e As System.EventArgs) Handles btnnotes.Click
        Try
       
            If lblcode.Text = "" Then
                lblerrcost.Text = "You Must Select Case no"
                Exit Sub
            End If
            If txtadmnotes.Text = "" Then
                lblerrcost.Text = "You Must Enter Short Notes"
                Exit Sub
            End If
            If txtadmnotes.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(lblno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtadmnotes.Text, "ADM-NOTES")
            End If
            
            lblnotes.Text = "Notes updated successfull."
            txtadmnotes.Text = ""
            DtNotes.DbSelectedDate = Date.Now()
            loadGrid(lblno.Text)
        Catch ex As Exception
            lblnotes.Text = ex.Message
        End Try
    End Sub


    Protected Sub btnstatus_Click(sender As Object, e As System.EventArgs) Handles btnstatus.Click
        Try
            If lblcode.Text = "" Then
                lblsts.Text = "You Must Select the Case No!"
                Exit Sub
            End If
            If cboadmstatus.SelectedValue = "" Then
                lblsts.Text = "You Must Select Admission status"
                Exit Sub
            End If
            If txtstatusnotes.Text = "" Then
                lblsts.Text = "You Must Enter Short Notes"
                Exit Sub
            End If
            If cbostatus.SelectedValue = "" Then
                lblsts.Text = "You Must Select Case Status"
                Exit Sub
            End If
        
            If txtclaimno.Text = "" Then
                lblsts.Text = "You Must Enter DP No."
                Exit Sub
            End If
           

            If txtstatusnotes.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(lblno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtstatusnotes.Text, "ADM-NOTES")
            End If
            If cbostatus.SelectedValue = "Open" And cboadmstatus.SelectedValue = "Discharged" Then
                UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET   Claim_No='" & txtclaimno.Text & "', [Admission_Status]='" & cboadmstatus.SelectedValue & "', [Case_Status]='" & cbostatus.SelectedValue & "',[Discharge_Date]='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "', Discharge_By='" & Session("username") & "' where [Case_No]='" & lblcode.Text & "'")
                'UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET Recovery_Status='" & cborecovery.SelectedValue & "'   where [Member_No]='" & lblno.Text & "'")

            ElseIf cbostatus.SelectedValue = "Open" And cboadmstatus.SelectedValue = "Admitted" Then

                UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET Claim_No='" & txtclaimno.Text & "', [Admission_Status]='" & cboadmstatus.SelectedValue & "', [Case_Status]='" & cbostatus.SelectedValue & "',[Admission_Dt]='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "' where [Case_No]='" & lblcode.Text & "'")

            ElseIf cbostatus.SelectedValue = "Closed" And cboadmstatus.SelectedValue = "Discharged" Then
             
                UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET Claim_No='" & txtclaimno.Text & "', [Admission_Status]='" & cboadmstatus.SelectedValue & "', [Case_Status]='" & cbostatus.SelectedValue & "',[Discharge_Date]='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "', Discharge_By='" & Session("username") & "',Closed_By='" & Session("username") & "',Close_Date='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "' where [Case_No]='" & lblcode.Text & "'")
            ElseIf cboadmstatus.SelectedValue = "Deceased" Then
                UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET Last_Exp_Date='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "',Last_Expense=1, Claim_No='" & txtclaimno.Text & "', [Admission_Status]='" & cboadmstatus.SelectedValue & "', [Case_Status]='Closed',[Discharge_Date]='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "', Discharge_By='" & Session("username") & "',Closed_By='" & Session("username") & "',Close_Date='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "' where [Case_No]='" & lblcode.Text & "'")
            Else
                lblsts.Text = "You Must do correct selection!"
                Exit Sub
            End If

            lblsts.Text = "Case updated successfull."
            cboadmstatus.Text = ""
            cboadmstatus.SelectedValue = ""
            cbostatus.Text = ""
         
            cbostatus.SelectedValue = ""
            txtstatusnotes.Text = ""
            dtstatus.DbSelectedDate = Date.Now()
            loadGrid(lblno.Text)
        Catch ex As Exception
            lblsts.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDCASE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDCASE.PageIndexChanged
        GDCASE.CurrentPageIndex = e.NewPageIndex
        GDCASE.DataSource = Session("DAD0_T")
        GDCASE.DataBind()
    End Sub
    Protected Sub GDCASE_HOME_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDCASE_HOME.PageIndexChanged
        GDCASE_HOME.CurrentPageIndex = e.NewPageIndex
        GDCASE_HOME.DataSource = Session("DAD1_T")
        GDCASE_HOME.DataBind()
    End Sub


    Protected Sub GDCASE_HOME_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCASE_HOME.SelectedIndexChanged
        Try
            lblCaseH.Text = ""
            lblCaseH.Text = (DirectCast(GDCASE_HOME.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_No").ToString()
            Str = "SELECT  [Claim_No]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Case_No='" & Trim(lblCaseH.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lbldp.Text = MyDatable.Rows(0).Item("Claim_No").ToString()
            End If
            'SqlAction = "SELECT [Note_id],[Note_Type],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_NOTES] WHERE  CASE_CODE ='" & lblCaseH.Text & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
            'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatable.Rows.Count > 0 Then
            '    GDNOTES.DataSource = MyDatable
            '    GDNOTES.DataBind()
            '    MyDatable = Nothing
            'Else
            '    GDNOTES.DataSource = Nothing
            '    GDNOTES.DataBind()
            'End If
        Catch ex As Exception
            lblhome.Text = ex.Message
        End Try
    End Sub
    Protected Sub btnhome_Click(sender As Object, e As System.EventArgs) Handles btnhome.Click
        Try
            If lblCaseH.Text = "" Then
                lblhome.Text = "You Must select the Case to close"
                Exit Sub
            End If
            If lbldp.Text = "" Then
                lblhome.Text = "You Must Update the Claim No"
                Exit Sub
            End If

            If txthomenotes.Text = "" Then
                lblhome.Text = "You Must Enter Short Notes"
                Exit Sub
            End If
            If cbohomests.SelectedValue = "" Then
                lblhome.Text = "You Must Select Case Status"
                Exit Sub
            End If
            

            If txtcostnotes.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(lblno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txthomenotes.Text, "ADM-NOTES")
            End If

            If cbohomests.Text = "Deceased" Then
                UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET  Last_Exp_Date='" & CDate(dtstatus.DbSelectedDate).ToString("yyyy-MM-dd") & "',Last_Expense=1, Admission_Status='Deceased', [Case_Status]='Closed', Closed_By='" & Session("username") & "',Close_Date='" & CDate(dthomests.DbSelectedDate).ToString("yyyy-MM-dd") & "' where [Case_No]='" & lblCaseH.Text & "'")

            Else
                UpdateRecord("UPDATE [TBL_MIS_CRM_COV_REGISTER] SET  Admission_Status='Discharged', [Case_Status]='" & cbohomests.SelectedValue & "', Closed_By='" & Session("username") & "',Close_Date='" & CDate(dthomests.DbSelectedDate).ToString("yyyy-MM-dd") & "' where [Case_No]='" & lblCaseH.Text & "'")

            End If

            lblhome.Text = "Case updated successfull."
            txthomenotes.Text = ""

            cbohomests.Text = ""
            cbohomests.SelectedValue = ""
       
            dtstatus.DbSelectedDate = Date.Now()
            LoadGrid_M()

        Catch ex As Exception
            lblhome.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDCOMORM_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDCOMORM.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("Id").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""

            DeleteRecord("DELETE FROM   [dbo].[TBL_MIS_CRM_COV_MEMBER_COMORB] WHERE Id='" & HiddenField1.Value.ToString & "'")
          
            Dim audit As New DataManagement
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Comorbidity Delete", "Deleted Record :-   :" & lblcode.Text & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblErr.Text = "Record Deleted!"
            'CmdSave.Enabled = False


            loadGrid(lblno.Text)

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub

   
   
  
    Protected Sub btnresult_Click(sender As Object, e As System.EventArgs) Handles btnresult.Click
        Try
            If lblcode.Text = "" Then
                lblerrresul.Text = "You Must select the Case to update"
                Exit Sub
            End If

            If txtresultnotes.Text = "" Then
                lblerrresul.Text = "You Must Enter Short Notes"
                Exit Sub
            End If

            If txtresultnotes.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(lblno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtresultnotes.Text, "RESULT-NOTES")
            End If
            If cboresults.SelectedValue <> "" Then
                MyDBAction.TRACKING_COV_RESULT(lblno.Text, lblcode.Text, cboresults.SelectedValue, CDate(dtresults.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"))

            End If
            lblerrresul.Text = "Results updated successfull."
            txtresultnotes.Text = ""
            cboresults.SelectedValue = ""
            cboresults.Text = ""
            dtresults.DbSelectedDate = Date.Now()
            loadGrid(lblno.Text)

        Catch ex As Exception
            lblerrresul.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim adm_status As String = ""
            Dim case_status As String = ""
            If cboclaimtype.SelectedValue = "IP" Then
                adm_status = "Admitted"
                case_status = "Open"
            Else
                adm_status = "Discharged"
                case_status = "Closed"
            End If
            MyDBAction.Covid_reg(lblcode.Text, "", CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, txtname.Text, txtmemno.Text, txtprop.Text, cboclient.SelectedValue, cboProvi.SelectedValue, cboProvi.SelectedValue, cboprovtype.SelectedValue, txtauth.Text, adm_status, cboclaimtype.SelectedValue, case_status, Session("UserName").ToString, Trim(txtclaimno.Text), 1)

            lblerr_f.Text = "Updated Successful!"
          
            HiddenField1.Value = 0
            lblcode.Text = ""

            dtadmin.DbSelectedDate = Date.Now()
            cbocomor.SelectedValue = ""
            txtname.Text = ""
            txtmemno.Text = ""
            txtprop.Text = ""
            txtclaimno.Text = ""
            cboclient.SelectedValue = ""
            cboProvi.SelectedValue = ""
            cboProvi.SelectedValue = ""
            cboprovtype.SelectedValue = ""
            txtauth.Text = ""
            cboclaimtype.SelectedValue = ""

            lblcode.Enabled = True

            dtadmin.Enabled = True
            cbocomor.Enabled = True
            txtname.Enabled = True
            txtmemno.Enabled = True
            txtprop.Enabled = True
            cboclient.Enabled = True
            cboProvi.Enabled = True
            cboProvi.Enabled = True
            cboprovtype.Enabled = True
            txtauth.Enabled = True
            cboclaimtype.Enabled = True

            cmdedit.Enabled = True
            cmdsave.Enabled = True
        Catch ex As Exception
            lblerr_f.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdedit_Click(sender As Object, e As System.EventArgs) Handles cmdedit.Click
        lblcode.Enabled = True

        dtadmin.Enabled = True
        cbocomor.Enabled = True
        txtname.Enabled = True
        txtmemno.Enabled = True
        txtprop.Enabled = True
        cboclient.Enabled = True
        cboProvi.Enabled = True
        cboProvi.Enabled = True
        cboprovtype.Enabled = True
        txtauth.Enabled = True
        cboclaimtype.Enabled = True

        cmdedit.Enabled = True
        cmdsave.Enabled = True
    End Sub
End Class
