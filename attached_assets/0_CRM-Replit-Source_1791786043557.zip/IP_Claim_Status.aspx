﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="IP_Claim_Status.aspx.vb" Inherits="_Default" %>


<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="IP CLAIM SEARCH"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1121px">
                            <table style="width: 97%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel36" runat="server">
                                            <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                Width="1102px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td style="width: 2860px">
                                                            <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                                                Text="Search By"></asp:Label>
                                                        </td>
                                                        <td style="width: 138px">
                                                            <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                                                <Items>
                                                                    <telerik:RadComboBoxItem runat="server" Text="Invoice No" Value="I" />
                                                                    <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                                    <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                                    <telerik:RadComboBoxItem runat="server" Text="File_No" Value="F" />
                                                                </Items>
                                                            </telerik:RadComboBox>
                                                        </td>
                                                        <td>
                                                            &nbsp;</td>
                                                        <td>
                                                            <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td>
                                                            <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                                            </telerik:RadButton>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </asp:Panel>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="Label163" runat="server" Text="IP Claims"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                            SortExpression="File_No" UniqueName="File_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Submit_dt" 
                                                            FilterControlAltText="Filter Submit_dt column" HeaderText="Submit_dt" 
                                                            SortExpression="Submit_dt" UniqueName="Submit_dt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                            ItemStyle-Wrap="False" SortExpression="Member_Name" UniqueName="Member_Name">
                                                            <ItemStyle Wrap="False" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_No" 
                                                            FilterControlAltText="Filter Invoice_No column" HeaderText="Invoice_No" 
                                                            SortExpression="Invoice_No" UniqueName="Invoice_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_Amt" 
                                                            DataFormatString="{0:###,##0.0}" 
                                                            FilterControlAltText="Filter Invoice_Amt column" HeaderText="Invoice_Amt" 
                                                            SortExpression="Invoice_Amt" UniqueName="Invoice_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Provider_Name" 
                                                            FilterControlAltText="Filter Provider_Name column" HeaderText="Provider_Name" 
                                                            SortExpression="Provider_Name" UniqueName="Provider_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_type" 
                                                            FilterControlAltText="Filter Invoice_type column" HeaderText="Invoice_type" 
                                                            SortExpression="Invoice_type" UniqueName="Invoice_type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Inv_Status" 
                                                            FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
                                                            SortExpression="Inv_Status" UniqueName="Inv_Status">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Discharge_By" 
                                                            FilterControlAltText="Filter Discharge_By column" HeaderText="Discharge_By" 
                                                            SortExpression="Discharge_By" UniqueName="Discharge_By">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label102" runat="server" Text="Receive Date"></asp:Label>
                                    </td>
                                    <td style="width: 194px">
                                        <telerik:RadDatePicker ID="dtreceive" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        <asp:Label ID="Label128" runat="server" Text="Service Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtservice" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label130" runat="server" Text="Bar Code"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtbarcode" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label126" runat="server" Text="Member No."></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Sunset" Width="250px" 
                                            EmptyMessage="KE123456700">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8">
                                        <asp:Label ID="Label154" runat="server" Text="Member Name."></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label105" runat="server" Text="Invoice No"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtinv_no" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        <asp:Label ID="Label106" runat="server" Text="Invoice Amt"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadNumericTextBox ID="txtinv_amt" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label159" runat="server" style="font-weight: 700" Text="Country"></asp:Label>
                                    </td>
                                    <td style="width: 194px">
                                        <telerik:RadComboBox ID="cbocountry" Runat="server" MarkFirstMatch="True" 
                                            Skin="Sunset" Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="AIK" Value="AIK" />
                                                <telerik:RadComboBoxItem runat="server" Text="AIT" Value="AIT" />
                                                <telerik:RadComboBoxItem runat="server" Text="AHS" Value="AHS" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        <asp:Label ID="Label160" runat="server" style="font-weight: 700" 
                                            Text="Proposer"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label161" runat="server" style="font-weight: 700" 
                                            Text="Invoice Type"></asp:Label>
                                    </td>
                                    <td style="width: 194px">
                                        <telerik:RadComboBox ID="cbotype" Runat="server" Skin="Simple" Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Normal" 
                                                    Value="Normal" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" 
                                                    Text="P &amp; I (Full Pay)" Value="P &amp; I (Full Pay)" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cbotype" 
                                                    Text="P &amp; I (Part Pay)" Value="P &amp; I (Part Pay)" />
                                                <telerik:RadComboBoxItem runat="server" Text="Intercompany" 
                                                    Value="Intercompany" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" bgcolor="#999999" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label155" runat="server" style="font-weight: 700" 
                                            Text="Amt Payable(Benefit)"></asp:Label>
                                    </td>
                                    <td style="width: 194px">
                                        <telerik:RadNumericTextBox ID="txtpayable" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8">
                                        <asp:Label ID="Label156" runat="server" style="font-weight: 700" 
                                            Text="Amt Payable(P &amp; I)"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txtpayP_I" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Label148" runat="server" Text="File Number"></asp:Label>
                                    </td>
                                    <td style="width: 194px">
                                        <asp:Label ID="lblfile" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 191px">
                                        <asp:Label ID="Disch" runat="server"></asp:Label>
                                    </td>
                                    <td style="width: 194px">
                                        <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 105px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr style="width: 1107px" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel2" runat="server" Width="1118px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel32" runat="server" Height="100%" Width="1111px">
                                                            <table style="width: 99%">
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                                            Width="1100px">
                                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </RowIndicatorColumn>
                                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </ExpandCollapseColumn>
                                                                                    <Columns>
                                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                                        </telerik:GridBoundColumn>
                                                                                      
                                                                                    </Columns>
                                                                                    <EditFormSettings>
                                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                        </EditColumn>
                                                                                    </EditFormSettings>
                                                                                </MasterTableView>
                                                                                <FilterMenu EnableImageSprites="False">
                                                                                </FilterMenu>
                                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                </HeaderContextMenu>
                                                                            </telerik:RadGrid>
                                                                        </asp:Panel>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                </tr>
                                                            </table>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1115px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" ItemStyle-Wrap ="True"
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                            <ItemStyle Wrap="True" />
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="True" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
        
    </asp:UpdatePanel>
</asp:Content>

