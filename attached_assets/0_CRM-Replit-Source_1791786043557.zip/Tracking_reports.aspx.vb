﻿
Imports DocManage.DataManagement
Imports System.Data
Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class Default2
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            loadListBox()
        End If

    End Sub

    Private Sub loadListBox()
        Try
            Dim MyDatatable As DataTable : Dim Str As String

            Str = "SELECT Rpt_Code, Rpt_Name FROM [dbo].[MainReports] where Is_Active=1"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With MainRptRad
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Rpt_Name").ToString
                .DataValueField = MyDatatable.Columns("Rpt_Code").ToString
                .DataBind()

            End With
            MyDatatable = Nothing

        Catch ex As Exception
            'LblErr.Text = ex.Message.ToString
            'Panel3.Visible = True
            'MyDBAction.DoLogs("Class==Standard_Reports.vb: Private Sub loadCombo()" & " : Error : " & ex.Message)
        End Try

        Try
            Dim MyDatatable As DataTable : Dim Str As String

            Str = ""




        Catch ex As Exception
            LblErr.Text = ex.Message.ToString
            Panel3.Visible = True
            MyDBAction.DoLogs("Class==Standard_Reports.vb: Private Sub loadCombo()" & " : Error : " & ex.Message)
        End Try


        'LblErr.Text = ex.Message.ToString
        'Panel3.Visible = True
        'MyDBAction.DoLogs("Class==Standard_Reports.vb: Private Sub loadCombo()" & " : Error : " & ex.Message)


    End Sub
    Protected Sub MainRptRad_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MainRptRad.SelectedIndexChanged
        Try
            Dim MyDatatable As DataTable : Dim Str As String
            Str = MainRptRad.SelectedValue

            Str = "SELECT Sub_Rpt_Code,Sub_Rpt_Name  FROM [dbo].[Sub_Reports] where Is_Active=1 and Can_Access=1 and Main_Rpt_Code ='" & MainRptRad.SelectedValue & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With SubRadRpt

                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Sub_Rpt_Name").ToString
                .DataValueField = MyDatatable.Columns("Sub_Rpt_Name").ToString
                .DataBind()

            End With
            MyDatatable = Nothing

        Catch ex As Exception
            'LblErr.Text = ex.Message.ToString
            'Panel3.Visible = True
            'MyDBAction.DoLogs("Class==Standard_Reports.vb: Private Sub loadCombo()" & " : Error : " & ex.Message)
        End Try
    End Sub

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Str_Live As String = ""
            Dim sp_name As String = ""
            Dim StrQuery As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MemberNo As String = ""
            Dim MemberNo_Family As String = ""
            Dim QuotationNo As String = ""
            Dim InvoiceNo As String = ""
            Dim EntryDate_From As String = ""
            Dim ValidAsAT As String = ""
            Dim EntryDate_To As String = ""
            Dim PolicyDate_From As String = ""
            Dim PolicyDate_To As String = ""
            Dim ReceiptNo As String = ""
            Dim PolicyCode As String = ""
            Dim Proposer As String = ""
            Dim CorporateName As String = ""
            Dim ClaimNo As String = ""
            Dim Agency As String = ""
            Dim ClaimRegDate_From As String = ""
            Dim ClaimRegDate_To As String = ""
            Session("Mytable") = ""
            Session("EntryDate_From") = Nothing
            Session("EntryDate_To") = Nothing
            Session("MemberNo") = Nothing
            Session("PolicyDate_From") = Nothing
            Session("PolicyDate_To") = Nothing
            Session("EXCEL") = Nothing
            Session("FrmDT") = Nothing
            Session("ToDt") = Nothing


            If chkexcel.Checked = True Then
                Session("EXCEL") = "TO EXCEL"
            End If
            Session("Reportname") = Nothing
            If SubRadRpt.SelectedIndex <> -1 Then
                Reportname = SubRadRpt.SelectedValue
                Session("FrmDT") = dtDateFrom.DbSelectedDate
                Session("ToDt") = dtDateTo.DbSelectedDate

                Select Case SubRadRpt.SelectedValue

                    Case "Card Reprint List"
                        Str = "SELECT Transaction_Date,Register_Date,Request_Date, FILENO,Member_Number,Member_Name,Receipt_Number,Allocated_To,Requested,Received,Dispatched,Dispatched_To,Photocard FROM TBL_CARD_ALLOCATION WITH (NOLOCK) WHERE Register_Date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' "
                    Case "Cards Not Allocated"
                        Str = "SELECT Transaction_Date,Register_Date, FILENO,Member_Number,Member_Name,Receipt_Number,Allocated_To,Requested,Received,Dispatched FROM TBL_CARD_ALLOCATION WITH (NOLOCK) where Allocated=0 and Register_Date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' "
                    Case "Cards Not Requested"
                        Str = "SELECT Transaction_Date,Register_Date, FILENO,Member_Number,Member_Name,Receipt_Number,Allocated_To,Requested,Received,Dispatched FROM TBL_CARD_ALLOCATION WITH (NOLOCK) where Allocated=1 AND Requested=0 and Register_Date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' "
                    Case "Cards Not Received"
                        Str = "SELECT Transaction_Date,Register_Date, FILENO,Member_Number,Member_Name,Receipt_Number,Allocated_To,Requested,Received,Dispatched FROM TBL_CARD_ALLOCATION WITH (NOLOCK) where Allocated=1 AND Requested=1 and Received=0 and Register_Date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' "
                    Case "Cards Not Dispatched"
                        Str = "SELECT Transaction_Date,Register_Date, FILENO,Member_Number,Member_Name,Receipt_Number,Allocated_To,Requested,Received,Dispatched FROM TBL_CARD_ALLOCATION WITH (NOLOCK) where Allocated=1 AND Requested=1 and Received=1 and Dispatched=0 and Register_Date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' "
                    Case "Cards Dispatched"
                        Str = "SELECT Transaction_Date,Register_Date, FILENO,Member_Number,Member_Name,Receipt_Number,Allocated_To,Requested,Received,Dispatched,Dispatched_To FROM TBL_CARD_ALLOCATION WITH (NOLOCK) where Allocated=1 AND Requested=1 and Received=1 and Dispatched=1 and Register_Date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' "

                    Case "Daily Tracking List"
                        Str = "SELECT T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status, T.Returned,T.Return_Received, T.Entered_by, T.Returned_To, T.Assigned_To,T.Ack,T.Ack_Date, T.Card_activated,T.Members_updated,Members_update_date, T.Card_requested, T.Card_Req_Date,T.Card_Dis, T.Card_Dis_Date, T.Card_Dis_To, T.Policy_Doc_Gen,T.Policy_Date_Gen,T.Policy_Dispatched,T.Policy_Date_Disp, T.Policy_Disp_To,T.Closed,T.Date_terminated AS Date_Closed, T.Filed,T.Consent_Received,T.Policy_Code,T.Invoice_No,T.Invoice_Dt,T.Period_From,T.Period_To,T.Receipt_Dt,T.Sign_Dt,T.Assigned_To FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS  WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID  WHERE T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "Daily Tracking List (Comments)"
                        Str = "SELECT T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status, T.Returned,T.Return_Received, T.Entered_by, T.Returned_To, T.Assigned_To,T.Ack,T.Ack_Date, T.Card_activated,T.Members_updated,Members_update_date, T.Card_requested, T.Card_Req_Date,T.Card_Dis, T.Card_Dis_Date, T.Card_Dis_To, T.Policy_Doc_Gen,T.Policy_Date_Gen,T.Policy_Dispatched,T.Policy_Date_Disp, T.Policy_Disp_To,T.Closed,T.Date_terminated AS Date_Closed, T.Filed,T.Consent_Received,T.Code_Receive_Date,T.Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS  WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID  WHERE T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"


                    Case "Allocted Pending Acknowledge"
                        Str = "SELECT T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status,  T.Assigned_To,Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK)  left JOIN dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID Where Complete_Business=1 and Ack=0 and T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Pending Card Request"
                        Str = "SELECT T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status,  T.Assigned_To,Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID Where Complete_Business=1 and Ack=1 and Card_requested=0 and T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Pending Card Dispatch"
                        Str = "SELECT    T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status,  T.Assigned_To,Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID Where Complete_Business=1 and Ack=1 and Card_requested=1 and Card_Dis=0 and T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Policy Document Not Generated"
                        Str = "SELECT    T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status,  T.Assigned_To,Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID Where Complete_Business=1 and Ack=1 and Card_requested=1 and Card_Dis=1 and Policy_Doc_Gen=0 and T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Policy Doc Not Dispatched"
                        Str = "SELECT    T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status,  T.Assigned_To,Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID Where Complete_Business=1 and Ack=1 and Card_requested=1 and Card_Dis=1 and Policy_Doc_Gen=1 and Policy_Dispatched=0 and T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Business Not Filed"
                        Str = "SELECT    T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status,  T.Assigned_To,Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID Where Complete_Business=1 and Ack=1 and Card_requested=1 and Card_Dis=1 and Policy_Doc_Gen=1 and Policy_Dispatched=1 and Filed=0 and T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Business Filed"
                        Str = "SELECT    T.Mem_Receive_date Receive_date, T.File_No,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Status,  T.Assigned_To,Membership_Comments FROM dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID Where Complete_Business=1 and Ack=1 and Card_requested=1 and Card_Dis=1 and Policy_Doc_Gen=1 and Policy_Dispatched=1 and Filed=1 and T.Mem_Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Non-Medical List"
                        Str = "SELECT DISTINCT File_No,NEW_RENEWAL,PROPOSER,Receive_date,PREMIUM,T.AGENT_ID, A.AGENT_NAME FROM TBL_TRACK_NON_MED T WITH (NOLOCK) left JOIN dbo.TBL_MIS_SALES_AGENTS A WITH (NOLOCK) ON T.AGENT_ID = A.USER_ID  where Receive_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "Files Not-Returned"
                        Str = "SELECT Req_No,Member_No,Proposer_Name,Request_Date,Requested_By,Department FROM dbo.TBL_FILE_REQUEST WITH (NOLOCK) WHERE File_Requested=1 and File_Released=1 and File_Returned=0"
                    Case "Files Not-Dispatched"
                        Str = "SELECT Req_No,Member_No,Proposer_Name,Request_Date,Requested_By,Department FROM dbo.TBL_FILE_REQUEST WITH (NOLOCK) WHERE File_Requested=1 and File_Released=0 and File_Returned=0"
                    Case "Files Returned"
                        Str = "SELECT Req_No,Member_No,Proposer_Name,Request_Date,Requested_By,Department FROM dbo.TBL_FILE_REQUEST WITH (NOLOCK) WHERE File_Requested=1 and File_Released=1 and File_Returned=1"
                    Case "Files Over-Due"
                        Str = "SELECT Req_No,Member_No,Proposer_Name,Request_Date,Requested_By,Department FROM dbo.TBL_FILE_REQUEST WITH (NOLOCK) WHERE File_Requested=1 and File_Released=1 and File_Returned=0 and DATEDIFF(day,Request_Date,Exp_Return_Date)>=1"

                    Case "CARD REGISTER-TAT SUMMARY"
                        Str = "select * from [VW_MIS_CARD_END_TO_END_TAT]"

                    Case "CARD REGISTER-SUMMARY PER MONTH"
                        Str = "select * from dbo.VW_MIS_CARD_REGISTER"

                    Case "CARD REGISTER-SUMMARY PER DAY"
                        Str = "select * from dbo.VW_MIS_CARD_DAILY_REGISTER WHERE Register_date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"


                    Case "MEMBERSHIP REGISTER-SUMMARY PER DAY"
                        Str = "SELECT * FROM [VW_MEMBERSHIP_REG_SUMMARY] WHERE Receive_Date BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "MEMBERSHIP REGISTER-SUMMARY PER MONTH"
                        Str = "SELECT * FROM dbo.VW_MEMBERSHIP_SUMMARY"
                    Case "MEMBERSHIP REGISTER-MONTHLY TAT PER ITEM"
                        Str = "SELECT * FROM [VW_MEMBERSHIP_DETAILED_TAT]"
                    Case "MEMBERSHIP_PROD-USER LEVEL"
                        Str = "SELECT * FROM [VW_MEMBERSHIP_PRODU_USER_LEVEL]"
                    Case "MEMBERSHIP_TAT-USER_LEVEL"
                        Str = "SELECT * FROM dbo.VW_MEMBERSHIP_TAT_USER_LEVEL"
                 
                        '----------------------------------------FINANCE
                                                   Case "Debtors ageing"
                        Str = "SELECT  [PROPOSER_ID],[POLICY_CODE],['0-30 Days'],['31-60 Days'],['61-90 Days'],['91-120 Days'],['121-180 Days'],['181-240 Days'],['241-300 Days'],['301-365 Days']  FROM [SALES].[dbo].[VW_MIS_DEBTORS_AGEING] FROM [SALES].[dbo].[VW_MIS_DEBTORS_AGEING]"

                    Case "Debtors Listing-Outstanding"
                        Str = "SELECT [AGREEMENT_DATE],[FILE_NO],[CORPORATE_NAME],[TOT_AMT_PAYABLE],[TOT_AMT_PAID],[TOT_BALANCE],[ACCPAC_NO],[DUE_DATE],[ENTRY_DATE],[ACC_MGR]  FROM [SALES].[dbo].[VW_DEBTOR_LISTING] WHERE TOT_BALANCE>0  "

                    Case "Debtors Listing-Paid"
                        Str = "SELECT [AGREEMENT_DATE],[FILE_NO],[CORPORATE_NAME],[TOT_AMT_PAYABLE],[TOT_AMT_PAID],[TOT_BALANCE],[ACCPAC_NO],[DUE_DATE],[ENTRY_DATE],[ACC_MGR]  FROM [SALES].[dbo].[VW_DEBTOR_LISTING] WHERE TOT_BALANCE=0  "
                    Case "Premium Refunds"
                        Str = "SELECT R.FILE_NO, R.PROPOSER_NAME, R.RECEIPT_NO, R.RECEIPT_DATE, R.AGENT_ID,R.AMOUNT, R.ENTRY_DATE, R.ENTERED_BY, R.APPROVED, R.APPROVED_BY,R.APPROVED_DATE, R.VERIFIED, R.VERIFIED_BY, R.VERIFIED_DATE, R.APPROVER_2_APPROVE,R.APPROVER_2_BY, R.APPROVER_2_DATE, R.PAID, A.AGENT_NAME,r.FAMILY_NO,r.COMMENT FROM  dbo.TBL_MIS_REFUND_SCHEDULE R LEFT JOIN dbo.TBL_MIS_SALES_AGENTS A ON R.AGENT_ID = A.USER_ID WHERE (R.ACTIVE = 1 AND R.ENTRY_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "')"

                        '-------------------------------------------Case management

                    Case "IP Register Listing"
                        Str = "SELECT  BARCODE,[FILE_NO],[INVOICE_NO],[INVOICE_AMT],[CARE_MGR],[RECEIVE_DT],[ALLOCATED_DT],[RESOLVE_DT],[CLAIM_ACK_DT],PROVIDER_NAME,PROVIDER,[STATUS],COMMENT  FROM [SALES].[dbo].[VW_IP_INV_REGISTER] WHERE RECEIVE_DT BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "IP Register Summary"
                        Str = "SELECT * FROM [VW_IP_INV_REGISTER_STATUS] "
                    Case "Claim Rejections"
                        Str = "SELECT *  FROM [SALES].[dbo].[TBL_MIS_INVOICE_REJECTIONS] WHERE ENTRY_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "IP Register Resolved_TAT"
                        Str = "SELECT * FROM dbo.VW_IP_CARE_TAT "

                    Case "IP Register-Not Resolved TAT"
                        Str = "SELECT * FROM VW_ALLOCATES_NOT_ACTIONED"

                    Case "IP Queries"
                        Str = "SELECT * FROM [VW_IP_INV_REGISTER_QUERIES]"

                    Case "IP Queries TAT"
                        Str = "SELECT * FROM [VW_IP_CARE_TAT_QUERIES]"

                        '--------------------------------------------------------------CLAIMS
                    Case "Capitation Report"
                        Str = "SELECT * FROM TBL_MIS_CAPITATION WHERE RECEIVE_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "Claims Received Register"
                        Str = "SELECT * FROM VW_MIS_CLAIMS_REC_REGISTER WHERE RECEIVE_DT BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "IP Claims Register"
                        Str = " select * from dbo.VW_IP_TRACKING_LIST WHERE RECEIVE_DT BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "OFF-Smart Approvals"
                        Str = "SELECT [APPROVAL_NO],[MEMBER_NO],[MEMBER_NAME],[BENEFIT],[PROVIDER_NAME],[INVOICE_NO],[INVOICE_AMT],[TRANSACTION_DATE],[REASON],[INV_STATUS],[ENTRY_DATE],[AUTHORIZED_BY],[BILLING_DATE],[BILL_VERIFIED],[VERIFIED_BY],[VERIFIED_DATE]  FROM [SALES].[dbo].[TBL_MIS_OFFSMART_APPROVALS] WHERE ENTRY_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "Claims Query Tracking"
                        Str = "SELECT dbo.TBL_MIS_QUERY_TRACKING.FILE_NO, dbo.TBL_MIS_QUERY_TRACKING.RECEIVE_DT, dbo.TBL_MIS_QUERY_TRACKING.SERVICE_DT, dbo.TBL_MIS_QUERY_TRACKING.CLAIM_TYPE, dbo.TBL_MIS_QUERY_TRACKING.MEMBER_NO, " & _
                              "dbo.TBL_MIS_QUERY_TRACKING.MEMBER_NAME, dbo.TBL_MIS_QUERY_TRACKING.INVOICE_NO, dbo.TBL_MIS_QUERY_TRACKING.INVOICE_AMT, dbo.TBL_MIS_QUERY_TRACKING.QUERY_TO, dbo.TBL_MIS_QUERY_TRACKING.QUERY_TO_NAME," & _
                              "dbo.TBL_MIS_QUERY_TRACKING.QUERY_STATUS, dbo.TBL_MIS_QUERY_TRACKING.RESOLVE_DT, dbo.TBL_MIS_QUERY_TRACKING.COMMENT, dbo.TBL_MIS_QUERY_TRACKING.ENTRY_DATE, dbo.TBL_MIS_QUERY_TRACKING.ENTERED_BY," & _
                              "dbo.TBL_MIS_PROVIDER.ORG_NAME FROM   dbo.TBL_MIS_QUERY_TRACKING LEFT OUTER JOIN  dbo.TBL_MIS_PROVIDER ON dbo.TBL_MIS_QUERY_TRACKING.PROVIDER_ID = dbo.TBL_MIS_PROVIDER.ORG_ID COLLATE SQL_Latin1_General_CP1_CI_AS WHERE  ENTRY_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                    Case "Reimbursement Tracking"
                        Str = "SELECT  FILE_NO,RECEIVE_DT,SERVICE_DT,CLAIM_TYPE,MEMBER_NO,MEMBER_NAME,INVOICE_NO,INVOICE_AMT,INV_STATUS,APPR_REJ_RET_DATE,PAYABLE_AMT,CLAIM_ACK_DATE,PROCESSED_DT,FINANCE_ACK_DATE,PAID_DATE,DOC_NO,REASON,PROPOSER,ENTERED_BY FROM TBL_MIS_REIMB_TRACKING WHERE RECEIVE_DT BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"
                        '----------------------------------------------------------------CLAIMS
                    Case "Complains Tracking"
                        Str = "SELECT [File_no],[Date_Received],[Mode_of_Receipt],[Received_By],[Membership_No],[Member_Name],[Contacts],[Email],[Complain_Type],[Complain_Descr],[Disposition],[Action_Taken],[Status],[Escalated_To],[Member_ack],[Date_closed]  FROM [dbo].[TBL_MIS_COMPLAINT_TRACKING] WHERE  Date_Received BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

                    Case "Provider Request Listing"
                        Str = "SELECT  [Provider_ID],[File_No],[Provider_Code],[Provider_Name],[County],[Contacts],[Mobile_Phone],[Email],[Location],[Speciality],[Provider_Type],[Date_Requested],[Request_Type],[Register_Comments],[Doc_requested],[Doc_req_Date],[Doc_received],[Doc_rec_Date],[Doc_Comments],[Visited],[Last_Date_Visited],[Visit_Coments],[Last_Visit_By],[Deferred],[Date_Deffered],[Defered_Coments],[Defered_by],[Price_Reviewed],[LastPrice_Date_reviewed],[PriceReview_Coments],[Price_Review_By],[Accredited],[Date_Accredited],[Contract_drawn],[Contracted],[Contract_Date],[Sys_update_BY],[Signed],[Date_Signed],[Sys_updated],[Sys_update_Date],[Accredit_Comments],[Last_signoff_Date],[Entered_By],[Entry_date],[Outstanding_Claims],[Comment],[Provider_Status],[Audited],[Last_Audit_Date],[Last_Audit_Comments],[Last_Audit_By],[IS_Active]  FROM [SALES].[dbo].[TBL_MIS_PNM_PROVIDERS] WHERE  Date_Requested BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' and IS_Active=1"

                End Select

                If Str <> "" Then
                    Session("Mytable") = Nothing
                    Session("Reportname") = Nothing

                    Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                    'Mytable = TryCast(MyDBAction.eoxegen(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                    Session("Mytable") = (Mytable)
                    Session("Reportname") = Reportname
                    ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                    Mytable = Nothing

                    'System.Threading.Thread.Sleep(5000)


                End If


            Else
                LblErr.Text = "Select a Report from the list provided."
                Panel3.Visible = True
                Exit Try
            End If
            
            Select Case SubRadRpt.SelectedValue
                Case "Member No" 'Account Information
                    LblErr.Text = "Select a Report from the list provided."

            End Select




        Catch ex As Exception
            LblErr.Text = ex.Message.ToString
            Panel3.Visible = True
            MyDBAction.DoLogs("Class==CRBReports.vb: Protected Sub RadRptFinalize_Click" & " : Error : " & ex.Message)
        End Try
    End Sub

    
End Class
