﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""

                ' dtupload.DbSelectedDate = Date.Now
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing
                Session("med") = 0
                Session("Allocate") = 0
                Session("INVOICED") = 0
               '
            
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()
                GD_STATE.DataSource = Nothing
                GD_STATE.DataBind()
                'ltEmbed.Text = ""
                LOADGRID()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            If cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT DISTINCT [PROPOSER_ID], PROPOSER_DISPLAY_NAME,CLIENT_TYPE   FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROPOSER_LIST] WITH (NOLOCK)  WHERE POLICY_CODE LIKE '%" & Trim(txtsearch.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT DISTINCT [PROPOSER_ID], PROPOSER_DISPLAY_NAME,CLIENT_TYPE  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROPOSER_LIST]  WHERE PROPOSER_DISPLAY_NAME  LIKE '%" & Trim(txtsearch.Text) & "%' "
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()
            End If
        Catch ex As Exception
            lblsave.Text = ex.Message
        End Try
    End Sub
  
    Public Sub LOADGRID()
        SqlAction = "SELECT PROPOSER_DISPLAY_NAME, REFERENCE_NO,INVOICE_DATE,PERIOD_FROM,PERIOD_TO,PREMIUM,REC_AMOUNT,TRANS_TYPE FROM [CRM].[dbo].[MASTER_STATEMENT_ADJUSTMENT] WHERE [POSTED]=0  AND IS_ACTIVE=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_STATE_1.DataSource = MyDatable
            GD_STATE_1.DataBind()
        Else
            GD_STATE_1.DataSource = Nothing
            GD_STATE_1.DataBind()
        End If
    End Sub



    Public Sub Generate_Task()

        SqlAction = "SELECT ISNULL((MAX(ID)+1),1) NUMBER FROM [CRM].[dbo].[MASTER_STATEMENT_ADJUSTMENT]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            RefNo.Text = "AARKE/ADJUST" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
            FILE_NO.Text = RefNo.Text
        End If
    End Sub
    Protected Sub btnsave_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0
            If cbotype.SelectedValue = "" Then
                lblsave.Text = "Select the Refund Type"
                txtname.Focus()
                txtname.BackColor = Drawing.Color.Red
                Exit Sub
            End If
            If txtname.Text = "" Then
                lblsave.Text = "Enter the Payee Name"
                txtname.Focus()
                txtname.BackColor = Drawing.Color.Red
                Exit Sub

            End If
           

            If txtrefund.Text = 0 Or txtrefund.Text = "" Then
                lblsave.Text = "Invalid Amount to refund"
                txtrefund.Focus()
                txtrefund.BackColor = Drawing.Color.Red
                Exit Sub
            End If



            If cbotype.SelectedValue = "DR" Then
                DR = txtrefund.Text
            ElseIf cbotype.SelectedValue = "CR" Then
                CR = txtrefund.Text
            Else
                lblsave.Text = "Select the Transtype"
            End If
            Generate_Task()
            MyDBAction.STATEMENT_ADJ_AMT(RefNo.Text, CDate(Date.Now).ToString("yyyy-MM-dd"), LBLPROP.Text, Session("username"), DR, CR, cbotype.SelectedValue)

            If lbltype.Text = "RET" Then
                MyDBAction.TASK_MESSAGES(LBLPROP.Text, txtcomment.Text, Session("username"), Date.Now(), "STATEMENT-ADJ", "RETAIL")

            ElseIf lbltype.Text = "CORP" Then
                MyDBAction.TASK_MESSAGES_CORP(LBLPROP.Text, txtcomment.Text, Session("username"), Date.Now(), "STATEMENT-ADJ", "CORPORATE")
            End If
            LOADGRID()
            lblsave.Text = "Transaction Saved Successfull!"



        Catch ex As Exception
            lblsave.Text = ex.Message
        End Try
    End Sub
    Public Sub LoadNotes(ByVal id As String)
      
        SqlAction = "SELECT PROPOSER_DISPLAY_NAME, REFERENCE_NO,INVOICE_DATE,PERIOD_FROM,PERIOD_TO,PREMIUM,REC_AMOUNT,TRANS_TYPE FROM [CRM].[dbo].[MASTER_STATEMENT_ADJUSTMENT] WHERE [POSTED]=0 AND PROPOSER_ID= '" & LBLPROP.Text & "' AND IS_ACTIVE=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_STATE_1.DataSource = MyDatable
            GD_STATE_1.DataBind()
        Else
            GD_STATE_1.DataSource = Nothing
            GD_STATE_1.DataBind()
        End If

            If lbltype.Text = "RET" Then
                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            ElseIf lbltype.Text = "CORP" Then
                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_CORPORATE_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            End If
           

    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GD_STATE_1_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GD_STATE_1.DeleteCommand
        Try
            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("REFERENCE_NO").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            DeleteRecord("UPDATE [CRM].[dbo].[MASTER_STATEMENT_ADJUSTMENT] SET IS_ACTIVE=0 WHERE REFERENCE_NO='" & HiddenField1.Value.ToString & "'")

            audit.AddAdminAuditTrail(Session("UserName").ToString, "Statement adjustment Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            LOADGRID()


        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

        'ShowGridDetails()
    End Sub

    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()

            FILE_NO.Text = ""
            txtname.Text = ""
            lbltype.Text = ""
         
            txtrefund.Text = 0
            txtpaid.Text = 0
            txtDR.Text = 0
            txtCR.Text = 0
            txtcomment.Text = ""

            Session("PROPOSER_ID") = Nothing
            Session("CLIENT_TYPE") = Nothing
            Dim dr As Decimal = 0
            Dim cr As Decimal = 0



            LBLPROP.Text = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()

            SqlAction = "SELECT  [PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,PERIOD_FROM,PERIOD_TO,CLIENT_TYPE FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROPOSER_LIST]  WHERE PROPOSER_ID  = '" & LBLPROP.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                txtname.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                lbltype.Text = MyDatable.Rows(0).Item("CLIENT_TYPE").ToString()
                'txtmobile.Text = MyDatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()

                SqlAction = "SELECT DISTINCT  [POLICY_CODE], Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & LBLPROP.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_STATE.DataSource = MyDatable
                    GD_STATE.DataBind()
                    Session("STATE_01") = MyDatable
                    dr = Convert.ToInt32(MyDatable.Compute("SUM(DR)", String.Empty))
                    cr = Convert.ToInt32(MyDatable.Compute("sum(CR)", String.Empty))
                    txtDR.Text = dr
                    txtCR.Text = cr

                    txtpaid.Text = dr - cr
                    txtrefund.Text = txtpaid.Text
                Else
                    GD_STATE.DataSource = Nothing
                    GD_STATE.DataBind()
                End If

                LoadNotes(LBLPROP.Text)


            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try


    End Sub
    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_STATE.PageIndexChanged
        GD_STATE.CurrentPageIndex = e.NewPageIndex
        GD_STATE.DataSource = Session("STATE_01")
        GD_STATE.DataBind()
    End Sub

    Protected Sub btnstatement_Click(sender As Object, e As System.EventArgs) Handles btnstatement.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable

            If LBLPROP.Text = "" Then
                lblsave.Text = "Select Proposer Name"
                Exit Sub
            End If


            Session("PRINT") = "PDF"
            Session("Report_") = "Customer Statement"

            Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR], [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & LBLPROP.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC,REFERENCE_NO"

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GD_STATE_1_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GD_STATE_1.NeedDataSource

    End Sub
End Class
