Imports System.Data.SqlClient
Imports DocManage
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports Telerik.Web.UI
Imports Telerik.Charting
Partial Class Welcome
    Inherits System.Web.UI.Page
    Public ActionIsRefresh As Boolean = False
    Private _dockStateCleared As Boolean = False
    Private MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""

    Private Property CurrentDockStates() As List(Of DockState)
        Get
           
            Dim _currentDockStates As List(Of DockState) = DirectCast(Session("CurrentDockStatesMyPortal"), List(Of DockState))
            If [Object].Equals(_currentDockStates, Nothing) Then
                _currentDockStates = New List(Of DockState)()
                Session("CurrentDockStatesMyPortal") = _currentDockStates
            End If
            Return _currentDockStates
        End Get
        Set(value As List(Of DockState))
            Session("CurrentDockStatesMyPortal") = value
        End Set
    End Property
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Overal_Level()
            NewBusiness_Level()
            ReNewBusiness_Level()
            'Enrichment_Finalized()
            'Enrichment_Approved()


        End If
    End Sub

    
#Region "General Graphs Functions"
    'Protected Sub RadDockLayout1_LoadDockLayout(sender As Object, e As DockLayoutEventArgs)
    '    'Populate the event args with the state information. The RadDockLayout control
    '    ' will automatically move the docks according that information.
    '    For Each state As DockState In CurrentDockStates
    '        e.Positions(state.UniqueName) = state.DockZoneID
    '        e.Indices(state.UniqueName) = state.Index
    '    Next
    'End Sub

    'Protected Sub RadDockLayout1_SaveDockLayout(sender As Object, e As DockLayoutEventArgs)
    '    If Not _dockStateCleared Then
    '        'Save the dock state in the session. This will enable us 
    '        ' to recreate the dock in the next Page_Init.
    '        CurrentDockStates = RadDockLayout1.GetRegisteredDocksState()
    '    Else
    '        'the clear state button was clicked, so we refresh the page and start over.
    '        Response.Redirect(Request.RawUrl, False)
    '    End If
    'End Sub
    'Private Function CreateRadDock(Optional ByVal MyTitle As String = "") As RadDock
    '    Dim dock As New RadDock()
    '    dock.DockMode = DockMode.Docked
    '    dock.UniqueName = Guid.NewGuid().ToString().Replace("-", "a")
    '    dock.ID = String.Format("RadDock{0}", dock.UniqueName)
    '    dock.Title = MyTitle
    '    dock.Text = String.Format("Added at {0}", DateTime.Now)
    '    dock.Width = Unit.Pixel(300)

    '    dock.Commands.Add(New DockCloseCommand())
    '    dock.Commands.Add(New DockExpandCollapseCommand())

    '    Return dock
    'End Function

    'Private Sub LoadWidget(dock As RadDock)
    '    If String.IsNullOrEmpty(dock.Tag) OrElse dock.Closed Then
    '        Return
    '    End If
    '    Dim widget As Control = LoadControl(dock.Tag)
    '    widget.EnableViewState = False
    '    dock.ContentContainer.Controls.Add(widget)
    'End Sub
#End Region
#Region "Overal Graphs"
    Private Function MakeAnalysisTable() As Data.DataTable
        Dim namesTable As New Data.DataTable
        Dim DirColumn As Data.DataColumn

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "Month"
        DirColumn.DefaultValue = ""
        namesTable.Columns.Add(DirColumn)

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "PERC_PRODUCTION"
        DirColumn.DefaultValue = 0
        namesTable.Columns.Add(DirColumn)

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "ACTUAL"
        DirColumn.DefaultValue = 0
        namesTable.Columns.Add(DirColumn)

        'DirColumn = New Data.DataColumn()
        'DirColumn.DataType = Type.GetType("System.String")
        'DirColumn.ColumnName = "Totals"
        'DirColumn.DefaultValue = ""
        'namesTable.Columns.Add(DirColumn)

        MakeAnalysisTable = namesTable

        Return namesTable
    End Function
    Private Sub Overal_Level()
        Try
            Dim MyChart As New RadChart
            Dim Str, Str1, Str2 As String : Dim MyGraphTable As DataTable
            Dim Mytable As DataTable : Dim Mytable1 As DataTable : Dim Mytable2 As DataTable

            Dim Myfiles As Array
            Myfiles = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}


            MyGraphTable = MakeAnalysisTable()

            For x As Integer = 0 To Myfiles.Length - 1
                Dim MyDatarow As Data.DataRow = MyGraphTable.NewRow

                Select Case Myfiles(x)
                    Case "Jan"
                        Str = "SELECT PERC_PRODUCTION FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jan'"
                        'Str1 = "SELECT ACTUAL_PROD  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE  YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jan'"
                        'Str2 = "SELECT COUNT(*) FROM FIN_VW_MISSING_ACC"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Feb"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Feb'"

                        '    'Str1 = "SELECT COUNT(*) FROM CONSUMER_EMPLOYER WHERE  YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  ACC_NO NOT IN (SELECT ACC_NO FROM FIN_VW_MISSING_CONSUMER)"
                        '    'Str2 = "SELECT COUNT(*) FROM FIN_VW_MISSING_CONSUMER"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Mar"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Mar'"

                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Apr"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Apr'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "May"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='May'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Jun"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jun'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Jul"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jul'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Aug"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Aug'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Sep"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Sep'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Oct"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Oct'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Nov"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Nov'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Dec"
                        Str = "SELECT PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Dec'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case Else
                        'do nothing
                End Select

                If Str.ToString <> "" Then
                    Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

                    'Mytable1 = TryCast(MyDBAction.DBAction(Str1, DataManagement.DBActionType.DataTable), Data.DataTable)
                    'Mytable2 = TryCast(MyDBAction.DBAction(Str2, DataManagement.DBActionType.DataTable), Data.DataTable)

                    If Mytable.Rows.Count > 0 Then
                        'MyDatarow.Item("Not_Analysis") = Mytable.Rows(0).Item(0)
                        'MyDatarow.Item("Analysis") = Mytable1.Rows(0).Item(0)
                        'MyDatarow.Item("Totals") = Mytable2.Rows(0).Item(0)

                        'MyDatarow.Item("Not_Analysis") = Mytable2.Rows(0).Item(0)
                        MyDatarow.Item("PERC_PRODUCTION") = Mytable.Rows(0).Item(0)
                        'MyDatarow.Item("ACTUAL") = Mytable1.Rows(0).Item(0)
                        MyGraphTable.Rows.Add(MyDatarow)
                    End If

                    Mytable = Nothing
                    Mytable1 = Nothing
                    Mytable2 = Nothing
                End If
            Next

            SqlAction = "SELECT CAST(DATENAME(month, MONTH_FROM) as char(3)) MON,MONTH_BUDGET, ACTUAL_PROD,PERC_PRODUCTION  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001'  order by MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_N.DataSource = MyDatable
                GD_N.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_N.DataSource = Nothing
                GD_N.DataBind()
            End If

            RadChart1.PlotArea.YAxis.YAxisType = ChartYAxisType.Primary
            RadChart1.PlotArea.XAxis.DataLabelsColumn = "Month"
            RadChart1.AutoLayout = True

            RadChart1.DataSource = MyGraphTable
            RadChart1.DataBind()

            'GD_N.DataSource = MyGraphTable
            'GD_N.DataBind()

            'Dim Dataitem As GridDataItem
            'Dim i As Integer = 0

            'For Each Dataitem In GD_N.Items
            '    Dim Lbl As Label = CType(Dataitem.FindControl("Lbl2"), Label)

            '    'For i As Integer = 0 To MyGraphTable.Rows.Count - 1
            '    Dim MyVal As Double = (MyGraphTable.Rows(i).Item("PERC_PRODUCTION"))
            '    'Dim MyVal As Double = (MyGraphTable.Rows(i).Item("PERC_PRODUCTION") / MyGraphTable.Rows(i).Item("PERC_PRODUCTION"))
            '    Lbl.Text = String.Format("{0:#,##0.00%}", MyVal) ' String.Format("{0:$#,##0.00}", MyVal)
            '    i = i + 1
            '    'Next
            'Next

            MyGraphTable = Nothing

        Catch ex As Exception
            LblErr.Text = ex.Message.ToString
            Panel4.Visible = True
            MyDBAction.DoLogs("Class==Welcome.vb: Private Sub Enrichment_Level()" & " : Error : " & ex.Message)
        End Try
    End Sub
#End Region

#Region "New Business Graphs"
    Private Function MakeAnalysisTable_1() As Data.DataTable
        Dim namesTable As New Data.DataTable
        Dim DirColumn As Data.DataColumn

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "Month"
        DirColumn.DefaultValue = ""
        namesTable.Columns.Add(DirColumn)

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "NEW_PERC"
        DirColumn.DefaultValue = 0
        namesTable.Columns.Add(DirColumn)

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "PERC_NEW_N"
        DirColumn.DefaultValue = 0
        namesTable.Columns.Add(DirColumn)

        'DirColumn = New Data.DataColumn()
        'DirColumn.DataType = Type.GetType("System.String")
        'DirColumn.ColumnName = "Totals"
        'DirColumn.DefaultValue = ""
        'namesTable.Columns.Add(DirColumn)

        MakeAnalysisTable_1 = namesTable

        Return namesTable
    End Function
    Private Sub NewBusiness_Level()
        Try
            Dim MyChart As New RadChart
            Dim Str, Str1, Str2 As String : Dim MyGraphTable As DataTable
            Dim Mytable As DataTable : Dim Mytable1 As DataTable : Dim Mytable2 As DataTable

            Dim Myfiles As Array
            Myfiles = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}


            MyGraphTable = MakeAnalysisTable_1()

            For x As Integer = 0 To Myfiles.Length - 1
                Dim MyDatarow As Data.DataRow = MyGraphTable.NewRow

                Select Case Myfiles(x)
                    Case "Jan"
                        Str = "SELECT NEW_PERC FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jan'"
                        'Str1 = "SELECT ACTUAL_PROD  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE  YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jan'"
                        'Str2 = "SELECT COUNT(*) FROM FIN_VW_MISSING_ACC"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Feb"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Feb'"

                        '    'Str1 = "SELECT COUNT(*) FROM CONSUMER_EMPLOYER WHERE  YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  ACC_NO NOT IN (SELECT ACC_NO FROM FIN_VW_MISSING_CONSUMER)"
                        '    'Str2 = "SELECT COUNT(*) FROM FIN_VW_MISSING_CONSUMER"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Mar"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Mar'"

                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Apr"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Apr'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "May"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='May'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Jun"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jun'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Jul"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jul'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Aug"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Aug'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Sep"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Sep'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Oct"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Oct'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Nov"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Nov'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Dec"
                        Str = "SELECT NEW_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Dec'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case Else

                        'do nothing
                End Select

                If Str.ToString <> "" Then
                    Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                    'Mytable1 = TryCast(MyDBAction.DBAction(Str1, DataManagement.DBActionType.DataTable), Data.DataTable)
                    If Mytable.Rows.Count > 0 Then
                        MyDatarow.Item("NEW_PERC") = Mytable.Rows(0).Item(0)
                        'MyDatarow.Item("PERC_NEW_N") = Mytable1.Rows(0).Item(0)
                        MyGraphTable.Rows.Add(MyDatarow)
                    End If

                    Mytable = Nothing
                    Mytable1 = Nothing
                    Mytable2 = Nothing
                End If
            Next

            SqlAction = "SELECT CAST(DATENAME(month, MONTH_FROM) as char(3)) MON,NEW_PERC ,NEW_BUDGET,ACTUAL_NEW  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001'  order by MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_N1.DataSource = MyDatable
                GD_N1.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_N1.DataSource = Nothing
                GD_N1.DataBind()
            End If

            RadChart2.PlotArea.YAxis.YAxisType = ChartYAxisType.Primary
            RadChart2.PlotArea.XAxis.DataLabelsColumn = "Month"
            RadChart2.AutoLayout = True

            RadChart2.DataSource = MyGraphTable
            RadChart2.DataBind()

            'GD_N.DataSource = MyGraphTable
            'GD_N.DataBind()

            'Dim Dataitem As GridDataItem
            'Dim i As Integer = 0

            'For Each Dataitem In GD_N.Items
            '    Dim Lbl As Label = CType(Dataitem.FindControl("Lbl2"), Label)

            '    'For i As Integer = 0 To MyGraphTable.Rows.Count - 1
            '    Dim MyVal As Double = (MyGraphTable.Rows(i).Item("PERC_PRODUCTION"))
            '    'Dim MyVal As Double = (MyGraphTable.Rows(i).Item("PERC_PRODUCTION") / MyGraphTable.Rows(i).Item("PERC_PRODUCTION"))
            '    Lbl.Text = String.Format("{0:#,##0.00%}", MyVal) ' String.Format("{0:$#,##0.00}", MyVal)
            '    i = i + 1
            '    'Next
            'Next

            MyGraphTable = Nothing

        Catch ex As Exception
            LblErr.Text = ex.Message.ToString
            Panel4.Visible = True
            MyDBAction.DoLogs("Class==Welcome.vb: Private Sub Enrichment_Level()" & " : Error : " & ex.Message)
        End Try
    End Sub
#End Region

#Region "Renew Business Graphs"
    Private Function MakeAnalysisTable_2() As Data.DataTable
        Dim namesTable As New Data.DataTable
        Dim DirColumn As Data.DataColumn

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "Month"
        DirColumn.DefaultValue = ""
        namesTable.Columns.Add(DirColumn)

        DirColumn = New Data.DataColumn()
        DirColumn.DataType = Type.GetType("System.String")
        DirColumn.ColumnName = "RENEWAL_PERC"
        DirColumn.DefaultValue = 0
        namesTable.Columns.Add(DirColumn)

        'DirColumn = New Data.DataColumn()
        'DirColumn.DataType = Type.GetType("System.String")
        'DirColumn.ColumnName = "RENEWAL_PERC"
        'DirColumn.DefaultValue = 0
        'namesTable.Columns.Add(DirColumn)

        'DirColumn = New Data.DataColumn()
        'DirColumn.DataType = Type.GetType("System.String")
        'DirColumn.ColumnName = "Totals"
        'DirColumn.DefaultValue = ""
        'namesTable.Columns.Add(DirColumn)

        MakeAnalysisTable_2 = namesTable

        Return namesTable
    End Function
    Private Sub ReNewBusiness_Level()
        Try
            Dim MyChart As New RadChart
            Dim Str, Str1, Str2 As String : Dim MyGraphTable As DataTable
            Dim Mytable As DataTable : Dim Mytable1 As DataTable : Dim Mytable2 As DataTable

            Dim Myfiles As Array
            Myfiles = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}


            MyGraphTable = MakeAnalysisTable_2()

            For x As Integer = 0 To Myfiles.Length - 1
                Dim MyDatarow As Data.DataRow = MyGraphTable.NewRow

                Select Case Myfiles(x)
                    Case "Jan"
                        Str = "SELECT RENEWAL_PERC FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jan'"
                        'Str1 = "SELECT ACTUAL_PROD  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE  YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jan'"
                        'Str2 = "SELECT COUNT(*) FROM FIN_VW_MISSING_ACC"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Feb"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Feb'"

                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Mar"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Mar'"

                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Apr"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Apr'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "May"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='May'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Jun"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jun'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Jul"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Jul'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Aug"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Aug'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Sep"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Sep'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Oct"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Oct'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Nov"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Nov'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case "Dec"
                        Str = "SELECT RENEWAL_PERC  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' AND YEAR([MONTH_FROM])='" & cboyear.SelectedValue & "' and  CAST(DATENAME(month, MONTH_FROM) as char(3))='Dec'"
                        MyDatarow.Item("Month") = Myfiles(x)
                    Case Else

                        'do nothing
                End Select

                If Str.ToString <> "" Then
                    Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                    'Mytable1 = TryCast(MyDBAction.DBAction(Str1, DataManagement.DBActionType.DataTable), Data.DataTable)
                    If Mytable.Rows.Count > 0 Then
                        MyDatarow.Item("RENEWAL_PERC") = Mytable.Rows(0).Item(0)
                        'MyDatarow.Item("PERC_NEW_N") = Mytable1.Rows(0).Item(0)
                        MyGraphTable.Rows.Add(MyDatarow)
                    End If

                    Mytable = Nothing
                    Mytable1 = Nothing
                    Mytable2 = Nothing
                End If
            Next

            SqlAction = "SELECT CAST(DATENAME(month, MONTH_FROM) as char(3)) MON,RENEWAL_PERC,RENEWAL_BUDGET,ACTUAL_RENEW  FROM TBL_SALES_NSM_SUMMARY_MTD WHERE NSM_CODE='N_0001' order by MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_N2.DataSource = MyDatable
                GD_N2.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_N2.DataSource = Nothing
                GD_N2.DataBind()
            End If

            RadChart3.PlotArea.YAxis.YAxisType = ChartYAxisType.Primary
            RadChart3.PlotArea.XAxis.DataLabelsColumn = "Month"
            RadChart3.AutoLayout = True

            RadChart3.DataSource = MyGraphTable
            RadChart3.DataBind()

            'GD_N.DataSource = MyGraphTable
            'GD_N.DataBind()

            'Dim Dataitem As GridDataItem
            'Dim i As Integer = 0

            'For Each Dataitem In GD_N.Items
            '    Dim Lbl As Label = CType(Dataitem.FindControl("Lbl2"), Label)

            '    'For i As Integer = 0 To MyGraphTable.Rows.Count - 1
            '    Dim MyVal As Double = (MyGraphTable.Rows(i).Item("PERC_PRODUCTION"))
            '    'Dim MyVal As Double = (MyGraphTable.Rows(i).Item("PERC_PRODUCTION") / MyGraphTable.Rows(i).Item("PERC_PRODUCTION"))
            '    Lbl.Text = String.Format("{0:#,##0.00%}", MyVal) ' String.Format("{0:$#,##0.00}", MyVal)
            '    i = i + 1
            '    'Next
            'Next

            MyGraphTable = Nothing

        Catch ex As Exception
            LblErr.Text = ex.Message.ToString
            Panel4.Visible = True
            MyDBAction.DoLogs("Class==Welcome.vb: Private Sub Enrichment_Level()" & " : Error : " & ex.Message)
        End Try
    End Sub
#End Region
    
    Protected Sub RadChart1_Click(ByVal sender As Object, ByVal args As Telerik.Charting.ChartClickEventArgs) Handles RadChart1.Click
        AddHandler RadChart1.ChartTitle.ActiveRegion.Click, AddressOf Region_Click
        For Each series As ChartSeries In radChart1.Series
            For Each item As ChartSeriesItem In series.Items
                AddHandler item.ActiveRegion.Click, AddressOf Region_Click
            Next
        Next
    End Sub
    Sub Region_Click(ByVal sender As Object, ByVal args As RegionClickEventArgs)
        Dim logFormat As String = "Item Class:{0} - ""{1}""" + Environment.NewLine
        If TypeOf sender Is ChartTitle Then
            LblErr.Text += [String].Format(logFormat, sender.[GetType]().Name, (TryCast(sender, ChartTitle)).TextBlock.Text)
        ElseIf TypeOf sender Is ChartSeriesItem Then
            LblErr.Text += [String].Format(logFormat, sender.[GetType]().Name, (TryCast(sender, ChartSeriesItem)).Name)
        End If
    End Sub

    Protected Sub cboyear_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboyear.SelectedIndexChanged
        Overal_Level()
        NewBusiness_Level()
        ReNewBusiness_Level()
    End Sub
End Class
