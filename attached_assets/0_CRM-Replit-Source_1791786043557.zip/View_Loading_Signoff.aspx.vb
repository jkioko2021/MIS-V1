﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Dim searchStr As String = ""


 


    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim msg As Integer = 0

            If chkLoading.Checked = True Then
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  [MED_VERIFIED]=1,MED_VERIFIED_BY='" & Session("username") & "' WHERE  [MED_VERIFIED]=0 AND PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] SET  [MED_VERIFICATION]=1 WHERE  [MED_VERIFICATION]=0 AND PERIOD_FROM = '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO= '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")

                'MailSent = SendLoginDetails(Session("EMPNAME"), Session("Path"), Session("RecepientEmail"), Session("agentEmail"))

                Session("MessageSubject") = Session("Month") & "-Renewal List Validation"
                msg = 1
                'MailSent = SendLoginDetails("Pricing Team", Session("Path"), "Quotations@aar.co.ke", "Relationship-Managers@aar.co.ke", msg)

            End If

            LoadGrid()



            lblerr.Text = "updated successfully!"
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub updateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)
    End Sub

    Protected Sub btnverexpo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnverexpo.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String


        Session("EXCEL") = "TO EXCEL"

        Reportname = "Loaded List-& " & dtF_1.DbSelectedDate & ""
        SqlAction = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[FIRST_ENROLLMENT_DATE],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[PROPOSER_PRI_PIN],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID],[UNIT],[BRANCH],[REGION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_ADD_LINE2],[POSTAL_CODE],[ADDRESS],[PROPOSER_PRI_MOBILE],[RENEWAL_DATE],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[AGE_BAND],[PRODUCT],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[SPLUS_IP_LIMIT],[FAMILY_SIZE],[POLICY_TYPE],[PRESENT_IP],[PRESENT_OP],[LAST_IP_DATE],[LAST_OP_DATE],[CURRENT_CLAIM],[IP_2016_2017],[LAST_CLAIM_DATE],[NCD_YEARS],[NCD_RATE],[IP_RATE],[IP_NET_NCD],[OP_RATE],[PA_PTD],[SILVER_PLUS_IP_PREMIUM],[SILVER_PLUS_NET_NCD],[SUB_TOTAL],[SUB_TOTAL_2],[LEVIES],[LEVIES_2],[TOTAL],[TOTAL_2],[IS_LOADING],[MED_VERIFIED] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' and VERIFIED=1 AND IS_LOADING=1"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("EXCEL") = Nothing
            Session("DAD_") = Nothing
            '


            SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] WHERE SIGNOFF_PERIOD=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                Session("PERIOD_FROM") = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                Session("PERIOD_TO") = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()
                dtF_1.DbSelectedDate = Session("PERIOD_FROM")
                DTt_1.DbSelectedDate = Session("PERIOD_TO")

            End If
            LoadGrid()

        End If

    End Sub
    Public Sub LoadGrid()
      
        SqlAction = "SELECT  [ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[PERIOD_FROM],[PERIOD_TO],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[POLICY_TYPE],[PRESENT_IP],[PRESENT_OP],[LAST_IP_DATE],[LAST_OP_DATE],[CURRENT_CLAIM] ,[IP_RATE],[OP_RATE],[PA_PTD] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST]   WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' and VERIFIED=1 and [MED_VERIFIED]=0 AND IS_LOADING=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub

    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_")
        GDSEARCH.DataBind()
    End Sub
    Private Function SendLoginDetails(ByVal EmployeeName As String, ByVal path As String, ByVal RecepientEmail As String, ByVal ccEmail As String, ByVal msg As Integer) As Boolean

        Dim MailSent As Boolean = False

        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""

        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""



        Try

            LoginFromEmail = "customerservice@aar.co.ke"
            LoginDisplayName = "AAR INSURANCE KENYA LTD"
            LoginSubject = "MEDICAL COVER-POLICY RENEWAL"
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailUserName = "customerservice@aar.co.ke"
            EmailPassword = "!Cu$T0mer$$2018"
            MessageSubject = Session("MessageSubject") '" Medical Cover-Policy Renewal"

        Catch ex As Exception

        End Try


        Try

            Dim strHTML As New StringBuilder


            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("</tr>")
            strHTML = strHTML.Append("<tr>")
            If msg = 1 Then
                strHTML = strHTML.Append("<td colspan='3'>")
                'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
                strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Dear Pricing Team, </b> </span>")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append(" This is to inform  you that Loading  for '" & Session("Month") & "' renewal is complete and updated.You are expected to update NCD and validate the Renewal List withing the next 72 Hours.")
            End If
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")


            Dim mymail As New Emailing

            MailSent = mymail.SendNotification(path, MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccEmail)


            Session("MailSent") = MailSent


        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False

        End Try

        Return MailSent
    End Function

    Private Declare Function Beep Lib "kernel32" (ByVal dwFreq As Long, ByVal dwDuration As Long) As Long

End Class
