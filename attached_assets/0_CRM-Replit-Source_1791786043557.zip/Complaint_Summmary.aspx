﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Complaint_Summmary.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="ISSUE UPDATE"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 982px">
                                                    &nbsp;</td>
                                                <td style="width: 127px" class="style17">
                                                    <asp:Label ID="Label141" runat="server" Text="Member No"></asp:Label>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadComboBox ID="cbodepart_1" Runat="server" AllowCustomText="True" 
                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Simple" Width="264px">
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search" Skin="Simple">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1140px">
                                            <telerik:RadGrid ID="GDCOMPL" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Issue_Code">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Issue_Code" 
                                                            FilterControlAltText="Filter Issue_Code column" HeaderText="Issue_Code" 
                                                            SortExpression="Issue_Code" UniqueName="Issue_Code">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Depart_Code" 
                                                            FilterControlAltText="Filter Depart_Code column" HeaderText="Depart_Code" 
                                                            SortExpression="Depart_Code" UniqueName="Depart_Code">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Issue_Name" 
                                                            FilterControlAltText="Filter Issue_Name column" HeaderText="Issue_Name" 
                                                            SortExpression="Issue_Name" UniqueName="Issue_Name">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="Escalate" 
                                                            FilterControlAltText="Filter Escalate column" HeaderText="Escalate To" 
                                                            SortExpression="Escalate" UniqueName="Escalate">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="SLA_Hrs" 
                                                            FilterControlAltText="Filter SLA_Hrs column" HeaderText="SLA_Hrs" 
                                                            SortExpression="SLA_Hrs" UniqueName="SLA_Hrs">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                                          <table style="width: 100%">
                                              <tr>
                                                  <td style="height: 13px;" align="center" bgcolor="#666666" colspan="5">
                                                      <asp:Label ID="Label176" runat="server" Font-Bold="True" ForeColor="White" 
                                                          Text="Complaint Details"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 28px;">
                                                      <asp:Label ID="Label178" runat="server" Text="Department"></asp:Label>
                                                  </td>
                                                  <td style="width: 330px; height: 28px;">
                                                      <telerik:RadComboBox ID="cbodepart" Runat="server" AllowCustomText="True" 
                                                          AutoPostBack="True" MarkFirstMatch="True" Skin="Simple" Width="264px">
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 28px;">
                                                      <asp:Label ID="Label167" runat="server" Text="Issue Summary"></asp:Label>
                                                  </td>
                                                  <td style="width: 330px">
                                                      <telerik:RadTextBox ID="txtissue" Runat="server" Skin="Simple" Width="300px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 28px;">
                                                  </td>
                                                  <td style="height: 28px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 28px;">
                                                      <asp:Label ID="Label156" runat="server" Text="Supervisor"></asp:Label>
                                                  </td>
                                                  <td colspan="2">
                                                      <telerik:RadComboBox ID="cboemp" Runat="server" AllowCustomText="True" 
                                                          MarkFirstMatch="True" Skin="Simple" Width="250px">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboemp" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Escalated" Value="Escalated" 
                                                                  Owner="cboemp" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Resolved" Value="Resolved" 
                                                                  Owner="cboemp" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 24px;">
                                                      <asp:Label ID="Label169" runat="server" Text="SLA Hrs"></asp:Label>
                                                  </td>
                                                  <td style="width: 330px">
                                                      <telerik:RadNumericTextBox ID="txtsla" Runat="server" Culture="en-US" Value="0" 
                                                          Width="125px" Skin="Simple" DataType="System.Int16">
                                                          <NumberFormat DecimalDigits="0" />
                                                      </telerik:RadNumericTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="height: 24px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 24px;">
                                                      <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                                  <td style="width: 330px; height: 24px;">
                                                      <telerik:RadButton ID="btnsave" runat="server" Skin="Simple" Text="Save" 
                                                          Width="150px">
                                                      </telerik:RadButton>
                                                      &nbsp;
                                                      <telerik:RadButton ID="btnnew" runat="server" Skin="Simple" Text="Add new" 
                                                          Width="100px">
                                                      </telerik:RadButton>
                                                      &nbsp;</td>
                                                  <td style="height: 24px;" colspan="2">
                                                      <telerik:RadButton ID="btnedit" runat="server" Skin="Simple" Text="Edit" 
                                                          Width="100px">
                                                      </telerik:RadButton>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 330px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td colspan="2" style="height: 24px;">
                                                      <asp:Label ID="lblerr" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate> 
            </asp:UpdatePanel>
</asp:Content>

