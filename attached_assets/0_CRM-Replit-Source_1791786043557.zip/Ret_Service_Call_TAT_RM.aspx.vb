﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim empcode As String
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                dtDateFrom.DbSelectedDate = Date.Now
                dtDateTo.DbSelectedDate = Date.Now
                empcode = ""
                Session("EXCEL") = Nothing
                Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                    'empcode = "0111"
                Else
                    lblerr.Text = "You are not authorized to view this page"
                    Exit Sub
                End If
                Str = ""
                Str = "SELECT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1 AND C_CODE='R' AND RE_CODE ='" & empcode & "' " '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cborm
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                    .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                    .DataBind()
                End With
                cborm.SelectedValue = empcode

                Load_Grid()

            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Load_Grid()
        Try

            GDRM.DataSource = Nothing
            GDRM.DataBind()
            GDRM_1.DataSource = Nothing
            GDRM_1.DataBind()


            SqlAction = " SELECT [RE_NAME],  Yr, SUM(NO_OF_POLICIES)NO_OF_POLICIES,SUM(CALLS_DONE)CALLS_DONE,SUM(PENDING_CALLS)PENDING_CALLS,avg(Call_Tat)TAT FROM  [VW_MIS_CRM_SERV_MEMBER_CALL_TAT] with(nolock)  WHERE Yr ='" & cbosearch.SelectedValue & "' and RMS_CODE= '" & cborm.SelectedValue & "'  group by Yr, [RE_NAME]"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDRM.DataSource = MyDatable
                GDRM.DataBind()
            Else
                GDRM.DataSource = Nothing
                GDRM.DataBind()
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDRM_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDRM.SelectedIndexChanged
        Try
            GDRM_1.DataSource = Nothing
            GDRM_1.DataBind()
            HiddenField1.Value = ""

            HiddenField1.Value = (DirectCast(GDRM.SelectedItems(0), GridDataItem)).GetDataKeyValue("RE_NAME").ToString()
            SqlAction = "SELECT Mon,  Yr,Mn,SUM(NO_OF_POLICIES)NO_OF_POLICIES,SUM(CALLS_DONE)CALLS_DONE,SUM(PENDING_CALLS)PENDING_CALLS,avg(Call_Tat)TAT FROM  [VW_MIS_CRM_SERV_MEMBER_CALL_TAT] with(nolock)   WHERE RE_NAME ='" & HiddenField1.Value & "' and Yr='" & cbosearch.SelectedValue & "' group by Yr,Mn,Mon order by Mon asc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDRM_1.DataSource = MyDatable
                GDRM_1.DataBind()
            Else
                GDRM_1.DataSource = Nothing
                GDRM_1.DataBind()
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub export_Click(sender As Object, e As System.EventArgs) Handles export.Click
        Try
            Dim Str As String = ""
            Session("EXCEL") = "TO EXCEL"

            Dim Reportname As String = "MIDPOLICY_CALLS"
            SqlAction = "SELECT [Yr],[Mn],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[PERIOD_FROM],[PERIOD_TO],[MID_POLICY_DATE],[Confirm_Call_Code],[Confirm_Call_Date],[RE_NAME],[CALL_tYPE],[MOBILE_NO],[SERVICE_CALL_TAT]  FROM [CRM].[dbo].[VW_MIS_CRM_SERVICE_MEMBER_CALL] WITH(NOLOCK) WHERE Yr='" & cbosearch.SelectedValue & "' and RE_NAME ='" & cborm.SelectedValue & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (MyDatable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            MyDatable = Nothing
            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
