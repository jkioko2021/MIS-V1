﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then


            empcode = ""
            Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                'empcode = "0081"
            Else
                lblerr.Text = "You are not authorized to view this page"
                Exit Sub
            End If
            Str = ""
            Str = "SELECT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1 AND C_CODE='R' AND RE_CODE ='" & empcode & "' " '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cborm
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()
            End With
            cborm.SelectedValue = empcode


            loadgrid()
        End If
    End Sub
    Public Sub loadgrid()
        Try
            SqlAction = "SELECT [PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[PERIOD_FROM],[PERIOD_TO],[RMS_CODE]  FROM [CRM].[dbo].[VW_MIS_RET_MEMBER_FOLLOUP] WHERE [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=1 AND PERIOD_TO>=Getdate() AND FOLLOWUP='YES'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
                Session("DAD_C_0") = MyDatable
                MyDatable = Nothing
            Else
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
            End If

        
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    
    Protected Sub GDProposer_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDProposer.PageIndexChanged
        GDProposer.CurrentPageIndex = e.NewPageIndex
        GDProposer.DataSource = Session("DAD_C_0")
        GDProposer.DataBind()
    End Sub


    
    Protected Sub GDProposer_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDProposer.SelectedIndexChanged
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            Session("FAMILY_NO") = Nothing
            PRD.Text = ""
            PRD.Text = (DirectCast(GDProposer.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing

            SqlAction = "SELECT [Proposer_ID],[Confirm_Call_Code],[Confirm_Call_By],[Confirm_Call_Date],[Correct_Cover],[Welcome_Package],[Ack_Consent],[Policy_Terms_Exp],[Satisfied_with_info],[Call_Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_NEW_RET_CALL_LOG]  WHERE PROPOSER_ID ='" & PRD.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_C_0") = MyDatable

                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & PRD.Text & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            Else
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim close As String
            If PRD.Text = "" Then
                lblerr.Text = "Select proposer!"
                Exit Sub
            End If
            'UPDATE TBL_MIS_CRM_NEW_POLICIES_RET SET [CONFIRMED]=1,FOLLOWUP=@Followup where PROPOSER_ID=@Proposer_ID
            If chkclose.Checked = True Then
                close = "NO"
            Else
                close = "YES"

            End If
            UpdateRecord("UPDATE TBL_MIS_CRM_NEW_POLICIES_RET SET FOLLOWUP='" & close & "' WHERE PROPOSER_ID='" & PRD.Text & "'")

            UpdateRecord("UPDATE [TBL_MIS_CRM_MID_POLICIES_RET] SET FOLLOWUP='" & close & "' WHERE PROPOSER_ID='" & PRD.Text & "'")

            If txtdescr.Text <> "" Then
                MyDBAction.TASK_MESSAGES(PRD.Text, txtdescr.Text, Session("username"), Date.Now(), "NEW MEMBER CALL", Session("FAMILY_NO"))

                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & PRD.Text & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            End If

            txtdescr.Text = ""
            lblerr.Text = "Saved Successfull"

            lblcode.Text = ""
            loadgrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
