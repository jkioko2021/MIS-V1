﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing

                dtfrom.DbSelectedDate = Date.Now()
                dtto.DbSelectedDate = Date.Now()
                Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 and department='CASE MANAGEMENT'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboNAME
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                    .DataValueField = MyDatatable.Columns("username").ToString
                    .DataBind()
                End With

                cboNAME.SelectedValue = Session("username")
                loadGrid_N()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If

    End Sub
    Public Sub loadGrid_N()

        SqlAction = "SELECT [Discharge_By],sum([DISCHARGED])[DISCHARGED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_DISCHARGED])[TOTAL_DISCHARGED]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CASE] WITH(NOLOCK)   GROUP BY Discharge_By"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_0.DataSource = MyDatable
            GDTracking_0.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
        End If

        SqlAction = "SELECT sum([SUBMITTED])[SUBMITTED],sum([DISCHARGED])[DISCHARGED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_DISCHARGED])[TOTAL_DISCHARGED]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CASE] WITH(NOLOCK)"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_1.DataSource = MyDatable
            GDTracking_1.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_1.DataSource = Nothing
            GDTracking_1.DataBind()
        End If
    End Sub

   


    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub



  

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try


            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            If chkdate.Checked = True And chkname.Checked = False Then
                SqlAction = "SELECT [Discharge_By],sum([DISCHARGED])[DISCHARGED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_DISCHARGED])[TOTAL_DISCHARGED]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CASE] WITH(NOLOCK) WHERE   [Discharge_DT]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY Discharge_By"


                Str = "SELECT sum([SUBMITTED])[SUBMITTED],sum([DISCHARGED])[DISCHARGED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_DISCHARGED])[TOTAL_DISCHARGED]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CASE] WITH(NOLOCK)   WHERE   [Submit_dt]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDTracking_1.DataSource = MyDatable
                    GDTracking_1.DataBind()
                    Session("DAD_T") = MyDatable
                    MyDatable = Nothing
                Else
                    GDTracking_1.DataSource = Nothing
                    GDTracking_1.DataBind()
                End If


            ElseIf chkdate.Checked = False And chkname.Checked = True Then
                SqlAction = "SELECT [Discharge_By],sum([DISCHARGED])[DISCHARGED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_DISCHARGED])[TOTAL_DISCHARGED]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CASE] WITH(NOLOCK) WHERE   Discharge_By ='" & cboNAME.SelectedValue & "' GROUP BY Discharge_By"

            ElseIf chkdate.Checked = True And chkname.Checked = True Then
                SqlAction = "SELECT [Discharge_By],,sum([DISCHARGED])[DISCHARGED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_DISCHARGED])[TOTAL_DISCHARGED]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CASE] WITH(NOLOCK) WHERE   Discharge_By ='" & cboNAME.SelectedValue & "' and Discharge_DT Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY Discharge_By"

            Else
                SqlAction = "SELECT [Discharge_By],sum([DISCHARGED])[DISCHARGED],sum([ALLOCATED])[ALLOCATED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([POSTED])[POSTED],sum([IT-ISSUE])[IT-ISSUE],sum([MSHIP-ISSUE])[MSHIP-ISSUE],sum([RETENTION-ISSUE])[RETENTION-ISSUE],sum([TOTAL_DISCHARGED])[TOTAL_DISCHARGED]  FROM [CRM].[dbo].[vw_MIS_CRM_IP_TRACKING_STATUS_CASE] WITH(NOLOCK) GROUP BY Discharge_By"

            End If
            MyDatable = Nothing
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking_0.DataSource = MyDatable
                GDTracking_0.DataBind()
                Session("DAD_T_0") = MyDatable
                MyDatable = Nothing
            Else
                GDTracking_0.DataSource = Nothing
                GDTracking_0.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDTracking_0_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDTracking_0.NeedDataSource

    End Sub


    Protected Sub GDTracking_0_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTracking_0.PageIndexChanged
        GDTracking_0.CurrentPageIndex = e.NewPageIndex
        GDTracking_0.DataSource = Session("DAD_T_0")
        GDTracking_0.DataBind()
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try

       
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "IP_Claim_List"
            Session("EXCEL") = "TO EXCEL"
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
            SqlAction = "SELECT [File_No],[Receive_dt],[Service_dt],[Claim_Type],[Member_No],[Member_Name],[Proposer],[Provider_Code],[Provider_Name],[Invoice_No],[Invoice_Amt],[Mobile_No],[Email],[Bar_code],[Inv_Status]," & _
                                   "[Entry_Date],[Entered_by],[Submitted],[Submitted_By],[Submit_dt],Care_Manager,[Discharged], Discharge_dt,discharge_by,[Invoice_type],[Amt_Payable_Ben],[P_I_Amount],[Country],Care_Manager,Care_Allocate_Dt,Care_Allocate_By," & _
                                   "[Payable_Amt] FROM [CRM].[dbo].[TBL_MIS_IP_CLAIM_TRACKING]   WHERE Submit_dt>= '" & CDate(dtfrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND  Submit_dt<= '" & CDate(dtto.SelectedDate).ToString("yyyy-MM-dd") & "' AND ACTIVE=1"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (MyDatable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            MyDatable = Nothing
            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
        'Reportname = ""
    End Sub


End Class
