﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Contacts_Tracking.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="CONTACT UPDATE"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 1025px" align="right">
                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <asp:Label ID="Label141" runat="server" Text="Search Member by"></asp:Label>
                                                </td>
                                                <td style="width: 261px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" Width="200px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1140px">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                           <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="MEMBERSHIP NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" 
                                                            HeaderText="MEMBER_BIRTH_DATE" SortExpression="MEMBER_BIRTH_DATE" 
                                                            UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                       
                                                      
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                                          <table style="width: 100%">
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label147" runat="server" style="font-weight: 700" 
                                                          Text="Member Info"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label143" runat="server" Text="Member No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 159px">
                                                      &nbsp;<asp:Label ID="Label144" runat="server" Text="Member Name"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadTextBox ID="txtname" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label146" runat="server" Text="Proposer Name"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 159px">
                                                      <asp:Label ID="Label145" runat="server" Text="Client Type"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Text="Corporate" Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Individual" Value="I" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label148" runat="server" style="font-weight: 700" 
                                                          Text="Mandatory Contacts"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label149" runat="server" Text="Primary Mobile No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadNumericTextBox ID="txtprimobile" Runat="server" Culture="en-US" 
                                                          DataType="System.Int32" Skin="Outlook" Value="254" Width="225px" 
                                                          MaxLength="12">
                                                          <NumberFormat DecimalDigits="0" GroupSeparator=" " />
                                                      </telerik:RadNumericTextBox>
                                                  </td>
                                                  <td style="width: 159px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label150" runat="server" Text="Pin_No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtpin" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 159px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px; height: 17px;">
                                                      <asp:Label ID="Label158" runat="server" Text="EMail"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 17px;">
                                                      <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 159px; height: 17px;">
                                                      &nbsp;</td>
                                                  <td style="height: 17px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label156" runat="server" Text="ID/Passport_No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtid" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 159px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label164" runat="server" Text="DOB"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadDatePicker ID="dtdob" Runat="server" FocusedDate="1900-01-01" 
                                                          MinDate="1900-01-01" Skin="Office2007">
                                                          <Calendar Skin="Office2007" UseColumnHeadersAsSelectors="False" 
                                                              UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                          </Calendar>
                                                          <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                          </DateInput>
                                                          <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                      </telerik:RadDatePicker>
                                                  </td>
                                                  <td style="width: 159px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label159" runat="server" style="font-weight: 700" 
                                                          Text="Optional Contacts"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label161" runat="server" Text="Marital_Status"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadComboBox ID="cbomarital" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Text="Married" Value="Married" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Single" Value="Single" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 159px">
                                                      <asp:Label ID="Label160" runat="server" Text="Secondary Mobile No"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadNumericTextBox ID="txtsecmobile" Runat="server" Culture="en-US" 
                                                          DataType="System.Int32" MaxLength="12" Skin="Outlook" Value="254" Width="225px">
                                                          <NumberFormat DecimalDigits="0" GroupSeparator=" " />
                                                      </telerik:RadNumericTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label162" runat="server" Text="Gender"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadComboBox ID="cbogender" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbogender" Text="Female" 
                                                                  Value="F" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbogender" Text="Male" 
                                                                  Value="M" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 159px">
                                                      <asp:Label ID="Label163" runat="server" Text="Physical_Addr"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadTextBox ID="txtaddress" Runat="server" Skin="Outlook" Width="350px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      &nbsp;</td>
                                                  <td style="width: 159px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      <telerik:RadButton ID="cmdsave" runat="server" Height="38px" Skin="Sunset" 
                                                          Text="Save" Width="113px">
                                                      </telerik:RadButton>
                                                  </td>
                                                  <td style="width: 159px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;&nbsp;<asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                  </td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>

