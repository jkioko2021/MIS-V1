﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retention_Page.aspx.vb" Inherits="Default2" %>

<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <asp:Panel ID="Panel5" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                style="font-weight: 700" Width="950px">
                <table style="width: 100%">
                    <tr>
                        <td bgcolor="#666666" colspan="4">
                            <asp:Label ID="Label60" runat="server" Font-Bold="True" 
                                Text="POLICY DOC ALLOCATION"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                Width="815px">
                                <table style="width: 100%">
                                    <tr>
                                        <td style="width: 500px">
                                            <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                                Text="Search By"></asp:Label>
                                        </td>
                                        <td>
                                            <telerik:RadComboBox ID="cbosearch" Runat="server">
                                                <Items>
                                                    <telerik:RadComboBoxItem runat="server" Text="File No" Value="F" />
                                                    <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                    <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                </Items>
                                            </telerik:RadComboBox>
                                        </td>
                                        <td>
                                            <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                            </telerik:RadTextBox>
                                        </td>
                                        <td>
                                            <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                            </telerik:RadButton>
                                        </td>
                                    </tr>
                                </table>
                            </asp:Panel>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <asp:Panel ID="Panel7" runat="server" Height="310px" ScrollBars="Both" 
                                Width="927px">
                                <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                    CellSpacing="0" GridLines="None" Height="100%" Skin="Simple" Width="100%">
                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                            <HeaderStyle Width="20px" />
                                        </RowIndicatorColumn>
                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                            <HeaderStyle Width="20px" />
                                        </ExpandCollapseColumn>
                                        <Columns>
                                            <telerik:GridButtonColumn CommandName="Select" 
                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                UniqueName="Select">
                                                <HeaderStyle ForeColor="Blue" Width="100px" />
                                                <ItemStyle Width="50px" />
                                            </telerik:GridButtonColumn>
                                            <telerik:GridBoundColumn DataField="File_No" 
                                                FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                SortExpression="File_No" UniqueName="File_No">
                                            </telerik:GridBoundColumn>
                                            <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                            </telerik:GridBoundColumn>                                        
                                            <telerik:GridBoundColumn DataField="Assigned_To" 
                                                FilterControlAltText="Filter Assigned_To column" HeaderText="Assigned_To" 
                                                SortExpression="Assigned_To" UniqueName="Assigned_To">
                                            </telerik:GridBoundColumn>
                                            <telerik:GridBoundColumn DataField="Status" 
                                                FilterControlAltText="Filter Status column" HeaderText="Status" 
                                                SortExpression="Status" UniqueName="Status">
                                            </telerik:GridBoundColumn>
                                        </Columns>
                                        <EditFormSettings>
                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                            </EditColumn>
                                        </EditFormSettings>
                                    </MasterTableView>
                                    <FilterMenu EnableImageSprites="False">
                                    </FilterMenu>
                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                    </HeaderContextMenu>
                                </telerik:RadGrid>
                            </asp:Panel>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            &nbsp;</td>
                        <td style="width: 89px">
                            <asp:Label ID="file" runat="server"></asp:Label>
                        </td>
                        <td class="style8" style="width: 123px">
                            &nbsp;</td>
                        <td style="width: 169px" class="style8">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            <asp:Label ID="Label33" runat="server" Text="Proposer"></asp:Label>
                        </td>
                        <td style="width: 89px">
                            <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Forest" Width="250px">
                            </telerik:RadTextBox>
                        </td>
                        <td class="style8" style="width: 123px">
                            <asp:Label ID="Label31" runat="server" style="font-weight: 700" Text="Type"></asp:Label>
                        </td>
                        <td style="width: 169px" class="style8">
                            <telerik:RadComboBox ID="cbotype" Runat="server" AutoPostBack="True" 
                                Skin="Forest" Width="150px">
                                <Items>
                                    <telerik:RadComboBoxItem runat="server" />
                                    <telerik:RadComboBoxItem runat="server" Text="RETAIL" Value="R" />
                                    <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="SME" Value="S" />
                                    <telerik:RadComboBoxItem runat="server" Text="CORP" Value="C" />
                                </Items>
                            </telerik:RadComboBox>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            <asp:Label ID="Label59" runat="server" Text="Agent"></asp:Label>
                        </td>
                        <td style="width: 89px">
                            <telerik:RadComboBox ID="cboagent" Runat="server" AccessibilityMode="True" 
                                AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Forest" 
                                Width="250px">
                            </telerik:RadComboBox>
                        </td>
                        <td class="style8" style="width: 123px">
                            <asp:Label ID="Label10" runat="server" style="font-weight: 700" Text="Action"></asp:Label>
                        </td>
                        <td style="width: 169px" class="style8">
                            <telerik:RadTextBox ID="txtaction" Runat="server">
                            </telerik:RadTextBox>
                        </td>
                    </tr>
                    <tr>
                        <td bgcolor="#666666" colspan="4">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            &nbsp;</td>
                        <td style="width: 89px">
                            <asp:Label ID="lblstatus" runat="server" ForeColor="Red"></asp:Label>
                        </td>
                        <td class="style8" style="width: 123px">
                            &nbsp;</td>
                        <td style="width: 169px" class="style8">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            <asp:CheckBox ID="chkack" runat="server" AutoPostBack="True" 
                                Text="Ack Received" />
                        </td>
                        <td style="width: 89px">
                            <telerik:RadDatePicker ID="dtackrec" Runat="server" 
                                FocusedDate="2017-08-31" MinDate="" Skin="Forest">
                                <Calendar Skin="Forest" UseColumnHeadersAsSelectors="False" 
                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                </Calendar>
                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                </DateInput>
                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                            </telerik:RadDatePicker>
                        </td>
                        <td class="style8" style="width: 123px; background-color: #CCCCCC;">
                            <asp:Label ID="Label76" runat="server" Text="Disp Date"></asp:Label>
                        </td>
                        <td style="width: 169px; background-color: #CCCCCC;" class="style8">
                            <telerik:RadDatePicker ID="dtpolidispdate" Runat="server" Enabled="False" 
                                FocusedDate="2017-08-31" MinDate="" Skin="Forest">
                                <Calendar Skin="Forest" UseColumnHeadersAsSelectors="False" 
                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                </Calendar>
                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                </DateInput>
                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                            </telerik:RadDatePicker>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            &nbsp;</td>
                        <td style="width: 89px">
                            &nbsp;</td>
                        <td style="width: 123px" class="style8">
                            &nbsp;</td>
                        <td style="width: 169px" class="style8">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td class="style9" style="width: 182px">
                            <asp:Label ID="Label75" runat="server" Text="Retention Officer"></asp:Label>
                        </td>
                        <td style="width: 89px">
                            <telerik:RadComboBox ID="cboretention" Runat="server" AccessibilityMode="True" 
                                AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Forest" 
                                Width="250px">
                            </telerik:RadComboBox>
                        </td>
                        <td class="style8" style="width: 123px">
                            &nbsp;</td>
                        <td class="style8" style="width: 169px">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            <asp:Label ID="Label55" runat="server" Text="Comments"></asp:Label>
                        </td>
                        <td colspan="2" rowspan="2">
                            <telerik:RadTextBox ID="txtOther_Comments" Runat="server" Height="70px" 
                                Skin="Forest" TextMode="MultiLine" Width="350px">
                            </telerik:RadTextBox>
                        </td>
                        <td style="width: 169px" class="style8">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            &nbsp;</td>
                        <td style="width: 169px" class="style8">
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            &nbsp;</td>
                        <td colspan="2">
                            &nbsp;</td>
                        <td style="width: 169px" class="style8">
                            <telerik:RadButton ID="BTNUPDATE" runat="server" Skin="Simple" 
                                Text="Update and Save" Width="164px">
                            </telerik:RadButton>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 182px" class="style9">
                            &nbsp;</td>
                        <td colspan="2">
                            <asp:Label ID="lbler" runat="server" ForeColor="Red"></asp:Label>
                        </td>
                        <td style="width: 169px" class="style8">
                            &nbsp;</td>
                    </tr>
                </table>
            </asp:Panel>
        </ContentTemplate>
    </asp:UpdatePanel>
</asp:Content>



