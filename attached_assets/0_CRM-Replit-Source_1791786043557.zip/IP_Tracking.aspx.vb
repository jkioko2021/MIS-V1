﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()
            loadGrid()

            Str = ""

            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM [MISREPORTS].dbo.TBL_MIS_PROVIDER  WHERE  [TERMINATED]='NO' ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboprovider
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub

    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim FILENO As String
        Dim app As Integer = 0

        Dim receivedate As String
        Try

            If cbotype.SelectedValue = "" Then
                lblerr.Text = "You have not selected the benefit type!"
                Exit Sub
            End If
            If txtinv_no.Text = "" Or txtinv_amt.Text = "" Or txtmemno.Text = "" Then
                lblerr.Text = "You must fill Invoice No,amount or member no!"
                Exit Sub
            End If

            If txtProvider_Name.Text = "" Then
                txtProvider_Name.Text = cboprovider.Text
            End If

            If HiddenField1.Value = "" Then
                Dim RandomClass As New Random()
                'Dim RandomNumber = RandomClass.Next(1, 99999)
                'FILENO = "C-" & RandomNumber
                Dim RandomNumber As Long = Now.Day & Now.Month & Now.Hour & Now.Minute & Now.Second

                If cbotype.SelectedValue = "OP" Then
                    lblfile.Text = "AAR-OP-" & Month(Date.Now) & "-" & RandomNumber
                Else
                    lblfile.Text = "AAR-IP-" & Month(Date.Now) & "-" & RandomNumber
                End If


                STS = 0
                MyDBAction.TRACK_IP_OP(lblfile.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtservice.DbSelectedDate).ToString("yyyy-MM-dd"), Trim(txtbarcode.Text), cbotype.SelectedValue, Trim(txtmemno.Text), Trim(txtProvider_Name.Text), cboprovider.SelectedValue, Trim(txtinv_no.Text), txtinv_amt.Text, txtcomment.Text, Session("username"), STS)

                lblfile.Text = lblfile.Text
                lblerr.Text = "Saved Successfully!"
                'cmdsave.Enabled = False
                HiddenField1.Value = ""
            Else
                STS = 1
                MyDBAction.TRACK_IP_OP(lblfile.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtservice.DbSelectedDate).ToString("yyyy-MM-dd"), Trim(txtbarcode.Text), cbotype.SelectedValue, Trim(txtmemno.Text), Trim(txtProvider_Name.Text), cboprovider.SelectedValue, Trim(txtinv_no.Text), txtinv_amt.Text, txtcomment.Text, Session("username"), STS)
                lblerr.Text = "Updated Successfully!"
                lblfile.Text = lblfile.Text
            End If
            'loadGrid()
            loadGrid_OTH(txtinv_no.Text)
            HiddenField1.Value = ""


            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()
            txtbarcode.Text = ""
            cbotype.Text = ""
            txtmemno.Text = ""
            cboprovider.Text = ""
            cboprovider.Text = ""
            txtinv_no.Text = ""
            txtcomment.Text = ""
            txtinv_amt.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        HiddenField1.Value = 1
        cboprovider.SelectedValue = ""
        cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""
        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT [ID],[FILE_NO],[RECEIVE_DT],[SERVICE_DT],[BARCODE],[CLAIM_TYPE],[MEMBER_NO],PROVIDER_NAME,[PROVIDER_ID],[INVOICE_NO],[INVOICE_AMT],[COMMENT] FROM [MISREPORTS].[dbo].[TBL_MIS_IP_OP_TRACKING] WITH (NOLOCK) WHERE ID ='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then

                lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                dtservice.DbSelectedDate = MyDatable.Rows(0).Item("SERVICE_DT").ToString()
                txtbarcode.Text = MyDatable.Rows(0).Item("BARCODE").ToString()
                cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                txtmemno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                cboprovider.SelectedValue = MyDatable.Rows(0).Item("PROVIDER_ID").ToString()
                txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                txtcomment.Text = MyDatable.Rows(0).Item("COMMENT").ToString()
                txtProvider_Name.Text = MyDatable.Rows(0).Item("PROVIDER_NAME").ToString()

                lblfile.Enabled = False
                dtreceive.Enabled = False
                dtservice.Enabled = False
                txtbarcode.Enabled = False
                cbotype.Enabled = False
                txtmemno.Enabled = False
                cboprovider.Enabled = False
                cboprovider.Enabled = False
                txtinv_no.Enabled = False
                txtcomment.Enabled = False
                txtinv_amt.Enabled = False
                txtProvider_Name.Enabled = False

            End If
            'Session("DAD_5") = Nothing



        End If
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT ID, BARCODE,INVOICE_NO,INVOICE_AMT,PROVIDER_NAME FROM [MISREPORTS].dbo.VW_MIS_IP_OP_SEARCH WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%'"

            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT ID, BARCODE,INVOICE_NO,INVOICE_AMT,PROVIDER_NAME FROM [MISREPORTS].dbo.VW_MIS_IP_OP_SEARCH   WITH (NOLOCK) WHERE ACTIVE=1 AND   PROVIDER_NAME Like '%" & Trim(txtsearch.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "B" Then
                SqlAction = "SELECT ID, BARCODE,INVOICE_NO,INVOICE_AMT,PROVIDER_NAME FROM [MISREPORTS].dbo.VW_MIS_IP_OP_SEARCH   WITH (NOLOCK) WHERE ACTIVE=1 AND   BARCODE Like '%" & Trim(txtsearch.Text) & "%'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        'SqlAction = "SELECT [ID],[TENDER_NO],[BOOKING_DATE],[DUE_DATE_TIME],[CORPORATE_NAME] FROM [MISREPORTS].[dbo].[TBL_MIS_TENDER] WITH (NOLOCK) WHERE DUE_DATE_TIME >='" & Date.Now & "' and IS_ACTIVE=1"
        SqlAction = "SELECT ID, BARCODE,INVOICE_NO,INVOICE_AMT,PROVIDER_NAME FROM [MISREPORTS].dbo.VW_MIS_IP_OP_SEARCH WHERE ACTIVE=1 AND CARE_MGR_ID=''"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Public Sub loadGrid_OTH(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT ID, BARCODE,INVOICE_NO,INVOICE_AMT,PROVIDER_NAME FROM [MISREPORTS].dbo.VW_MIS_IP_OP_SEARCH WHERE ACTIVE=1 AND INVOICE_NO='" & Trim(txtinv_no.Text) & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub

    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1

        lblfile.Enabled = True
        dtreceive.Enabled = True
        dtservice.Enabled = True
        txtbarcode.Enabled = True
        cbotype.Enabled = True
        txtmemno.Enabled = True
        cboprovider.Enabled = True
        cboprovider.Enabled = True
        txtinv_no.Enabled = True
        txtcomment.Enabled = True
        txtinv_amt.Enabled = True
        txtProvider_Name.Enabled = True
    End Sub

    Protected Sub cmdNEW_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdNEW.Click
        HiddenField1.Value = ""
        dtreceive.DbSelectedDate = Date.Now()
        dtservice.DbSelectedDate = Date.Now()
        txtbarcode.Text = ""
        cbotype.Text = ""
        txtmemno.Text = ""
        cboprovider.Text = ""

        txtinv_no.Text = ""
        txtcomment.Text = ""
        txtinv_amt.Text = ""
        txtProvider_Name.Enabled = True
        txtProvider_Name.Text = ""
        lblfile.Enabled = True
        dtreceive.Enabled = True
        dtservice.Enabled = True
        txtbarcode.Enabled = True
        cbotype.Enabled = True
        txtmemno.Enabled = True
        cboprovider.Enabled = True
        cboprovider.Enabled = True
        txtinv_no.Enabled = True
        txtcomment.Enabled = True
        txtinv_amt.Enabled = True
    End Sub

    Protected Sub cboprovider_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboprovider.SelectedIndexChanged
        'txtProvider_Name.Text = cboprovider.Text
    End Sub

    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDSEARCH.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("ID").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""

            Try

                Dim MyDatable As New Data.DataTable
                MySqlAction = "SELECT [ID],[FILE_NO] FROM [MISREPORTS].[dbo].[TBL_MIS_IP_OP_TRACKING] WITH (NOLOCK) WHERE ID ='" & ID & "'"


                MyDataTable = TryCast(MyDBAction.DBAction(MySqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDataTable.Rows.Count > 0 Then
                    File_No = MyDataTable.Rows(0).Item("ID")
                End If
            Catch ex As Exception

            End Try

            'AUDIT TRAIL-------
            Dim audit As New DataManagement
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Delete File", "Successfully Deleted File :- File deleted is: FleNO - " & File_No & ", proposer - " & Proposer_Name & ".", _
            Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            '----END AUDIT TRAIL-----

            DeleteRecord("Delete from TBL_MIS_IP_OP_TRACKING where ID= '" & HiddenField1.Value.ToString & "'")

            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid()

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub

    Protected Sub GDSEARCH_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub
End Class
