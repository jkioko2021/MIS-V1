﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Off_System_TAT.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="TAT- MID POLICY SERVICE CALLS"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel25" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="59px" Width="1107px" Wrap="False">
                            <table style="width: 82%">
                                <tr>
                                    <td class="style11" style="width: 115px">
                                        &nbsp;</td>
                                    <td style="width: 81px">
                                        &nbsp;</td>
                                    <td class="style10" style="width: 122px">
                                        <asp:Label ID="Label87" runat="server" Text="Date From"></asp:Label>
                                    </td>
                                    <td style="width: 11px">
                                        <telerik:RadDatePicker ID="dtDateFrom" Runat="server" Culture="en-US" 
                                            Skin="Web20">
                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style11" style="width: 115px; height: 32px;">
                                    </td>
                                    <td style="width: 81px; height: 32px;">
                                    </td>
                                    <td class="style10" style="width: 122px; height: 32px;">
                                        <asp:Label ID="Label88" runat="server" Text="Date To"></asp:Label>
                                    </td>
                                    <td style="width: 11px; height: 32px;">
                                        <telerik:RadDatePicker ID="dtDateTo" Runat="server" Culture="en-US" 
                                            Skin="Web20" Width="150px">
                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td style="width: 151px; height: 32px;">
                                        <telerik:RadButton ID="view" runat="server" Skin="Web20" Text="View" 
                                            Width="100px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1121px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel23" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="99%">
                                            <telerik:RadGrid ID="GDRM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="50" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Entered_by">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Entered_by" 
                                                            FilterControlAltText="Filter Entered_by column" HeaderText="Name" 
                                                            SortExpression="Entered_by" UniqueName="Entered_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Yr" FilterControlAltText="Filter Yr column" 
                                                            HeaderText="Year" SortExpression="Yr" UniqueName="Yr">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_cnt" 
                                                            FilterControlAltText="Filter Total_cnt column" HeaderText="Total_cnt" 
                                                            SortExpression="Total_cnt" UniqueName="Total_cnt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="avg_TaT" 
                                                            FilterControlAltText="Filter avg_TaT column" HeaderText="avg_TaT" 
                                                            SortExpression="avg_TaT" UniqueName="avg_TaT">
                                                        </telerik:GridBoundColumn>
                                                        
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="Label1" runat="server" style="font-weight: 700" Text="MONTH"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel24" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="99%">
                                            <telerik:RadGrid ID="GDRM_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="50" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" >
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Mn" FilterControlAltText="Filter Mn column" 
                                                            HeaderText="Month" SortExpression="Mn" UniqueName="Mn">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_cnt" 
                                                            FilterControlAltText="Filter Total_cnt column" HeaderText="Total_cnt" 
                                                            SortExpression="Total_cnt" UniqueName="Total_cnt">
                                                        </telerik:GridBoundColumn>
                                                       
                                                        <telerik:GridBoundColumn DataField="avg_TaT" 
                                                            FilterControlAltText="Filter avg_TaT column" HeaderText="avg_TaT" 
                                                            SortExpression="TAT" UniqueName="avg_TaT">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <telerik:RadButton ID="export" runat="server" Skin="Web20" Text="Export" 
                                            Width="149px">
                                        </telerik:RadButton>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                    </td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
   
    </asp:UpdatePanel>
</asp:Content>
