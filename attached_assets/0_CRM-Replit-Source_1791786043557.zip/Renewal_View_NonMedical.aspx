﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Renewal_View_NonMedical.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%;">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="#CCCCCC" style="font-weight: 700" 
                            Text="VIEW NON-MED"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="center" style="text-align: left">
                        <asp:Label ID="Label131" runat="server" style="font-weight: 700" Text="From"></asp:Label>
                        &nbsp;&nbsp;
                        <telerik:RadDatePicker ID="dtmonthfr" Runat="server" MinDate="" Skin="Forest">
                            <Calendar Skin="Forest" UseColumnHeadersAsSelectors="False" 
                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                            </Calendar>
                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                            </DateInput>
                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                        </telerik:RadDatePicker>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td align="center" colspan="4" style="text-align: left">
                        <asp:Label ID="Label130" runat="server" style="font-weight: 700" 
                            Text="To"></asp:Label>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <telerik:RadDatePicker ID="dtmonthto" Runat="server" MinDate="" Skin="Forest">
                            <Calendar Skin="Forest" UseColumnHeadersAsSelectors="False" 
                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                            </Calendar>
                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                            </DateInput>
                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                        </telerik:RadDatePicker>
                        &nbsp;&nbsp;&nbsp;
                        </td>
                </tr>
                <tr>
                    <td align="center" colspan="4" style="text-align: left">
                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                            <table style="width: 100%">
                                <tr>
                                    <td>
                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" Text="Select"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" AutoPostBack="True">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Policy No" Value="PN" />
                                                <telerik:RadComboBoxItem runat="server" Text="Proposer" Value="P" />
                                                <telerik:RadComboBoxItem runat="server" Text="Agent" Value="A" />
                                                <telerik:RadComboBoxItem runat="server" Text="RM" Value="RM" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbotext" Runat="server" AllowCustomText="True" 
                                            MarkFirstMatch="True" Width="300px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                            Width="157px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1207px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>                                                       
                                                        <telerik:GridBoundColumn DataField="Policy_Number" 
                                                            FilterControlAltText="Filter Policy_Number column" HeaderText="Policy_Number" 
                                                            SortExpression="Policy_Number" UniqueName="Policy_Number">
                                                        </telerik:GridBoundColumn>
                                                    
                                                        <telerik:GridBoundColumn DataField="Insured" 
                                                            FilterControlAltText="Filter Insured column" 
                                                            HeaderText="Insured" SortExpression="Insured" 
                                                            UniqueName="Insured">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Renewal_start_date" 
                                                            FilterControlAltText="Filter Renewal_start_date column" 
                                                            HeaderText="Start_date" SortExpression="Renewal_start_date" 
                                                            UniqueName="Renewal_start_date" DataFormatString="{0:dd-MM-yyyy}">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="Renewal_end_date" 
                                                            FilterControlAltText="Filter Renewal_end_date column" 
                                                            HeaderText="End_date" SortExpression="Renewal_end_date" 
                                                            UniqueName="Renewal_end_date" DataFormatString="{0:dd-MM-yyyy}">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Basic_Premium" 
                                                            FilterControlAltText="Filter Basic_Premium column" HeaderText="Basic_Premium" 
                                                            SortExpression="Basic_Premium" UniqueName="Basic_Premium">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Policy_Fund" 
                                                            FilterControlAltText="Filter Policy_Fund column" 
                                                            HeaderText="Policy_Fund" SortExpression="Policy_Fund" 
                                                            UniqueName="Policy_Fund">
                                                        </telerik:GridBoundColumn>                                                      
                                                        <telerik:GridBoundColumn DataField="Training_Levy" 
                                                            FilterControlAltText="Filter Training_Levy column" HeaderText="Training_Levy" 
                                                            SortExpression="Training_Levy" UniqueName="Training_Levy">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Claim_Amount" 
                                                            FilterControlAltText="Filter Claim_Amount column" HeaderText="Claim_Amount" 
                                                            SortExpression="Claim_Amount" UniqueName="Claim_Amount">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_Premium" 
                                                            FilterControlAltText="Filter Total_Premium column" HeaderText="Total_Premium" 
                                                            SortExpression="Total_Premium" UniqueName="Total_Premium">
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="[policy type]" 
                                                            FilterControlAltText="Filter [policy type] column" 
                                                            HeaderText="Class" SortExpression="[policy type]" 
                                                            UniqueName="[policy type]">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Agency" 
                                                            FilterControlAltText="Filter Agency column" 
                                                            HeaderText="Agency" SortExpression="Agency" 
                                                            UniqueName="Agency">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label104" runat="server" Text="Total Premiums"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txttotal" Runat="server" Width="155px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#333333" colspan="4">
                                        <asp:Label ID="Label135" runat="server" 
                                            style="font-weight: 700; color: #FFFFFF;" Text="Print"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        <asp:Label ID="Label136" runat="server" style="font-weight: 700" Text="Product"></asp:Label>
                                    </td>
                                    <td style="width: 151px; height: 11px;">
                                        <telerik:RadComboBox ID="cboTYPE" Runat="server" Skin="Simple">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cboTYPE" Text="Schedule" 
                                                    Value="S" />
                                                <telerik:RadComboBoxItem runat="server" Text="Letter" Value="L" />
                                                <telerik:RadComboBoxItem runat="server" Text="Claim Statement" Value="C" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        <telerik:RadButton ID="BTNprint" runat="server" Skin="Simple" 
                                            Text="Print Renewal Notices">
                                        </telerik:RadButton>
                                    </td>
                                    <td rowspan="2" style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        &nbsp;</td>
                                    <td style="width: 151px; height: 11px;">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>

