﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            Str = "SELECT DISTINCT [Code],[Descr] FROM [dbo].[TBL_MIS_REIMB_REASONS] WHERE ACTIVE=1" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboreason
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Descr").ToString
                .DataValueField = MyDatatable.Columns("Code").ToString
                .DataBind()
            End With
          
            '
            loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WHERE ACTIVE=1 and Approved=0 and Inv_Status='DECLINED' and entered_by='" & Session("username") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        Dim Is_Appeal As Integer = 0
        Dim Is_SPECIAL As Integer = 0
        'cboprovider.Text = ""

        lblfile.Text = ""
        Try


            cboreason.SelectedValue = ""
            cboreason.Text = ""
            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT  [ID],[FILE_NO],[RECEIVE_DT],[SERVICE_DT],[CLAIM_TYPE],[MEMBER_NO],MEMBER_NAME,[INVOICE_NO],[INVOICE_AMT],REASON,PROPOSER,email,Mobile_no,is_appeal,Is_Special  FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) WHERE File_No ='" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                    dtservice.DbSelectedDate = MyDatable.Rows(0).Item("SERVICE_DT").ToString()
                    txtmobile.Text = MyDatable.Rows(0).Item("Mobile_no").ToString()
                    cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                    txtmemno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                    txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                    txtemail.Text = MyDatable.Rows(0).Item("email").ToString()
                    cboreason.SelectedValue = MyDatable.Rows(0).Item("REASON").ToString()
                    txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER").ToString()
                    Is_Appeal = MyDatable.Rows(0).Item("Is_Appeal").ToString()
                    Is_SPECIAL = MyDatable.Rows(0).Item("Is_Special").ToString()
                  
                    load_Grid(lblfile.Text)
                    SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE  File_No ='" & lblfile.Text & "' and Active=1"
                    MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                 

                    txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False
                    dtservice.Enabled = False

                    'txtbarcode.Enabled = False
                    cbotype.Enabled = False
                    txtmemno.Enabled = False

                    txtinv_no.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False

                    txtname.Enabled = False
                    txtinv_no.Enabled = False

                    txtinv_amt.Enabled = False
                    'txtcomment.Enabled = False


                    txtinv_amt.Enabled = False

                    cboreason.Enabled = False

                End If

                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

          

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM [dbo].[TBL_MIS_REIMB_TRACKING] WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%' and Inv_Status='DECLINED'"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%' and Inv_Status='DECLINED'"
            ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%' and Inv_Status='DECLINED'"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%' and Inv_Status='DECLINED'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub

    

    
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub
End Class
