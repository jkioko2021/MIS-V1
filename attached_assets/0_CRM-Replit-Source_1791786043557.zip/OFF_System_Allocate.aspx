﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="OFF_System_Allocate.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="OFF-SYSTEM ALLOCATE"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 261px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Ref No" Value="R" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" 
                                                        Width="200px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1140px">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Id">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                           <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" 
                                                            HeaderText="Ref_No" SortExpression="Ref_No" 
                                                            UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                            SortExpression="Member_Name" UniqueName="Member_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                            FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                            SortExpression="Proposer_Name" 
                                                            UniqueName="Proposer_Name">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Provider_name" 
                                                            FilterControlAltText="Filter Provider_name column" HeaderText="Provider" 
                                                            SortExpression="Provider_name" 
                                                            UniqueName="Provider">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Service_Dt" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter Service_Dt column" 
                                                            HeaderText="Service_Dt" SortExpression="Service_Dt" 
                                                            UniqueName="Service_Dt">
                                                        </telerik:GridBoundColumn>                                                 
                                                            <telerik:GridBoundColumn DataField="Inv_Status" 
                                                            FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
                                                            SortExpression="Inv_Status" UniqueName="Inv_Status">
                                                        </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="Entered_By" 
                                                            FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                            SortExpression="Entered_By" UniqueName="Entered_By">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                                          <table style="width: 100%">
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label147" runat="server" style="font-weight: 700" 
                                                          Text="Member Info"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px">
                                                      <asp:Label ID="Label143" runat="server" Text="Member No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 116px">
                                                      &nbsp;<asp:Label ID="Label144" runat="server" Text="Member Name"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadTextBox ID="txtname" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px">
                                                      <asp:Label ID="Label165" runat="server" Text="Mobile No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtmobile" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td>
                                                      <asp:Label ID="Label146" runat="server" Text="Corporate Name"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px">
                                                      <asp:Label ID="Label166" runat="server" Text="Bar Code"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtbar" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td>
                                                      <asp:Label ID="Label173" runat="server" Text="Reason"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadComboBox ID="cboReason" Runat="server" AllowCustomText="True" 
                                                          MarkFirstMatch="True" Skin="Outlook" Width="300px">
                                                      </telerik:RadComboBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px">
                                                      <asp:Label ID="Label170" runat="server" Text="Invoice No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtinv" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td>
                                                      <asp:Label ID="Label169" runat="server" Text="Invoice Amt"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadNumericTextBox ID="txtamt" Runat="server" Skin="Web20">
                                                      </telerik:RadNumericTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px">
                                                      <asp:Label ID="Label174" runat="server" Text="eClaim Type"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadComboBox ID="cboclaimtype" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Text="MTIBA" Value="M" />
                                                              <telerik:RadComboBoxItem runat="server" Text="SMART" Value="S" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td>
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Update ">
                                                      </telerik:RadButton>
                                                  </td>
                                                  <td>
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label148" runat="server" style="font-weight: 700" 
                                                          Text="Documentation"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                          Width="1141px">
                                                          <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                              GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                              <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                  <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                  <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                      <HeaderStyle Width="20px" />
                                                                  </RowIndicatorColumn>
                                                                  <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                      <HeaderStyle Width="20px" />
                                                                  </ExpandCollapseColumn>
                                                                  <Columns>
                                                                    
                                                                      <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                          FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                          SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Ref_No" 
                                                                          FilterControlAltText="Filter Ref_No column" HeaderText="Ref No" 
                                                                          SortExpression="Ref_No" UniqueName="Ref_No">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                          FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                          SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                          FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                          SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="File_Name" 
                                                                          FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                          SortExpression="File_Name" UniqueName="File_Name">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Upload_By" 
                                                                          FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                          SortExpression="Upload_By" UniqueName="Upload_By">
                                                                      </telerik:GridBoundColumn>
                                                                            <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                            SortExpression="DOC_ID">
                                                                            <ItemTemplate>
                                                                                <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                    CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                            </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                                  </Columns>
                                                                  <EditFormSettings>
                                                                      <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                      </EditColumn>
                                                                  </EditFormSettings>
                                                              </MasterTableView>
                                                              <FilterMenu EnableImageSprites="False">
                                                              </FilterMenu>
                                                              <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                              </HeaderContextMenu>
                                                          </telerik:RadGrid>
                                                      </asp:Panel>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                          ScrollBars="Horizontal" Width="1100px">
                                                          <asp:Literal ID="ltEmbed" runat="server" />
                                                      </asp:Panel>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px; height: 19px;">
                                                      <asp:Label ID="Label172" runat="server" Text="Action"></asp:Label>
                                                  </td>
                                                  <td colspan="2" style="height: 19px;">
                                                      <telerik:RadComboBox ID="cboaction" Runat="server" Skin="Simple" Width="250px">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Text="Allocate" Value="A" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Membership Issue" Value="M" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Return Incomplete" Value="R" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="height: 19px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px; height: 19px;">
                                                      <asp:Label ID="Label171" runat="server" Text="Allocate To"></asp:Label>
                                                  </td>
                                                  <td colspan="2" style="height: 19px;">
                                                      <telerik:RadComboBox ID="cboallocate" Runat="server" Skin="Simple" 
                                                          Width="250px">
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="height: 19px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px; height: 19px;">
                                                      <asp:Label ID="Label156" runat="server" Text="Notes"></asp:Label>
                                                  </td>
                                                  <td colspan="2" style="height: 19px;">
                                                      <telerik:RadTextBox ID="txtnotes" Runat="server" Font-Size="Large" 
                                                          Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                          TextMode="MultiLine" Width="500px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="height: 19px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px; height: 19px;">
                                                      &nbsp;</td>
                                                  <td colspan="2" style="height: 19px;">
                                                      &nbsp;</td>
                                                  <td style="height: 19px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px; height: 34px;">
                                                  </td>
                                                  <td colspan="2" style="height: 34px;">
                                                      <telerik:RadButton ID="cmdsub" runat="server" Height="38px" Skin="Sunset" 
                                                          Text="Submit" Width="127px">
                                                      </telerik:RadButton>
                                                      &nbsp;&nbsp;</td>
                                                  <td style="height: 34px">
                                                      <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 123px">
                                                      <asp:Label ID="Label163" runat="server" Text="Reference No" Font-Size="X-Small" 
                                                          style="font-weight: 700"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                                  <td style="width: 116px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;&nbsp;<asp:Label ID="enteredby" runat="server" Font-Size="X-Small" 
                                                          style="font-weight: 700"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                                          Width="1140px">
                                                          <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                              GridLines="None" Height="100%" Skin="Windows7" Width="100%">
                                                              <MasterTableView AutoGenerateColumns="False">
                                                                  <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                  <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                  </RowIndicatorColumn>
                                                                  <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                  </ExpandCollapseColumn>
                                                                  <Columns>
                                                                      <telerik:GridBoundColumn DataField="Note_date" 
                                                                          FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                                          ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                                          <ItemStyle Width="100px" />
                                                                      </telerik:GridBoundColumn>                                                                
                                                                      <telerik:GridBoundColumn DataField="Note_From" 
                                                                          FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                                          ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                                          <ItemStyle Width="100px" />
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Notes" 
                                                                          FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                          SortExpression="Notes" UniqueName="Notes">
                                                                      </telerik:GridBoundColumn>
                                                                  </Columns>
                                                                  <EditFormSettings>
                                                                      <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                      </EditColumn>
                                                                  </EditFormSettings>
                                                              </MasterTableView>
                                                              <ItemStyle Wrap="False" />
                                                              <FilterMenu EnableImageSprites="False">
                                                              </FilterMenu>
                                                              <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                              </HeaderContextMenu>
                                                          </telerik:RadGrid>
                                                      </asp:Panel>
                                                  </td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
           
            </asp:UpdatePanel>
</asp:Content>

