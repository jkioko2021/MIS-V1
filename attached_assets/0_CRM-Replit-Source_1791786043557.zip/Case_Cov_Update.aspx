﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Case_Cov_Update.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#CC0000" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8" style="height: 523px">
                                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" Width="1151px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#CCCCCC">
                                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                                            Text="Case update"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="center">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                                </td>
                                                                <td style="width: 261px">
                                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                                        Skin="Sunset" Width="190px">
                                                                        <Items>
                                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" 
                                                                                Owner="cbosearch" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Case No" Value="C" 
                                                                                Owner="cbosearch" />
                                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch" Text="Provider" 
                                                                                Value="P" />
                                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch" Text="Member Name" 
                                                                                Value="N" />
                                                                        </Items>
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td style="width: 250px">
                                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" Width="200px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td style="width: 261px">
                                                                    <asp:Label ID="lblno" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td style="width: 250px">
                                                                    <asp:Label ID="lbldp" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1140px">
                                                            <telerik:RadGrid ID="GDCASE" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Outlook" Width="100%" PageSize="20">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_No">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                            <ItemStyle Width="50px" />
                                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="Case_No" 
                                                                            FilterControlAltText="Filter Case_No column" HeaderText="Case_No" 
                                                                            SortExpression="Case_No" UniqueName="Case_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Name" 
                                                                            SortExpression="Member_Name" UniqueName="Member_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Admission_Dt" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter Admission_Dt column" HeaderText="Admission_Date" 
                                                                            SortExpression="Admission_Dt" UniqueName="Admission_Dt">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Prov_name" 
                                                                            FilterControlAltText="Filter Prov_name column" HeaderText="Provider" 
                                                                            SortExpression="Prov_name" UniqueName="Prov_name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Case_Status" 
                                                                            FilterControlAltText="Filter Case_Status column" HeaderText="Case_Status" 
                                                                            SortExpression="Case_Status" UniqueName="Case_Status">
                                                                        </telerik:GridBoundColumn>
                                                                               <telerik:GridBoundColumn DataField="Admission_Status" 
                                                                            FilterControlAltText="Filter Admission_Status column" HeaderText="Adm_Status" 
                                                                            SortExpression="Admission_Status" UniqueName="Admission_Status">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Pre_Auth_Amt" DataFormatString="{0:### ##0.0}"
                                                                            FilterControlAltText="Filter Pre_Auth_Amt column" HeaderText="Auth_Amt" 
                                                                            SortExpression="Pre_Auth_Amt" UniqueName="Pre_Auth_Amt">
                                                                        </telerik:GridBoundColumn>
                                                                          <telerik:GridBoundColumn DataField="Total_Actual_Cost"  DataFormatString="{0:### ##0.0}"
                                                                            FilterControlAltText="Filter Total_Actual_Cost column" HeaderText="Actual_Cost" 
                                                                            SortExpression="Total_Actual_Cost" UniqueName="Total_Actual_Cost">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Entered_by" 
                                                                            FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                            SortExpression="Entered_by" UniqueName="Entered_by">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="lblprov" runat="server" Font-Size="Large" ForeColor="Red" 
                                                            Visible="False"></asp:Label>
                                                    </td>
                                                </tr>
                                            </table>
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="left" colspan="4">
                                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                                            MultiPageID="RadMultiPage1" Skin="Outlook" Width="100%" SelectedIndex="7">
                                                            <Tabs>
                                                                <telerik:RadTab runat="server" PageViewID="V2" Text="Data Fulfilment">
                                                                </telerik:RadTab>
                                                                <telerik:RadTab runat="server" PageViewID="V8" Text="Test Results">
                                                                </telerik:RadTab>
                                                                <telerik:RadTab runat="server" PageViewID="V1" Text="Comorbidity">
                                                                </telerik:RadTab>
                                                                <telerik:RadTab runat="server" PageViewID="V3" Text="Costs">
                                                                </telerik:RadTab>
                                                                <telerik:RadTab runat="server" PageViewID="V4" Text="Notes">
                                                                </telerik:RadTab>
                                                                <telerik:RadTab runat="server" PageViewID="V5" Text="Admit/Discharg">
                                                                </telerik:RadTab>
                                                                <telerik:RadTab runat="server" PageViewID="V6" Text="HomeCare" 
                                                                    SelectedIndex="5">
                                                                </telerik:RadTab>
                                                            </Tabs>
                                                        </telerik:RadTabStrip>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="100%">
                                                            <telerik:RadPageView ID="V1" runat="server">
                                                                <asp:Panel ID="Panel32" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label159" runat="server" style="font-weight: 700" 
                                                                                    Text="COMORBIDITY UPDATE"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 94px">
                                                                                <asp:Label ID="Label158" runat="server" Text="Comorbidity"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 225px">
                                                                                <telerik:RadComboBox ID="cbocomor" Runat="server" Skin="Outlook" Width="250px">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbocomor" Text="Open" 
                                                                                            Value="Open" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbocomor" Text="Closed" 
                                                                                            Value="Closed" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 94px">
                                                                                <asp:Label ID="Label161" runat="server" Text="Dx date"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 225px">
                                                                                <telerik:RadDatePicker ID="dtdxdate" Runat="server" Skin="Outlook">
                                                                                    <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 94px">
                                                                                <asp:Label ID="Label160" runat="server" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td colspan="2" rowspan="2">
                                                                                <telerik:RadTextBox ID="txtnotesCorm" Runat="server" Font-Size="Large" 
                                                                                    Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                    TextMode="MultiLine" Width="500px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="height: 13px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 94px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 42px; width: 94px">
                                                                            </td>
                                                                            <td style="width: 225px; height: 42px">
                                                                                <telerik:RadButton ID="cmdsavecom" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Save" Width="113px">
                                                                                </telerik:RadButton>
                                                                                &nbsp;<asp:Label ID="lblCOMM" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1140px">
                                                                                    <telerik:RadGrid ID="GDCOMORM" runat="server" AllowPaging="True" 
                                                                                        CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Id">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                   <telerik:GridBoundColumn DataField="Id"  
                                                                                                    FilterControlAltText="Filter Id column" HeaderText="Id" 
                                                                                                    SortExpression="Id" UniqueName="Id">
                                                                                                </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Dx_Date" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                    FilterControlAltText="Filter Dx_Date column" HeaderText="Dx_Date" 
                                                                                                    SortExpression="Dx_Date" UniqueName="Dx_Date">
                                                                                                </telerik:GridBoundColumn>
                                                                                                   <telerik:GridBoundColumn DataField="Name" 
                                                                                                    FilterControlAltText="Filter Name column" HeaderText="Name" 
                                                                                                    SortExpression="Name" UniqueName="Name">
                                                                                                </telerik:GridBoundColumn>
                                                                                               <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                    FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                    SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                </telerik:GridBoundColumn>
                                                                                                  <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                                        ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                                        Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                        <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                        <ItemStyle CssClass="ButtonColumn" />
                                                                    </telerik:GridButtonColumn>
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </telerik:RadPageView>
                                                              <telerik:RadPageView ID="V2" runat="server" Selected="True">
                                                                <asp:Panel ID="Panel2" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label147" runat="server" style="font-weight: 700" 
                                                                                    Text="Member Info"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 146px">
                                                                                <asp:Label ID="Label143" runat="server" Text="Member No"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 272px">
                                                                                <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Outlook" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 131px">
                                                                                &nbsp;<asp:Label ID="Label144" runat="server" Text="Member Name"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txtname" Runat="server" Skin="Outlook" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 146px">
                                                                                <asp:Label ID="Label146" runat="server" Text="Proposer Name"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 272px">
                                                                                <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Outlook" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 131px">
                                                                                <asp:Label ID="Label145" runat="server" Text="Client Type"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Corporate" Value="C" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Individual" Value="I" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label148" runat="server" style="font-weight: 700" 
                                                                                    Text="Case Info"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 146px">
                                                                                <asp:Label ID="Label149" runat="server" Text="Admission date"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 272px">
                                                                                <telerik:RadDatePicker ID="dtadmin" Runat="server" Skin="Outlook">
                                                                                    <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td style="width: 131px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 146px">
                                                                                <asp:Label ID="Label150" runat="server" Text="Provider"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 272px">
                                                                                <telerik:RadComboBox ID="cboProvi" Runat="server" AllowCustomText="True" 
                                                                                    MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboProvi" Text="Corporate" 
                                                                                            Value="C" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboProvi" Text="Individual" 
                                                                                            Value="I" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td style="width: 131px">
                                                                                <asp:Label ID="Label151" runat="server" Text="Provider Type"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cboprovtype" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Public" Value="Public" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Private" Value="Private" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 146px; height: 17px;">
                                                                                <asp:Label ID="Label154" runat="server" Text="Claim Type"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 272px; height: 17px;">
                                                                                <telerik:RadComboBox ID="cboclaimtype" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Text="IP" Value="IP" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="OP" Value="OP" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td style="width: 131px; height: 17px;">
                                                                                <asp:Label ID="Label171" runat="server" Text="DP No"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 17px">
                                                                                <telerik:RadTextBox ID="txtDPno" Runat="server" Skin="Outlook" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 146px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 272px">
                                                                                <asp:Label ID="lblcodeU" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 131px">
                                                                                <telerik:RadButton ID="cmdedit" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Edit" Width="113px">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadButton ID="cmdsave" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Save" Width="113px">
                                                                                </telerik:RadButton>
                                                                                &nbsp;&nbsp;<asp:Label ID="lblerr_f" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </telerik:RadPageView>
                                                               <telerik:RadPageView ID="V3" runat="server">
                                                                <asp:Panel ID="Panel4" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label6" runat="server" style="font-weight: 700" 
                                                                                    Text="COSTS UPDATE"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 129px">
                                                                                <asp:Label ID="Label163" runat="server" Text="Pre-Auth Amt"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadNumericTextBox ID="txtauth" Runat="server" Culture="en-US" 
                                                                                    Skin="Outlook" Value="0" Width="125px">
                                                                                </telerik:RadNumericTextBox>
                                                                            </td>
                                                                            <td>
                                                                                <asp:Label ID="Label164" runat="server" Text="Actual Total Cost"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadNumericTextBox ID="txtactual" Runat="server" Culture="en-US" 
                                                                                    Enabled="False" Skin="Outlook" Value="0" Width="125px">
                                                                                </telerik:RadNumericTextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 129px">
                                                                                <asp:Label ID="Label165" runat="server" Text="Cost Date"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadDatePicker ID="dtcost" Runat="server" Skin="Outlook">
                                                                                    <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 129px">
                                                                                <asp:Label ID="Label7" runat="server" Text="Charge Type"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cbocost" Runat="server" AllowCustomText="True" 
                                                                                    MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbocost" Text="Test Charges" 
                                                                                            Value="Test" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbocost" 
                                                                                            Text="Treatment Charges" Value="Treatment" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbocost" 
                                                                                            Text="Isolation Charges" Value="Isolation" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbocost" Text="PPe Charges" 
                                                                                            Value="PPe" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbocost" Text="Other Costs" 
                                                                                            Value="Other" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 129px">
                                                                                <asp:Label ID="Label9" runat="server" Text="Cost"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadNumericTextBox ID="txtcost" Runat="server" Culture="en-US" 
                                                                                    Skin="Outlook" Value="0" Width="125px">
                                                                                </telerik:RadNumericTextBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 129px">
                                                                                <asp:Label ID="Label10" runat="server" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td colspan="2" rowspan="2">
                                                                                <telerik:RadTextBox ID="txtcostnotes" Runat="server" Font-Size="Large" 
                                                                                    Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                    TextMode="MultiLine" Width="500px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="height: 13px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 129px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 42px; width: 129px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                                <telerik:RadButton ID="btncost" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Save" Width="113px">
                                                                                </telerik:RadButton>
                                                                                &nbsp;<asp:Label ID="lblerrcost" runat="server" Font-Size="Medium" 
                                                                                    ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                <asp:Panel ID="Panel5" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1140px">
                                                                                    <telerik:RadGrid ID="GDCOST" runat="server" AllowPaging="True" 
                                                                                        CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%" 
                                                                                        ShowFooter="True">
                                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_Code">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                <telerik:GridBoundColumn DataField="Case_Code" FilterControlAltText="Filter Case_Code column" 
                                                                                                    HeaderText="Case_Code" SortExpression="Case_Code" UniqueName="Case_Code">
                                                                                                </telerik:GridBoundColumn>
                                                                                             <telerik:GridBoundColumn DataField="Cost_Date" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                    FilterControlAltText="Filter Cost_Date column" HeaderText="Cost_Date" 
                                                                                                    SortExpression="Cost_Date" UniqueName="Cost_Date">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Cost_Code" 
                                                                                                    FilterControlAltText="Filter Case_Code column" HeaderText="Cost_Name" 
                                                                                                    SortExpression="Cost_Code" UniqueName="Cost_Code">
                                                                                                </telerik:GridBoundColumn>     
                                                                                                                  <telerik:GridBoundColumn Aggregate="Sum" DataField="Cost_Amount" 
                                                    DataFormatString="{0:#,#}" FooterStyle-Font-Bold="true" HeaderText="Cost_Amount" 
                                                    UniqueName="Cost_Amount">
                                                </telerik:GridBoundColumn>                                                                                                                                                                                       
                                                                                                <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                    FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                    SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                </telerik:GridBoundColumn>   
                                                                                                                                                                      
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </telerik:RadPageView>
                                                            <telerik:RadPageView ID="V4" runat="server">
                                                                <asp:Panel ID="Panel6" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label5" runat="server" style="font-weight: 700" 
                                                                                    Text="NOTES UPDATE"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label12" runat="server" Text="Notes  Date"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadDatePicker ID="DtNotes" Runat="server" Skin="Outlook">
                                                                                    <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 139px">
                                                                                <asp:Label ID="Label15" runat="server" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td colspan="2" rowspan="2">
                                                                                <telerik:RadTextBox ID="txtadmnotes" Runat="server" Font-Size="Large" 
                                                                                    Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                    TextMode="MultiLine" Width="500px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="height: 13px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 42px; width: 139px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                                <telerik:RadButton ID="btnnotes" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Save" Width="113px">
                                                                                </telerik:RadButton>
                                                                                &nbsp;<asp:Label ID="lblnotes" runat="server" Font-Size="Medium" 
                                                                                    ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </telerik:RadPageView>
                                                            <telerik:RadPageView ID="V5" runat="server">
                                                                <asp:Panel ID="Panel7" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label8" runat="server" style="font-weight: 700" 
                                                                                    Text="DISCHARGE UPDATE"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label166" runat="server" Text="Admission Status"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cboadmstatus" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Discharged" Value="Discharged" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Admitted" Value="Admitted" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Deceased" Value="Deceased" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                <asp:Label ID="Label168" runat="server" Text="eOx DP No"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txtclaimno" Runat="server" Skin="Outlook" Width="200px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label167" runat="server" Text="Case Status"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cbostatus" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbostatus" Text="Open" 
                                                                                            Value="Open" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbostatus" Text="Closed" 
                                                                                            Value="Closed" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label11" runat="server" Text="Status  Date"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadDatePicker ID="dtstatus" Runat="server" Skin="Outlook">
                                                                                    <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 139px">
                                                                                <asp:Label ID="Label13" runat="server" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td colspan="2" rowspan="2">
                                                                                <telerik:RadTextBox ID="txtstatusnotes" Runat="server" Font-Size="Large" 
                                                                                    Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                    TextMode="MultiLine" Width="500px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="height: 13px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 42px; width: 139px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                                <telerik:RadButton ID="btnstatus" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Save" Width="113px">
                                                                                </telerik:RadButton>
                                                                                &nbsp;<asp:Label ID="lblsts" runat="server" Font-Size="Medium" 
                                                                                    ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </telerik:RadPageView>
                                                             <telerik:RadPageView ID="V6" runat="server" Selected="True">
                                                                <asp:Panel ID="Panel9" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label14" runat="server" style="font-weight: 700" 
                                                                                    Text="HOMECARE"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1140px">
                                                                                    <telerik:RadGrid ID="GDCASE_HOME" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                        GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_No">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                       <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                            <ItemStyle Width="50px" />
                                                                        </telerik:GridButtonColumn>
                                                                                                <telerik:GridBoundColumn DataField="Case_No" 
                                                                                                    FilterControlAltText="Filter Case_No column" HeaderText="Case_No" 
                                                                                                    SortExpression="Case_No" UniqueName="Case_No">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Member_No" 
                                                                                                    FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                                                    SortExpression="Member_No" UniqueName="Member_No">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Member_Name" 
                                                                                                    FilterControlAltText="Filter Member_Name column" HeaderText="Name" 
                                                                                                    SortExpression="Member_Name" UniqueName="Member_Name">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Admission_Dt" 
                                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                    FilterControlAltText="Filter Admission_Dt column" HeaderText="Admission_Date" 
                                                                                                    SortExpression="Admission_Dt" UniqueName="Admission_Dt">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Prov_name" 
                                                                                                    FilterControlAltText="Filter Prov_name column" HeaderText="Provider" 
                                                                                                    SortExpression="Prov_name" UniqueName="Prov_name">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Case_Status" 
                                                                                                    FilterControlAltText="Filter Case_Status column" HeaderText="Case_Status" 
                                                                                                    SortExpression="Case_Status" UniqueName="Case_Status">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Admission_Status" 
                                                                                                    FilterControlAltText="Filter Admission_Status column" HeaderText="Adm_Status" 
                                                                                                    SortExpression="Admission_Status" UniqueName="Admission_Status">
                                                                                                </telerik:GridBoundColumn>
                                                                                              
                                                                                             
                                                                                            
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label17" runat="server" Text="Case Status"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cbohomests" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbohomests" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cbohomests" Text="Closed" 
                                                                                            Value="Closed" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Deceased" Value="Deceased" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label18" runat="server" Text="Status  Date"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadDatePicker ID="dthomests" Runat="server" Skin="Outlook">
                                                                                    <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 139px">
                                                                                <asp:Label ID="Label19" runat="server" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td colspan="2" rowspan="2">
                                                                                <telerik:RadTextBox ID="txthomenotes" Runat="server" Font-Size="Large" 
                                                                                    Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                    TextMode="MultiLine" Width="500px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="height: 13px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 42px; width: 139px">
                                                                                <asp:Label ID="lblCaseH" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                                <telerik:RadButton ID="btnhome" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Save" Width="113px">
                                                                                </telerik:RadButton>
                                                                                &nbsp;<asp:Label ID="lblhome" runat="server" Font-Size="Medium" 
                                                                                    ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </telerik:RadPageView>
                                                             <telerik:RadPageView ID="V8" runat="server">
                                                                <asp:Panel ID="Panel12" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td bgcolor="#999999" colspan="4">
                                                                                <asp:Label ID="Label23" runat="server" style="font-weight: 700" 
                                                                                    Text="TEST RESULTS UPDATE"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label24" runat="server" Text="Notes  Date"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadDatePicker ID="dtresults" Runat="server" Skin="Outlook">
                                                                                    <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                <asp:Label ID="Label169" runat="server" Text="Results"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cboresults" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboresults" />
                                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboresults" Text="Negative" 
                                                                                            Value="Negative" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Positive" Value="Positive" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 139px">
                                                                                &nbsp;</td>
                                                                            <td colspan="2" rowspan="3">
                                                                                <telerik:RadTextBox ID="txtresultnotes" Runat="server" Font-Size="Large" 
                                                                                    Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                    TextMode="MultiLine" Width="500px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="height: 13px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 139px">
                                                                                <asp:Label ID="Label25" runat="server" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 13px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 139px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 42px; width: 139px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                                <telerik:RadButton ID="btnresult" runat="server" Height="38px" Skin="Sunset" 
                                                                                    Text="Save" Width="113px">
                                                                                </telerik:RadButton>
                                                                                &nbsp;<asp:Label ID="lblerrresul" runat="server" Font-Size="Medium" 
                                                                                    ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                            <td style="height: 42px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1140px">
                                                                                    <telerik:RadGrid ID="GDRESULTS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                        GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="id">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                <telerik:GridBoundColumn DataField="ID" 
                                                                                                    FilterControlAltText="Filter ID column" HeaderText="id" 
                                                                                                    SortExpression="ID" UniqueName="ID">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Test_date" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                    FilterControlAltText="Filter Test_date column" HeaderText="Test_date" 
                                                                                                    SortExpression="Test_date" UniqueName="Test_date">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Case_No" 
                                                                                                    FilterControlAltText="Filter Case_No column" HeaderText="Case_No" 
                                                                                                    SortExpression="Case_No" UniqueName="Case_No">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Test_Result" 
                                                                                                    FilterControlAltText="Filter Test_Result column" HeaderText="Test_Result" 
                                                                                                    SortExpression="Test_Result" UniqueName="Test_Result">
                                                                                                </telerik:GridBoundColumn>
                                                                                              
                                                                                                <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                    FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                    SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                                                                    ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                                                                    Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                                                    <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                                                    <ItemStyle CssClass="ButtonColumn" />
                                                                                                </telerik:GridButtonColumn>
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </telerik:RadPageView>
                                                        </telerik:RadMultiPage>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left">
                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" 
                                            Text="Member Notes"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%" PageSize="20">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                       
                                                        <telerik:GridBoundColumn DataField="Note_date"  DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            SortExpression="Note_date" 
                                                            UniqueName="Note_date" ItemStyle-Width="100">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            SortExpression="Note_From" UniqueName="Note_From" ItemStyle-Width="100">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" 
                                                            HeaderText="Note_Type " SortExpression="Note_Type" 
                                                            UniqueName="Note_Type">
                                                             <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>                                                           
                                                           <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" 
                                                            HeaderText="Notes" SortExpression="Notes" 
                                                            UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                       
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="True" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="lblErr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>

