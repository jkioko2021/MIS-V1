﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try

                HiddenField1.Value = 0

                lblno.Text = ""
                SqlAction = "select [POLICY_CODE],[PROPOSER_DISPLAY_NAME],MAPPING_CODE  from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE [IS_MAPPING]=1"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDMapped.DataSource = MyDatable
                    GDMapped.DataBind()
                    MyDatable = Nothing
                Else
                    GDMapped.DataSource = Nothing
                    GDMapped.DataBind()
                End If

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If

    End Sub

    Protected Sub GDTracking_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTracking.PageIndexChanged
        GDTracking.CurrentPageIndex = e.NewPageIndex
        GDTracking.DataSource = Session("DAD_T")
        GDTracking.DataBind()
    End Sub



    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub



    Protected Sub GDTracking_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTracking.SelectedIndexChanged
        Try
            HiddenField1.Value = 1


            Dim POLICY_CODE As String = ""
            POLICY_CODE = (DirectCast(GDTracking.SelectedItems(0), GridDataItem)).GetDataKeyValue("POLICY_CODE").ToString()
            SqlAction = "select [POLICY_CODE] from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE POLICY_CODE='" & POLICY_CODE & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                LBLID.Text = MyDatable.Rows(0).Item("POLICY_CODE").ToString()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub ToggleRowSelection(ByVal sender As Object, ByVal e As EventArgs)
        Dim Total As Decimal

        TryCast(TryCast(sender, CheckBox).NamingContainer, GridItem).Selected = TryCast(sender, CheckBox).Checked
        Dim checkHeader As Boolean = True
        For Each dataItem As GridDataItem In GD_Pay.MasterTableView.Items
            If Not TryCast(dataItem.FindControl("chkreturn"), CheckBox).Checked Then
                checkHeader = False

                Exit For
            End If

        Next
        Dim headerItem As GridHeaderItem = TryCast(GD_Pay.MasterTableView.GetItems(GridItemType.Header)(0), GridHeaderItem)
        TryCast(headerItem.FindControl("chkheader"), CheckBox).Checked = checkHeader

    End Sub

    Protected Sub ToggleSelectedState(ByVal sender As Object, ByVal e As EventArgs)
        Dim headerCheckBox As CheckBox = TryCast(sender, CheckBox)

        For Each dataItem As GridDataItem In GD_Pay.MasterTableView.Items
            TryCast(dataItem.FindControl("chkreturn"), CheckBox).Checked = headerCheckBox.Checked
            dataItem.Selected = headerCheckBox.Checked

        Next
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub
    Protected Sub GD_Pay_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GD_Pay.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("POLICY_CODE").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            UpdateRecord("UPDATE [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] SET  [IS_MAPPING]=0   WHERE  POLICY_CODE='" & HiddenField1.Value & "'")
            'DeleteRecord("DELETE FROM TBL_MIS_CRM_DOCS WHERE  File_No='" & HiddenField1.Value.ToString & "'")
            SqlAction = "select [PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME]  from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE [IS_MAPPING]=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_Pay.DataSource = MyDatable
                GD_Pay.DataBind()
                MyDatable = Nothing
            Else
                GD_Pay.DataSource = Nothing
                GD_Pay.DataBind()
            End If
            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record updated!"
            'CmdSave.Enabled = False
        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try

            If cbosearch.SelectedValue = "N" Then
                SqlAction = "select [PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],MAPPING_CODE  from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE   PROPOSER_DISPLAY_NAME Like '%" & Trim(txtsearch.Text.ToUpper) & "%'"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "select [PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME],MAPPING_CODE  from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE   POLICY_CODE Like '%" & Trim(txtsearch.Text.ToUpper) & "%'"
            Else
                Exit Sub
            End If

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking.DataSource = MyDatable
                GDTracking.DataBind()
                'Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDTracking.DataSource = Nothing
                GDTracking.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub btnadd_Click(sender As Object, e As System.EventArgs) Handles btnadd.Click
        Try
            GD_Pay.DataSource = Nothing
            GD_Pay.DataBind()
            UpdateRecord("UPDATE [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] SET [IS_MAPPING]=1  WHERE [POLICY_CODE]='" & Trim(LBLID.Text) & "'")

            SqlAction = "select [PROPOSER_ID],[POLICY_CODE],[PROPOSER_DISPLAY_NAME]  from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE [IS_MAPPING]=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_Pay.DataSource = MyDatable
                GD_Pay.DataBind()
                txtid.Text = MyDatable.Rows(0).Item("PROPOSER_ID").ToString
                txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString
                MyDatable = Nothing
            Else
                GD_Pay.DataSource = Nothing
                GD_Pay.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub btngen_Click(sender As Object, e As System.EventArgs) Handles btngen.Click
        Try
            GDMapped.DataSource = Nothing
            GDMapped.DataBind()

            For Each dataItem As GridDataItem In GD_Pay.MasterTableView.Items
                Dim chkSelect As CheckBox = DirectCast(dataItem.FindControl("chkreturn"), CheckBox)

                If chkSelect.Checked Then
                    Dim ID As String = dataItem.GetDataKeyValue("POLICY_CODE").ToString()
                    UpdateRecord("UPDATE [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] SET  MAPPING_CODE='" & txtid.Text & "',[PROPOSER_DISPLAY_NAME]='" & Trim(txtproposer.Text.ToUpper) & "'  WHERE [POLICY_CODE]='" & Trim(ID) & "'")
                    UpdateRecord("UPDATE [DATA_REPOSITORY_DB].[dbo].[MASTER_STATEMENT] SET  PROPOSER_ID='" & txtid.Text & "',[PROPOSER_DISPLAY_NAME]='" & Trim(txtproposer.Text.ToUpper) & "'  WHERE [POLICY_CODE]='" & Trim(ID) & "'")

                End If

            Next

            Dim audit As New DataManagement
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Proposer Mapping", "Mapping Record :-   :" & txtproposer.Text.ToUpper & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".",
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)

            lblerr.Text = "Records Mapped successfully"
            SqlAction = "select [POLICY_CODE],[PROPOSER_DISPLAY_NAME],MAPPING_CODE  from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE [IS_MAPPING]=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMapped.DataSource = MyDatable
                GDMapped.DataBind()
                MyDatable = Nothing
            Else
                GDMapped.DataSource = Nothing
                GDMapped.DataBind()
            End If

            lblno.Text = ""

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btngen0_Click(sender As Object, e As EventArgs) Handles btngen0.Click
        If chkRefresh.Checked = True Then

            Me.MyDBAction.PROPOSER_MAPPING(Session("username"))
            UpdateRecord("UPDATE [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] SET  [IS_MAPPING]=0   WHERE IS_MAPPING=1")
            lblerr.Text = "Statement Updated successfully"
            SqlAction = "select [POLICY_CODE],[PROPOSER_DISPLAY_NAME],MAPPING_CODE  from [DATA_REPOSITORY_DB].dbo.[MASTER_PROPOSER_MAPPING] WITH (NOLOCK) WHERE [IS_MAPPING]=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMapped.DataSource = MyDatable
                GDMapped.DataBind()
                MyDatable = Nothing
            Else
                GDMapped.DataSource = Nothing
                GDMapped.DataBind()
            End If
        End If
    End Sub
End Class
