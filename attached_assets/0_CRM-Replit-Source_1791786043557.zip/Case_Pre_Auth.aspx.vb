﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                dtadmin.DbSelectedDate = Date.Now()
                dtdischarge.DbSelectedDate = Date.Now()

                Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME]  FROM [CRM].[dbo].[TBL_MIS_PROVIDER_MASTER] ORDER BY ORG_NAME" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboProvi
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                    .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                    .DataBind()
                End With
                Str = "SELECT DISTINCT [BENEFIT]  FROM [dbo].[TBL_MIS_BENEFITS] ORDER BY BENEFIT" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbobenefit
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("BENEFIT").ToString
                    .DataValueField = MyDatatable.Columns("BENEFIT").ToString
                    .DataBind()
                End With

                Session("empcode") = Nothing
                Session("agentemail") = Nothing

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
    Public Sub LoadGrid(ByVal str As String)

        SqlAction = "SELECT [Note_id],[Note_Type],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_PREAUTH_NOTES] WHERE  Member_No ='" & str & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM [CRM].[dbo].[TBL_VALID_LIST]  with(nolock) WHERE MEMBER_NAME  LIKE '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME,[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM [CRM].[dbo].[TBL_VALID_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO like '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                If cbosearch.SelectedValue = "N" Then
                    SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM [CRM].[dbo].[TBL_LAPSED_LIST]  with(nolock) WHERE MEMBER_NAME  LIKE '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
                ElseIf cbosearch.SelectedValue = "M" Then
                    SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME,[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM [CRM].[dbo].[TBL_LAPSED_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO like '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
                End If
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDMEMBER.DataSource = MyDatable
                    GDMEMBER.DataBind()
                    Session("DAD_T") = MyDatable
                    MyDatable = Nothing
                Else
                    GDMEMBER.DataSource = Nothing
                    GDMEMBER.DataBind()
                End If

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
            number = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],GRP_INDV FROM [CRM].[dbo].[TBL_VALID_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO ='" & number & "' order by DISPLAY_MEMBERSHIP_NO"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()

                Str = "SELECT   [Pre_Auth_id],[Case_No],[Member_No],[Member_Name],[Pre_Auth_Amt],[Claim_Type],[Benefit_Name],[Pre_Auth_Status]  FROM [CRM].[dbo].[TBL_MIS_CRM_PRE_AUTH] WHERE  Member_No='" & number & "'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDCASE.DataSource = MyDatable
                    GDCASE.DataBind()
                    MyDatable = Nothing
                    HiddenField1.Value = 0
                    cmdsave.Enabled = True
                Else
                    GDCASE.DataSource = Nothing
                    GDCASE.DataBind()
                    HiddenField1.Value = 0
                    cmdsave.Enabled = True
                End If
            Else
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],GRP_INDV FROM [CRM].[dbo].[TBL_LAPSED_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO ='" & number & "' order by DISPLAY_MEMBERSHIP_NO"
                MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                    txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                    cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()

                    Str = "SELECT   [Pre_Auth_id],[Case_No],[Member_No],[Member_Name],[Pre_Auth_Amt],[Claim_Type],[Benefit_Name],[Pre_Auth_Status]  FROM [CRM].[dbo].[TBL_MIS_CRM_PRE_AUTH] WHERE  Member_No='" & number & "'"
                    MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                    If MyDatable.Rows.Count > 0 Then
                        GDCASE.DataSource = MyDatable
                        GDCASE.DataBind()
                        MyDatable = Nothing
                        HiddenField1.Value = 0
                        cmdsave.Enabled = True
                    Else
                        GDCASE.DataSource = Nothing
                        GDCASE.DataBind()
                        HiddenField1.Value = 0
                        cmdsave.Enabled = True
                    End If
                End If
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Generate_Task()
        SqlAction = "SELECT ISNULL((MAX([Pre_Auth_id])+1),1) NUMBER FROM [CRM].[dbo].[TBL_MIS_CRM_PRE_AUTH]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblcode.Text = "DP" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub
    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim adm_status As String = ""
            Dim case_status As String = ""
            HiddenField1.Value = 0
            lblerr.Text = ""
            If HiddenField1.Value = 0 Then
             
                Generate_Task()
               
                'MyDBAction.Pre_Auth_reg(lblcode.Text, CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(Date.Now()).ToString("yyyy-MM-dd"), CDate(dtdischarge.DbSelectedDate).ToString("yyyy-MM-dd"), txtname.Text, txtmemno.Text, cboclient.SelectedValue, cboProvi.SelectedValue, txtauth.Text, cboclaimtype.SelectedValue, cbobenefit.SelectedValue, case_status, Session("UserName").ToString, 0)
            End If
            If txtnotes.Text <> "" Then
                MyDBAction.TRACKING_PREAUTH_MESSAGES(txtmemno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text, "AUTH-NOTES")
            End If
         

            Str = "SELECT   [Pre_Auth_id],[Case_No],[Member_No],[Member_Name],[Pre_Auth_Amt],[Claim_Type],[Benefit_Name],[Pre_Auth_Status]  FROM [CRM].[dbo].[TBL_MIS_CRM_PRE_AUTH] WHERE  Member_No='" & txtmemno.Text & "'"
            'Str = "SELECT [Case_No] ,[Admission_Dt],[Member_No],[Transfer_To_Provider],[Admission_Status],[Case_Status],[Pre_Auth_Amt],[Entered_by],[Entry_date]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Member_No='" & txtmemno.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE.DataSource = MyDatable
                GDCASE.DataBind()
            End If
            lblerr.Text = "Saved Successfully.."

            HiddenField1.Value = 0
            lblcode.Text = ""
            txtnotes.Text = ""
            dtadmin.DbSelectedDate = Date.Now()

            txtname.Text = ""
            txtmemno.Text = ""
            txtprop.Text = ""

            cboclient.SelectedValue = ""
            cboProvi.SelectedValue = ""
            cboProvi.SelectedValue = ""

            txtauth.Text = ""
            cboclaimtype.SelectedValue = ""

            lblcode.Enabled = True
            txtnotes.Enabled = True
            dtadmin.Enabled = True

            txtname.Enabled = True
            txtmemno.Enabled = True
            txtprop.Enabled = True
            cboclient.Enabled = True
            cboProvi.Enabled = True
            cboProvi.Enabled = True

            txtauth.Enabled = True
            cboclaimtype.Enabled = True

            cmdsave.Enabled = True
            cmdsave.Enabled = True

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String
            Reportname = "Pre-Auth List-Detail"
            'SqlAction = "SELECT  [Case_id],[Case_No],[Admission_Dt],[Member_Name],[Proposer_Name],[Client_Type],[Member_No],[Initial_Provider],[Transfer_To_Provider],[Facility_Type],[Test_Results],[Admission_Status],[Case_Status],[Pre_Auth_Amt],[Test_Cost],[Treatment_Cost],[Isolation_Cost],[PPE_Cost],[Other_Charges],[Total_Actual_Cost],[Entered_by],[Entry_date],[Claim_No],[Discharge_Date],[Discharge_By],[Close_Date],[Closed_By],[Re_Opened],[Re_Open_Dt],[Re_Opened_By],Claim_Type,Recovery_Status  FROM [CRM].[dbo].[VW_MIS_CRM_COV_CASE_LIST] Where Admission_Dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Claim_Type='IP'"

            SqlAction = "SELECT [Pre_Auth_id] ,[Case_No],[Admission_Dt],[Discharge_Dt],[Pre_Auth_Dt],[Member_No],[Member_Name],[Pre_Auth_Amt],[Claim_Type],[Benefit_Name], P.ORG_NAME [Provider]     ,[Entered_By],[Entry_date],[Pre_Auth_Status]  FROM [CRM].[dbo].[TBL_MIS_CRM_PRE_AUTH] R INNER JOIN dbo.TBL_MIS_PROVIDER_MASTER P WITH(NOLOCK) ON R.Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID Where [Pre_Auth_Dt] Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"


            Session("EXCEL") = "TO EXCEL"
            Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
            'Reportname = ""
        Catch ex As Exception

        End Try
    End Sub
End Class

