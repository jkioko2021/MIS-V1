﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
      
      
            Str = ""
            MyDatatable = Nothing

            loadGrid()
            Str = ""
            MyDatatable = Nothing
            ' dtupload.DbSelectedDate = Date.Now
        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "  SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE Submitted=0 AND Inv_Status='RTS'  AND ACTIVE=1 "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_IP_CLAIM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr_1.Text = ex.Message
        End Try
    End Sub

   
    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/File_Claims_IP.ashx?Id="), id)
    End Sub
    

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        ltEmbed.Text = ""

        Session("Audited") = 0
        Session("Posting") = 0
        lblfile.Text = ""
        Try
            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],Audited,Posting, INV_STATUS,Member_Name,Provider_Name,RECEIVE_DT,SERVICE_DT FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING] T WITH (NOLOCK)   INNER JOIN [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST p WITH (NOLOCK)  ON T.Provider_Code COLLATE DATABASE_DEFAULT =P.ORG_ID    WHERE File_No ='" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then
                    lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    Session("Audited") = MyDatable.Rows(0).Item("Audited").ToString()
                    Session("Posting") = MyDatable.Rows(0).Item("Posting").ToString()
                    load_Grid(lblfile.Text)
                    'txtproposer.Enabled = False
                    lblfile.Enabled = False
                End If
                HiddenField1.Value = 1
                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception
            lblerr_1.Text = ex.Message
        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr_1.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,P.ORG_NAME FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING] T WITH (NOLOCK)   INNER JOIN [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST p WITH (NOLOCK)  ON T.Provider_Code COLLATE DATABASE_DEFAULT =P.ORG_ID  WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%' AND Inv_Status='RTS'"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,P.ORG_NAME FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING] T WITH (NOLOCK)   INNER JOIN [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST p WITH (NOLOCK)  ON T.Provider_Code COLLATE DATABASE_DEFAULT =P.ORG_ID  WHERE ACTIVE=1 AND   MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%' AND Inv_Status='RTS'"
            ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,P.ORG_NAME FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING] T WITH (NOLOCK)   INNER JOIN [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST p WITH (NOLOCK)  ON T.Provider_Code COLLATE DATABASE_DEFAULT =P.ORG_ID  WHERE ACTIVE=1 AND   MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%' AND Inv_Status='RTS'"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,P.ORG_NAME FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING] T WITH (NOLOCK)   INNER JOIN [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST p WITH (NOLOCK)  ON T.Provider_Code COLLATE DATABASE_DEFAULT =P.ORG_ID  WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%' AND Inv_Status='RTS'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub


    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try

            lblerr_1.Text = ""
            If lblfile.Text = "" Then
                lblerr_1.Text = "Select the File to Submit!"
                Exit Sub
            End If
            If txtcomment.Text = "" Then
                lblerr_1.Text = "You must enter short notes!"
                Exit Sub
            End If
            If cboallocate.SelectedValue = "F" Then
                UpdateRecord("UPDATE [dbo].[TBL_MIS_IP_CLAIM_TRACKING] SET Submitted=1,[Discharged]=1,[Discharge_By]='" & Session("username") & "',[Discharge_DT]='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Inv_Status='DISCHARGED'  where [File_No]= '" & lblfile.Text & "'")

            Else
                UpdateRecord("UPDATE [dbo].[TBL_MIS_IP_CLAIM_TRACKING] SET   Submitted=0,Inv_Status='RETURNED-DPU'  where [File_No]= '" & lblfile.Text & "'")

            End If

            MyDBAction.TRACKING_IP_CLAIM_MESSAGES(lblfile.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
            lblerr_1.Text = "Submit successfull!"

            HiddenField1.Value = ""
            lblfile.Enabled = False
           
            lblfile.Text = ""
            ltEmbed.Text = ""
           
            txtcomment.Text = ""
            
            txtcomment.Text = ""
          
            load_Grid(lblfile.Text)
            loadGrid()

        Catch ex As Exception
            lblerr_1.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
End Class

