﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Statements_Non_Medical.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Insured Name"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Member_code">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter Member_code column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Member_code" 
                                                            FilterControlAltText="Filter Member_code column" 
                                                            HeaderText="Member_code" SortExpression="Member_code" 
                                                            UniqueName="Member_code">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_name" 
                                                            FilterControlAltText="Filter Member_name column" HeaderText="Member_name" 
                                                            SortExpression="Member_name" UniqueName="Member_name">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Member_DOB"  DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter Member_DOB column" HeaderText="Member_DOB" 
                                                            SortExpression="Member_DOB" UniqueName="Member_DOB">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="Member_Pin_No" 
                                                            FilterControlAltText="Filter Member_Pin_No column" HeaderText="Member_Pin_No" 
                                                            SortExpression="Member_Pin_No" UniqueName="Member_Pin_No">
                                                        </telerik:GridBoundColumn>
                                                     
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="LBLFAMNO" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="Label146" runat="server" style="font-weight: 700" Text="RM"></asp:Label>
                                        :<asp:Label ID="RMNAME" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="3" Skin="Office2007">
                                            <Tabs>
                                                <telerik:RadTab runat="server" PageViewID="V2" Text="Premium Statement">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V7" 
                                                    Text="Non-Medical Policies">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server">
                                            <telerik:RadPageView ID="V2" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel1" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="3">
                                                                <asp:Label ID="Label144" runat="server" Text="Premium Statement"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>                                                                           
                                                                                <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                    SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                    SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                    SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ACTION_TYPE" 
                                                                                    FilterControlAltText="Filter ACTION_TYPE column" HeaderText="ACTION_TYPE" 
                                                                                    SortExpression="ACTION_TYPE" UniqueName="ACTION_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="TOTAL_MEMBERS" 
                                                                                    FilterControlAltText="Filter TOTAL_MEMBERS column" HeaderText="MEMBERS" 
                                                                                    SortExpression="TOTAL_MEMBERS" UniqueName="TOTAL_MEMBERS">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                                                    FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                                                    SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="TRANSACTION_DATE" 
                                                                                    FilterControlAltText="Filter TRANSACTION_DATE column" HeaderText="TRANSACTION_DATE" 
                                                                                    SortExpression="TRANSACTION_DATE" UniqueName="TRANSACTION_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                                      <telerik:GridBoundColumn DataField="DR" 
                                                                                    FilterControlAltText="Filter DR column" HeaderText="DR" 
                                                                                    SortExpression="DR" UniqueName="DR">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="CR" 
                                                                                    FilterControlAltText="Filter CR column" HeaderText="CR" 
                                                                                    SortExpression="CR" UniqueName="CR">
                                                                                </telerik:GridBoundColumn>
                                                                             
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:CheckBox ID="chkcurrent" runat="server" Text="Active Policy" />
                                                            </td>
                                                            <td style="width: 215px" align="right">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:CheckBox ID="chkex" runat="server" Text="Excel Version" />
                                                            </td>
                                                            <td align="right" style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <telerik:RadButton ID="btnstatement" runat="server" Skin="Simple" 
                                                                    Text="Print Statement" Width="276px">
                                                                </telerik:RadButton>
                                                            </td>
                                                            <td align="right" style="width: 215px">
                                                                <asp:Label ID="Label145" runat="server" Font-Bold="True" Text="O/S balance"></asp:Label>
                                                            </td>
                                                            <td style="width: 223px">
                                                                <telerik:RadNumericTextBox ID="txtbal" Runat="server" Enabled="False" 
                                                                    Skin="Simple">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="lblid" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                            </td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                              <telerik:RadPageView ID="V7" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel8" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label1" runat="server" Font-Bold="True" 
                                                                    Text="NON-MEDICAL POLICY HISTRY"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel10" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="RD_NONMED" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                               <telerik:GridBoundColumn DataField="Insured" 
                                                                                    FilterControlAltText="Filter Insured column" HeaderText="Insured" 
                                                                                    SortExpression="Insured" UniqueName="Insured">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="Client_Type" 
                                                                                    FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                                    SortExpression="Client_Type" UniqueName="Client_Type">
                                                                                </telerik:GridBoundColumn>
                                                                                  <telerik:GridBoundColumn DataField="Policy_no" 
                                                                                    FilterControlAltText="Filter Policy_no column" HeaderText="Policy_no" 
                                                                                    SortExpression="Policy_no" UniqueName="Policy_no">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Commence"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Commence column" HeaderText="Commence" 
                                                                                    SortExpression="Commence" UniqueName="Commence">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Expiring"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Expiring column" HeaderText="Expiring" 
                                                                                    SortExpression="Expiring" UniqueName="Expiring">
                                                                                </telerik:GridBoundColumn>
                                                                                                                                                          
                                                                                      <telerik:GridBoundColumn DataField="Agency" 
                                                                                    FilterControlAltText="Filter Agency column" HeaderText="Agency" 
                                                                                    SortExpression="Agency" UniqueName="Agency">
                                                                                </telerik:GridBoundColumn>
                                                                                     <telerik:GridBoundColumn DataField="Class_Name" 
                                                                                    FilterControlAltText="Filter Class_Name column" HeaderText="Class_Name" 
                                                                                    SortExpression="Class_Name" UniqueName="Class_Name">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>

