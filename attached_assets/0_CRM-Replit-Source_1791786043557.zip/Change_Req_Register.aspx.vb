﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    'Dim empcode As String = ""
    Dim AB As Integer
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            HiddenField1.Value = 0
            dtbooking.DbSelectedDate = Date.Now

            dtbooking.Enabled = False
            cbostatus.Enabled = False



            cmdnew.Enabled = False
            cmdedit.Enabled = False

            Session("email") = Nothing
            Str = "SELECT [Doc_Code],[Doc_Name]FROM [dbo].[TBL_MIS_TASK_DOC_TYPE]"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With chklist
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Doc_Name").ToString
                .DataValueField = MyDatatable.Columns("Doc_Code").ToString
                .DataBind()
            End With

       
            Str = "SELECT SYSTEM_NAME,SYSTEM_NAME FROM [TBL_MIS_TASK_SYSTEM]"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbosystem
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("SYSTEM_NAME").ToString
                .DataValueField = MyDatatable.Columns("SYSTEM_NAME").ToString
                .DataBind()
            End With
            SqlAction = "SELECT CR_No, [CR_Name],[CR_dt],[CR_Status],[Entered_by],[Entry_Date],[CR_priority]  FROM [dbo].[TBL_MIS_TASK_CR] WHERE  CR_Status ='O' "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
                MyDatable = Nothing
            Else
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
            End If
        End If
    End Sub
    Public Sub Generate_Task()

        If cbotype.SelectedValue = "D" Then
            SqlAction = "SELECT ISNULL((MAX(id)+1),1) NUMBER FROM [dbo].[TBL_MIS_TASK_CR]"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
                Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
                lbltaskno.Text = "CR/" & cbotype.SelectedValue & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
            End If
        Else
            SqlAction = "SELECT ISNULL((MAX(id)+1),1) NUMBER FROM [dbo].[TBL_MIS_TASK_SYSTEM_CR]"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
                Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
                lbltaskno.Text = "CR/" & cbotype.SelectedValue & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
            End If
        End If

    End Sub
    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim MailSent As Boolean = False
            Dim allocated As String = ""
            If txttaskname.Text = "" Then
                lblerr.Text = "Task Name Missing!"
                Exit Sub
            End If

            If HiddenField1.Value = 0 Then
                Generate_Task()
                MyDBAction.TASK_CREATION(lbltaskno.Text, cbotype.SelectedValue, txttaskname.Text, CDate(dtbooking.SelectedDate).ToString("yyyy-MM-dd"), cbostatus.SelectedValue, Session("username"), CDate(Date.Now()).ToString("yyyy-MM-dd"), cbopriority.SelectedValue, txtdescr.Text, cbosystem.SelectedValue)
            Else
                MyDBAction.TASK_CREATION(lbltaskno.Text, cbotype.SelectedValue, txttaskname.Text, CDate(dtbooking.SelectedDate).ToString("yyyy-MM-dd"), cbostatus.SelectedValue, Session("username"), CDate(Date.Now()).ToString("yyyy-MM-dd"), cbopriority.SelectedValue, txtdescr.Text, cbosystem.SelectedValue)
            End If
            For Each MyItem In chklist.Items
                If MyItem.Selected = True Then
                    MyDBAction.UPLOAD_ITEMS_CR(lbltaskno.Text, MyItem.value, MyItem.TEXT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"))
                End If
            Next

            cmdsave.Enabled = False
            cmdnew.Enabled = True
            cmdedit.Enabled = True
            loadgrid(lbltaskno.Text)
            lbltaskno.Text = ""
            txttaskname.Text = ""
            txtdescr.Text = "" : dtbooking.SelectedDate = Date.Now : cbostatus.SelectedValue = "" : allocated = "NO" : cbopriority.SelectedValue = "" : cbosystem.SelectedValue = ""
            HiddenField1.Value = 0
            lblerr.Text = "Lead saved successfully!"
            Generate_Task()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    
    Protected Sub cmdedit_Click(sender As Object, e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        cmdsave.Enabled = True
        txttaskname.Enabled = True
        txtdescr.Enabled = True
        dtbooking.Enabled = True
        'dtclosing.Enabled = True
        cbostatus.Enabled = True
        cbopriority.Enabled = True
        'dtclosing.Enabled = True
        cbosystem.Enabled = True
        'txtcomment.Enabled = True
    End Sub

    Protected Sub cmdnew_Click(sender As Object, e As System.EventArgs) Handles cmdnew.Click
        HiddenField1.Value = 0
        Generate_Task()
        cmdsave.Enabled = True
        txttaskname.Enabled = True
        txtdescr.Enabled = True
        dtbooking.Enabled = True

        cbostatus.Enabled = True
        cbopriority.Enabled = True

        cbosystem.Enabled = True
        txttaskname.Text = "" : txtdescr.Text = "" : dtbooking.SelectedDate = Date.Now : cbostatus.SelectedValue = "" : cbopriority.SelectedValue = "" : cbosystem.SelectedValue = ""
    End Sub
    Public Sub loadgrid(ByVal task As String)
        MyDatable = Nothing

        SqlAction = "SELECT CR_No, [CR_Name],[CR_dt],[CR_Status],[Entered_by],[Entry_Date],[CR_priority]  FROM [dbo].[TBL_MIS_TASK_CR] WHERE  CR_No ='" & task & "' "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
            MyDatable = Nothing
        Else
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
        End If

    End Sub

    Protected Sub GDSEARCH_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH_1.SelectedIndexChanged
        Try
            lbltaskno.Text = (DirectCast(GDSEARCH_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("CR_No").ToString()
            SqlAction = "SELECT CR_No, [CR_Name],[CR_dt],[CR_Status],[Entered_by],[Entry_Date],[CR_priority]  FROM [dbo].[TBL_MIS_TASK_CREATION] WHERE  CR_No ='" & lbltaskno.Text & "' "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txttaskname.Text = MyDatable.Rows(0).Item("Task_name").ToString()
                txtdescr.Text = MyDatable.Rows(0).Item("Task_description").ToString()
                dtbooking.DbSelectedDate = MyDatable.Rows(0).Item("Task_open_dt").ToString()
                'dtclosing.SelectedDate = MyDatable.Rows(0).Item("Task_due_dt").ToString()
                cbostatus.SelectedValue = MyDatable.Rows(0).Item("Task_status").ToString()
                cbopriority.SelectedValue = MyDatable.Rows(0).Item("Task_priority").ToString()
                'cboallocateto.SelectedValue = MyDatable.Rows(0).Item("Task_allocated_To").ToString()
                cmdsave.Enabled = False
                cmdnew.Enabled = True
                cmdedit.Enabled = True
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


  
End Class
