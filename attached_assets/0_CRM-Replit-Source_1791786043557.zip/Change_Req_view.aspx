﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Change_Req_view.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <table style="width: 100%">
                        <tr>
                            <td>
                                <asp:Panel ID="Panel14" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                    Width="1214px">
                                    <table style="100%: ;">
                                        <tr>
                                            <td class="style8">
                                                <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                    Height="100%" Width="1151px">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td align="center" bgcolor="#CCCCCC">
                                                                <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                                                    Text="Upload Documents"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center">
                                                                <asp:Panel ID="Panel16" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                    Height="100%" Width="1151px">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="width: 2817px">
                                                                                <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                                                                    Text="Search By"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 445px">
                                                                                <telerik:RadComboBox ID="cbosearch" Runat="server" Skin="Web20" 
                                                                                    style="margin-left: 0px" AutoPostBack="True">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Task Name" Value="N" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Task No" Value="T" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Specification" Value="S" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadComboBox ID="cbotext" Runat="server" AllowCustomText="True" 
                                                                                    Skin="Web20" Width="250px">
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadButton ID="SEARCH" runat="server" Skin="Web20" Text="Search">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <asp:Panel ID="Panel23" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="100%">
                                                    <telerik:RadGrid ID="GD_TASKS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="CR_No">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                    UniqueName="Select">
                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                    <ItemStyle Width="50px" />
                                                                </telerik:GridButtonColumn>
                                                                <telerik:GridBoundColumn DataField="CR_No" 
                                                                    FilterControlAltText="Filter CR_No column" HeaderText="CR_No" 
                                                                    SortExpression="CR_No" UniqueName="CR_No">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="CR_Name" 
                                                                    FilterControlAltText="Filter CR_Name column" HeaderText="CR_Name" 
                                                                    SortExpression="CR_Name" UniqueName="CR_Name">
                                                                    <HeaderStyle Width="200px" />
                                                                    <ItemStyle Width="200px" />
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="CR_dt" 
                                                                    FilterControlAltText="Filter CR_dt column" HeaderText="CR_dt" 
                                                                    SortExpression="CR_dt" UniqueName="CR_dt">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Entered_by" 
                                                                    FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                    SortExpression="Entered_by" UniqueName="Entered_by">
                                                                </telerik:GridBoundColumn>
                                                              
                                                        
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <asp:Label ID="Label145" runat="server" Font-Bold="True" Text="CR Status"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <telerik:RadDatePicker ID="dtclose" Runat="server">
                                                </telerik:RadDatePicker>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                &nbsp;<telerik:RadComboBox ID="cbostatus" Runat="server" AutoPostBack="True" 
                                                    Skin="Web20" style="margin-left: 0px">
                                                    <Items>
                                                        <telerik:RadComboBoxItem runat="server" Text="Open" Value="O" />
                                                        <telerik:RadComboBoxItem runat="server" Text="Closed" Value="C" />
                                                    </Items>
                                                </telerik:RadComboBox>
                                                &nbsp;&nbsp;&nbsp;&nbsp;
                                                <telerik:RadButton ID="SEARCH0" runat="server" Skin="Web20" Text="update">
                                                </telerik:RadButton>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <asp:Label ID="Label144" runat="server" Font-Bold="True" Text="Documents"></asp:Label>
                                            </td>
                                        </tr>
                                        <tr>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                                    Width="100%">
                                                    <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                        GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                <HeaderStyle Width="20px" />
                                                            </RowIndicatorColumn>
                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                <HeaderStyle Width="20px" />
                                                            </ExpandCollapseColumn>
                                                            <Columns>
                                                                <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                    FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                    SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Cr_No" 
                                                                    FilterControlAltText="Filter Cr_No column" HeaderText="Cr_No" 
                                                                    SortExpression="Cr_No" UniqueName="Cr_No">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                    FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                    SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                    FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                    SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="File_Name" 
                                                                    FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                    SortExpression="File_Name" UniqueName="File_Name">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Upload_By" 
                                                                    FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                    SortExpression="Upload_By" UniqueName="Upload_By">
                                                                </telerik:GridBoundColumn>
                                                                <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                    SortExpression="DOC_ID">
                                                                    <ItemTemplate>
                                                                        <asp:LinkButton ID="lnkView" runat="server" 
                                                                            CommandArgument='<%# Eval("DOC_ID") %>' OnClick="View" Text="View"></asp:LinkButton>
                                                                    </ItemTemplate>
                                                                </telerik:GridTemplateColumn>
                                                            </Columns>
                                                            <EditFormSettings>
                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                </EditColumn>
                                                            </EditFormSettings>
                                                        </MasterTableView>
                                                        <FilterMenu EnableImageSprites="False">
                                                        </FilterMenu>
                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                        </HeaderContextMenu>
                                                    </telerik:RadGrid>
                                                </asp:Panel>
                                            </td>
                                            <td class="style8">
                                                <asp:HiddenField ID="HiddenField1" runat="server" />
                                            </td>
                                            <td class="style8" bgcolor="#666666">
                                                <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                &nbsp;</td>
                                            <td class="style8">
                                            </td>
                                            <td class="style9" style="width: 109px;">
                                                &nbsp;</td>
                                            <td style="width: 287px">
                                                &nbsp;&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td class="style8">
                                                <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                    ScrollBars="Horizontal" Width="1142px">
                                                    <asp:Literal ID="ltEmbed" runat="server" />
                                                </asp:Panel>
                                            </td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </td>
                        </tr>
                    </table>
                </ContentTemplate>
           
            </asp:UpdatePanel>
</asp:Content>
