﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                dtadmin.DbSelectedDate = Date.Now()

                Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME]  FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST ORDER BY ORG_NAME" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboProvi
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                    .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                    .DataBind()
                End With
                Str = "SELECT DISTINCT [Code],[Name]  FROM [dbo].[TBL_MIS_CRM_COV_COMORB] ORDER BY CODE" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbocomor
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Name").ToString
                    .DataValueField = MyDatatable.Columns("Code").ToString
                    .DataBind()
                End With

                Session("empcode") = Nothing
                Session("agentemail") = Nothing

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE MEMBER_NAME  LIKE '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME,[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO like '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDMEMBER.DataSource = Nothing
                GDMEMBER.DataBind()
                End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
            number = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],GRP_INDV FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO ='" & number & "' order by DISPLAY_MEMBERSHIP_NO"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()

                Str = "SELECT R.Case_No,R.Claim_No, R.Admission_Dt,R.Admission_Status, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt, R.Total_Actual_Cost, R.Entered_by, R.Entry_date,P.ORG_NAME Transfer_To_Provider FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) INNER JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Member_No='" & number & "' AND Claim_type='IP'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDCASE.DataSource = MyDatable
                    GDCASE.DataBind()
                    MyDatable = Nothing
                    HiddenField1.Value = 0
                    cmdsave.Enabled = True
                Else
                    GDCASE.DataSource = Nothing
                    GDCASE.DataBind()
                    HiddenField1.Value = 0
                    cmdsave.Enabled = True
                End If

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Generate_Task()
        SqlAction = "SELECT ISNULL((MAX(Case_Id)+1),1) NUMBER FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblcode.Text = "CV" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub
    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim adm_status As String = ""
            Dim case_status As String = ""
            HiddenField1.Value = 0
            lblerr.Text = ""
            If cboProvi.SelectedValue = "" Then
                lblerr.Text = "You Must Select Provider Name"
                Exit Sub
            End If
            If cboprovtype.SelectedValue = "" Then
                lblerr.Text = "You Must Select Provider Type"
                Exit Sub
            End If
            If txtauth.Text = 0 Then
                lblerr.Text = "You Must Enter the Pre-Auth Amount"
                Exit Sub
            End If
            If txtmemno.Text = "" Then
                lblerr.Text = "You Must Enter the Member No"
                Exit Sub
            End If
            If txtname.Text = "" Then
                lblerr.Text = "You Must Enter the Member name"
                Exit Sub
            End If
            If txtprop.Text = "" Then
                lblerr.Text = "You Must Enter the Proposer name"
                Exit Sub
            End If
            If cboclient.SelectedValue = "" Then
                lblerr.Text = "You Must Select Client Type"
                Exit Sub
            End If
            If cboclaimtype.SelectedValue = "" Then
                lblerr.Text = "You Must Select Claim Type"
                Exit Sub
            End If

            If HiddenField1.Value = 0 Then
                Str = "SELECT [Case_No]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Member_No='" & Trim(txtmemno.Text) & "' and Case_Status='Open' and Claim_Type='IP'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    lblerr.Text = "You Must Close the Previous Case before admitting."
                    Exit Sub
                End If
                Generate_Task()
                If cboclaimtype.SelectedValue = "IP" Then
                    adm_status = "Admitted"
                    case_status = "Open"
                Else
                    adm_status = "Discharged"
                    case_status = "Closed"
                End If
                MyDBAction.Covid_reg(lblcode.Text, "", CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, txtname.Text, txtmemno.Text, txtprop.Text, cboclient.SelectedValue, cboProvi.SelectedValue, cboProvi.SelectedValue, cboprovtype.SelectedValue, txtauth.Text, adm_status, cboclaimtype.SelectedValue, case_status, Session("UserName").ToString, Trim(txtclaimno.Text), 0)
            Else
                MyDBAction.Covid_reg(lblcode.Text, "", CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, txtname.Text, txtmemno.Text, txtprop.Text, cboclient.SelectedValue, cboProvi.SelectedValue, cboProvi.SelectedValue, cboprovtype.SelectedValue, txtauth.Text, adm_status, cboclaimtype.SelectedValue, case_status, Session("UserName").ToString, Trim(txtclaimno.Text), 1)
            End If
            If txtnotes.Text <> "" Then
                MyDBAction.TRACKING_COV_MESSAGES(txtmemno.Text, lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotes.Text, "ADM-NOTES")
            End If
            If cbocomor.SelectedValue <> "" Then
                MyDBAction.TRACKING_COV_COMORB(CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, txtmemno.Text, Session("username"), CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), lblcode.Text)
            End If
            If cboProvi.SelectedValue <> "" Then
                MyDBAction.TRACKING_COV_PROV(txtmemno.Text, lblcode.Text, cboProvi.SelectedValue, CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cboprovtype.SelectedValue, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"))
            End If

            If cboresults.SelectedValue <> "" Then
                MyDBAction.TRACKING_COV_RESULT(txtmemno.Text, lblcode.Text, cboresults.SelectedValue, CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"))
            End If

            Str = "SELECT R.Case_No, R.Admission_Dt, R.Member_No, R.Member_Name, R.Admission_Status,R.Case_Status, R.Pre_Auth_Amt,   R.Entered_by, R.Entry_date,P.ORG_NAME Transfer_To_Provider FROM   dbo.TBL_MIS_CRM_COV_REGISTER R  WITH(NOLOCK) LEFT JOIN DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST P WITH(NOLOCK) ON R.Transfer_To_Provider COLLATE SQL_Latin1_General_CP1_CS_AS = P.ORG_ID WHERE R.Member_No='" & txtmemno.Text & "'  ORDER BY R.Admission_Dt DESC"
            'Str = "SELECT [Case_No] ,[Admission_Dt],[Member_No],[Transfer_To_Provider],[Admission_Status],[Case_Status],[Pre_Auth_Amt],[Entered_by],[Entry_date]  FROM [CRM].[dbo].[TBL_MIS_CRM_COV_REGISTER] WHERE Member_No='" & txtmemno.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE.DataSource = MyDatable
                GDCASE.DataBind()
            End If
            lblerr.Text = "Saved Successfully.."

            HiddenField1.Value = 0
            lblcode.Text = ""
            txtnotes.Text = ""
            dtadmin.DbSelectedDate = Date.Now()
            cbocomor.SelectedValue = ""
            txtname.Text = ""
            txtmemno.Text = ""
            txtprop.Text = ""
            txtclaimno.Text = ""
            cboclient.SelectedValue = ""
            cboProvi.SelectedValue = ""
            cboProvi.SelectedValue = ""
            cboprovtype.SelectedValue = ""
            txtauth.Text = ""
            cboclaimtype.SelectedValue = ""

            lblcode.Enabled = True
            txtnotes.Enabled = True
            dtadmin.Enabled = True
            cbocomor.Enabled = True
            txtname.Enabled = True
            txtmemno.Enabled = True
            txtprop.Enabled = True
            cboclient.Enabled = True
            cboProvi.Enabled = True
            cboProvi.Enabled = True
            cboprovtype.Enabled = True
            txtauth.Enabled = True
            cboclaimtype.Enabled = True

            cmdsave.Enabled = True
            cmdsave.Enabled = True

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


End Class
