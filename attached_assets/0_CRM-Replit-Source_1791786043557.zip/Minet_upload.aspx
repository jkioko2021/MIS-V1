﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Minet_upload.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>

        </ProgressTemplate>
     
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            &nbsp;<table style="width: 99%">
                                <tr>
                                    <td class="style8" bgcolor="#999999">
                                        <asp:Label ID="lblupload0" runat="server" Font-Size="Medium" 
                                            style="font-weight: 700">UPLOAD MINET CLAIMS</asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td style="width: 109px">
                                                        <asp:Label ID="LBLFAMNO1" runat="server" style="font-weight: 700">DATA DATE</asp:Label>
                                                    </td>
                                                    <td style="width: 122px">
                                                        <telerik:RadDatePicker ID="DTDATE" Runat="server">
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 109px">
                                                        <asp:Label ID="LBLFAMNO0" runat="server" style="font-weight: 700">UPLOAD KYC</asp:Label>
                                                    </td>
                                                    <td style="width: 122px">
                                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                    </td>
                                                    <td>
                                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 109px">
                                                        &nbsp;</td>
                                                    <td style="width: 122px">
                                                        <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" Text="Upload">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        <asp:Label ID="lblupload" runat="server" Font-Size="Medium"></asp:Label>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1198px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="30" Skin="Sunset" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                       
                                                        <telerik:GridBoundColumn DataField="BREAKUP_ID" 
                                                            FilterControlAltText="Filter BREAKUP_ID column" HeaderText="BREAKUP_ID" 
                                                            SortExpression="BREAKUP_ID" UniqueName="BREAKUP_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CLAIM_ID" 
                                                            FilterControlAltText="Filter CLAIM_ID column" HeaderText="CLAIM_ID" 
                                                            SortExpression="CLAIM_ID" UniqueName="CLAIM_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" HeaderText="DISPLAY_MEMBERSHIP_NO" 
                                                            SortExpression="DISPLAY_MEMBERSHIP_NO" UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter MEMBER_DISPLAY_NAME column" HeaderText="MEMBER_DISPLAY_NAME" 
                                                            SortExpression="MEMBER_DISPLAY_NAME" UniqueName="MEMBER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_NAME column" HeaderText="PROPOSER_NAME" 
                                                            SortExpression="PROPOSER_NAME" UniqueName="PROPOSER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CLIENT_TYPE" 
                                                            FilterControlAltText="Filter CLIENT_TYPE column" HeaderText="CLIENT_TYPE" 
                                                            SortExpression="CLIENT_TYPE" UniqueName="CLIENT_TYPE">
                                                        </telerik:GridBoundColumn>
                                                       
                                                         <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_ID" 
                                                            FilterControlAltText="Filter POLICY_ID column" HeaderText="POLICY_ID" 
                                                            SortExpression="POLICY_ID" UniqueName="POLICY_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FUND_MANAGE" 
                                                            FilterControlAltText="Filter FUND_MANAGE column" HeaderText="FUND_MANAGE" 
                                                            SortExpression="FUND_MANAGE" UniqueName="FUND_MANAGE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CATEGORY" 
                                                            FilterControlAltText="Filter CATEGORY column" HeaderText="CATEGORY" 
                                                            SortExpression="CATEGORY" UniqueName="CATEGORY">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGE" 
                                                            FilterControlAltText="Filter AGE column" HeaderText="AGE" 
                                                            SortExpression="AGE" UniqueName="AGE">
                                                        </telerik:GridBoundColumn>


                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="lbL1" runat="server" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;<asp:Label ID="lbLVALI0" runat="server" Font-Bold="True" Font-Size="Small">Total Records:</asp:Label>
                                        &nbsp;
                                        <asp:Label ID="lbLver" runat="server" Font-Size="Small"></asp:Label>
                                        &nbsp; </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <telerik:RadButton ID="btnSave" runat="server" style="font-weight: 700" 
                                            Text="Save Data">
                                        </telerik:RadButton>
                                        <asp:Label ID="lbLERROR" runat="server" Font-Size="Small" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <hr />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 38px">
                                        <asp:Label ID="lbLVALI1" runat="server" Font-Bold="True" Font-Size="Small">Saved Records:</asp:Label>
                                        <asp:Label ID="lbLs" runat="server" Font-Size="Small"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 22px">
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
          <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
          </Triggers>
    </asp:UpdatePanel>
</asp:Content>




