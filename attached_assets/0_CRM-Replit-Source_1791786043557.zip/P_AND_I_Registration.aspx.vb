﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()
           
            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST    ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboprovider
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With
            Str = "SELECT  [Doc_Code],[Doc_Name] FROM CRM.[dbo].[TBL_MIS_IP_CLAIM_REQUIREMENTS] "
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With chklist
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Doc_Name").ToString
                .DataValueField = MyDatatable.Columns("Doc_Code").ToString
                .DataBind()
            End With
            Str = ""
            MyDatatable = Nothing
            cmdsave.Enabled = True
            loadGrid()
            Str = ""
            MyDatatable = Nothing
            dtupload.DbSelectedDate = Date.Now
        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name], [Inv_Status],L.ORG_NAME Provider_Name FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] I INNER JOIN  [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST L  ON L.ORG_ID=I.PROVIDER_ID  WHERE Submitted=0  AND [Is_Active]=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
        End If
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

      
            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INV_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Function ContainsSpecialChars(s As String) As Boolean
        Return s.IndexOfAny("[~`!@#$%^&*()-+=|{}':;.,<>/?]".ToCharArray) <> -1
    End Function
    Public Sub Generate_Task()
        Dim AB As Integer
        SqlAction = "SELECT ISNULL((MAX(Id)+1),1) NUMBER FROM [dbo].[TBL_MIS_CRM_PAY_N_INVOICE]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblfile.Text = "PNI" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""

        End If
    End Sub
   
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        'Dim PROCESSED As Integer = 0
        'Dim TO_FINANCE As Integer = 0
        Dim FILENO As String
        Dim app As Integer = 0
        Dim Member_no As String


        Dim receivedate As String
        Try
            If txtname.Text = "" Then
                lblerr.Text = "You must enter member name"
                Exit Sub
            End If
            If txtmemno.Text = "" Then
                lblerr.Text = "You have not captured the Member Number"
                Exit Sub
            End If

            If chknew.Checked = True Then
                app = 1
            End If

            If (Len(txtmemno.Text) < 4 Or Len(txtmemno.Text) > 12) Then
                lblerr.Text = "You have not captured the correct member no!"
                Exit Sub
            End If

            If ContainsSpecialChars(txtmemno.Text) = True Then
                lblerr.Text = "Ensure you remove special characters on    member no!"
                Exit Sub
            End If


            'If HiddenField1.Value = "" Then
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim DEPART As String = ""

            'SqlAction = "SELECT INVOICE_NO,MEMBER_NO FROM TBL_MIS_REIMB_TRACKING WHERE MEMBER_NO= '" & Trim(txtmemno.Text) & "' AND  INVOICE_NO= '" & Trim(txtinv_no.Text) & "' "
            'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            'If MyDatable.Rows.Count > 0 Then
            '    lblerr.Text = "Invoice already Registered..Duplicate!"
            '    Exit Sub
            'End If
            Generate_Task()

            STS = 0
            MyDBAction.Register_PNI(lblfile.Text, app, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtservice.DbSelectedDate).ToString("yyyy-MM-dd"), Trim(txtmemno.Text), Trim(txtname.Text), Trim(cboprovider.SelectedValue), Trim(txtprop.Text), Session("username"))

            For Each MyItem In chklist.Items
                If MyItem.Selected = True Then
                    MyDBAction.UPLOAD_PNI_CLAIMS(lblfile.Text, MyItem.value, MyItem.TEXT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"))
                End If
            Next
            lblerr.Text = "Saved Successfully!"
            HiddenField1.Value = ""

            'Else
            'STS = 1
            'MyDBAction.Register_PNI(lblfile.Text, chknew.Checked, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtservice.DbSelectedDate).ToString("yyyy-MM-dd"), Trim(txtmemno.Text), Trim(txtname.Text), Trim(cboprovider.SelectedValue), Trim(txtprop.Text), Session("username"))
            'For Each MyItem In chklist.Items
            '    If MyItem.Selected = True Then
            '        MyDBAction.UPLOAD_PNI_CLAIMS(lblfile.Text, MyItem.value, MyItem.TEXT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"))
            '    End If
            'Next
            'lblerr.Text = "Updated Successfully!"
            'FILENO = ""
            'End If
            loadGrid()
            load_Grid(lblfile.Text)
            cmdsave.Enabled = False
            'loadGrid_OTH(txtinv_no.Text)
            HiddenField1.Value = ""



        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        'ltEmbed.Text = ""
        lblerr.Text = ""
        Session("Audited") = 0
        Session("Posting") = 0
        lblfile.Text = ""
        Try


            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            'SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],Audited,Posting,Memb_Disch_dt,Bar_code, INV_STATUS,Member_Name,Provider_Name,RECEIVE_DT,SERVICE_DT,Proposer FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING] T WITH (NOLOCK)   INNER JOIN [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST p WITH (NOLOCK)  ON T.Provider_Code COLLATE DATABASE_DEFAULT =P.ORG_ID    WHERE File_No ='" & ID & "'"
            SqlAction = "SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE DISPLAY_MEMBERSHIP_NO = '" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    txtmemno.Text = MyDatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                
                    txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtprop.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                    'cboreason.SelectedValue = MyDatable.Rows(0).Item("REASON").ToString()
                    'txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER").ToString()
                 
                    'load_Grid(lblfile.Text)
                    'SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_IP_CLAIM_DOCS] WHERE  File_No ='" & lblfile.Text & "' and Active=1"
                    'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                    'chklist.ClearSelection()
                    'For Each dt2_row As System.Data.DataRow In MyDatable.Rows
                    '    Dim IT As String = dt2_row("Doc_code").ToString()
                    '    For i As Integer = 0 To chklist.Items.Count - 1
                    '        If chklist.Items(i).Value = IT Then
                    '            chklist.Items(i).Selected = True
                    '        End If
                    '    Next

                    'Next

                    '  txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False
                    dtservice.Enabled = False

                    'txtbarcode.Enabled = False
                    '  cbotype.Enabled = False
                    txtmemno.Enabled = False

                    'cmdsave.Enabled = False


                End If
                HiddenField1.Value = 1
                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If
            'SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]
           
                If cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE DISPLAY_MEMBERSHIP_NO Like '%" & Trim(txtsearch.Text) & "%'"
                ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%'"

                End If

                Dim MyDatable As New Data.DataTable
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDatable.Rows.Count > 0 Then
                    GDSEARCH.DataSource = MyDatable
                    GDSEARCH.DataBind()
                    Session("DAD_5") = MyDatable
                    MyDatable = Nothing
                Else
                    GDSEARCH.DataSource = MyDatable
                    GDSEARCH.DataBind()
                End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub

    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        cmdsave.Enabled = True
        lblfile.Enabled = True
        dtreceive.Enabled = True
        dtservice.Enabled = True
        'txtbarcode.Enabled = True
        'cbotype.Enabled = True
        txtmemno.Enabled = True

        'txtinv_no.Enabled = True
        txtcomment.Enabled = True

        'cboreason.Enabled = True
        'txtname.Enabled = True
       
        txtcomment.Enabled = True
        'txtproposer.Enabled = True

       

    End Sub

    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If txttitle.Text = "" Then
                lblerr.Text = "You must enter Document title!"
                Exit Sub
            End If

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".jpeg"
                    contenttype = "image/jpeg"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
                Case ".eml"
                    contenttype = "application/zip"
                    Exit Select
                Case ".msg"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_File_PNI_CLAIMS(bytes, filename, contenttype, lblfile.Text, Trim(txttitle.Text.ToUpper), CDate(dtupload.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), DOC_ID.Text)
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green

                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            load_Grid(lblfile.Text)

            DOC_ID.Text = ""
            'lbltaskno.Text = ""
            txttitle.Text = ""
            dtupload.DbSelectedDate = Date.Now

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub


    Protected Sub GD_DOCS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_DOCS.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""
            'ltEmbed.Text = ""
            stst = (DirectCast(GD_DOCS.SelectedItems(0), GridDataItem)).GetDataKeyValue("DOC_ID").ToString()
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM  [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE  DOC_ID ='" & stst & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txttitle.Text = MyDatable.Rows(0).Item("Doc_Title").ToString()
                DOC_ID.Text = MyDatable.Rows(0).Item("DOC_ID").ToString()
            End If
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "REIMBURMENT PROCESSING" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "REIMBURMENT TRACKING"
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear, " & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>File No:" & lblfile.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            '  strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Member Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            lblerr.Text = ""
            lblerr_1.Text = ""
            If lblfile.Text = "" Then
                lblerr_1.Text = "Select the File to Submit!"
                Exit Sub
            End If
            If txtcomment.Text = "" Then
                lblerr_1.Text = "You must enter short notes!"
                Exit Sub
            End If



            SqlAction = "SELECT  File_Name FROM [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE File_No='" & lblfile.Text & "' AND ACTIVE=1 AND Upload_Done=0"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                lblerr_1.Text = "You must upload the Missing Documents!"
                Exit Sub
            Else
              
                UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_PAY_N_INVOICE] SET   Submitted=1,[Discharged]=0, Submitted_By='" & Session("username") & "',Submit_dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Inv_Status='SUBMITTED' where [Ref_No]= '" & lblfile.Text & "'")
                MyDBAction.TRACKING_PNI_CLAIM_MESSAGES(lblfile.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
                lblerr_1.Text = "Submit successfull!"
            End If




           

            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()
            HiddenField1.Value = ""
            lblfile.Enabled = False
            dtreceive.Enabled = False
            dtservice.Enabled = False
            chklist.ClearSelection()
            lblfile.Text = ""
            'ltEmbed.Text = ""

            cboprovider.Text = ""
            cboprovider.SelectedValue = ""
            txtmemno.Text = ""

            txtcomment.Text = ""

            ' txtname.Text = ""

            txtcomment.Text = ""

            txtname.Text = ""
            txtprov.Text = ""

            load_Grid(lblfile.Text)
            loadGrid()

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDSEARCH.DeleteCommand
        Try
            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("File_No").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            DeleteRecord("DELETE FROM  dbo.TBL_MIS_CRM_PAY_N_INVOICE WHERE  File_no='" & HiddenField1.Value.ToString & "'")

            audit.AddAdminAuditTrail(Session("UserName").ToString, "IP Claim  Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid()

        Catch ex As Exception

            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Protected Sub GD_DOCS_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GD_DOCS.DeleteCommand
        Try
            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("DOC_ID").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            DeleteRecord("DELETE FROM [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE  DOC_ID='" & HiddenField1.Value.ToString & "' AND [Upload_By]='" & Session("username") & "'")

            audit.AddAdminAuditTrail(Session("UserName").ToString, "PNI Claim Doc Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid()


        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub



    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnprov_Click(sender As Object, e As System.EventArgs) Handles btnprov.Click
        GDPROV.DataSource = Nothing
        GDPROV.DataBind()
        Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME]  FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST where ORG_NAME LIKE '%" & Trim(txtprov.Text) & "%'  ORDER BY ORG_NAME" '"
        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
        If MyDatatable.Rows.Count > 0 Then
            GDPROV.DataSource = MyDatatable
            GDPROV.DataBind()
            Session("MEM_P") = MyDatatable
        Else
            GDPROV.DataSource = Nothing
            GDPROV.DataBind()
        End If
    End Sub
    Protected Sub GDPROV_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROV.SelectedIndexChanged
        cboprovider.SelectedValue = (DirectCast(GDPROV.SelectedItems(0), GridDataItem)).GetDataKeyValue("ORG_ID").ToString()
    End Sub
    Protected Sub GDPROV_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDPROV.PageIndexChanged
        GDPROV.CurrentPageIndex = e.NewPageIndex
        GDPROV.DataSource = Session("MEM_P")
        GDPROV.DataBind()
    End Sub

   

    Protected Sub GDSEARCH_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH_1.SelectedIndexChanged
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            ID = ""
            lblfile.Text = (DirectCast(GDSEARCH_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()

            load_Grid(lblfile.Text)
            SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_IP_CLAIM_DOCS] WHERE  File_No ='" & lblfile.Text & "' and Active=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            chklist.ClearSelection()
            For Each dt2_row As System.Data.DataRow In MyDatable.Rows
                Dim IT As String = dt2_row("Doc_code").ToString()
                For i As Integer = 0 To chklist.Items.Count - 1
                    If chklist.Items(i).Value = IT Then
                        chklist.Items(i).Selected = True
                    End If
                Next

            Next

            load_Grid(lblfile.Text)


        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GD_DOCS_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GD_DOCS.NeedDataSource

    End Sub
End Class
