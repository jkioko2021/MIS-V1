﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] WHERE SIGNOFF_PERIOD=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                Session("PERIOD_FROM") = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                Session("PERIOD_TO") = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()

                dtF.DbSelectedDate = Session("PERIOD_FROM")
                DTt.DbSelectedDate = Session("PERIOD_TO")

                dtF_1.DbSelectedDate = Session("PERIOD_FROM")
                DTt_1.DbSelectedDate = Session("PERIOD_TO")

                dtDateFrom.DbSelectedDate = Session("PERIOD_FROM")
                dtDateTo.DbSelectedDate = Session("PERIOD_TO")

            End If
            Session("EXCEL") = Nothing

            loadgr()


            Session("EXCEL") = Nothing

        End If
    End Sub
    Public Sub loadgr()
        'Try
        '    Dim MyDatable As New Data.DataTable

        '    SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[AGE],[OP_L_RATE],[IP_L_RATE],[IP_PREMIUM],[OP_PREMIUM],[LOADED_IP_PREM],[LOADED_OP_PREM],[CURRENT_IP_CLAIMS],[CURRENT_OP_CLAIMS],[DIAGNOSIS],[PERIOD_FROM],[PERIOD_TO],[LOAD_DATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WHERE APPROVED=0 AND ACTIVE=1"

        '    MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        '    If MyDatable.Rows.Count > 0 Then
        '        RD_LOAD.DataSource = MyDatable
        '        RD_LOAD.DataBind()
        '        Session("DAD_5_1") = MyDatable
        '        MyDatable = Nothing
        '    Else
        '        RD_LOAD.DataSource = MyDatable
        '        RD_LOAD.DataBind()
        '    End If

        'Catch ex As Exception

        'End Try

        Try
            Dim MyDatable As New Data.DataTable

            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[AGE],[OP_L_RATE],[IP_L_RATE],[IP_PREMIUM],[OP_PREMIUM],[LOADED_IP_PREM],[LOADED_OP_PREM],[CURRENT_IP_CLAIMS],[CURRENT_OP_CLAIMS],[DIAGNOSIS],[PERIOD_FROM],[PERIOD_TO],[LOAD_DATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WHERE APPROVED=0 AND ACTIVE=1"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                RD_LOAD.DataSource = MyDatable
                RD_LOAD.DataBind()
                Session("DAD_5_1") = MyDatable

                MyDatable = Nothing
            Else
                RD_LOAD.DataSource = MyDatable
                RD_LOAD.DataBind()
            End If

        Catch ex As Exception

        End Try
        Try
            Dim MyDatable As New Data.DataTable

            SqlAction = "SELECT [ID],[MEMBER_NO] DISPLAY_MEMBERSHIP_NO,[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO  FROM [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] WHERE LOADED=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
                Session("DAD_5_2") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
            End If


            SqlAction = "SELECT   [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.ID, [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.MEMBER_NO, [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.MEMBER_NAME, [MISREPORTS].dbo.TBL_MIS_RENEWAL_LIST.RELATION, [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.PERIOD_FROM POLICY_VALID_FROM, [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.PERIOD_TO POLICY_VALID_UPTO,[MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.PRODUCT FROM  [MISREPORTS].dbo.TBL_MIS_LOADING_FLAG INNER JOIN [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST ON [MISREPORTS].[dbo].TBL_MIS_LOADING_FLAG.MEMBER_NO = [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.MEMBER_NO AND [MISREPORTS].[dbo].TBL_MIS_LOADING_FLAG.PERIOD_TO = [MISREPORTS].[dbo].TBL_MIS_RENEWAL_LIST.POLICY_VALID_UPTO where LOADED=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5_3") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If


            'SqlAction = "SELECT [ID],[MEMBER_NO] DISPLAY_MEMBERSHIP_NO,[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO  FROM [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] WHERE LOADED=0"

            'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            'If MyDatable.Rows.Count > 0 Then
            '    GDSEARCH_1.DataSource = MyDatable
            '    GDSEARCH_1.DataBind()
            '    Session("DAD_5_2") = MyDatable
            '    MyDatable = Nothing
            'Else
            '    GDSEARCH_1.DataSource = MyDatable
            '    GDSEARCH_1.DataBind()
            'End If


            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],LOADING_RATE,[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE],POLICY_CODE,ON_HOLD  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WHERE ON_HOLD=1  ORDER BY FAMILY_NO"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                rdhold.DataSource = MyDatable
                rdhold.DataBind()
                Session("DAD_5_5") = MyDatable
                MyDatable = Nothing
            Else
                rdhold.DataSource = MyDatable
                rdhold.DataBind()
            End If
            'SELECT dbo.TBL_MIS_LOADING_FLAG.MEMBER_NO, dbo.TBL_MIS_RENEWAL_LIST.MEMBER_NAME, dbo.TBL_MIS_RENEWAL_LIST.RELATION, dbo.TBL_MIS_RENEWAL_LIST.POLICY_VALID_FROM, dbo.TBL_MIS_RENEWAL_LIST.POLICY_VALID_UPTO FROM  dbo.TBL_MIS_LOADING_FLAG INNER JOIN dbo.TBL_MIS_RENEWAL_LIST ON dbo.TBL_MIS_LOADING_FLAG.MEMBER_NO = dbo.TBL_MIS_RENEWAL_LIST.MEMBER_NO AND dbo.TBL_MIS_LOADING_FLAG.PERIOD_TO = dbo.TBL_MIS_RENEWAL_LIST.POLICY_VALID_UPTO where IS_LOADING=0 

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub RD_LOAD_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RD_LOAD.SelectedIndexChanged
        Dim ID As String = ""

        Session("IP_L_RATE") = Nothing
        Session("LOADED_IP_PREM") = Nothing
        Session("LOADED_OP_PREM") = Nothing
        Session("MEMBER_NO") = Nothing
        Session("POLICY_VALID_FROM") = Nothing
        Session("POLICY_VALID_UPTO") = Nothing
        Session("POLICY_CODE") = Nothing

        lblerr.Text = ""

        ID = (DirectCast(RD_LOAD.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT [DIAGNOSIS],IP_L_RATE,LOADED_IP_PREM,LOADED_OP_PREM,MEMBER_NO,PERIOD_FROM,PERIOD_TO,POLICY_CODE,L_REVISED,ON_HOLD FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WHERE  ID='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then


                txtcom1.Text = MyDatable.Rows(0).Item("DIAGNOSIS").ToString()
                chkrevise.Checked = MyDatable.Rows(0).Item("L_REVISED").ToString()
                txtrate.Text = MyDatable.Rows(0).Item("IP_L_RATE").ToString()
                txtrate_ip.Text = MyDatable.Rows(0).Item("LOADED_IP_PREM").ToString()
                Session("IP_L_RATE") = MyDatable.Rows(0).Item("IP_L_RATE").ToString()
                Session("LOADED_IP_PREM") = MyDatable.Rows(0).Item("LOADED_IP_PREM").ToString()
                Session("LOADED_OP_PREM") = MyDatable.Rows(0).Item("LOADED_OP_PREM").ToString()
                Session("MEMBER_NO") = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                Session("POLICY_VALID_FROM") = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
                Session("POLICY_VALID_UPTO") = MyDatable.Rows(0).Item("PERIOD_TO").ToString()
                Session("POLICY_CODE") = MyDatable.Rows(0).Item("POLICY_CODE").ToString()


            End If


        End If
    End Sub
    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""

        lblerr.Text = ""

        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        If chkrevise.Checked = False Then

            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],PERIOD_FROM [POLICY_VALID_FROM], PERIOD_TO [POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],LOADING_RATE,[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE],POLICY_CODE,ON_HOLD,SILVER_PLUS_IP_PREMIUM,SCHEME_NAME  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE ID ='" & ID & "' AND  VERIFIED=1"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then

                    lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    'lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    txtno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtrela.Text = MyDatable.Rows(0).Item("RELATION").ToString()
                    dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_FROM").ToString()
                    DTto.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_UPTO").ToString()
                    txtage.Text = MyDatable.Rows(0).Item("AGE").ToString()

                    txtipprem.Text = MyDatable.Rows(0).Item("IP_RATE").ToString()
                    txtopprem.Text = MyDatable.Rows(0).Item("OP_RATE").ToString()

                    txtLIPPrem.Text = MyDatable.Rows(0).Item("IP_RATE").ToString()
                    txtLopprem.Text = MyDatable.Rows(0).Item("OP_RATE").ToString()

                    txtipsplus.Text = MyDatable.Rows(0).Item("SILVER_PLUS_IP_PREMIUM").ToString()
                    'txtsplusIpload.Text = MyDatable.Rows(0).Item("LOADED_S_PLUS_IP").ToString()

                    txtiprate.Text = MyDatable.Rows(0).Item("LOADING_RATE").ToString()
                    LBLPOLICY.Text = MyDatable.Rows(0).Item("POLICY_CODE").ToString()
                    LBLSCHEME.Text = MyDatable.Rows(0).Item("SCHEME_NAME").ToString()

                    'txtoprate.Text = MyDatable.Rows(0).Item("OP_L_RATE").ToString()
                End If
            End If
        Else
            SqlAction = "SELECT ID,[MEMBER_NO],[MEMBER_NAME],[AGE],PERIOD_FROM,PERIOD_TO,[OP_L_RATE],[IP_L_RATE],[IP_PREMIUM],[OP_PREMIUM],[LOADED_IP_PREM],[LOADED_OP_PREM],[CURRENT_IP_CLAIMS],[CURRENT_OP_CLAIMS],[DIAGNOSIS],[PERIOD_FROM],[PERIOD_TO],POLICY_CODE,ON_HOLD,S_PLUS_IP,LOADED_S_PLUS_IP  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WITH (NOLOCK) WHERE ID ='" & ID & "' AND  [APPROVED]=1"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then

                    lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    'lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    txtno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    'txtrela.Text = MyDatable.Rows(0).Item("RELATION").ToString()
                    dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
                    DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()
                    txtage.Text = MyDatable.Rows(0).Item("AGE").ToString()

                    txtipprem.Text = MyDatable.Rows(0).Item("IP_PREMIUM").ToString()
                    txtopprem.Text = MyDatable.Rows(0).Item("OP_PREMIUM").ToString()

                    txtLIPPrem.Text = MyDatable.Rows(0).Item("LOADED_IP_PREM").ToString()
                    txtLopprem.Text = MyDatable.Rows(0).Item("LOADED_OP_PREM").ToString()

                    txtipsplus.Text = MyDatable.Rows(0).Item("S_PLUS_IP").ToString()
                    txtsplusIpload.Text = MyDatable.Rows(0).Item("LOADED_S_PLUS_IP").ToString()

                    txtiprate.Text = MyDatable.Rows(0).Item("IP_L_RATE").ToString()
                    txtcomment.Text = MyDatable.Rows(0).Item("DIAGNOSIS").ToString()

                    LBLPOLICY.Text = MyDatable.Rows(0).Item("POLICY_CODE").ToString()

                    'txtoprate.Text = MyDatable.Rows(0).Item("OP_L_RATE").ToString()
                End If

            End If
            lblID.Enabled = False : txtno.Enabled = False : txtname.Enabled = False : txtage.Enabled = False : txtoprate.Enabled = False : txtiprate.Enabled = False : txtipprem.Enabled = False : txtopprem.Enabled = False : txtLIPPrem.Enabled = False : txtLopprem.Enabled = False : txtipsplus.Enabled = False : txtsplusIpload.Enabled = False : txtcomment.Enabled = False : txtipsplus.Enabled = False
            If txtipprem.Text = "" Then
                txtipprem.Text = 0
            End If
            If txtopprem.Text = "" Then
                txtopprem.Text = 0
            End If

            If txtipsplus.Text = "" Then
                txtipsplus.Text = 0
            End If

            If txtsplusIpload.Text = "" Then
                txtsplusIpload.Text = 0
            End If
            Session("DAD_5") = Nothing

        End If
    End Sub
    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click

        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub

            End If
            If chkrevise.Checked = True Then
                If cbosearch.SelectedValue = "N" Then
                    SqlAction = "SELECT ID,[MEMBER_NO],[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WHERE  MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%' and  LOADED=1"

                ElseIf cbosearch.SelectedValue = "M" Then
                    SqlAction = "SELECT ID,[MEMBER_NO],[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM]  WITH (NOLOCK) WHERE MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%' and  LOADED=1"
                End If
            Else

                If cbosearch.SelectedValue = "N" Then
                    SqlAction = "SELECT ID, [MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],PERIOD_FROM [POLICY_VALID_FROM],PERIOD_TO [POLICY_VALID_UPTO]   FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WHERE  MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%' and  VERIFIED=1 AND ON_HOLD=0"

                ElseIf cbosearch.SelectedValue = "M" Then
                    SqlAction = "SELECT ID, [MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],PERIOD_FROM [POLICY_VALID_FROM], PERIOD_TO [POLICY_VALID_UPTO]   FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST]   WITH (NOLOCK) WHERE MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%' and  VERIFIED=1  AND ON_HOLD=0"
                End If

            End If
            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim STS As Integer = 0
        Dim HOLD As Integer = 0
        Dim rel As Integer = 0




        Try
            If chkrevise.Checked = True Then
                STS = 1
                MyDBAction.Save_Loading(txtno.Text, txtname.Text, txtage.Text, txtoprate.Text, txtiprate.Text, txtipprem.Text, txtopprem.Text, txtLIPPrem.Text, txtLopprem.Text, txtsplusIpload.Text, txtipsplus.Text, txtcomment.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"), STS, LBLPOLICY.Text)
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] SET  LOADED=1,FLAGED_BY='" & Session("username") & "', FLAG_DATE= '" & CDate(Date.Now).ToString("yyyy-MM-dd") & "' where MEMBER_NO= '" & Trim(txtno.Text) & "'AND PERIOD_TO='" & CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and lOADED=0")

            Else
                STS = 0
                MyDBAction.Save_Loading(txtno.Text, txtname.Text, txtage.Text, txtoprate.Text, txtiprate.Text, txtipprem.Text, txtopprem.Text, txtLIPPrem.Text, txtLopprem.Text, txtsplusIpload.Text, txtipsplus.Text, txtcomment.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"), STS, LBLPOLICY.Text)
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] SET  LOADED=1,FLAGED_BY='" & Session("username") & "', FLAG_DATE= '" & CDate(Date.Now).ToString("yyyy-MM-dd") & "' where MEMBER_NO= '" & Trim(txtno.Text) & "'AND PERIOD_TO='" & CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and lOADED=0")

            End If


            lblID.Text = "" : txtno.Text = "" : txtname.Text = "" : txtage.Text = 0 : txtoprate.Text = 0 : txtiprate.Text = 0 : txtipprem.Text = 0 : txtopprem.Text = 0 : txtLIPPrem.Text = 0 : txtLopprem.Text = 0 : txtipsplus.Text = 0 : txtsplusIpload.Text = 0 : txtcomment.Text = ""
            loadgr()
            lblerr.Text = "Saved successfully!"
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub

    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        lblID.Enabled = True : txtno.Enabled = True : txtname.Enabled = True : txtage.Enabled = True : txtoprate.Enabled = True : txtiprate.Enabled = True : txtipprem.Enabled = True : txtopprem.Enabled = True : txtLIPPrem.Enabled = True : txtLopprem.Enabled = True : txtipsplus.Enabled = True : txtsplusIpload.Enabled = True : txtcomment.Enabled = True

    End Sub

    Protected Sub cmdnew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdnew.Click
        HiddenField1.Value = ""
        lblID.Enabled = True : txtno.Enabled = True : txtname.Enabled = True : txtage.Enabled = True : txtoprate.Enabled = True : txtiprate.Enabled = True : txtipprem.Enabled = True : txtopprem.Enabled = True : txtLIPPrem.Enabled = True : txtLopprem.Enabled = True : txtipsplus.Enabled = True : txtsplusIpload.Enabled = True : txtcomment.Enabled = True
        'lblID.Text = "" : txtno.Text = "" : txtname.Text = "" : txtage.Text = "" : txtoprate.Text = "" : txtiprate.Text = "" : txtipprem.Text = "" : txtopprem.Text = "" : txtLIPPrem.Text = "" : txtLopprem.Text = "" : txtipclaims.Text = "" : txtopclaims.Text = "" : txtcomment.Text = ""
        lblID.Text = "" : txtno.Text = "" : txtname.Text = "" : txtage.Text = 0 : txtoprate.Text = 0 : txtiprate.Text = 0 : txtipprem.Text = 0 : txtopprem.Text = 0 : txtLIPPrem.Text = 0 : txtLopprem.Text = 0 : txtipsplus.Text = 0 : txtsplusIpload.Text = 0 : txtcomment.Text = ""

    End Sub

    Protected Sub txtoprate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtoprate.TextChanged
        txtLopprem.Text = txtopprem.Text + (txtoprate.Text * txtopprem.Text)
    End Sub

    Protected Sub txtiprate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtiprate.TextChanged
        txtLIPPrem.Text = txtipprem.Text + (txtiprate.Text * txtipprem.Text)
    End Sub


    Protected Sub btnactsearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnactsearch.Click
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            If TXTSEARC.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub

            End If
            If cbosearch_ac.SelectedValue = "N" Then
                SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[AGE],[OP_L_RATE],[IP_L_RATE],[IP_PREMIUM],[OP_PREMIUM],[LOADED_IP_PREM],[LOADED_OP_PREM],[CURRENT_IP_CLAIMS],[CURRENT_OP_CLAIMS],[DIAGNOSIS],[PERIOD_FROM],[PERIOD_TO],[LOAD_DATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WHERE  MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%'"

            ElseIf cbosearch_ac.SelectedValue = "M" Then
                SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[AGE],[OP_L_RATE],[IP_L_RATE],[IP_PREMIUM],[OP_PREMIUM],[LOADED_IP_PREM],[LOADED_OP_PREM],[CURRENT_IP_CLAIMS],[CURRENT_OP_CLAIMS],[DIAGNOSIS],[PERIOD_FROM],[PERIOD_TO],[LOAD_DATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WITH (NOLOCK) WHERE MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                RD_LOAD.DataSource = MyDatable
                RD_LOAD.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                RD_LOAD.DataSource = MyDatable
                RD_LOAD.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton2.Click
        Try
            Dim hold As Integer = 0
            Dim revised As Integer = 0

            HiddenField1.Value = (DirectCast(RD_LOAD.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()

            SqlAction = "SELECT [ID],COMMENTS,ON_HOLD  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE POLICY_CODE= '" & Session("POLICY_CODE") & "' AND  ON_HOLD=1"


            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                LBLAPPR.Text = "Policy on Hold!"
                Exit Sub
            End If

            If cboappro.SelectedValue = 1 Then
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] SET APPROVED='" & cboappro.SelectedValue & "', ACTIVE='" & cboappro.SelectedValue & "' where ID= '" & HiddenField1.Value.ToString & "'")
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] SET  LOADED='" & cboappro.SelectedValue & "' where MEMBER_NO= '" & Trim(txtno.Text) & "'AND PERIOD_TO='" & Session("PERIOD_TO") & "' and lOADED=1")
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  LOADING_RATE='" & Session("IP_L_RATE") & "' ,NCD_RATE=0,NCD_YEARS=0,VALIDATED=0,APPROVED=0,IP_NET_NCD=0,SUB_TOTAL=0,TOTAL=0 ,IS_SUMMATION=0, IP_RATE='" & Session("LOADED_IP_PREM") & "', IS_LOADING ='" & cboappro.SelectedValue & "' where MEMBER_NO= '" & Session("MEMBER_NO") & "' AND PERIOD_FROM='" & Session("POLICY_VALID_FROM") & "' AND PERIOD_TO='" & Session("POLICY_VALID_UPTO") & "' and VERIFIED=1 and ON_HOLD=0")


                If chkrevise.Checked = True Then
                    updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  VALIDATED=0,APPROVED=0,IP_NET_NCD=0,SUB_TOTAL=0,TOTAL=0,IS_SUMMATION=0, IS_REVISED=1 where POLICY_CODE= '" & Session("POLICY_CODE") & "'  and VERIFIED=1 and ON_HOLD=0")
                    updateRecord("UPDATE  [MISREPORTS].[dbo].TBL_MIS_RENEWAL_PROPOSER_LIST  SET EMAIL_SCHEDULE=0, APPROVED=0  where POLICY_CODE= '" & Session("POLICY_CODE") & "'")
                    updateRecord("UPDATE  [MISREPORTS].[dbo].TBL_MIS_RENEWAL_UPLOAD  SET  APPROVED=0   where POLICY_CODE= '" & Session("POLICY_CODE") & "'")

                End If

            Else
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] SET APPROVED='" & cboappro.SelectedValue & "', ACTIVE='" & cboappro.SelectedValue & "' where ID= '" & HiddenField1.Value.ToString & "'")
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] SET  LOADED='" & cboappro.SelectedValue & "' where MEMBER_NO= '" & Trim(txtno.Text) & "'AND PERIOD_TO='" & Session("PERIOD_TO") & "' and lOADED=1")

            End If

            loadgr()

            Session("IP_L_RATE") = Nothing
            Session("LOADED_IP_PREM") = Nothing
            Session("LOADED_OP_PREM") = Nothing

            lb.Text = "updated successfully!"
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Private Sub updateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

        'ShowGridDetails()
    End Sub

    Protected Sub RD_LOAD_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_LOAD.PageIndexChanged
        RD_LOAD.CurrentPageIndex = e.NewPageIndex
        RD_LOAD.DataSource = Session("DAD_5_1")
        RD_LOAD.DataBind()
    End Sub

    Protected Sub GDSEARCH_1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH_1.PageIndexChanged
        GDSEARCH_1.CurrentPageIndex = e.NewPageIndex
        GDSEARCH_1.DataSource = Session("DAD_5_2")
        GDSEARCH_1.DataBind()
    End Sub
    Protected Sub RDHOLD_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RDHOLD.PageIndexChanged
        RDHOLD.CurrentPageIndex = e.NewPageIndex
        RDHOLD.DataSource = Session("DAD_5_5")
        RDHOLD.DataBind()
    End Sub
    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5_3")
        GDSEARCH.DataBind()
    End Sub

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click

        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "Loading As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""

        Session("EXCEL") = "TO EXCEL"
        SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[AGE],[OP_L_RATE],[IP_L_RATE],[IP_PREMIUM],[OP_PREMIUM],[LOADED_IP_PREM],[LOADED_OP_PREM],[CURRENT_IP_CLAIMS],[CURRENT_OP_CLAIMS],[DIAGNOSIS],[PERIOD_FROM],[PERIOD_TO],[LOAD_DATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WITH (NOLOCK) WHERE LOAD_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)

    End Sub

    Protected Sub RadButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton3.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String


        Session("EXCEL") = "TO EXCEL"
        If cboreport.SelectedValue = "R" Then
            Reportname = "Renewal List As At-& " & dtDateTo.DbSelectedDate & ""
            'SqlAction = "SELECT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[FIRST_ENROLLMENT_DATE],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[PROPOSER_PRI_PIN],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID],[UNIT],[BRANCH],[REGION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_ADD_LINE2],[POSTAL_CODE],[ADDRESS],[PERIOD_FROM],[PERIOD_TO],[AGE],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[FAMILY_SIZE],[POLICY_TYPE],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[IP_NET_NCD],[OP_RATE],[PA_PTD],[IS_LOADING]   FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt.SelectedDate).ToString("yyyy-MM-dd") & "'"
            SqlAction = "SELECT     T.POLICY_CODE, T.PROPOSER_DISPLAY_NAME, T.MEMBER_NO,T.MEMBER_NAME, T.RELATION, T.SCHEME_NAME, T.MEMBER_BIRTH_DATE, T.MEMBER_ADMINISTRATIVE_SEX, T.FIRST_ENROLLMENT_DATE, T.MEMBER_PRI_ADD_LINE1,T.PROPOSER_PRI_PIN, +''''+ T.MEMBER_PRI_MOBILE MEMBER_PRI_MOBILE, T.MEMBER_PRI_EMAIL, T.PROPOSER_PRI_ADD_LINE1, T.ADDRESS,T.POSTAL_CODE, +''''+ T.PROPOSER_PRI_MOBILE PROPOSER_PRI_MOBILE, T.PROPOSER_PRI_EMAIL,T.PERIOD_FROM, T.PERIOD_TO, T.AGE,T.FAMILY_NO, T.AGE_BAND, T.LOADING_RATE,T.OP_LIMIT, T.IP_LIMIT, T.POLICY_TYPE,T.LAST_CLAIM_DATE, T.NCD_YEARS, T.NCD_RATE,T.IP_NET_NCD, T.OP_RATE, T.PA_PTD,T.SUB_TOTAL, T.LEVIES, T.TOTAL,T.IS_LOADING, V.AGENT_NAME, V.UM_MANAGER, V.REGION_NAME,V.REGION_MANAGER FROM MISREPORTS.dbo.TBL_MIS_RENEWAL_LIST T INNER JOIN  COMMISSION.dbo.VW_MIS_AGENTS_LISTING V ON T.USER_ID = (V.USER_ID) WHERE T.PERIOD_FROM>= '" & CDate(dtF.SelectedDate).ToString("yyyy-MM-dd") & "' AND T.PERIOD_FROM<= '" & CDate(DTt.SelectedDate).ToString("yyyy-MM-dd") & "' AND ON_HOLD=0"

        Else
            Reportname = "Claims List As At-& " & dtDateTo.DbSelectedDate & ""
            SqlAction = "SELECT [MEMBER_NO],[MEMBER_NAME],[POLICY_FROM],[POLICY_TO],[OP_CLAIMS],[IP_CLAIMS],[DIAX],SUBTYPE  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_CLAIM_SUMMARY] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt.SelectedDate).ToString("yyyy-MM-dd") & "'"

        End If

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub


    Protected Sub cmdsave_1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave_1.Click
        Dim STS As Integer

        Try
            MyDBAction.Flag_Loading(txtno_1.Text, txtname_1.Text, CDate(dtfrom_1.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto_1.DbSelectedDate).ToString("yyyy-MM-dd"), txtcomment_1.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"))

            lblID_1.Text = "" : txtno_1.Text = "" : txtname_1.Text = "" : txtcomment_1.Text = ""
            loadgr()
            lblerr.Text = "Saved successfully!"
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub BTN_S_1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BTN_S_1.Click

        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            If txts_1.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If
            If cbos_1.SelectedValue = "N" Then
                SqlAction = "SELECT DISPLAY_MEMBERSHIP_NO,MEMBER_NAME,RELATION,POLICY_VALID_FROM,POLICY_VALID_UPTO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE  GRP_INDV='I' AND    MEMBER_NAME Like '%" & Trim(txts_1.Text) & "%'"
            ElseIf cbos_1.SelectedValue = "M" Then
                SqlAction = "SELECT DISPLAY_MEMBERSHIP_NO,MEMBER_NAME,RELATION,POLICY_VALID_FROM,POLICY_VALID_UPTO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK) WHERE  GRP_INDV='I' AND    DISPLAY_MEMBERSHIP_NO Like '%" & Trim(txts_1.Text) & "%'"
            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub



    Protected Sub GDSEARCH_1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH_1.SelectedIndexChanged
        Dim ID As String = ""

        lblerr.Text = ""

        ID = (DirectCast(GDSEARCH_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT DISPLAY_MEMBERSHIP_NO,MEMBER_NAME,RELATION,POLICY_VALID_FROM,POLICY_VALID_UPTO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK) WHERE  GRP_INDV='I' AND DISPLAY_MEMBERSHIP_NO ='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then

                lblID_1.Text = MyDatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                'lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                txtno_1.Text = MyDatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                txtname_1.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                'txtrela_1.Text = MyDatable.Rows(0).Item("RELATION").ToString()
                dtfrom_1.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_FROM").ToString()
                DTto_1.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_UPTO").ToString()
                lblID.Enabled = False : txtno.Enabled = False : txtname.Enabled = False

            End If
            Session("DAD_5") = Nothing

        End If
    End Sub

    Protected Sub RadButton6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton6.Click

        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "Flag-Loading As At-& " & dtDateTo.DbSelectedDate & ""

        Session("EXCEL") = "TO EXCEL"
        SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[NOTES],[FLAGED_BY],[FLAG_DATE],[PERIOD_FROM],[PERIOD_TO],[LOADED]  FROM [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub




    Protected Sub rdhold_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdhold.SelectedIndexChanged
        Dim ID As String = ""

        Session("IP_L_RATE") = Nothing
        Session("LOADED_IP_PREM") = Nothing
        Session("LOADED_OP_PREM") = Nothing
        Session("MEMBER_NO") = Nothing
        Session("POLICY_VALID_FROM") = Nothing
        Session("POLICY_VALID_UPTO") = Nothing
        Session("POLICY_CODE") = Nothing

        lblerr.Text = ""

        ID = (DirectCast(rdhold.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT [ID],COMMENTS,ON_HOLD  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE ID = '" & ID & "' AND  VERIFIED=1"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                txthold.Text = MyDatable.Rows(0).Item("COMMENTS").ToString()
                chkhD.Checked = MyDatable.Rows(0).Item("ON_HOLD").ToString()
            End If


        End If
    End Sub

    Protected Sub GDSEARCH_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub


    Protected Sub btnactsea_h_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnactsea_h.Click
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            If TXThol.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub

            End If
            If cbohsear.SelectedValue = "F" Then
                SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],LOADING_RATE,[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE],POLICY_CODE,ON_HOLD  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE FAMILY_NO = '" & Trim(TXThol.Text) & "' AND  VERIFIED=1"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                rdhold.DataSource = MyDatable
                rdhold.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                rdhold.DataSource = MyDatable
                rdhold.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton8_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton8.Click
        Dim HOLD As Integer = 0

        If chkhD.Checked = True Then
            HOLD = 1
        End If
        lblhold.Text = ""

        Try
            If TXThol.Text = "" Then
                lblhold.Text = "Empty string!"
                Exit Sub
            End If

            updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  VALIDATED=0,IP_NET_NCD=0,SUB_TOTAL=0,NCD_RATE=0, TOTAL=0,IS_SUMMATION=0, IS_REVISED=1,ON_HOLD='" & HOLD & "',COMMENTS='" & Trim(txthold.Text) & "'   where  FAMILY_NO = '" & Trim(TXThol.Text) & "'  and VERIFIED=1 and APPROVED=0")

            lblhold.Text = "Saved Successfully!"
        Catch ex As Exception
            lblhold.Text = ex.Message
        End Try


    End Sub

    Protected Sub RadButton7_Click(sender As Object, e As System.EventArgs) Handles RadButton7.Click

    End Sub
End Class
