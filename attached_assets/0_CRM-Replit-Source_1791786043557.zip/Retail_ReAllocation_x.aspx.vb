﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""

    Dim MyDatatable As DataTable : Dim Str As String



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then


            dtfrom.DbSelectedDate = Date.Now()
            DTto.DbSelectedDate = Date.Now()

            dtq1from.DbSelectedDate = Date.Now()
            DTQ1TO.DbSelectedDate = Date.Now()

            DTQ2FROM.DbSelectedDate = Date.Now()
            dtQ2TO.DbSelectedDate = Date.Now()

            dTQ3FROM.DbSelectedDate = Date.Now()
            dtQ3TO.DbSelectedDate = Date.Now()

            dtQ4FROM.DbSelectedDate = Date.Now()
            DTQ4TO.DbSelectedDate = Date.Now()


            Str = ""

            Str = "SELECT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1 AND C_CODE='R'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cborm
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()
            End With
            MyDatatable = Nothing

            Str = "SELECT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboagent

                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()

            End With

            MyDatatable = Nothing

            loadGrid()

        End If
    End Sub

    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        SqlAction = "SELECT PROPOSER_ID, PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_FROM],[Q1_TO_DATE],[Q2_FROM],[Q2_TO],[Q3_FROM],[Q3_TO],[Q4_FROM],[Q4_TO],[PREMIUMS],[LIVES],[RM_CODE]  FROM CRM.[dbo].[TBL_MIS_RET_RETAIL] WHERE [RM_CODE] is null or [RM_CODE] ='' AND PERIOD_TO>=GETDATE()"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub


    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""

        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()
        Dim SqlAction As String = ""
        Session("status_1") = Nothing

        SqlAction = "SELECT  PROPOSER_ID,PROPOSER_DISPLAY_NAME,AGENCY_CODE,[RM_CODE],[PERIOD_FROM],[PERIOD_TO],[Q1_FROM],[Q1_TO_DATE],[Q2_FROM],[Q2_TO],[Q3_FROM],[Q3_TO],[Q4_FROM],[Q4_TO],[PREMIUMS],LIVES FROM CRM.[dbo].[TBL_MIS_RET_RETAIL] WITH (NOLOCK) WHERE PROPOSER_ID ='" & ID & "'"
        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then


                lblfile.Text = MyDatable.Rows(0).Item("PROPOSER_ID").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()

                cboagent.SelectedValue = MyDatable.Rows(0).Item("AGENCY_CODE").ToString()
                cborm.SelectedValue = MyDatable.Rows(0).Item("RM_CODE").ToString()

                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

                dtq1from.DbSelectedDate = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                DTQ1TO.DbSelectedDate = MyDatable.Rows(0).Item("Q1_TO_DATE").ToString()

                DTQ2FROM.DbSelectedDate = MyDatable.Rows(0).Item("Q2_FROM").ToString()
                dtQ2TO.DbSelectedDate = MyDatable.Rows(0).Item("Q2_TO").ToString()

                dTQ3FROM.DbSelectedDate = MyDatable.Rows(0).Item("Q3_FROM").ToString()
                dtQ3TO.DbSelectedDate = MyDatable.Rows(0).Item("Q3_TO").ToString()

                dtQ4FROM.DbSelectedDate = MyDatable.Rows(0).Item("Q4_FROM").ToString()
                DTQ4TO.DbSelectedDate = MyDatable.Rows(0).Item("Q4_TO").ToString()



                txtpremium.Text = MyDatable.Rows(0).Item("PREMIUMS").ToString()
                'txtcomment.Text = MyDatable.Rows(0).Item("NOTES").ToString()
                txtlives.Text = MyDatable.Rows(0).Item("LIVES").ToString()

            End If
            HiddenField1.Value = 1
            Session("DAD_5") = Nothing

            dtfrom.Enabled = False
            DTto.Enabled = False

            dtq1from.Enabled = False
            DTQ1TO.Enabled = False

            DTQ2FROM.Enabled = False
            dtQ2TO.Enabled = False

            dTQ3FROM.Enabled = False
            dtQ3TO.Enabled = False

            dtQ4FROM.Enabled = False
            DTQ4TO.Enabled = False

            dtfrom.Enabled = False
            DTto.Enabled = False

            txtpremium.Enabled = False

            txtlives.Enabled = False
            txtproposer.Enabled = True
            txtpolicy.Enabled = False
        End If
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0

        Dim FILENO As String
        Dim app As Integer = 0
        Try

            UpdateRecord("UPDATE [TBL_MIS_RET_RETAIL] SET [RM_CODE]='" & cborm.SelectedValue & "',ENTERED_BY='" & Session("username") & "'  WHERE [PROPOSER_ID]='" & Trim(lblfile.Text) & "' AND PERIOD_TO>=GETDATE()")

            lblerr.Text = "updated successfully"
            lblfile.Text = ""
            loadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message

        End Try



    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT PROPOSER_ID, PROPOSER_DISPLAY_NAME,[POLICY_CODE],[PERIOD_FROM],[PERIOD_TO],[Q1_FROM],[Q1_TO_DATE],[Q2_FROM],[Q2_TO],[Q3_FROM],[Q3_TO],[Q4_FROM],[Q4_TO],[PREMIUMS],[LIVES],[RM_CODE]  FROM CRM.[dbo].[TBL_MIS_RET_RETAIL] WHERE  PROPOSER_DISPLAY_NAME Like '%" & Trim(txtsearch.Text) & "%'"""

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String = "RETENTION As -& " & cbosearch.Text & ""

            Session("EXCEL") = "TO EXCEL"

            Str = "SELECT  S.PROPOSER_DISPLAY_NAME,  S.PERIOD_FROM, S.PERIOD_TO, S.Q1_FROM,S.Q1_TO_DATE, S.Q2_FROM, S.Q2_TO, S.Q3_FROM, S.Q3_TO, S.Q4_FROM,S.Q4_TO, SUM(S.PREMIUMS)PREMIUMS, SUM(S.LIVES)LIVES, E.EmployeeName, A.AGENT_NAME, A.AGENT_TYPE, A.BRANCH_NAME ,S.CONTACT_PERSON,S.MOBILE_NO FROM   dbo.[TBL_MIS_RET_RETAIL] S LEFT JOIN dbo.Employees E ON S.RM_CODE = E.Emp_Code LEFT JOIN COMMISSION.dbo.VW_MIS_AGENTS_LISTING A ON S.AGENCY_CODE = A.USER_ID WHERE (S.PERIOD_TO >= GETDATE())" & _
            "GROUP BY S.PROPOSER_DISPLAY_NAME, S.POLICY_CODE, S.PERIOD_FROM, S.PERIOD_TO, S.Q1_FROM,S.Q1_TO_DATE, S.Q2_FROM, S.Q2_TO, S.Q3_FROM, S.Q3_TO, S.Q4_FROM,S.Q4_TO, E.EmployeeName, A.AGENT_NAME, A.AGENT_TYPE, A.BRANCH_NAME ,S.CONTACT_PERSON,S.MOBILE_NO"

            Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing

            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub
End Class
