﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Prem_Statement_Per_Agent.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Agent name"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="USER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT_NAME" 
                                                            FilterControlAltText="Filter AGENT_NAME column" 
                                                            HeaderText="AGENT_NAME" SortExpression="AGENT_NAME" 
                                                            UniqueName="AGENT_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT_TYPE" 
                                                            FilterControlAltText="Filter AGENT_TYPE column" HeaderText="AGENT_TYPE" 
                                                            SortExpression="AGENT_TYPE" UniqueName="AGENT_TYPE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="UNIT_NAME"                                                             
                                                            FilterControlAltText="Filter UNIT_NAME column" HeaderText="UNIT_NAME" 
                                                            SortExpression="UNIT_NAME" UniqueName="UNIT_NAME">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="USER_ID"                                                             
                                                            FilterControlAltText="Filter USER_ID column" HeaderText="USER_ID" 
                                                            SortExpression="USER_ID" UniqueName="USER_ID">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="LBLFAMNO" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="Label146" runat="server" style="font-weight: 700" Text="RM"></asp:Label>
                                        :<asp:Label ID="RMNAME" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel1" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td colspan="3">
                                                        <asp:Label ID="Label144" runat="server" Text="Premium Statement"></asp:Label>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1200px">
                                                            <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="PROPOSER_DISPLAY_NAME" 
                                                                            SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="USER_DISPLAY_NAME"                                                                             
                                                                            FilterControlAltText="Filter USER_DISPLAY_NAME column" HeaderText="USER_DISPLAY_NAME" 
                                                                            SortExpression="USER_DISPLAY_NAME" UniqueName="USER_DISPLAY_NAME">
                                                                        </telerik:GridBoundColumn>
                                                                      
                                                                        <telerik:GridBoundColumn DataField="DR" FilterControlAltText="Filter DR column" 
                                                                            HeaderText="DR" SortExpression="DR" UniqueName="DR">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="CR" FilterControlAltText="Filter CR column" 
                                                                            HeaderText="CR" SortExpression="CR" UniqueName="CR">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style17" style="width: 220px">
                                                        <asp:CheckBox ID="chkcurrent" runat="server" Text="Active Policy" />
                                                    </td>
                                                    <td align="right" style="width: 85px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style17" style="width: 220px">
                                                        <asp:CheckBox ID="chkex" runat="server" Text="Excel Version" />
                                                    </td>
                                                    <td align="right" style="width: 85px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style17" style="width: 220px">
                                                        &nbsp;</td>
                                                    <td align="right" style="width: 85px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style17" style="width: 220px">
                                                        &nbsp;</td>
                                                    <td align="right" style="width: 85px">
                                                        <asp:Label ID="Label145" runat="server" Font-Bold="True" Text="O/S balance"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadNumericTextBox ID="txtbal" Runat="server" Enabled="False" 
                                                            Skin="Simple">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel24" runat="server">
                                                            <table style="width: 100%">
                                                                <tr>
                                                                    <td style="width: 77px; height: 25px;">
                                                                        <asp:Label ID="Label154" runat="server" Text="Date From"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 25px; width: 86px;">
                                                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" Culture="en-US" 
                                                                            SelectedDate="2022-10-31" Skin="Simple">
                                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                            </Calendar>
                                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                                SelectedDate="2022-10-31">
                                                                            </DateInput>
                                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                        </telerik:RadDatePicker>
                                                                    </td>
                                                                    <td style="height: 25px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 25px; width: 107px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 25px; width: 158px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 25px; width: 796px;">
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 77px; height: 23px;">
                                                                        <asp:Label ID="Label155" runat="server" Text="Date To"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 23px; width: 86px;">
                                                                        <telerik:RadDatePicker ID="dtto" Runat="server" Culture="en-US" 
                                                                            SelectedDate="2022-10-31" Skin="Simple">
                                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                            </Calendar>
                                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                                SelectedDate="2022-10-31">
                                                                            </DateInput>
                                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                        </telerik:RadDatePicker>
                                                                    </td>
                                                                    <td style="height: 23px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 107px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 158px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 796px;">
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 77px; height: 23px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 86px;">
                                                                        <telerik:RadButton ID="btnstatement" runat="server" Skin="Simple" 
                                                                            Text="Print Statement" Width="149px">
                                                                        </telerik:RadButton>
                                                                    </td>
                                                                    <td style="height: 23px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 107px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 158px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 796px;">
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 77px; height: 23px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 86px;">
                                                                        <asp:Label ID="lblid" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 23px; width: 63px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 107px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 158px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 23px; width: 796px;">
                                                                        &nbsp;</td>
                                                                </tr>
                                                            </table>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel20" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            style="margin-bottom: 6px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#999999" colspan="3">
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Report Extract"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; ">
                                                        <asp:Label ID="Label152" runat="server" Font-Bold="True" 
                                                            Text="Outstanding Balances"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="export" 
                                                            Width="200px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>
