﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail
    Dim Mytable As DataTable = Nothing
    Dim Reportname As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try

                Dim SqlAction As String = ""

                Dim MyDBAction As New DataManagement
                '--SELECT [PERIOD_FROM]      ,[PERIOD_TO]      ,[MONTH_CLOSED]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_MONTHS]
                SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_MONTHS] WHERE [MONTH_CLOSED]=0"
                Dim MyDatable As New Data.DataTable
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDatable.Rows.Count > 0 Then
                    DTEXTRFROM.DbSelectedDate = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                    DTEXTRACTTO.DbSelectedDate = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()

                    Session("FrmDT") = DTEXTRFROM.DbSelectedDate
                    Session("ToDt") = DTEXTRACTTO.DbSelectedDate
                End If
                'LOADGRID()

            Catch ex As Exception

            End Try
        End If
    End Sub

    Protected Sub btnsubmit1_Click(sender As Object, e As System.EventArgs) Handles btnsubmit1.Click
        Try

            Session("Report_") = Nothing
             
            If cborpt.SelectedValue = "LPP" Then
                SqlAction = "SELECT  [Policy_Code],[Start_Date],[End_Date],[Data_Date],[Annual_Premium],[Earned_Premium],[IP_Claims_Reported],[OP_Claims_Reported],[Total_Claims_Reported],[Total_LR],[Loading],[is_Loading],[POLICY_TYPE]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_REN_Policy_Loss_Ratio] WHERE IS_LOADING=1 AND     Start_Date BETWEEN     CONVERT(date, '" & DTEXTRFROM.DbSelectedDate & "') AND  CONVERT(date, '" & DTEXTRACTTO.DbSelectedDate & "')"
                Session("Report_") = "LOADING PER POLICY"
            ElseIf cborpt.SelectedValue = "LPI" Then
                SqlAction = "SELECT [Policy_Code],[Member_No],[Policy_Type],[Policy_Utilization],[Member_Utilization],[Contr_to_claims],[Sharing_Check],[Policy_Loading],[Ind_Loading],[PERIOD_FROM],[PERIOD_TO],[RELATION],[Is_Loading]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_REN_Ind_Loading] WHERE IS_LOADING=1 AND     PERIOD_FROM BETWEEN     CONVERT(date, '" & DTEXTRFROM.DbSelectedDate & "') AND  CONVERT(date, '" & DTEXTRACTTO.DbSelectedDate & "')"
                Session("Report_") = "LOADING PER IND"
           
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            '-----------------------------------------------------------------------------------------------------------------------------------------------------
            Session("EXCEL") = "TO EXCEL"
            If MyDatable.Rows.Count > 0 Then
                Session("DA") = MyDatable
                If Session("DA").Rows.Count > 0 Then
                    Session("Mytable") = Nothing
                    Session("Reportname") = Nothing
                    Session("Mytable") = Session("DA")
                    Session("Reportname") = Session("Report_")
                    ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                    MyDatable = Nothing

                    System.Threading.Thread.Sleep(5000)

                End If
            Else
                lblerror.Text = "Cannot generate Report!"

            End If

            MyDatable = Nothing

        Catch ex As Exception
            lblerror.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnsubmit2_Click(sender As Object, e As System.EventArgs) Handles btnsubmit2.Click
        Try
            GDSEARCH_3.DataSource = Nothing
            GDSEARCH_3.DataBind()


            If txtsearch.Text <> "" Then
                SqlAction = "SELECT [Policy_Code],[Start_Date],[End_Date],[Data_Date],[Annual_Premium],[Earned_Premium],[IP_Claims_Reported],[OP_Claims_Reported],[Total_Claims_Reported],[Total_LR],[Loading],[is_Loading],[POLICY_TYPE]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_REN_Policy_Loss_Ratio] WITH (NOLOCK) WHERE Policy_Code = '" & Trim(txtsearch.Text) & "' AND DATEADD(DAY,1,End_Date) BETWEEN CONVERT(date, '" & DTEXTRFROM.DbSelectedDate & "') AND  CONVERT(date, '" & DTEXTRACTTO.DbSelectedDate & "'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDSEARCH_3.DataSource = MyDatable
                    GDSEARCH_3.DataBind()
                    Session("DAD_L") = MyDatable
                    MyDatable = Nothing
                Else
                    GDSEARCH_3.DataSource = Nothing
                    GDSEARCH_3.DataBind()
                End If
            End If


       
        Catch ex As Exception
            lblerror.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub


    Protected Sub GDSEARCH_3_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH_3.SelectedIndexChanged
        Try
            GDSEARCH_2.DataSource = Nothing
            GDSEARCH_2.DataBind()

            ID = (DirectCast(GDSEARCH_3.SelectedItems(0), GridDataItem)).GetDataKeyValue("Policy_Code").ToString()
            SqlAction = "SELECT [Member_No],[Policy_Type],[Policy_Utilization],[Member_Utilization],[Contr_to_claims],[Policy_Loading],[Ind_Loading],[RELATION],[Is_Loading]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_REN_Ind_Loading] WITH (NOLOCK) WHERE Policy_Code='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
                Session("DAD_L") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_2.DataSource = Nothing
                GDSEARCH_2.DataBind()
            End If
        Catch ex As Exception
            lblerror.Text = ex.Message
        End Try
    End Sub
 
End Class
