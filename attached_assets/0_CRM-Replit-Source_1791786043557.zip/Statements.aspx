﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Statements.aspx.vb" Inherits="Default2" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
 <ContentTemplate>
  <asp:UpdateProgress runat="server" id="PageUpdateProgress">
            <ProgressTemplate>
                Loading...                
            </ProgressTemplate>
        </asp:UpdateProgress>
        <br />
     <asp:Panel ID="Panel1" runat="server" Height="242px" BorderStyle="Solid" 
         BorderWidth="1px" style="margin-left: 24px" Width="1197px">
     
                <table style="width: 100%">
                    <tr>
                        <td style="width: 144px">
                            &nbsp;</td>
                        <td style="width: 317px">
                            <asp:Label ID="Label14" runat="server" Text="Type"></asp:Label>
                        </td>
                        <td style="width: 172px">
                            <telerik:RadComboBox ID="rdapprove_2" Runat="server" Skin="Simple" 
                                style="margin-top: 0px">
                                <Items>
                                    <telerik:RadComboBoxItem runat="server" />
                                    <telerik:RadComboBoxItem runat="server" Owner="rdapprove_1" 
                                        Text="Commissions/Incentive" Value="SA" />
                                    <telerik:RadComboBoxItem runat="server" Owner="rdapprove_1" 
                                        Text="Overrides-UM/BM/RM" Value="OV" />
                                    <telerik:RadComboBoxItem runat="server" Text="Emails Not Send" Value="EN" />
                                    <telerik:RadComboBoxItem runat="server" Text="Emails Send" Value="ES" />
                                    <telerik:RadComboBoxItem runat="server" Text="Statement-Comments" Value="SC" />
                                </Items>
                            </telerik:RadComboBox>
                        </td>
                        <td style="width: 107px">
                            &nbsp;</td>
                        <td style="width: 125px">
                            &nbsp;</td>
                        <td>
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 144px; height: 26px;">
                        </td>
                        <td style="width: 317px; height: 26px;">
                            <asp:CheckBox ID="chkBranch" runat="server" Text="Branch" />
                        </td>
                        <td style="width: 172px; height: 26px;">
                            <telerik:RadComboBox ID="CBOBRANCH" Runat="server" Skin="Forest" 
                                AllowCustomText="True" MarkFirstMatch="True" Width="191px" 
                                AutoPostBack="True">
                            </telerik:RadComboBox>
                        </td>
                        <td style="width: 107px; height: 26px;">
                        </td>
                        <td style="width: 125px; height: 26px">
                        </td>
                        <td style="height: 26px">
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 144px">
                            &nbsp;</td>
                        <td style="width: 317px">
                            <asp:CheckBox ID="chkrm" runat="server" Text="Regional Managers" />
                        </td>
                        <td style="width: 172px">
                            <telerik:RadComboBox ID="CBORM" Runat="server" Skin="Forest" 
                                AllowCustomText="True" Width="191px" MarkFirstMatch="True">
                            </telerik:RadComboBox>
                        </td>
                        <td style="width: 107px">
                            &nbsp;</td>
                        <td style="width: 125px">
                            &nbsp;</td>
                        <td>
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 144px; height: 26px;">
                            </td>
                        <td style="width: 317px; height: 26px;">
                            <asp:CheckBox ID="chkbm" runat="server" Text="Branch Managers" />
                        </td>
                        <td style="width: 172px; height: 26px;">
                            <telerik:RadComboBox ID="CBOBM" Runat="server" Skin="Forest" 
                                AllowCustomText="True" Width="191px" MarkFirstMatch="True">
                            </telerik:RadComboBox>
                        </td>
                        <td style="width: 107px; height: 26px;">
                            </td>
                        <td style="width: 125px; height: 26px">
                            </td>
                        <td style="height: 26px">
                            </td>
                    </tr>
                    <tr>
                        <td style="width: 144px">
                            &nbsp;</td>
                        <td style="width: 317px">
                            <asp:CheckBox ID="chkum" runat="server" Text="Unit Managers" />
                        </td>
                        <td style="width: 172px">
                            <telerik:RadComboBox ID="CBOUM" Runat="server" Skin="Forest" 
                                AllowCustomText="True" Width="191px" MarkFirstMatch="True">
                            </telerik:RadComboBox>
                        </td>
                        <td style="width: 107px">
                            &nbsp;</td>
                        <td style="width: 125px">
                            &nbsp;</td>
                        <td>
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 144px">
                            &nbsp;</td>
                        <td style="width: 317px">
                            <asp:CheckBox ID="chkagents" runat="server" Text="Agents" />
                        </td>
                        <td style="width: 172px">
                            <telerik:RadComboBox ID="CBOagents" Runat="server" Skin="Forest" 
                                AllowCustomText="True" Width="225px" MarkFirstMatch="True">
                            </telerik:RadComboBox>
                        </td>
                        <td style="width: 107px">
                            &nbsp;</td>
                        <td style="width: 125px">
                            &nbsp;</td>
                        <td>
                            &nbsp;</td>
                    </tr>
                    <tr>
                        <td style="width: 144px">
                            &nbsp;</td>
                        <td style="width: 317px">
                            <asp:Label ID="Label6" runat="server" Text="Date From"></asp:Label>
                        </td>
                        <td style="width: 172px">
                            <telerik:RadDatePicker ID="dtfrom" Runat="server" Skin="Sunset">
                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                </Calendar>
                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                </DateInput>
                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                            </telerik:RadDatePicker>
                        </td>
                        <td style="width: 107px">
                            <asp:Label ID="Label7" runat="server" Text="Date From"></asp:Label>
                        </td>
                        <td style="width: 125px">
                            <telerik:RadDatePicker ID="dtto" Runat="server" Skin="Sunset">
                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                </Calendar>
                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                </DateInput>
                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                            </telerik:RadDatePicker>
                        </td>
                        <td>
                            <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="View" 
                                Width="100px">
                            </telerik:RadButton>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 144px">
                            &nbsp;</td>
                        <td style="width: 317px">
                            &nbsp;</td>
                        <td style="width: 172px">
                            &nbsp;</td>
                        <td style="width: 107px">
                            &nbsp;</td>
                        <td style="width: 125px">
                            &nbsp;</td>
                        <td>
                            &nbsp;</td>
                    </tr>
                </table>
                <br />
                </asp:Panel>
     <asp:Panel ID="Panel2" runat="server" BorderStyle="Solid" BorderWidth="1px" 
         Height="129px" Width="1189px" style="margin-left: 24px">

         <table style="width: 100%">
             <tr>
                 <td colspan="6">
                     <hr />
                 </td>
             </tr>
             <tr>
                 <td style="width: 158px">
                     &nbsp;</td>
                 <td style="width: 209px">
                     <asp:Label ID="Label8" runat="server" Text="Commission"></asp:Label>
                 </td>
                 <td style="width: 125px">
                     <telerik:RadNumericTextBox ID="txtcomm" Runat="server" Skin="Simple" 
                         ReadOnly="True">
                     </telerik:RadNumericTextBox>
                 </td>
                 <td style="width: 130px">
                     <asp:Label ID="Label12" runat="server" Text="Overide New"></asp:Label>
                 </td>
                 <td style="width: 129px">
                     <telerik:RadNumericTextBox ID="txtovernew" Runat="server" Skin="Simple" 
                         Enabled="False">
                     </telerik:RadNumericTextBox>
                 </td>
                 <td>
                     &nbsp;</td>
             </tr>
             <tr>
                 <td style="width: 158px">
                     &nbsp;</td>
                 <td style="width: 209px">
                     <asp:Label ID="Label10" runat="server" Text="Incentive New"></asp:Label>
                 </td>
                 <td style="width: 125px">
                     <telerik:RadNumericTextBox ID="txtincenew" Runat="server" Skin="Simple" 
                         Enabled="False">
                     </telerik:RadNumericTextBox>
                 </td>
                 <td style="width: 130px">
                     <asp:Label ID="Label13" runat="server" Text="Overide Renew"></asp:Label>
                 </td>
                 <td style="width: 129px">
                     <telerik:RadNumericTextBox ID="txtoverrenew" Runat="server" Skin="Simple" 
                         Enabled="False">
                     </telerik:RadNumericTextBox>
                 </td>
                 <td>
                     &nbsp;</td>
             </tr>
             <tr>
                 <td style="width: 158px">
                     &nbsp;</td>
                 <td style="width: 209px">
                     <asp:Label ID="Label11" runat="server" Text="Incentive Renew"></asp:Label>
                 </td>
                 <td style="width: 125px">
                     <telerik:RadNumericTextBox ID="txtincerenew" Runat="server" Skin="Simple" 
                         Enabled="False">
                     </telerik:RadNumericTextBox>
                 </td>
                 <td style="width: 130px">
                     <asp:CheckBox ID="chkemail" runat="server" Text="Email" />
                 </td>
                 <td style="width: 129px">
                     <telerik:RadButton ID="RadButton2" runat="server" Skin="Simple" Text="Generate" 
                         Width="100px">
                     </telerik:RadButton>
                 </td>
                 <td>
                     <asp:Label ID="lblstate" runat="server"></asp:Label>
                 </td>
             </tr>
         </table>

     </asp:Panel>
 </ContentTemplate>
 </asp:UpdatePanel>
</asp:Content>

