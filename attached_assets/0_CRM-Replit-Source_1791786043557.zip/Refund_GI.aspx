﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Refund_GI.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Insured Name"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Web20" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Member_code">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter Member_code column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Member_code" 
                                                            FilterControlAltText="Filter Member_code column" 
                                                            HeaderText="Member_code" SortExpression="Member_code" 
                                                            UniqueName="Member_code">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_name" 
                                                            FilterControlAltText="Filter Member_name column" HeaderText="Member_name" 
                                                            SortExpression="Member_name" UniqueName="Member_name">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Member_DOB"  DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter Member_DOB column" HeaderText="Member_DOB" 
                                                            SortExpression="Member_DOB" UniqueName="Member_DOB">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="Member_Pin_No" 
                                                            FilterControlAltText="Filter Member_Pin_No column" HeaderText="Member_Pin_No" 
                                                            SortExpression="Member_Pin_No" UniqueName="Member_Pin_No">
                                                        </telerik:GridBoundColumn>
                                                     
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel1" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td colspan="3">
                                                        <asp:Label ID="Label144" runat="server" Text="Premium Statement"></asp:Label>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1142px">
                                                            <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" 
                                                                Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="ACTION_TYPE" 
                                                                            FilterControlAltText="Filter ACTION_TYPE column" HeaderText="ACTION_TYPE" 
                                                                            SortExpression="ACTION_TYPE" UniqueName="ACTION_TYPE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="TOTAL_MEMBERS" 
                                                                            FilterControlAltText="Filter TOTAL_MEMBERS column" HeaderText="MEMBERS" 
                                                                            SortExpression="TOTAL_MEMBERS" UniqueName="TOTAL_MEMBERS">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                                            FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                                            SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="TRANSACTION_DATE" 
                                                                            FilterControlAltText="Filter TRANSACTION_DATE column" 
                                                                            HeaderText="TRANSACTION_DATE" SortExpression="TRANSACTION_DATE" 
                                                                            UniqueName="TRANSACTION_DATE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="DR" FilterControlAltText="Filter DR column" 
                                                                            HeaderText="DR" SortExpression="DR" UniqueName="DR">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="CR" FilterControlAltText="Filter CR column" 
                                                                            HeaderText="CR" SortExpression="CR" UniqueName="CR">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 143px">
                                                        <asp:Label ID="Label145" runat="server" Font-Bold="True" Text="O/S balance"></asp:Label>
                                                    </td>
                                                    <td align="right" style="width: 215px">
                                                        <telerik:RadNumericTextBox ID="txtbal" Runat="server" Enabled="False" 
                                                            Skin="Web20">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td style="width: 324px">
                                                        &nbsp;</td>
                                                    <td>
                                                        <telerik:RadButton ID="btnstatement" runat="server" Skin="Web20" 
                                                            Text="Print Statement" Width="276px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 148px; height: 34px;">
                                                                </td>
                                                                <td colspan="2" style="height: 34px">
                                                                    <asp:Label ID="LBLPROP" runat="server" Visible="False"></asp:Label>
                                                                </td>
                                                                <td style="width: 174px; height: 34px;">
                                                                </td>
                                                                <td style="height: 34px">
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label160" runat="server" Text="Total DR"></asp:Label>
                                                                </td>
                                                                <td colspan="2">
                                                                    <telerik:RadNumericTextBox ID="txtDR" Runat="server" Enabled="False" 
                                                                        Width="150px">
                                                                    </telerik:RadNumericTextBox>
                                                                </td>
                                                                <td style="width: 174px">
                                                                    <asp:Label ID="Label161" runat="server" Text="Total CR"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadNumericTextBox ID="txtCR" Runat="server" Enabled="False" 
                                                                        Width="150px">
                                                                    </telerik:RadNumericTextBox>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label154" runat="server" Text="Payee Name"></asp:Label>
                                                                </td>
                                                                <td colspan="2">
                                                                    <telerik:RadTextBox ID="txtname" Runat="server" Skin="Web20" Width="250px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                                <td style="width: 174px">
                                                                    <asp:Label ID="Label162" runat="server" Text="Client Type"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    <asp:Label ID="lbltype" runat="server"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label157" runat="server" Text="Payee eMail"></asp:Label>
                                                                </td>
                                                                <td colspan="2">
                                                                    <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Web20" Width="250px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                                <td style="width: 174px">
                                                                    <asp:Label ID="Label164" runat="server" Text="Proposal"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Web20" Width="250px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label158" runat="server" Text="Payee Mobile"></asp:Label>
                                                                </td>
                                                                <td colspan="2">
                                                                    <telerik:RadNumericTextBox ID="txtmobile" Runat="server" 
                                                                        DataType="System.Int32" Width="225px">
                                                                        <NumberFormat DecimalDigits="0" GroupSeparator="" />
                                                                    </telerik:RadNumericTextBox>
                                                                </td>
                                                                <td style="width: 174px">
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label155" runat="server" Text="Amount Bal"></asp:Label>
                                                                </td>
                                                                <td style="width: 169px">
                                                                    <telerik:RadNumericTextBox ID="txtpaid" Runat="server" Culture="en-US" 
                                                                        Enabled="False" Value="0" Width="150px">
                                                                    </telerik:RadNumericTextBox>
                                                                </td>
                                                                <td style="width: 123px">
                                                                    &nbsp;</td>
                                                                <td style="width: 174px">
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label156" runat="server" Text="Refund Amt"></asp:Label>
                                                                </td>
                                                                <td style="width: 169px">
                                                                    <telerik:RadNumericTextBox ID="txtrefund" Runat="server" Culture="en-US" 
                                                                        Value="0" Width="150px">
                                                                    </telerik:RadNumericTextBox>
                                                                </td>
                                                                <td style="width: 123px">
                                                                    &nbsp;</td>
                                                                <td style="width: 174px">
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label163" runat="server" Text="Refund Type"></asp:Label>
                                                                </td>
                                                                <td style="width: 169px">
                                                                    <telerik:RadComboBox ID="cbotype" Runat="server" AllowCustomText="True" 
                                                                        MarkFirstMatch="True" Skin="Web20" Width="190px">
                                                                        <Items>
                                                                            <telerik:RadComboBoxItem runat="server" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="TERMINATION" 
                                                                                Value="TERMINATION" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="OVER-PAYMENT" 
                                                                                Value="OVER-PAYMENT" />
                                                                        </Items>
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td style="width: 123px">
                                                                    &nbsp;</td>
                                                                <td style="width: 174px">
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="5">
                                                                    <hr />
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    <asp:Label ID="Label153" runat="server" Text="Documents"></asp:Label>
                                                                </td>
                                                                <td colspan="3">
                                                                    <asp:Panel ID="Panel32" runat="server" BorderStyle="Dotted" BorderWidth="1px" 
                                                                        Height="100%" Width="100%">
                                                                        <asp:CheckBoxList ID="chklist" runat="server" Font-Bold="True" 
                                                                            Font-Size="Medium" ForeColor="#CC0000" Width="391px">
                                                                        </asp:CheckBoxList>
                                                                    </asp:Panel>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="height: 46px; width: 148px">
                                                                </td>
                                                                <td style="height: 46px; width: 169px">
                                                                    <telerik:RadButton ID="btnsave" runat="server" Skin="Web20" Text="Save" 
                                                                        Width="150px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td colspan="2" style="height: 46px">
                                                                    &nbsp;</td>
                                                                <td style="height: 46px">
                                                                    <asp:Label ID="Label159" runat="server" Font-Size="Medium" Text="Refund No"></asp:Label>
                                                                    &nbsp;:<asp:Label ID="RefNo" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                                        ForeColor="Red"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 148px">
                                                                    &nbsp;</td>
                                                                <td style="width: 169px">
                                                                    &nbsp;</td>
                                                                <td colspan="2">
                                                                    <asp:Label ID="lblsave" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                                        ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1128px">
                                                            <telerik:RadGrid ID="GDTrackingRef" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" 
                                                                Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Refund_No">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="50px" />
                                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="Refund_No" 
                                                                            FilterControlAltText="Filter Receive_dt column" HeaderText="Refund_No" 
                                                                            SortExpression="Refund_No" UniqueName="Refund_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                            FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Request_Dt" 
                                                                            FilterControlAltText="Filter Request_Dt column" HeaderText="Request_Dt" 
                                                                            SortExpression="Request_Dt" UniqueName="Request_Dt">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Payee_Name" 
                                                                            FilterControlAltText="Filter Payee_Name column" HeaderText="Payee_Name" 
                                                                            SortExpression="Payee_Name" UniqueName="Payee_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Amount_Paid" 
                                                                            FilterControlAltText="Filter Amount_Paid column" HeaderText="Amount_Paid" 
                                                                            SortExpression="Amount_Paid" UniqueName="Amount_Paid">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Refund_Amt" 
                                                                            FilterControlAltText="Filter Refund_Amt column" HeaderText="Refund_Amt" 
                                                                            SortExpression="Refund_Amt" UniqueName="Refund_Amt">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Payee_eMail" 
                                                                            FilterControlAltText="Filter Payee_eMail column" HeaderText="Payee_eMail" 
                                                                            SortExpression="Payee_eMail" UniqueName="Payee_eMail">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Payee_Mobile" 
                                                                            FilterControlAltText="Filter Payee_Mobile column" HeaderText="Payee_Mobile" 
                                                                            SortExpression="Payee_Mobile" UniqueName="Payee_Mobile">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Refund_Status" 
                                                                            FilterControlAltText="Filter Refund_Status column" HeaderText="Refund_Status" 
                                                                            SortExpression="Refund_Status" UniqueName="Refund_Status">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Entered_By" 
                                                                            FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                            SortExpression="Entered_By" UniqueName="Entered_By">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 143px">
                                                        <asp:Label ID="lblid" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                    </td>
                                                    <td style="width: 215px">
                                                        &nbsp;</td>
                                                    <td style="width: 324px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel2" runat="server">
                                                            <table style="width: 99%">
                                                                <tr>
                                                                    <td colspan="4">
                                                                        <asp:Label ID="Label147" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="4">
                                                                        <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                                            Width="1100px">
                                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </RowIndicatorColumn>
                                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </ExpandCollapseColumn>
                                                                                    <Columns>
                                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                                            FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                                            UniqueName="Select">
                                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                            <ItemStyle Width="50px" />
                                                                                        </telerik:GridButtonColumn>
                                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                                        </telerik:GridBoundColumn>
                                                                                    </Columns>
                                                                                    <EditFormSettings>
                                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                        </EditColumn>
                                                                                    </EditFormSettings>
                                                                                </MasterTableView>
                                                                                <FilterMenu EnableImageSprites="False">
                                                                                </FilterMenu>
                                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                </HeaderContextMenu>
                                                                            </telerik:RadGrid>
                                                                        </asp:Panel>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="Label165" runat="server" Text="Document Title"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 35px">
                                                                        <telerik:RadTextBox ID="txttitle" Runat="server" Enabled="False" Skin="Web20" 
                                                                            Width="300px">
                                                                        </telerik:RadTextBox>
                                                                    </td>
                                                                    <td style="width: 155px; height: 35px;">
                                                                        <asp:Label ID="DOC_ID" runat="server" 
                                                                            style="font-weight: 700; color: #CC0000; background-color: #FFFFFF" 
                                                                            Visible="False"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 35px">
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="Label146" runat="server" Text="Document"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 35px">
                                                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                                    </td>
                                                                    <td style="width: 155px; height: 35px;">
                                                                        <asp:Label ID="Label138" runat="server" Text="Upload Date"></asp:Label>
                                                                    </td>
                                                                    <td style="height: 35px">
                                                                        <telerik:RadDatePicker ID="dtupload" Runat="server" Enabled="False" MinDate="" 
                                                                            Skin="Web20">
                                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                            </Calendar>
                                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                                            </DateInput>
                                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                        </telerik:RadDatePicker>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 24px; height: 35px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 35px">
                                                                        <telerik:RadButton ID="btnupload" runat="server" Skin="Web20" Text="Upload" 
                                                                            Width="150px">
                                                                        </telerik:RadButton>
                                                                        &nbsp;
                                                                    </td>
                                                                    <td style="width: 155px; height: 35px;">
                                                                        &nbsp;</td>
                                                                    <td style="height: 35px">
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="4" style="height: 35px;">
                                                                        <asp:Label ID="lblupload" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                                            ForeColor="Red"></asp:Label>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>
