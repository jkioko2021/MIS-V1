﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] WHERE SIGNOFF_PERIOD=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                Session("PERIOD_FROM") = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                Session("PERIOD_TO") = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()
                dtF_1.DbSelectedDate = Session("PERIOD_FROM")
                DTt_1.DbSelectedDate = Session("PERIOD_TO")
            End If
            Session("EXCEL") = Nothing
            loadgr()
            Session("EXCEL") = Nothing

        End If
    End Sub
    Public Sub loadgr()
        Try
            Dim MyDatable As New Data.DataTable

            SqlAction = "SELECT [ID],[MEMBER_NO] DISPLAY_MEMBERSHIP_NO,[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO  FROM [CRM].[dbo].[TBL_MIS_LOADING_FLAG] WHERE LOADED=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
                Session("DAD_5_2") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try

            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [ID],[MEMBER_NO] DISPLAY_MEMBERSHIP_NO,[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO  FROM [CRM].[dbo].[TBL_MIS_LOADING_FLAG] WHERE LOADED=0 AND MEMBER_NO='" & STR & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
                Session("DAD_5_2") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
            End If

            'Notes
            SqlAction = "SELECT   [Note_id],[Member_No],[Notes],[Note_From],[Note_Date],[Note_Type],[Active]  FROM [CRM].[dbo].[TBL_MIS_CRM_LOADING_NOTES] WHERE  Member_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Private Sub updateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

        'ShowGridDetails()
    End Sub
    Protected Sub GDSEARCH_1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH_1.PageIndexChanged
        GDSEARCH_1.CurrentPageIndex = e.NewPageIndex
        GDSEARCH_1.DataSource = Session("DAD_5_2")
        GDSEARCH_1.DataBind()
    End Sub
    Protected Sub cmdsave_1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave_1.Click
        Dim STS As Integer

        Try
            MyDBAction.Flag_Loading(txtno_1.Text, txtname_1.Text, CDate(dtfrom_1.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto_1.DbSelectedDate).ToString("yyyy-MM-dd"), txtcomment.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"))
            If txtcomment.Text <> "" Then
                MyDBAction.TRACKING_UW_MESSAGES(txtno_1.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
            End If
            load_Grid(txtno_1.Text)
            lblID_1.Text = "" : txtno_1.Text = "" : txtname_1.Text = "" : txtcomment.Text = ""
            lblerr.Text = "Saved successfully!"
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDSEARCH_1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH_1.SelectedIndexChanged
        Dim ID As String = ""
        GDSEARCH_2.DataSource = Nothing
        GDSEARCH_2.DataBind()
        lblerr.Text = ""

        ID = (DirectCast(GDSEARCH_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
        Dim SqlAction As String = ""
        SqlAction = "SELECT [ID],[MEMBER_NO] DISPLAY_MEMBERSHIP_NO,[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO   FROM [CRM].[dbo].[TBL_MIS_LOADING_FLAG] WHERE LOADED=0 AND MEMBER_NO='" & ID & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH_2.DataSource = MyDatable
            GDSEARCH_2.DataBind()
            Session("DAD_5_2") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH_2.DataSource = Nothing
            GDSEARCH_2.DataBind()

            Session("status_1") = Nothing
            SqlAction = "SELECT DISPLAY_MEMBERSHIP_NO,MEMBER_NAME,RELATION,POLICY_VALID_FROM,POLICY_VALID_UPTO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK) WHERE  GRP_INDV='I' AND DISPLAY_MEMBERSHIP_NO ='" & ID & "'"
            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    lblID_1.Text = MyDatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                    'lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    txtno_1.Text = MyDatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                    txtname_1.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    'txtrela_1.Text = MyDatable.Rows(0).Item("RELATION").ToString()
                    dtfrom_1.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_FROM").ToString()
                    DTto_1.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_UPTO").ToString()
                    'lblID.Enabled = False : txtno.Enabled = False : txtname.Enabled = False
                    load_Grid(txtno_1.Text)
                End If
                Session("DAD_5") = Nothing

            End If
        End If
    End Sub

    Protected Sub RadButton6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton6.Click

        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "Flag-Loading As At-& "

        Session("EXCEL") = "TO EXCEL"
        SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[NOTES],[FLAGED_BY],[FLAG_DATE],[PERIOD_FROM],[PERIOD_TO],[LOADED]  FROM [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub

    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            If TXTSEARCH.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If


            SqlAction = "SELECT DISPLAY_MEMBERSHIP_NO,MEMBER_NAME,RELATION,POLICY_VALID_FROM,POLICY_VALID_UPTO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK) WHERE  GRP_INDV='I' AND    DISPLAY_MEMBERSHIP_NO Like '%" & Trim(TXTSEARCH.Text) & "%'"
            Dim MyDatable As New Data.DataTable

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub

    Protected Sub GDSEARCH_2_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH_2.SelectedIndexChanged
        Try
            ID = (DirectCast(GDSEARCH_2.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            Dim SqlAction As String = ""
            SqlAction = "SELECT [ID],[MEMBER_NO] DISPLAY_MEMBERSHIP_NO,[MEMBER_NAME],PERIOD_FROM POLICY_VALID_FROM,PERIOD_TO POLICY_VALID_UPTO   FROM [CRM].[dbo].[TBL_MIS_LOADING_FLAG] WHERE LOADED=0 AND MEMBER_NO='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                SqlAction = "SELECT   [Note_id],[Member_No],[Notes],[Note_From],[Note_Date],[Note_Type],[Active]  FROM [CRM].[dbo].[TBL_MIS_CRM_LOADING_NOTES] WHERE  Member_No ='" & ID & "' ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
