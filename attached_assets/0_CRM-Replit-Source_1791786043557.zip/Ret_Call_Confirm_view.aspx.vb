﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            empcode = ""
            Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                'empcode = "0111"
            Else
                lblerr.Text = "You are not authorized to view this page"
                Exit Sub
            End If
            Str = ""
            Str = "SELECT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1 AND C_CODE='R' AND RE_CODE ='" & empcode & "' " '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cborm
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()
            End With
            cborm.SelectedValue = empcode

            loadgrid()
        End If
    End Sub
    Public Sub loadgrid()
        Try
            SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM [TBL_MIS_CRM_NEW_POLICIES_RET] WHERE [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=1 AND PERIOD_TO>=Getdate()"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
                Session("DAD_C_0") = MyDatable
                MyDatable = Nothing
            Else
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
            End If

            SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & PRD.Text & "'  ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDProposer.DataSource = Nothing
            GDProposer.DataBind()
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()

            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM TBL_MIS_CRM_NEW_POLICIES_RET WHERE PROPOSER_DISPLAY_NAME LIKE '%" & cbosearch_1.Text & "%'  AND [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=1"
            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM TBL_MIS_CRM_NEW_POLICIES_RET WHERE POLICY_CODE LIKE '%" & cbosearch_1.Text & "%' AND  [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=1"
            ElseIf cbosearch.SelectedValue = "A" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID, POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO FROM TBL_MIS_CRM_NEW_POLICIES_RET WHERE USER_ID = '" & cbosearch_1.SelectedValue & "'  AND [RMS_CODE]='" & cborm.SelectedValue & "' AND [CONFIRMED]=1"

            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
                Session("DAD_C_0") = MyDatable
                MyDatable = Nothing
            Else
                GDProposer.DataSource = MyDatable
                GDProposer.DataBind()
            End If
            '

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDProposer_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDProposer.PageIndexChanged
        GDProposer.CurrentPageIndex = e.NewPageIndex
        GDProposer.DataSource = Session("DAD_C_0")
        GDProposer.DataBind()
    End Sub


    Protected Sub cbosearch_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbosearch.SelectedIndexChanged
        If cbosearch.SelectedValue = "A" Then
            Str = "SELECT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1 AND RMS_CODE_RET='" & cborm.SelectedValue & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbosearch_1
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()
            End With

        Else
            cbosearch_1.SelectedValue = ""
            cbosearch_1.Text = ""
        End If
    End Sub
    Protected Sub GDProposer_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDProposer.SelectedIndexChanged
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            PRD.Text = ""
            PRD.Text = (DirectCast(GDProposer.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()
            Dim SqlAction As String = ""
            Session("status_1") = Nothing

            SqlAction = "SELECT [Proposer_ID],[Confirm_Call_Code],[Confirm_Call_By],[Confirm_Call_Date],[Correct_Cover],[Welcome_Package],[Ack_Consent],[Policy_Terms_Exp],[Satisfied_with_info],[Call_Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_NEW_RET_CALL_LOG]  WHERE PROPOSER_ID ='" & PRD.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_C_0") = MyDatable

                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & PRD.Text & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            Else
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    
End Class
