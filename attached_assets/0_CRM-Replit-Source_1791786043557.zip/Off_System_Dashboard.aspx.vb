﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing

                dtfrom.DbSelectedDate = Date.Now()
                dtto.DbSelectedDate = Date.Now()
               
                loadGrid_N()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If

    End Sub
    Public Sub loadGrid_N()

        SqlAction = "SELECT  [Entered_by],SUM([NOT_SUBMITTED])[NOT_SUBMITTED],SUM([NOT_SCANNED])[NOT_SCANNED],SUM([NOT_ALLOCATED])[NOT_ALLOCATED],SUM([NOT_BILLED])[NOT_BILLED],SUM([BILLED])[BILLED],SUM(WITH_ISSUES)WITH_ISSUES,SUM([RETURNED_INCOMPLETE])[RETURNED_INCOMPLETE],SUM(TOTAL_APPROVALS)TOTAL_APPROVALS FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_TRACKING_STATUS] GROUP BY Entered_by"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_0.DataSource = MyDatable
            GDTracking_0.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
        End If
    End Sub

    


    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub



    

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDTracking.DataSource = Nothing
            GDTracking.DataBind()
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
           

            SqlAction = "SELECT  [Entered_by],SUM([NOT_SUBMITTED])[NOT_SUBMITTED],SUM([NOT_SCANNED])[NOT_SCANNED],SUM([NOT_ALLOCATED])[NOT_ALLOCATED],SUM([NOT_BILLED])[NOT_BILLED],SUM([BILLED])[BILLED],SUM(WITH_ISSUES)WITH_ISSUES,SUM([RETURNED_INCOMPLETE])[RETURNED_INCOMPLETE],SUM(TOTAL_APPROVALS)TOTAL_APPROVALS  FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_TRACKING_STATUS]  WITH(NOLOCK) WHERE   [Entry_Date]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY entered_by"
          
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking_0.DataSource = MyDatable
                GDTracking_0.DataBind()
                Session("DAD_T_0") = MyDatable
                MyDatable = Nothing
            Else
                GDTracking_0.DataSource = Nothing
                GDTracking_0.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GDTracking_0_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTracking_0.SelectedIndexChanged
        Try
            GDTracking.DataSource = Nothing
            GDTracking.DataBind()
            HiddenField1.Value = 1
            ID = (DirectCast(GDTracking_0.SelectedItems(0), GridDataItem)).GetDataKeyValue("entered_by").ToString()

            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE entered_by='" & ID & "'  AND Entry_Date Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' order by INV_Status"
           

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking.DataSource = MyDatable
                GDTracking.DataBind()
                Session("DAD_T_1") = MyDatable
                MyDatable = Nothing
            Else
                GDTracking.DataSource = Nothing
                GDTracking.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDTracking_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTracking.PageIndexChanged
        GDTracking.CurrentPageIndex = e.NewPageIndex
        GDTracking.DataSource = Session("DAD_T_1")
        GDTracking.DataBind()
    End Sub
    Protected Sub GDTracking_0_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTracking_0.PageIndexChanged
        GDTracking_0.CurrentPageIndex = e.NewPageIndex
        GDTracking_0.DataSource = Session("DAD_T_0")
        GDTracking_0.DataBind()
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "Off_System_List"

        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        If cboNAME.SelectedValue = "RE" Then
            SqlAction = "SELECT [Id],[Entry_Date],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason_name],[Off_Type],[Entered_By],[Inv_Status],[submitted],[Provider_ID], [Mobile_no],[New_Member],[Indexed],[Invoice_no],[Invoice_Amt],[Allocated],[Bar_Code],[Policy_issue],[Mtiba_Code],[Billed]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System]  with(nolock) WHERE   Entry_Date Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Inv_Status='REGISTERED'"
        ElseIf cboNAME.SelectedValue = "SU" Then
            SqlAction = "SELECT [Id],[Entry_Date],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason_name],[Off_Type],[Entered_By],[Inv_Status],[submitted],[Provider_ID], [Mobile_no],[New_Member],[Indexed],[Invoice_no],[Invoice_Amt],[Allocated],[Bar_Code],[Policy_issue],[Mtiba_Code],[Billed]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System]  with(nolock) WHERE   Entry_Date Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Inv_Status='SUBMITTED'"
        ElseIf cboNAME.SelectedValue = "ALL" Then
            SqlAction = "SELECT [Id],[Entry_Date],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason_name],[Off_Type],[Entered_By],[Inv_Status],[submitted],[Provider_ID], [Mobile_no],[New_Member],[Indexed],[Invoice_no],[Invoice_Amt],[Allocated],[Bar_Code],[Policy_issue],[Mtiba_Code],[Billed]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System]  with(nolock) WHERE   Entry_Date Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
        End If

        Session("EXCEL") = "TO EXCEL"
        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
        'Reportname = ""
    End Sub


End Class
