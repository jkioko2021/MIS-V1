﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Refund_From_Decline.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="DECLINE -REFUND REQUEST" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td align="right" colspan="4">
                                                    <asp:Panel ID="Panel31" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 192px">
                                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                                </td>
                                                                <td style="width: 143px">
                                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" AllowCustomText="True" 
                                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Web20" Width="190px">
                                                                        <Items>
                                                                            <telerik:RadComboBoxItem runat="server" Text="File No." Value="F" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                                        </Items>
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td style="width: 266px">
                                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Web20" Width="250px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="FILE_NO" runat="server" Font-Bold="True" Font-Size="Small" 
                                                        style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    &nbsp;</td>
                                                <td style="width: 264px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTracking" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="Receive_dt" 
                                                                        FilterControlAltText="Filter Receive_dt column" HeaderText="Receive_dt" 
                                                                        SortExpression="Receive_dt" UniqueName="Receive_dt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="File_No" 
                                                                        FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                                        SortExpression="File_No" UniqueName="File_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                        FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                        SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                    </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="Client_Type" 
                                                                        FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                        SortExpression="Client_Type" UniqueName="Client_Type">
                                                                    </telerik:GridBoundColumn>   
                                                                    <telerik:GridBoundColumn DataField="Business_Type" 
                                                                        FilterControlAltText="Filter Business_Type column" HeaderText="Type" 
                                                                        SortExpression="Business_Type" UniqueName="Business_Type">
                                                                    </telerik:GridBoundColumn>                                                   
                                                                    <telerik:GridBoundColumn DataField="File_Status" 
                                                                        FilterControlAltText="Filter File_Status column" HeaderText="Status" 
                                                                        SortExpression="File_Status" UniqueName="File_Status">
                                                                    </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Entered_By" 
                                                                        FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                        SortExpression="Entered_By" UniqueName="Entered_By">
                                                                    </telerik:GridBoundColumn>
                                                             
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 148px">
                                                    <asp:Label ID="Label154" runat="server" Text="Payee Name"></asp:Label>
                                                </td>
                                                <td colspan="2">
                                                    <telerik:RadTextBox ID="txtname" Runat="server" Skin="Web20" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td style="width: 174px">
                                                    <asp:Label ID="Label160" runat="server" Text="Client"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblclient" runat="server"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">
                                                    <asp:Label ID="Label157" runat="server" Text="Payee eMail"></asp:Label>
                                                </td>
                                                <td colspan="2">
                                                    <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Web20" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td style="width: 174px">
                                                    <asp:Label ID="Label162" runat="server" Text="Proposer"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadTextBox ID="txtPROPOSER" Runat="server" Skin="Web20" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">
                                                    <asp:Label ID="Label158" runat="server" Text="Payee Mobile"></asp:Label>
                                                </td>
                                                <td colspan="2">
                                                    <telerik:RadNumericTextBox ID="txtmobile" Runat="server" 
                                                        DataType="System.Int32" Width="225px">
                                                        <NumberFormat DecimalDigits="0" GroupSeparator="" />
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                                <td style="width: 174px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">
                                                    <asp:Label ID="Label155" runat="server" Text="Paid Amount"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadNumericTextBox ID="txtpaid" Runat="server" Width="150px">
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                                <td style="width: 123px">
                                                    &nbsp;</td>
                                                <td style="width: 174px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">
                                                    <asp:Label ID="Label156" runat="server" Text="Amount To Refund"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadNumericTextBox ID="txtrefund" Runat="server" Width="150px">
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                                <td style="width: 123px">
                                                    &nbsp;</td>
                                                <td style="width: 174px">
                                                    <asp:Label ID="Label161" runat="server" Text="Entered By"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblentered" runat="server"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">&nbsp;</td>
                                                <td>
                                                    <telerik:RadButton ID="btnsave" runat="server" Skin="Simple" Text="Save" Width="150px">
                                                    </telerik:RadButton>
                                                </td>
                                                <td style="width: 123px">&nbsp;</td>
                                                <td style="width: 174px">
                                                    <asp:Label ID="Label159" runat="server" Font-Size="Medium" Text="Refund No"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="RefNo" runat="server" Font-Bold="True" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">&nbsp;</td>
                                                <td colspan="3">
                                                    <asp:Label ID="lblsave" runat="server" Font-Bold="True" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                </td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" Width="1128px">
                                                        <telerik:RadGrid ID="GDTrackingRef" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="Refund_No">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                                    <telerik:GridBoundColumn DataField="Refund_No" FilterControlAltText="Filter Receive_dt column" HeaderText="Refund_No" SortExpression="Refund_No" UniqueName="Refund_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="File_No" FilterControlAltText="Filter File_No column" HeaderText="File_No" SortExpression="File_No" UniqueName="File_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Request_Dt" FilterControlAltText="Filter Request_Dt column" HeaderText="Request_Dt" SortExpression="Request_Dt" UniqueName="Request_Dt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Payee_Name" FilterControlAltText="Filter Payee_Name column" HeaderText="Payee_Name" SortExpression="Payee_Name" UniqueName="Payee_Name">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Amount_Paid" FilterControlAltText="Filter Amount_Paid column" HeaderText="Amount_Paid" SortExpression="Amount_Paid" UniqueName="Amount_Paid">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Refund_Amt" FilterControlAltText="Filter Refund_Amt column" HeaderText="Refund_Amt" SortExpression="Refund_Amt" UniqueName="Refund_Amt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Payee_eMail" FilterControlAltText="Filter Payee_eMail column" HeaderText="Payee_eMail" SortExpression="Payee_eMail" UniqueName="Payee_eMail">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Payee_Mobile" FilterControlAltText="Filter Payee_Mobile column" HeaderText="Payee_Mobile" SortExpression="Payee_Mobile" UniqueName="Payee_Mobile">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Refund_Status" FilterControlAltText="Filter Refund_Status column" HeaderText="Refund_Status" SortExpression="Refund_Status" UniqueName="Refund_Status">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Entered_By" FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" SortExpression="Entered_By" UniqueName="Entered_By">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <hr />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#666666" colspan="5">
                                                    <asp:Label ID="Label153" runat="server" Text="Documents"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="height: 23px; width: 148px">
                                                    <asp:Label ID="Label145" runat="server" Text="Document Title"></asp:Label>
                                                </td>
                                                <td style="height: 23px; width: 169px">
                                                    <telerik:RadComboBox ID="cbodocs" Runat="server" AccessibilityMode="True" AllowCustomText="True" MarkFirstMatch="True" Skin="Web20" Width="300px">
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td colspan="2" style="height: 23px">
                                                    <asp:Label ID="DOC_ID" runat="server" style="font-weight: 700; color: #CC0000; background-color: #FFFFFF" Visible="False"></asp:Label>
                                                </td>
                                                <td style="height: 23px">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">
                                                    &nbsp;</td>
                                                <td style="width: 169px">
                                                    <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                </td>
                                                <td colspan="2">
                                                    <asp:Label ID="Label138" runat="server" Text="Upload Date"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadDatePicker ID="dtupload" Runat="server" Enabled="False" MinDate="" Skin="Web20">
                                                        <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">&nbsp;</td>
                                                <td style="width: 169px">&nbsp;</td>
                                                <td colspan="2">&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">&nbsp;</td>
                                                <td style="width: 169px">
                                                    <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" Text="Upload" Width="150px">
                                                    </telerik:RadButton>
                                                    <asp:Label ID="lblupload" runat="server" Font-Bold="True" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                </td>
                                                <td colspan="2">&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" Width="1100px">
                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                               
                                                        <telerik:GridBoundColumn DataField="DOC_ID" FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" FilterControlAltText="Filter File_No column" HeaderText="File No" SortExpression="File_No" UniqueName="File_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Title" FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Date" FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_Name" FilterControlAltText="Filter File_Name column" HeaderText="File_Name" SortExpression="File_Name" UniqueName="File_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Upload_By" FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" SortExpression="Upload_By" UniqueName="Upload_By">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                            <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                            <ItemStyle CssClass="ButtonColumn" />
                                                        </telerik:GridButtonColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td colspan="3">
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <hr />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 117px">
                                                    <asp:Label ID="Label163" runat="server" Text="Action"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadComboBox ID="cboAction" Runat="server" AllowCustomText="True" 
                                                        MarkFirstMatch="True" Skin="Web20" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" 
                                                                Text="Allocate-Membership" Value="A" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Forward- Supervisor" Value="F" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 117px">
                                                    <asp:Label ID="Label164" runat="server" Text="Allocate To"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadComboBox ID="cboAllocateto" Runat="server" AllowCustomText="True" 
                                                        MarkFirstMatch="True" Skin="Web20" Width="190px">
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 117px">
                                                    <asp:Label ID="Label144" runat="server" Text="Notes"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadTextBox ID="txtcomment" Runat="server" Height="50px" Skin="Web20" 
                                                        TextMode="MultiLine" Width="450px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 117px; height: 38px;">
                                                    </td>
                                                <td style="height: 38px;">
                                                    <telerik:RadButton ID="btnforward" runat="server" Skin="Simple" 
                                                        Text="Submit Refund" Width="200px">
                                                    </telerik:RadButton>
                                                </td>
                                                <td style="height: 38px">
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
        <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
        </Triggers>
            </asp:UpdatePanel>
</asp:Content>
