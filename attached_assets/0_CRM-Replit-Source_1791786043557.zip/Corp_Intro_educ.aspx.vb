﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
'Imports Microsoft.Office.Interop.Word
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Configuration

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyDatatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim Str As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            DTactivity.DbSelectedDate = Date.Now()
            dtfrom.DbSelectedDate = Date.Now()
            DTto.DbSelectedDate = Date.Now()
            Session("D_INTRO_1") = Nothing
            Session("D_MEM_1") = Nothing
            Session("ACT_01") = Nothing
            Str = ""
            Session("emp_code") = "0106"

            Str = "SELECT  [ACTIVITY_CODE],[ACTIVITY_NAME]  FROM CRM.[dbo].[TBL_MIS_RET_ACTIVITY] where TASK='N'"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboactivity
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ACTIVITY_NAME").ToString
                .DataValueField = MyDatatable.Columns("ACTIVITY_CODE").ToString
                .DataBind()

            End With

            MyDatatable = Nothing


            loadGrid()

        End If
    End Sub

    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        MyDatable = Nothing
        SqlAction = "SELECT CORPORATE_ID,POLICY_CODE, PROPOSER_DISPLAY_NAME,PERIOD_TO, [PERIOD_FROM],[INTRO_DATE_DUE] FROM CRM.[dbo].[TBL_MIS_CRM_NEW_POLICIES_CORP] WHERE [RMS_CODE]='" & Session("emp_code") & "' AND INTRO_DONE=0 AND PERIOD_TO>=GETDATE() "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDINTRO.DataSource = MyDatable
            GDINTRO.DataBind()
            Session("D_INTRO_1") = MyDatable
            MyDatable = Nothing
        Else
            GDINTRO.DataSource = MyDatable
            GDINTRO.DataBind()
        End If
        SqlAction = "SELECT CORPORATE_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_TO,[PERIOD_FROM],[EDUC_DATE_DUE] FROM CRM.[dbo].[TBL_MIS_CRM_MEM_EDUCATION_CORP] WHERE [RMS_CODE]='" & Session("emp_code") & "' AND [EDUC_DONE]=0 AND PERIOD_TO>=GETDATE() "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEM.DataSource = MyDatable
            GDMEM.DataBind()
            Session("D_MEM_1") = MyDatable
            MyDatable = Nothing
        Else
            GDMEM.DataSource = MyDatable
            GDMEM.DataBind()
        End If

        SqlAction = "SELECT   [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_MINUTES],FILE_NAME  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE RM_CODE='" & Session("emp_code") & "' AND PERIOD_TO>=GETDATE()"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
            Session("ACT_01") = MyDatable
            MyDatable = Nothing
        Else
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
        End If
       
    End Sub
    

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDINTRO.SelectedIndexChanged
        Dim ID As String = ""
        ltEmbed.Text = ""
        Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
        cboactivity.SelectedValue = ""
        cboactivity.Text = ""
        ID = (DirectCast(GDINTRO.SelectedItems(0), GridDataItem)).GetDataKeyValue("CORPORATE_ID").ToString()
        Dim SqlAction As String = ""
        Session("status_1") = Nothing
     
        SqlAction = "SELECT CORPORATE_ID,[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[PERIOD_FROM] ,[PERIOD_TO]  FROM CRM.[dbo].[TBL_MIS_CRM_NEW_POLICIES_CORP] WHERE [CORPORATE_ID]='" & ID & "'"
        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                lblIPolicy.Text = MyDatable.Rows(0).Item("POLICY_CODE").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

            End If
            'HiddenField1.Value = 1


            dtfrom.Enabled = False
            DTto.Enabled = False
        End If
    End Sub
    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDINTRO.PageIndexChanged
        GDINTRO.CurrentPageIndex = e.NewPageIndex
        GDINTRO.DataSource = Session("D_INTRO_1")
        GDINTRO.DataBind()
    End Sub
    Protected Sub GDMEM_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDMEM.PageIndexChanged
        GDMEM.CurrentPageIndex = e.NewPageIndex
        GDMEM.DataSource = Session("D_MEM_1")
        GDMEM.DataBind()
    End Sub
    Protected Sub RD_ACTIVITY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_ACTIVITY.PageIndexChanged
        RD_ACTIVITY.CurrentPageIndex = e.NewPageIndex
        RD_ACTIVITY.DataSource = Session("ACT_01")
        RD_ACTIVITY.DataBind()
    End Sub
    Protected Sub GDMEM_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDMEM.SelectedIndexChanged
        Dim ID As String = ""
        ltEmbed.Text = ""
        Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
        cboactivity.SelectedValue = ""
        cboactivity.Text = ""
        lblIPolicy.Text = (DirectCast(GDMEM.SelectedItems(0), GridDataItem)).GetDataKeyValue("POLICY_CODE").ToString()
        Dim SqlAction As String = ""
        Session("status_1") = Nothing

        SqlAction = "SELECT CORPORATE_ID,[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[PERIOD_FROM] ,[PERIOD_TO]  FROM CRM.[dbo].[TBL_MIS_CRM_MEM_EDUCATION_CORP] WHERE [POLICY_CODE]='" & lblIPolicy.Text & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
            'txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
            dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
            DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

        End If
        'HiddenField1.Value = 1


        dtfrom.Enabled = False
        DTto.Enabled = False

    End Sub

    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0


        Dim FILENO As String

        If cboactivity.SelectedValue = "" Then
            lblerr.Text = "You must select an activity"
            Exit Sub
        End If
        If FL1.PostedFile.FileName = "" Then
            lblerr.Text = "You must upload a reference pdf file!"
            Exit Sub
        End If

        Dim filePath As String = FL1.PostedFile.FileName

        Dim filename As String = Path.GetFileName(filePath)

        Dim ext As String = Path.GetExtension(filename)

        Dim contenttype As String = String.Empty

        Dim fs As Stream = FL1.PostedFile.InputStream

        Dim br As New BinaryReader(fs)

        'Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))
        Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))
        Dim app As Integer = 0
        Try

            If ext <> ".pdf" Or ext <> ".PDF" Then
                lblerr.Text = "You must attach a pdf document"
                'Exit Sub
            End If
            Select Case ext
                Case ".pdf"
                    contenttype = "application/pdf"
                Case ".PDF"
                    contenttype = "application/PDF"
                    Exit Select
                Case Else
                    lblerr.Text = "You must upload a pdf format!"
                    Exit Sub

            End Select

            If contenttype <> String.Empty Then

                Dim fileLocation As String = ""
                'FL1.SaveAs(fileLocation)
                              'Response.Redirect(Request.Url.AbsoluteUri)
                If cboactivity.SelectedValue = "0012" Then
                    MyDBAction.Retention_Register_corp(bytes, filename, contenttype, lblIPolicy.Text, lblID.Text, cboactivity.SelectedValue, CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd"), "", Session("username"), txtcomment.Text, fileLocation, CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"))

                    UpdateRecord("UPDATE TBL_MIS_CRM_NEW_POLICIES_CORP SET INTRO_DONE=1, [INTRO_DATE_DUE]='" & CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd") & "' ,INTRO_BY='" & Session("username") & "' where Corporate_id='" & lblID.Text & "'")

                Else
                    MyDBAction.Retention_Register_corp(bytes, filename, contenttype, lblIPolicy.Text, lblID.Text, cboactivity.SelectedValue, CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd"), "", Session("username"), txtcomment.Text, fileLocation, CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"))

                    UpdateRecord("UPDATE TBL_MIS_CRM_MEM_EDUCATION_CORP SET EDUC_DONE=1 ,[EDUC_DATE_DONE]='" & CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd") & "', EDUC_BY='" & Session("username") & "' where POLICY_CODE='" & lblIPolicy.Text & "'")

                End If
                lblerr.ForeColor = System.Drawing.Color.Green
                lblerr.Text = "File Uploaded Successfully"

            Else
                filename = ""
                'MyDBAction.Retention_Register_corp(bytes, filename, contenttype, "", lblID.Text, cboactivity.SelectedValue, CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd"), "", Session("username"), txtcomment.Text, "", CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"))

                lblerr.ForeColor = System.Drawing.Color.Red
                lblerr.Text = "data Saved Successfully"
                lblerr.Text = "File format not recognised." + " Upload Image/PDF"

            End If



            loadGrid()

            lblID.Text = ""

            cboactivity.SelectedValue = ""
            dtfrom.DbSelectedDate = ""
            DTto.DbSelectedDate = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

    Private Sub deleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try
            RD_ACTIVITY.DataSource = Nothing
            RD_ACTIVITY.DataBind()
            GDINTRO.DataSource = Nothing
            GDINTRO.DataBind()
            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            SqlAction = "SELECT  [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES],FILE_NAME  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE PROPOSER_DISPLAY_NAME Like '%" & Trim(txtsearch.Text) & "%' AND [RM_CODE]='" & Session("emp_code") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                RD_ACTIVITY.DataSource = MyDatable
                RD_ACTIVITY.DataBind()
                Session("ACT_01") = MyDatable
                MyDatable = Nothing


            Else
                RD_ACTIVITY.DataSource = MyDatable
                RD_ACTIVITY.DataBind()
            End If


        
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub View(ByVal sender As Object, ByVal e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""800px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""http://get.adobe.com/reader/"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileVB.ashx?Id="), id)
    End Sub

    

    Protected Sub DTactivity_SelectedDateChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs) Handles DTactivity.SelectedDateChanged
        If DTactivity.DbSelectedDate < DateAdd(DateInterval.Day, -7, Date.Now()) Or DTactivity.DbSelectedDate > Date.Now() Then

            DTactivity.DbSelectedDate = Date.Now
            lblerr.Text = "Activity date can only be within 7 days from the activity date!"

        Else
            lblerr.Text = ""
        End If

    End Sub


End Class
