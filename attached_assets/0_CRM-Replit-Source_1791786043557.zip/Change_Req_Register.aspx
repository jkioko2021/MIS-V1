﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Change_Req_Register.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8" colspan="4">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" Text="Create CR Task"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDSEARCH_1" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="CR_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                      <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                   
                                                        <telerik:GridBoundColumn DataField="CR_No" 
                                                            FilterControlAltText="Filter CR_No column" HeaderText="CR No" 
                                                            SortExpression="CR_No" UniqueName="CR_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CR_Name" 
                                                            FilterControlAltText="Filter CR_Name column" HeaderText="CR name" 
                                                            SortExpression="CR_Name" UniqueName="CR_Name">
                                                            <HeaderStyle Width="200px" />
                                                            <ItemStyle Width="200px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CR_dt" 
                                                            FilterControlAltText="Filter CR_dt column" HeaderText="CR date" 
                                                            SortExpression="CR_dt" UniqueName="CR_dt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CR_Status" 
                                                            FilterControlAltText="Filter CR_Status column" HeaderText="CR Status" 
                                                            SortExpression="CR_Status" UniqueName="CR_Status">
                                                        </telerik:GridBoundColumn>                                                      
                                                        <telerik:GridBoundColumn DataField="Entered_by" 
                                                            FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                            SortExpression="Entered_by" UniqueName="Entered_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CR_priority" 
                                                            FilterControlAltText="Filter CR_priority column" HeaderText="Priority" 
                                                            SortExpression="CR_priority" UniqueName="CR_priority">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label134" runat="server" Text="CR Code" 
                                            style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                    </td>
                                    <td>
                                        <asp:Label ID="lbltaskno" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style9" style="width: 109px" align="left">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label139" runat="server" Text="System"></asp:Label>
                                    </td>
                                    <td style="width: 90px">
                                        <telerik:RadComboBox ID="cbosystem" Runat="server" Skin="Web20" Width="190px" 
                                            AllowCustomText="True" MarkFirstMatch="True">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style9" style="width: 109px" align="left">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label112" runat="server" Text="CR Name"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txttaskname" Runat="server" Skin="Web20" Width="300px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style9" style="width: 109px" align="left">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label137" runat="server" Text="Priority"></asp:Label>
                                    </td>
                                    <td style="width: 90px">
                                        <telerik:RadComboBox ID="cbopriority" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Web20" 
                                            Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Low" Value="Low" />
                                                <telerik:RadComboBoxItem runat="server" Text="Medium" Value="Medium" />
                                                <telerik:RadComboBoxItem runat="server" Text="High" Value="High" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style9" align="left">
                                        &nbsp;</td>
                                    <td style="width: 287px" align="left">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label102" runat="server" Text="CR Date"></asp:Label>
                                    </td>
                                    <td style="width: 90px">
                                        <telerik:RadDatePicker ID="dtbooking" Runat="server" MinDate="" Skin="Web20">
                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style9" align="left">
                                        &nbsp;</td>
                                    <td style="width: 287px" align="left">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" style="width: 119px">
                                        <asp:Label ID="Label141" runat="server" Text="CR Type"></asp:Label>
                                    </td>
                                    <td style="width: 90px">
                                        <telerik:RadComboBox ID="cbotype" Runat="server" AllowCustomText="True" 
                                            MarkFirstMatch="True" Skin="Web20" Width="190px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Internal" Value="D" />
                                                <telerik:RadComboBoxItem runat="server" Text="External" Value="P" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td align="left" class="style9">
                                        &nbsp;</td>
                                    <td align="left" style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" style="width: 119px">
                                        &nbsp;</td>
                                    <td style="width: 90px">
                                        &nbsp;</td>
                                    <td align="left" class="style9">
                                        &nbsp;</td>
                                    <td align="left" style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        <asp:Label ID="Label136" runat="server" Text="Description"></asp:Label>
                                    </td>
                                    <td colspan="3" rowspan="3" align="left">
                                        <telerik:RadTextBox ID="txtdescr" Runat="server" Height="100px" Skin="Web20" 
                                            TextMode="MultiLine" Width="600px" style="font-size: medium" 
                                            Font-Size="Large" Rows="3">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px" align="left">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px">
                                        <asp:Label ID="Label140" runat="server" Text="Documents"></asp:Label>
                                    </td>
                                    <td style="width: 90px">
                                        <asp:Panel ID="Panel28" runat="server" BorderStyle="Dotted" BorderWidth="1px" 
                                            Height="100%" Width="243px">
                                            <asp:CheckBoxList ID="chklist" runat="server" Width="225px">
                                            </asp:CheckBoxList>
                                        </asp:Panel>
                                    </td>
                                    <td class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 119px">
                                        <asp:Label ID="Label127" runat="server" Text="Status"></asp:Label>
                                    </td>
                                    <td style="width: 90px">
                                        <telerik:RadComboBox ID="cbostatus" Runat="server" Skin="Web20" Width="150px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Open" Value="O" />
                                                <telerik:RadComboBoxItem runat="server" Text="Closed" Value="C" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666" class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;</td>
                                    <td align="left" class="style8">
                                        &nbsp;</td>
                                    <td class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style9" style="width: 109px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        <telerik:RadButton ID="cmdsave" runat="server" Height="38px" Skin="Web20" 
                                            Text="Save" Width="80px">
                                        </telerik:RadButton>
                                        &nbsp;<telerik:RadButton ID="cmdedit" runat="server" Height="38px" Skin="Web20" 
                                            Text="Edit" Width="80px">
                                        </telerik:RadButton>
                                        &nbsp;<telerik:RadButton ID="cmdnew" runat="server" Height="38px" Skin="Web20" 
                                            Text="New" Width="80px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>

