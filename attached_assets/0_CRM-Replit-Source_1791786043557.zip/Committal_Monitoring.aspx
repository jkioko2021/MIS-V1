﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Committal_Monitoring.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="3" align="center">
                                        <asp:Panel ID="Panel34" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" Width="1181px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td style="width: 906px">
                                                    </td>
                                                    <td style="width: 261px">
                                                        <asp:Label ID="Label177" runat="server" style="font-weight: 700" 
                                                            Text="Date From"></asp:Label>
                                                    </td>
                                                    <td style="width: 244px">
                                                        <telerik:RadDatePicker ID="Dtfrom" Runat="server" Skin="Simple">
                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 906px">
                                                        &nbsp;</td>
                                                    <td style="width: 261px">
                                                        <asp:Label ID="Label178" runat="server" style="font-weight: 700" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td style="width: 244px">
                                                        <telerik:RadDatePicker ID="Dtto" Runat="server" Skin="Simple">
                                                            <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview0" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" class="style8" colspan="3">
                                        <asp:Label ID="Label175" runat="server" style="font-weight: 700" Text="SUMMARY"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1179px">
                                            <telerik:RadGrid ID="GD_SUMM_STATUS" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                      
                                                        <telerik:GridBoundColumn DataField="Committal_Status" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Committal_Status" 
                                                            SortExpression="Committal_Status" UniqueName="Committal_Status">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Cnt_Committal" 
                                                            FilterControlAltText="Filter Cnt_Committal column" HeaderText="Cnt_Committal" 
                                                            SortExpression="Cnt_Committal" UniqueName="Cnt_Committal">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Premium_Amt"  DataFormatString="{0:###,###.##}" 
                                                            FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                            SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Paid_Amt"  DataFormatString="{0:###,###.##}" 
                                                            FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                            SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OS_Bal_Amt"  DataFormatString="{0:###,###.##}" 
                                                            FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                            SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Label ID="Label176" runat="server" style="font-weight: 700" 
                                            Text="ACCOUNTS ON NOTICE"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1169px">
                                            <telerik:RadGrid ID="GD_DUE" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                            FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                            SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Premium_Amt"  DataFormatString="{0:###,###.##}" 
                                                            FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                            SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Paid_Amt"  DataFormatString="{0:###,###.##}" 
                                                            FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                            SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OS_Bal_Amt"  DataFormatString="{0:###,###.##}" 
                                                            FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                            SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Credit_Period" 
                                                            FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                            SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                            SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                            SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="Notice_Date" DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter Notice_Date column" HeaderText="Notice_Due_Dt" 
                                                            SortExpression="Notice_Date" UniqueName="Notice_Date">
                                                        </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Requested_by" 
                                                            FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                            SortExpression="Requested_by" UniqueName="Requested_by">
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Committal_Status" 
                                                            FilterControlAltText="Filter Committal_Status column" HeaderText="Status" 
                                                            SortExpression="Committal_Status" UniqueName="Committal_Status">
                                                        </telerik:GridBoundColumn>
                                                              <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>

                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Label ID="LBLFAMNO" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="0" Skin="Office2007">
                                            <Tabs>
                                                <telerik:RadTab runat="server" PageViewID="V1" Text="Data Mapping" 
                                                    Selected="True">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V2" Text="Within Period">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V3" 
                                                    Text="Past Due">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V4" 
                                                    Text="In Arrears">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V5" Text="Suspended">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V7" Text="Terminated">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V8" Text="Closed">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V6" Text="DashBoard">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="30px">
                                            <telerik:RadPageView ID="V2" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel1" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label144" runat="server" Text="WITHIN PERIOD" 
                                                                    style="font-weight: 700"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel26" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_WITHIN" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                    Text="Select" UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="Ref_No" 
                                                                                    FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                                    SortExpression="Ref_No" UniqueName="Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                                    FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                                    SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                                    SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                                    SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                       <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Requested_by" 
                                                                                    FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                                    SortExpression="Requested_by" UniqueName="Requested_by">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                                                  <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V1" runat="server" Width="1151px" Selected="True">
                                                <asp:Panel ID="Panel2" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="5">
                                                                <asp:Label ID="Label174" runat="server" style="font-weight: 700" 
                                                                    Text="Data Update"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="5">
                                                                <asp:Panel ID="Panel30" runat="server" Height="100%" Width="1181px" 
                                                                    BorderStyle="Solid" BorderWidth="1px">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="width: 498px">
                                                                            </td>
                                                                            <td style="width: 131px">
                                                                                <asp:Label ID="Label171" runat="server" style="font-weight: 700" 
                                                                                    Text="Corporate  name"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 273px">
                                                                                &nbsp;<telerik:RadTextBox ID="TXTSEARCH" Runat="server" Skin="Outlook" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                                                    Width="157px">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="5">
                                                                <asp:Panel ID="Panel27" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_ENR" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                    Text="Select" UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="Ref_No" 
                                                                                    FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                                    SortExpression="Ref_No" UniqueName="Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                                    FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                                    SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                                    SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                                    SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                      <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Requested_by" 
                                                                                    FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                                    SortExpression="Requested_by" UniqueName="Requested_by">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                                                  <telerik:GridBoundColumn DataField="committal_status" 
                                                                                    FilterControlAltText="Filter committal_status column" HeaderText="Status" 
                                                                                    SortExpression="committal_status" UniqueName="committal_status">
                                                                                </telerik:GridBoundColumn>
                                                                                  <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>
                                                                             
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="Label161" runat="server" Text="Effective Date"></asp:Label>
                                                            </td>
                                                            <td class="style17" style="width: 277px">
                                                                <telerik:RadDatePicker ID="DtEff" Runat="server" Skin="Simple">
                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                    </Calendar>
                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                    </DateInput>
                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                </telerik:RadDatePicker>
                                                            </td>
                                                            <td style="width: 109px">
                                                                &nbsp;</td>
                                                            <td style="width: 136px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="Label153" runat="server" Text="Proposer Name"></asp:Label>
                                                            </td>
                                                            <td class="style17" style="width: 277px">
                                                                <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Simple" Width="250px">
                                                                </telerik:RadTextBox>
                                                            </td>
                                                            <td>
                                                                <asp:Label ID="Label165" runat="server" Text=" "></asp:Label>
                                                                <asp:Label ID="Label166" runat="server" Text="Invoice No"></asp:Label>
                                                            </td>
                                                            <td>
                                                                <telerik:RadTextBox ID="txtinvoice" Runat="server" Skin="Simple" Width="250px">
                                                                </telerik:RadTextBox>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px; height: 26px">
                                                                <asp:Label ID="Label154" runat="server" Text="Premium Amount"></asp:Label>
                                                            </td>
                                                            <td class="style17" style="width: 277px">
                                                                <telerik:RadNumericTextBox ID="txtprem" Runat="server" Culture="en-US" 
                                                                    Skin="Simple" Value="0" Width="125px">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td style="height: 26px; width: 109px">
                                                                &nbsp;</td>
                                                            <td style="height: 26px; width: 136px">
                                                                &nbsp;</td>
                                                            <td style="height: 26px">
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="Label155" runat="server" Text="Paid Amount"></asp:Label>
                                                            </td>
                                                            <td class="style17" style="width: 277px">
                                                                <telerik:RadNumericTextBox ID="txtcomm" Runat="server" Culture="en-US" 
                                                                    Skin="Simple" Value="0" Width="125px">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td style="width: 109px">
                                                                &nbsp;</td>
                                                            <td style="width: 136px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="Label158" runat="server" Text="Credit Period"></asp:Label>
                                                            </td>
                                                            <td class="style17" style="width: 277px">
                                                                <telerik:RadNumericTextBox ID="txtcredit" Runat="server" AutoPostBack="True" 
                                                                    Culture="en-US" DataType="System.Int16" Skin="Simple" Value="0" Width="125px">
                                                                    <NumberFormat DecimalDigits="0" />
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td style="width: 109px">
                                                                <asp:Label ID="Label164" runat="server" Text="Due date"></asp:Label>
                                                            </td>
                                                            <td style="width: 136px">
                                                                <telerik:RadDatePicker ID="DtDue" Runat="server" Skin="Simple" 
                                                                    AutoPostBack="True">
                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                    </Calendar>
                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                        AutoPostBack="True">
                                                                    </DateInput>
                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                </telerik:RadDatePicker>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="Label196" runat="server" style="font-weight: 700" Text="Notes"></asp:Label>
                                                            </td>
                                                            <td class="style17" rowspan="3" style="width: 277px">
                                                                <telerik:RadTextBox ID="txtnotesenr" Runat="server" Height="70px" Rows="1" 
                                                                    Skin="Simple" TextMode="MultiLine" Width="400px">
                                                                </telerik:RadTextBox>
                                                            </td>
                                                            <td style="width: 109px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 109px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 109px">
                                                                <telerik:RadButton ID="btnsave" runat="server" Skin="Simple" Text="Save " 
                                                                    Width="150px">
                                                                </telerik:RadButton>
                                                            </td>
                                                            <td>
                                                                <telerik:RadButton ID="btnedit" runat="server" Skin="Simple" Text="Edit" 
                                                                    Width="150px">
                                                                </telerik:RadButton>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="5">
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V3" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel23" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label168" runat="server" style="font-weight: 700" 
                                                                    Text="PAST DUE"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel28" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_PAST" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                    Text="Select" UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="Ref_No" 
                                                                                    FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                                    SortExpression="Ref_No" UniqueName="Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name" ItemStyle-Wrap="false">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt" DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                                    FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                                    SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                                    SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                                    SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                                </telerik:GridBoundColumn>

                                                                                             <telerik:GridBoundColumn DataField="Notice_Date" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Notice_Date column" HeaderText="Notice_Due_Dt" 
                                                                                    SortExpression="Notice_Date" UniqueName="Notice_Date">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Requested_by" 
                                                                                    FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                                    SortExpression="Requested_by" UniqueName="Requested_by">
                                                                                </telerik:GridBoundColumn>
                                                                             <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="On_Notice" 
                                                                                    FilterControlAltText="Filter On_Notice column" HeaderText="On_Notice" 
                                                                                    SortExpression="On_Notice" UniqueName="On_Notice">
                                                                                </telerik:GridBoundColumn>
                                                                                      <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <EditItemStyle Wrap="False" />
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel37" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label179" runat="server" Text="Effective Date"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 198px">
                                                                                <telerik:RadDatePicker ID="DtEff_1" Runat="server" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                <asp:Label ID="Label181" runat="server" Text="Due Date"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                <telerik:RadDatePicker ID="Dtdue_1" Runat="server" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                <asp:Label ID="lblproposer" runat="server" style="font-weight: 700"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label180" runat="server" Text="Proposer Name"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txtproposer_1" Runat="server" Skin="Simple" 
                                                                                    Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                <asp:Label ID="Label182" runat="server" Text="Physical Address"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txtaddress_1" Runat="server" Skin="Simple" 
                                                                                    Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label184" runat="server" Text="Town/City"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txttown_1" Runat="server" Skin="Simple" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                <asp:Label ID="Label185" runat="server" Text="Balance O/s"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                <telerik:RadNumericTextBox ID="txtBal_1" Runat="server" Culture="en-US" 
                                                                                    Skin="Simple" Value="0" Width="125px">
                                                                                </telerik:RadNumericTextBox>
                                                                            </td>
                                                                            <td>
                                                                                <asp:Label ID="Label186" runat="server" Text="Susp date"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadDatePicker ID="DtSusp" Runat="server" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:CheckBox ID="chknotice" runat="server" style="font-weight: 700" 
                                                                                    Text="Suspension Letter" />
                                                                            </td>
                                                                            <td style="width: 198px">
                                                                                <telerik:RadButton ID="RadButton8" runat="server" Skin="Simple" 
                                                                                    Text="Generate Letter">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="6">
                                                                                <hr />
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 198px">
                                                                                <asp:CheckBox ID="chksusp" runat="server" Text="Suspend Account" />
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                &nbsp;</td>
                                                                            <td colspan="2" rowspan="3">
                                                                                <telerik:RadTextBox ID="txtnotespast" Runat="server" Height="70px" Rows="1" 
                                                                                    Skin="Simple" TextMode="MultiLine" Width="400px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label172" runat="server" style="font-weight: 700" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 234px">
                                                                                <telerik:RadButton ID="RadButton7" runat="server" Skin="Simple" Text="Save " 
                                                                                    Width="150px">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                                <telerik:RadPageView ID="V4" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel3" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label1" runat="server" style="font-weight: 700" 
                                                                    Text="ARREARS"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel39" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_ARREARS" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                    Text="Select" UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="Ref_No" 
                                                                                    FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                                    SortExpression="Ref_No" UniqueName="Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt" DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                                    FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                                    SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                                    SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                                    SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Notice_Date" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Notice_Date column" HeaderText="Notice_Due_Dt" 
                                                                                    SortExpression="Notice_Date" UniqueName="Notice_Date">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Requested_by" 
                                                                                    FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                                    SortExpression="Requested_by" UniqueName="Requested_by">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="On_Notice" 
                                                                                    FilterControlAltText="Filter On_Notice column" HeaderText="On_Notice" 
                                                                                    SortExpression="On_Notice" UniqueName="On_Notice">
                                                                                </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="On_Demand" 
                                                                                    FilterControlAltText="Filter On_Demand column" HeaderText="On_Demand" 
                                                                                    SortExpression="On_Demand" UniqueName="On_Demand">
                                                                                </telerik:GridBoundColumn>
                                                                                     <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel38" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label187" runat="server" Text="Effective Date"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 198px">
                                                                                <telerik:RadDatePicker ID="DtEff_2" Runat="server" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                <asp:Label ID="Label188" runat="server" Text="Due Date"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                <telerik:RadDatePicker ID="Dtdue_2" Runat="server" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                <asp:Label ID="lblproposer0" runat="server" style="font-weight: 700"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label189" runat="server" Text="Proposer Name"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txtproposer_2" Runat="server" Skin="Simple" 
                                                                                    Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                <asp:Label ID="Label190" runat="server" Text="Physical Address"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txtaddress_2" Runat="server" Skin="Simple" 
                                                                                    Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label192" runat="server" Text="Town/City"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadTextBox ID="txttown_2" Runat="server" Skin="Simple" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                <asp:Label ID="Label193" runat="server" Text="Balance O/s"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                <telerik:RadNumericTextBox ID="txtBal_2" Runat="server" Culture="en-US" 
                                                                                    Skin="Simple" Value="0" Width="125px">
                                                                                </telerik:RadNumericTextBox>
                                                                            </td>
                                                                            <td>
                                                                                <asp:Label ID="Label194" runat="server" Text="Term date"></asp:Label>
                                                                            </td>
                                                                            <td>
                                                                                <telerik:RadDatePicker ID="DtTerm" Runat="server" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:CheckBox ID="chkterminate" runat="server" style="font-weight: 700" 
                                                                                    Text="Demand Letter" />
                                                                            </td>
                                                                            <td style="width: 198px">
                                                                                <telerik:RadButton ID="RadButton9" runat="server" Skin="Simple" 
                                                                                    Text="Generate Letter">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="6">
                                                                                <hr />
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 198px">
                                                                                <asp:CheckBox ID="chkterm" runat="server" Text="Terminate Account" />
                                                                            </td>
                                                                            <td style="width: 123px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                &nbsp;</td>
                                                                            <td colspan="2" rowspan="3">
                                                                                <telerik:RadTextBox ID="txtnotesterm" Runat="server" Height="70px" Rows="1" 
                                                                                    Skin="Simple" TextMode="MultiLine" Width="400px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                <asp:Label ID="Label195" runat="server" style="font-weight: 700" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 234px">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 179px">
                                                                                &nbsp;</td>
                                                                            <td style="width: 234px">
                                                                                <telerik:RadButton ID="RadButton11" runat="server" Skin="Simple" Text="Save " 
                                                                                    Width="150px">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                              <telerik:RadPageView ID="V5" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel5" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label3" runat="server" style="font-weight: 700" 
                                                                    Text="SUSPENDED"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_SUS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                    Text="Select" UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="Ref_No" 
                                                                                    FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                                    SortExpression="Ref_No" UniqueName="Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt" DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                                    FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                                    SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                                    SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                                    SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Requested_by" 
                                                                                    FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                                    SortExpression="Requested_by" UniqueName="Requested_by">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:CheckBox ID="chklift" runat="server" Text="Lift suspension" />
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <telerik:RadTextBox ID="txtnoteslift" Runat="server" Height="70px" Rows="1" 
                                                                    Skin="Simple" TextMode="MultiLine" Width="400px">
                                                                </telerik:RadTextBox>
                                                                <telerik:RadButton ID="RadButton10" runat="server" Skin="Simple" Text="Save " 
                                                                    Width="150px">
                                                                </telerik:RadButton>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                                <telerik:RadPageView ID="V7" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel4" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label4" runat="server" style="font-weight: 700" 
                                                                    Text="TERMINATED"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel8" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_TERM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                    Text="Select" UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="Ref_No" 
                                                                                    FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                                    SortExpression="Ref_No" UniqueName="Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt" DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                                    FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                                    SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                                    SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                                    SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Requested_by" 
                                                                                    FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                                    SortExpression="Requested_by" UniqueName="Requested_by">
                                                                                </telerik:GridBoundColumn>
                                                                           <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                               <telerik:RadPageView ID="V6" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel6" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label2" runat="server" style="font-weight: 700" 
                                                                    Text="DASHBOARD"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel32" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_SUMM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="Mon" 
                                                                                    FilterControlAltText="Filter Mon column" HeaderText="Month" 
                                                                                    SortExpression="Mon" UniqueName="Mon">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Cnt_Committal" 
                                                                                    FilterControlAltText="Filter Cnt_Committal column" HeaderText="Cnt_Committal" 
                                                                                    SortExpression="Cnt_Committal" UniqueName="Cnt_Committal">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt"  DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>

                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                             <telerik:RadPageView ID="V8" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel10" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label5" runat="server" style="font-weight: 700" 
                                                                    Text="CLOSED"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="2">
                                                                <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1169px">
                                                                    <telerik:RadGrid ID="GD_CLOSED" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                    Text="Select" UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="Ref_No" 
                                                                                    FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                                                    SortExpression="Ref_No" UniqueName="Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Premium_Amt column" HeaderText="Premium" 
                                                                                    SortExpression="Premium_Amt" UniqueName="Premium_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt" DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="OS_Bal_Amt" 
                                                                                    DataFormatString="{0:###,###.##}" 
                                                                                    FilterControlAltText="Filter OS_Bal_Amt column" HeaderText="Os/Bal" 
                                                                                    SortExpression="OS_Bal_Amt" UniqueName="OS_Bal_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Credit_Period" 
                                                                                    FilterControlAltText="Filter Credit_Period column" HeaderText="Credit_Period" 
                                                                                    SortExpression="Credit_Period" UniqueName="Credit_Period">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Effective_Dt" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Effective_Dt column" HeaderText="Effective_Dt" 
                                                                                    SortExpression="Effective_Dt" UniqueName="Effective_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Due_Dt" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Dt" 
                                                                                    SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Business" 
                                                                                    FilterControlAltText="Filter Business column" HeaderText="Business" 
                                                                                    SortExpression="Business" UniqueName="Business">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Requested_by" 
                                                                                    FilterControlAltText="Filter Requested_by column" HeaderText="Requested_by" 
                                                                                    SortExpression="Requested_by" UniqueName="Requested_by">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="Committal_Type" 
                                                                            FilterControlAltText="Filter Committal_Type column" HeaderText="Type" 
                                                                            SortExpression="Committal_Type" UniqueName="Committal_Type">
                                                                        </telerik:GridBoundColumn>
                                                                           <telerik:GridBoundColumn DataField="Agent_name" 
                                                                                    FilterControlAltText="Filter Agent_name column" HeaderText="Agent_name" 
                                                                                    SortExpression="Agent_name" UniqueName="Agent_name">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel35" runat="server">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label147" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel36" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1125px">
                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                            SortExpression="DOC_ID">
                                                                            <ItemTemplate>
                                                                                <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                    CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                            </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                            ScrollBars="Horizontal" Width="1071px">
                                                            <asp:Literal ID="ltEmbed" runat="server" />
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="height: 17px;">
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Note_From" UniqueName="Note_From">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        &nbsp;&nbsp;&nbsp;<asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel20" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="99px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#999999" colspan="4">
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Report Extract"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; height: 37px;">
                                                        <asp:Label ID="Label152" runat="server" Font-Bold="True" Text="Report name"></asp:Label>
                                                    </td>
                                                    <td style="width: 168px; height: 37px;">
                                                        <telerik:RadComboBox ID="cboreport" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreport" Text="WITHIN_PERIOD" 
                                                                    Value="W" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreport" Text="PAST_DUE" 
                                                                    Value="P" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreport" Text="IN_ARREARS" 
                                                                    Value="I" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreport" Text="CLOSED" 
                                                                    Value="C" />
                                                                <telerik:RadComboBoxItem runat="server" Text="ALL RECORDS" Value="A" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="height: 37px">
                                                    </td>
                                                    <td style="height: 37px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px">
                                                        &nbsp;</td>
                                                    <td colspan="2">
                                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="export" 
                                                            Width="200px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>

