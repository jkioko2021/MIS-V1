﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                dtadmin.DbSelectedDate = Date.Now()
                HiddenField1.Value = 0
                dtrec.DbSelectedDate = Date.Now
                'dtresp.DbSelectedDate = Date.Now
                Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME]  FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST ORDER BY ORG_NAME" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboProvi
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                    .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                    .DataBind()
                End With
                Str = "SELECT [Reason_Code],[Reason]  FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM_REASON] WHERE IS_ACTIVE=1" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboReason
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Reason").ToString
                    .DataValueField = MyDatatable.Columns("Reason_Code").ToString
                    .DataBind()
                End With
                Me.Str = "SELECT [CODE],[BENEFIT]  FROM [CRM].[dbo].[TBL_MIS_OFF_SYSTEM_BENEFITS] WHERE ACTIVE=1"
                Me.MyDatatable = TryCast(Me.MyDBAction.DBAction(Me.Str, DataManagement.DBActionType.DataTable, "", Nothing), DataTable)
                Dim cbobenefittype As RadComboBox = Me.cbobenefittype
                cbobenefittype.Items.Clear()
                cbobenefittype.DataSource = Me.MyDatatable
                cbobenefittype.DataTextField = Me.MyDatatable.Columns("BENEFIT").ToString()
                cbobenefittype.DataValueField = Me.MyDatatable.Columns("CODE").ToString()
                cbobenefittype.DataBind()
                LoadGrid()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub

    Public Sub Generate_REF()
        SqlAction = "SELECT ISNULL((MAX(Id)+1),1) NUMBER FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblcode.Text = cboclaimtype.SelectedValue & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub

    Public Sub LoadGrid()
        SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 and Is_Active=1 AND Entered_By='" & Session("username") & "' order by Ref_No desc"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub
    Protected Sub GDMEMBER_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDMEMBER.PageIndexChanged
        GDMEMBER.CurrentPageIndex = e.NewPageIndex
        GDMEMBER.DataSource = Session("MEM_01")
        GDMEMBER.DataBind()
    End Sub
    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim new_mem As Integer = 0
            If txtname.Text = "" Then
                lblerr.Text = "Enter member name!"
                Exit Sub
            End If
            If txtmemno.Text = "" And chknew.Checked = False Then
                lblerr.Text = "Enter member Number!"
                Exit Sub
            End If
            If txtprop.Text = "" And chknew.Checked = False Then
                lblerr.Text = "Enter Scheme Name!"
                Exit Sub
            End If
            If chknew.Checked = True Then
                new_mem = 1
            Else
                new_mem = 0
            End If
            If cboProvi.SelectedValue = "" Then
                lblerr.Text = "Select provider!"
                Exit Sub
            End If
            If cboReason.SelectedValue = "" Then
                lblerr.Text = "Select Reason!"
                Exit Sub
            End If
            If cboclaimtype.SelectedValue = "" Then
                lblerr.Text = "Select Claim provider type!"
                Exit Sub
            End If
            If txtnotes.Text = "" Then
                lblerr.Text = "Enter short Notes!"
                Exit Sub
            End If
            If HiddenField1.Value = 0 Then
                Generate_REF()
                MyDBAction.Off_system_Tracking(lblcode.Text, txtmobile.Text, Trim(txtmemno.Text), Trim(txtname.Text), Trim(txtprop.Text), cboProvi.SelectedValue, CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cboReason.SelectedValue, cboclaimtype.SelectedValue, Session("UserName").ToString, 0, new_mem, CDate(dtrec.DbSelectedDate).ToString("yyyy-MM-dd hh:mm"), CDate(Date.Now).ToString("yyyy-MM-dd hh:mm"), Trim(txtmis.Text), cbobenefittype.SelectedValue) '
            Else
                MyDBAction.Off_system_Tracking(lblcode.Text, txtmobile.Text, txtmemno.Text, txtname.Text, txtprop.Text, cboProvi.SelectedValue, CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cboReason.SelectedValue, cboclaimtype.SelectedValue, Session("UserName").ToString, 1, new_mem, CDate(dtrec.DbSelectedDate).ToString("yyyy-MM-dd hh:mm"), CDate(Date.Now).ToString("yyyy-MM-dd hh:mm"), Trim(txtmis.Text), cbobenefittype.SelectedValue)
            End If
            If txtnotes.Text <> "" Then
                MyDBAction.TRACKING_OFF_SYSTEM_MESSAGES(lblcode.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd hh:mm"), txtnotes.Text)
            End If
            LoadGrid()
            txtmemno.Text = ""
            txtname.Text = ""
            txtprop.Text = ""
            chknew.Text = ""
            cboProvi.Text = ""
            txtmis.Text = ""
            chknew.Checked = False
            txtmobile.Text = 0
            txtnotes.Text = ""
            cboReason.SelectedValue = ""
            cboclaimtype.SelectedValue = ""
            lblerr.Text = "Saved Successfull"
            dtrec.DbSelectedDate = Date.Now
            GDPROV.DataSource = Nothing
            GDPROV.DataBind()
            txtprov.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdnew_Click(sender As Object, e As System.EventArgs) Handles cmdnew.Click
        HiddenField1.Value = 0
        lblcode.Text = ""
        txtmemno.Text = ""
        txtname.Text = ""
        txtprop.Text = ""
        txtmis.Text = ""
        chknew.Text = ""
        txtmobile.Text = ""
        cboProvi.Text = ""
        cboReason.SelectedValue = ""
        cboclaimtype.SelectedValue = ""
        lblerr.Text = ""
        lblcode.Enabled = True
        txtmemno.Enabled = True
        txtname.Enabled = True
        txtprop.Enabled = True
        cboProvi.Enabled = True
        cboReason.Enabled = True
        cboclaimtype.Enabled = True
        txtmobile.Enabled = True
        chknew.Enabled = True
        dtrec.DbSelectedDate = Date.Now
    End Sub

    Protected Sub cmdedit_Click(sender As Object, e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        lblcode.Enabled = True
        txtmemno.Enabled = True
        txtname.Enabled = True
        txtprop.Enabled = True
        cboProvi.Enabled = True
        cboReason.Enabled = True
        cboclaimtype.Enabled = True
        chknew.Enabled = True
        txtmobile.Enabled = True
    End Sub

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            HiddenField1.Value = 1
            Dim code As Integer = 0
            lblcode.Text = ""
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()
            'code = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("Id").ToString()
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],Mobile_no,New_Member,MIS_No,[Member_Name],[Proposer_Name],[Provider_ID],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Id]='" & code & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                lblcode.Text = MyDatatable.Rows(0).Item("Ref_No").ToString()
                txtmobile.Text = MyDatatable.Rows(0).Item("Mobile_no").ToString()
                txtmemno.Text = MyDatatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatatable.Rows(0).Item("Proposer_Name").ToString()
                cboProvi.SelectedValue = MyDatatable.Rows(0).Item("Provider_ID").ToString()
                cboReason.SelectedValue = MyDatatable.Rows(0).Item("Reason").ToString()
                cboclaimtype.SelectedValue = MyDatatable.Rows(0).Item("Off_Type").ToString()
                dtadmin.DbSelectedDate = MyDatatable.Rows(0).Item("Service_Dt").ToString()
                chknew.Checked = MyDatatable.Rows(0).Item("New_Member").ToString()
                txtmis.Text = MyDatatable.Rows(0).Item("MIS_No").ToString()
                SqlAction = "SELECT [Note_id],[Ref_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM_NOTES] WHERE  Ref_No ='" & lblcode.Text & "' ORDER BY  Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = Nothing
                    GDNOTES.DataBind()
                End If
            End If

            lblcode.Enabled = False
            txtmemno.Enabled = False
            txtname.Enabled = False
            txtprop.Enabled = False
            cboProvi.Enabled = False
            cboReason.Enabled = False
            cboclaimtype.Enabled = False
            txtmobile.Text = False
            chknew.Enabled = False
            dtrec.DbSelectedDate = Date.Now
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        If cbosearch.SelectedValue = "M" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 AND Member_No LIKE '%" & txtsearch.Text & "%' and Is_Active=1"
        ElseIf cbosearch.SelectedValue = "N" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 AND Member_Name LIKE '%" & txtsearch.Text & "%' and Is_Active=1"
        ElseIf cbosearch.SelectedValue = "R" Then
            SqlAction = "SELECT [Id],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason],[Off_Type],[Entered_By],[Inv_Status]  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System] WHERE [Submitted]=0 AND Ref_No LIKE '%" & txtsearch.Text & "%' and Is_Active=1"
        End If
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDMEMBER.DataSource = MyDatable
            GDMEMBER.DataBind()
            Session("MEM_01") = MyDatable
            MyDatable = Nothing
        Else
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
        End If
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)
        'ShowGridDetails()
    End Sub
    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDMEMBER.DeleteCommand
        Try
            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("Id").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_CRM_OFF_SYSTEM] SET Is_Active=0  WHERE Id='" & HiddenField1.Value.ToString & "' and Entered_By='" & Session("username") & "'")
            'DeleteRecord("DELETE FROM TBL_MIS_CRM_DOCS WHERE  File_No='" & HiddenField1.Value.ToString & "'")
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Off System Tracking Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
            Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""
            HiddenField1.Value = ""
            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False
            LoadGrid()
        Catch ex As Exception
            Dim ErrMsg As String = ex.Message
        End Try
    End Sub

    Protected Sub btnprov_Click(sender As Object, e As System.EventArgs) Handles btnprov.Click
        GDPROV.DataSource = Nothing
        GDPROV.DataBind()
        Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME]  FROM DATA_REPOSITORY_DB.dbo.MASTER_PROVIDER_LIST where ORG_NAME LIKE '%" & Trim(txtprov.Text) & "%'  ORDER BY ORG_NAME" '"
        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
        If MyDatatable.Rows.Count > 0 Then
            GDPROV.DataSource = MyDatatable
            GDPROV.DataBind()
            Session("MEM_P") = MyDatatable
        Else
            GDPROV.DataSource = Nothing
            GDPROV.DataBind()
        End If
    End Sub
    Protected Sub GDPROV_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROV.SelectedIndexChanged
        cboProvi.SelectedValue = (DirectCast(GDPROV.SelectedItems(0), GridDataItem)).GetDataKeyValue("ORG_ID").ToString()
    End Sub
    Protected Sub GDPROV_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDPROV.PageIndexChanged
        GDPROV.CurrentPageIndex = e.NewPageIndex
        GDPROV.DataSource = Session("MEM_P")
        GDPROV.DataBind()
    End Sub
End Class
