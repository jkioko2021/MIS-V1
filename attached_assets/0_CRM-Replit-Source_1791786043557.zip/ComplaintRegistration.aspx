﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="ComplaintRegistration.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="COMPLAINT REGISTER"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 982px">
                                                    &nbsp;</td>
                                                <td style="width: 200px" class="style17">
                                                    <asp:Label ID="Label141" runat="server" Text="Member No"></asp:Label>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" 
                                                        Width="200px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1140px">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                           <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="MEMBERSHIP NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" 
                                                            HeaderText="MEMBER_BIRTH_DATE" SortExpression="MEMBER_BIRTH_DATE" 
                                                            UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                            FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                            SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                            FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                            SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                            FilterControlAltText="Filter POLICY_STATUS column" HeaderText="POLICY_STATUS" 
                                                            SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                            FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA_DATE" 
                                                            SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                                          <table style="width: 100%">
                                              <tr>
                                                  <td style="height: 16px;" align="center" bgcolor="#666666" colspan="5">
                                                      &nbsp;&nbsp;
                                                      <asp:Label ID="Label175" runat="server" Font-Bold="True" ForeColor="White" 
                                                          Text=" Customer Information"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 26px;">
                                                  </td>
                                                  <td style="width: 136px; height: 26px;">
                                                      <asp:Label ID="Label149" runat="server" Text="Receive Date"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 26px;">
                                                      <telerik:RadDateTimePicker ID="dtreceive" Runat="server" Skin="Simple">
                                                          <TimeView CellSpacing="-1">
                                                          </TimeView>
                                                          <TimePopupButton HoverImageUrl="" ImageUrl="" />
                                                          <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                              UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                          </Calendar>
                                                          <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                          </DateInput>
                                                          <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                      </telerik:RadDateTimePicker>
                                                  </td>
                                                  <td style="width: 131px; height: 26px;">
                                                  </td>
                                                  <td style="height: 26px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 22px;">
                                                  </td>
                                                  <td style="width: 136px; height: 22px;">
                                                      <asp:Label ID="Label143" runat="server" Text="Member No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 22px; margin-left: 80px;">
                                                      <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 22px;">
                                                  </td>
                                                  <td style="height: 22px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 23px;">
                                                      </td>
                                                  <td style="width: 136px; height: 23px;">
                                                      <asp:Label ID="Label144" runat="server" Text="Client Name"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 23px; margin-left: 80px;">
                                                      <telerik:RadTextBox ID="txtname" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 23px;">
                                                      </td>
                                                  <td style="height: 23px">
                                                      </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 23px;">
                                                      </td>
                                                  <td style="width: 136px; height: 23px;">
                                                      <asp:Label ID="Label172" runat="server" Text="Client Type"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 23px; margin-left: 80px;">
                                                      <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboclient" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboclient" Text="Corporate" 
                                                                  Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboclient" Text="Retail" 
                                                                  Value="I" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 23px;">
                                                      </td>
                                                  <td style="height: 23px">
                                                      </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 26px;">
                                                      </td>
                                                  <td style="width: 136px; height: 26px;">
                                                      <asp:Label ID="Label165" runat="server" Text="Mobile Number"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 26px; margin-left: 80px;">
                                                      <telerik:RadTextBox ID="txtmobile" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 26px;">
                                                      </td>
                                                  <td style="height: 26px">
                                                      </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 29px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 29px;">
                                                      <asp:Label ID="Label166" runat="server" Text="Email Address"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 29px; margin-left: 80px;">
                                                      <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 29px;">
                                                      &nbsp;</td>
                                                  <td style="height: 29px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="height: 13px;" align="center" bgcolor="#666666" colspan="5">
                                                      <asp:Label ID="Label176" runat="server" Font-Bold="True" ForeColor="White" 
                                                          Text="Complaint Details"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 23px;">
                                                      </td>
                                                  <td style="width: 136px; height: 23px;">
                                                      <asp:Label ID="Label171" runat="server" Text="Type of Query"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 23px; margin-left: 80px;">
                                                      <telerik:RadComboBox ID="cbotype" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Complain" 
                                                                  Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Enquiry" 
                                                                  Value="E" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Feedback" 
                                                                  Value="F" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 23px;">
                                                      </td>
                                                  <td style="height: 23px">
                                                      </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 21px;">
                                                      </td>
                                                  <td style="width: 136px; height: 21px;">
                                                      <asp:Label ID="Label164" runat="server" Text="Mode of Receipt"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 21px;">
                                                      <telerik:RadComboBox ID="cbomode" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Call" Value="Call" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Email" Value="Email" />
                                                              <telerik:RadComboBoxItem runat="server" Text="On_line_Chat" 
                                                                  Value="On_line_Chat" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Walk-In" Value="Walk-In" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Twitter" Value="Twitter" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Facebook" Value="Facebook" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Whatsup" Value="Whatsup" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Online" Value="Online" />
                                                              <telerik:RadComboBoxItem runat="server" Text="IG" Value="IG" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Survey" Value="Survey" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 21px;">
                                                      </td>
                                                  <td style="height: 21px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 28px;">
                                                      <asp:Label ID="Label178" runat="server" Text="Department"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 28px;">
                                                      <telerik:RadComboBox ID="cbodepart" Runat="server" AllowCustomText="True" 
                                                          AutoPostBack="True" MarkFirstMatch="True" Skin="Outlook" Width="264px">
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 28px;">
                                                      <asp:Label ID="Label167" runat="server" Text="Issue Summary"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 28px;">
                                                      <telerik:RadComboBox ID="cbissue" Runat="server" AllowCustomText="True" 
                                                          EnableOverlay="False" Height="400px" MarkFirstMatch="True" MaxHeight="400px" 
                                                          Skin="Outlook" Width="300px">
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 28px;">
                                                  </td>
                                                  <td style="height: 28px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 28px;">
                                                      <asp:Label ID="Label156" runat="server" Text="Issue Description"></asp:Label>
                                                  </td>
                                                  <td colspan="2" rowspan="2">
                                                      <telerik:RadTextBox ID="txtdescr" Runat="server" Font-Size="Large" 
                                                          Height="50px" Rows="3" Skin="Outlook" style="font-size: medium" 
                                                          TextMode="MultiLine" Width="400px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 24px;">
                                                      <asp:Label ID="Label169" runat="server" Text="Action Taken"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 24px;">
                                                      <telerik:RadComboBox ID="cboaction" Runat="server" 
                                                          Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboaction" Text="In_Progress" 
                                                                  Value="In_Progress" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboaction" Text="Noted" 
                                                                  Value="Noted" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Escalated" Value="Escalated" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Resolved" Value="Resolved" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="height: 24px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 272px; height: 24px;">
                                                      <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                                  <td style="width: 131px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="height: 24px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#666666" colspan="5" style="height: 24px;">
                                                      <asp:Label ID="Label177" runat="server" Font-Bold="True" ForeColor="White" 
                                                          Text="Documentation"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 33px;">
                                                  </td>
                                                  <td style="width: 136px; height: 33px;">
                                                      <asp:Label ID="Label146" runat="server" Text="Document upload"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 33px;">
                                                      <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                  </td>
                                                  <td style="width: 131px; height: 33px;">
                                                  </td>
                                                  <td style="height: 33px">
                                                      <asp:Label ID="lblesc" runat="server"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 24px;">
                                                      <asp:Label ID="Label179" runat="server" Text="Short Notes"></asp:Label>
                                                  </td>
                                                  <td rowspan="2">
                                                      <telerik:RadTextBox ID="txtcomment" Runat="server" Font-Size="Large" 
                                                          Height="50px" Rows="3" Skin="Outlook" style="font-size: medium" 
                                                          TextMode="MultiLine" Width="300px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="height: 24px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 131px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="height: 24px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 136px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 272px; height: 24px;">
                                                      <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" 
                                                          Text="Register Complain" Width="150px">
                                                      </telerik:RadButton>
                                                      &nbsp;
                                                      </td>
                                                  <td style="height: 24px;" colspan="2">
                                                      <asp:Label ID="lblerr" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left">
                                        <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1140px">
                                            <telerik:RadGrid ID="GDCOMPL" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" 
                                                    DataKeyNames="Case_no">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Case_no" 
                                                            FilterControlAltText="Filter Case_no column" 
                                                            HeaderText="Case_no" SortExpression="Case_no" 
                                                            UniqueName="Case_no">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Date_Received" 
                                                            FilterControlAltText="Filter Date_Received column" HeaderText="Date_Received" 
                                                            SortExpression="Date_Received" UniqueName="Date_Received">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Mode_of_Receipt"   DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter Mode_of_Receipt column" HeaderText="Mode_of_Receipt" 
                                                            SortExpression="Mode_of_Receipt" UniqueName="Mode_of_Receipt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Membership_No" 
                                                            FilterControlAltText="Filter Membership_No column" HeaderText="Membership_No" 
                                                            SortExpression="Membership_No" 
                                                            UniqueName="Membership_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Issue_Name" 
                                                            FilterControlAltText="Filter Issue_Name column" HeaderText="Complain" 
                                                            SortExpression="Issue_Name" UniqueName="Issue_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Action_Taken"                                                          
                                                            FilterControlAltText="Filter Action_Taken column" 
                                                            HeaderText="Action" SortExpression="Action_Taken" 
                                                            UniqueName="Action_Taken">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Customer_Name" 
                                                            FilterControlAltText="Filter Customer_Name column" HeaderText="Customer_Name" 
                                                            SortExpression="Customer_Name" UniqueName="Customer_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Contacts" 
                                                            FilterControlAltText="Filter Contacts column" HeaderText="Contacts" 
                                                            SortExpression="Contacts" UniqueName="Contacts">
                                                        </telerik:GridBoundColumn>
                                                   <telerik:GridBoundColumn DataField="Entered_By" 
                                                            FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                            SortExpression="Entered_By" UniqueName="Entered_By">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Escalated_To" 
                                                            FilterControlAltText="Filter Escalated_To column" HeaderText="Escalated_To" 
                                                            SortExpression="Escalated_To" UniqueName="Escalated_To">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Due_Dt" 
                                                            FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Date" 
                                                            SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" bgcolor="#666666">
                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" Text="Notes" 
                                            ForeColor="White"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666" class="style8">
                                        <asp:Label ID="Label180" runat="server" ForeColor="White" 
                                            style="font-weight: 700" Text="Notes"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1135px">
                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                            ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                            Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                            <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                            <ItemStyle CssClass="ButtonColumn" />
                                                        </telerik:GridButtonColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
             <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
          </Triggers>
            </asp:UpdatePanel>
</asp:Content>

