﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Mtiba_Data_Push.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1200px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1200px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="MTIBA DATA PUSH LOGS" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td>
                                                    <asp:Panel ID="Panel31" runat="server" Height="64px">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 145px">
                                                                    <asp:Label ID="Label159" runat="server" style="font-weight: 700" 
                                                                        Text="Entry Date From"></asp:Label>
                                                                </td>
                                                                <td style="width: 166px">
                                                                    <telerik:RadDatePicker ID="dtDateFrom_1" Runat="server" Culture="en-US" 
                                                                        Skin="Web20">
                                                                        <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                        </Calendar>
                                                                        <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                                        </DateInput>
                                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                    </telerik:RadDatePicker>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 145px; height: 30px;">
                                                                    <asp:Label ID="Label160" runat="server" style="font-weight: 700" 
                                                                        Text="Entry Date To"></asp:Label>
                                                                </td>
                                                                <td style="width: 166px; height: 30px;">
                                                                    <telerik:RadDatePicker ID="dtDateTo_1" Runat="server" Culture="en-US" 
                                                                        Skin="Web20">
                                                                        <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                        </Calendar>
                                                                        <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                                        </DateInput>
                                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                    </telerik:RadDatePicker>
                                                                </td>
                                                                <td style="height: 30px">
                                                                    <telerik:RadButton ID="cmdview_1" runat="server" Skin="Simple" Text="View" 
                                                                        Width="157px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <asp:Panel ID="Panel25" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1171px">
                                                        <telerik:RadGrid ID="GD_SUMM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                            GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                        FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                        SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                        FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                        HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                        UniqueName="CNT_EOX_UPDATED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                        FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                        HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                        UniqueName="CNT_PUSH_SUCCESS">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                        FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                        SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                                        FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA_DATE" 
                                                                        SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <PagerStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <hr />
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td style="width: 141px">
                                                        <asp:Label ID="Label155" runat="server" style="font-weight: 700" 
                                                            Text="Client Type"></asp:Label>
                                                    </td>
                                                    <td style="width: 374px">
                                                        <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Outlook">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="Retail" Value="R" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Corp &amp; SME" Value="C" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Per Member" Value="M" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="height: 37px">
                                                    </td>
                                                    <td style="height: 37px; width: 141px;">
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Proposer  name"></asp:Label>
                                                    </td>
                                                    <td style="height: 37px; width: 374px;">
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" Skin="Outlook" Width="300px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td style="height: 37px">
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1171px">
                                            <telerik:RadGrid ID="GD_SEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_ID" 
                                                            FilterControlAltText="Filter PROPOSER_ID column" HeaderText="PROPOSER_ID" 
                                                            SortExpression="PROPOSER_ID" UniqueName="PROPOSER_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                        <asp:Label ID="LBLPLAN" runat="server" style="font-weight: 700"></asp:Label>
                                        <asp:Label ID="lblPROP" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="3" Skin="Office2007">
                                            <Tabs>
                                                <telerik:RadTab runat="server" PageViewID="V1" Text="Plan">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V2" Text="Category">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V3" 
                                                    Text="Policy">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V4" 
                                                    Selected="True" Text="Proposer">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V5" 
                                                    Text="New Policy">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V6" Text="Renew Policy">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V7" Text="Endorsement">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server">
                                            <telerik:RadPageView ID="V1" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel23" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="3">
                                                                <asp:Label ID="Label144" runat="server" Font-Bold="True" Text="PLAN DETAILS"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="3">
                                                                <asp:Panel ID="Panel26" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_SUMM_PLAN" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                                    FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                                    HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                                    UniqueName="CNT_EOX_UPDATED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                                    FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                                    HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                                    UniqueName="CNT_PUSH_SUCCESS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                                    FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                                    SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                                </telerik:GridBoundColumn>
                                                                             
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_PLAN" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="PLAN_NAME" 
                                                                                    FilterControlAltText="Filter PLAN_NAME column" HeaderText="PLAN_NAME" 
                                                                                    SortExpression="PLAN_NAME" UniqueName="PLAN_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="REMARKS" 
                                                                                    FilterControlAltText="Filter REMARKS column" HeaderText="REMARKS" 
                                                                                    SortExpression="REMARKS" UniqueName="REMARKS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ENTRY_TIME" 
                                                                                    FilterControlAltText="Filter ENTRY_TIME column" HeaderText="ENTRY_TIME" 
                                                                                    SortExpression="ENTRY_TIME" UniqueName="ENTRY_TIME">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="lblid" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                            </td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V2" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel2" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label153" runat="server" style="font-weight: 700" 
                                                                    Text="CATEGORY DETAILS"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel27" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_SUMM_CAT" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                                    FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                                    HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                                    UniqueName="CNT_EOX_UPDATED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                                    FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                                    HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                                    UniqueName="CNT_PUSH_SUCCESS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                                    FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                                    SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel21" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_CAT" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                                    FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                                                    SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="REMARKS" 
                                                                                    FilterControlAltText="Filter REMARKS column" HeaderText="REMARKS" 
                                                                                    SortExpression="REMARKS" UniqueName="REMARKS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ENTRY_TIME" 
                                                                                    FilterControlAltText="Filter ENTRY_TIME column" HeaderText="ENTRY_TIME" 
                                                                                    SortExpression="ENTRY_TIME" UniqueName="ENTRY_TIME">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V3" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel5" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label154" runat="server" style="font-weight: 700" 
                                                                    Text="POLICY DETAILS"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel28" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_SUMM_POL" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                                    FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                                    HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                                    UniqueName="CNT_EOX_UPDATED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                                    FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                                    HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                                    UniqueName="CNT_PUSH_SUCCESS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                                    FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                                    SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_POL" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="30" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                    UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="PLAN_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                                    FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                                                    SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CLAUSE_CODE_DEP" 
                                                                                    FilterControlAltText="Filter CLAUSE_CODE_DEP column" 
                                                                                    HeaderText="CLAUSE_CODE_DEP" SortExpression="CLAUSE_CODE_DEP" 
                                                                                    UniqueName="CLAUSE_CODE_DEP">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="REMARKS" 
                                                                                    FilterControlAltText="Filter REMARKS column" HeaderText="REMARKS" 
                                                                                    SortExpression="REMARKS" UniqueName="REMARKS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ENTRY_TIME" 
                                                                                    FilterControlAltText="Filter ENTRY_TIME column" HeaderText="ENTRY_TIME" 
                                                                                    SortExpression="ENTRY_TIME" UniqueName="ENTRY_TIME">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V4" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel4" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label148" runat="server" Font-Bold="True" Text="PROPOSER INFO"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_SUMM_PROP" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                                    FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                                    HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                                    UniqueName="CNT_EOX_UPDATED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                                    FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                                    HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                                    UniqueName="CNT_PUSH_SUCCESS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                                    FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                                    SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel22" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_PROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" 
                                                                          >
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                    FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                    HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                    UniqueName="PROPOSER_DISPLAY_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="REMARKS" 
                                                                                    FilterControlAltText="Filter REMARKS column" HeaderText="REMARKS" 
                                                                                    SortExpression="REMARKS" UniqueName="REMARKS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ENTRY_TIME" 
                                                                                    FilterControlAltText="Filter ENTRY_TIME column" HeaderText="ENTRY_TIME" 
                                                                                    SortExpression="ENTRY_TIME" UniqueName="ENTRY_TIME">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V5" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel24" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label1" runat="server" Font-Bold="True" 
                                                                    Text="NEW POLICY DETAILS"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_SUMM_MEM" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                                    FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                                    HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                                    UniqueName="CNT_EOX_UPDATED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                                    FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                                    HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                                    UniqueName="CNT_PUSH_SUCCESS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                                    FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                                    SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel10" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_MEM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                                    FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                                                    HeaderText="DISPLAY_MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                                                    UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MEMBER_DISPLAY_NAME" 
                                                                                    FilterControlAltText="Filter MEMBER_DISPLAY_NAME column" 
                                                                                    HeaderText="MEMBER_DISPLAY_NAME" SortExpression="MEMBER_DISPLAY_NAME" 
                                                                                    UniqueName="MEMBER_DISPLAY_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="REMARKS" 
                                                                                    FilterControlAltText="Filter REMARKS column" HeaderText="REMARKS" 
                                                                                    SortExpression="REMARKS" UniqueName="REMARKS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ENTRY_TIME" 
                                                                                    FilterControlAltText="Filter ENTRY_TIME column" HeaderText="ENTRY_TIME" 
                                                                                    SortExpression="ENTRY_TIME" UniqueName="ENTRY_TIME">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                              <telerik:RadPageView ID="V6" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel3" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label2" runat="server" Font-Bold="True" 
                                                                    Text="RENEW POLICY DETAILS"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_RENEW" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                                    FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                                    HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                                    UniqueName="CNT_EOX_UPDATED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                                    FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                                    HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                                    UniqueName="CNT_PUSH_SUCCESS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                                    FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                                    SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel9" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_RENEW_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                                    FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                                                    HeaderText="DISPLAY_MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                                                    UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MEMBER_DISPLAY_NAME" 
                                                                                    FilterControlAltText="Filter MEMBER_DISPLAY_NAME column" 
                                                                                    HeaderText="MEMBER_DISPLAY_NAME" SortExpression="MEMBER_DISPLAY_NAME" 
                                                                                    UniqueName="MEMBER_DISPLAY_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="REMARKS" 
                                                                                    FilterControlAltText="Filter REMARKS column" HeaderText="REMARKS" 
                                                                                    SortExpression="REMARKS" UniqueName="REMARKS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ENTRY_TIME" 
                                                                                    FilterControlAltText="Filter ENTRY_TIME column" HeaderText="ENTRY_TIME" 
                                                                                    SortExpression="ENTRY_TIME" UniqueName="ENTRY_TIME">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V7" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel11" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label3" runat="server" Font-Bold="True" 
                                                                    Text="ENDORSEMENT DETAILS"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel14" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_ENDR" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_EOX_UPDATED" 
                                                                                    FilterControlAltText="Filter CNT_EOX_UPDATED column" 
                                                                                    HeaderText="CNT_EOX_UPDATED" SortExpression="CNT_EOX_UPDATED" 
                                                                                    UniqueName="CNT_EOX_UPDATED">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_PUSH_SUCCESS" 
                                                                                    FilterControlAltText="Filter CNT_PUSH_SUCCESS column" 
                                                                                    HeaderText="CNT_PUSH_SUCCESS" SortExpression="CNT_PUSH_SUCCESS" 
                                                                                    UniqueName="CNT_PUSH_SUCCESS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="CNT_FAILED" 
                                                                                    FilterControlAltText="Filter CNT_FAILED column" HeaderText="CNT_FAILED" 
                                                                                    SortExpression="CNT_FAILED" UniqueName="CNT_FAILED">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel16" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_ENDR_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="DATA_TYPE" 
                                                                                    FilterControlAltText="Filter DATA_TYPE column" HeaderText="DATA_TYPE" 
                                                                                    SortExpression="DATA_TYPE" UniqueName="DATA_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                                    FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                                                    HeaderText="DISPLAY_MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                                                    UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MEMBER_DISPLAY_NAME" 
                                                                                    FilterControlAltText="Filter MEMBER_DISPLAY_NAME column" 
                                                                                    HeaderText="MEMBER_DISPLAY_NAME" SortExpression="MEMBER_DISPLAY_NAME" 
                                                                                    UniqueName="MEMBER_DISPLAY_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="REMARKS" 
                                                                                    FilterControlAltText="Filter REMARKS column" HeaderText="REMARKS" 
                                                                                    SortExpression="REMARKS" UniqueName="REMARKS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ENTRY_TIME" 
                                                                                    FilterControlAltText="Filter ENTRY_TIME column" HeaderText="ENTRY_TIME" 
                                                                                    SortExpression="ENTRY_TIME" UniqueName="ENTRY_TIME">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <asp:Panel ID="Panel20" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="104%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#999999" colspan="4">
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Report Extract"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; height: 37px;">
                                                        <asp:Label ID="Label157" runat="server" Font-Bold="True" Text="Update From"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadDatePicker ID="dtDateFrom" Runat="server" Culture="en-US" 
                                                            Skin="Web20">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="height: 37px">
                                                        &nbsp;</td>
                                                    <td style="height: 37px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; height: 37px;">
                                                        <asp:Label ID="Label158" runat="server" Font-Bold="True" Text="Update To"></asp:Label>
                                                    </td>
                                                    <td style="width: 168px; height: 37px;">
                                                        <telerik:RadDatePicker ID="dtDateto" Runat="server" Culture="en-US" 
                                                            Skin="Web20">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td style="height: 37px">
                                                        &nbsp;</td>
                                                    <td style="height: 37px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; height: 37px;">
                                                        <asp:Label ID="Label156" runat="server" Font-Bold="True" Text="Push Type"></asp:Label>
                                                    </td>
                                                    <td style="width: 168px; height: 37px;">
                                                        <telerik:RadComboBox ID="cboreport" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="SUCCESS" Value="S" />
                                                                <telerik:RadComboBoxItem runat="server" Text="FAILED" Value="F" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="height: 37px">
                                                    </td>
                                                    <td style="height: 37px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; height: 37px;">
                                                        <asp:Label ID="Label152" runat="server" Font-Bold="True" Text="Report name"></asp:Label>
                                                    </td>
                                                    <td style="width: 168px; height: 37px;">
                                                        <telerik:RadComboBox ID="cboreport_name" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreport_name" 
                                                                    Text="POLICY DATA" Value="PD" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreport_name" Text="CATEGORY" 
                                                                    Value="CA" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboreport_name" Text="MEMBER" 
                                                                    Value="ME" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="height: 37px">
                                                        &nbsp;</td>
                                                    <td style="height: 37px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px">
                                                        <asp:CheckBox ID="chkall" runat="server" Text="Export All" />
                                                    </td>
                                                    <td colspan="2">
                                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="export" 
                                                            Width="200px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1100px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
       
            </asp:UpdatePanel>
</asp:Content>
