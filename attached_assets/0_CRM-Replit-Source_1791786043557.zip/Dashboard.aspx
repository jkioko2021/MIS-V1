<%@ Page Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false"
    CodeFile="Dashboard.aspx.vb" Inherits="Welcome" Title="Welcome" %>

<%@ Register Assembly="Telerik.Web.UI" Namespace="Telerik.Web.UI" TagPrefix="telerik" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="Telerik.Web.UI" Namespace="Telerik.Charting" TagPrefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div id="maincontainer">
    &nbsp;<table cellpadding="1px" cellspacing="1px" width="100%" style="overflow: hidden; table-layout: fixed; position: relative;">
        <tr>
            <td colspan="2" style="height: 23px">
                <asp:Label ID="Label18" runat="server" Text="DASHBOARD" CssClass="tablestyle" Font-Bold="True"
                    Font-Size="Large"></asp:Label>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <hr style="width: 100%" />
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <asp:Panel ID="Panel4" runat="server" CssClass="box1" 
                    
                    style="background-color:ButtonHighlight; border:0px; padding:3px 5px 2px 5px;" 
                    Width="91%" Height="43px">
                    <table style="width: 100%">
                        <tr>
                            <td style="width: 89px" class="style11">
                                <asp:Label ID="Label19" runat="server" CssClass="tablestyle" Font-Bold="True" 
                                    Font-Size="Large" Text="Year"></asp:Label>
                            </td>
                            <td>
                                <telerik:RadComboBox ID="cboyear" Runat="server" Height="19px" 
                                    style="margin-left: 0px; margin-top: 0px;" AutoPostBack="True">
                                    <Items>
                                        <telerik:RadComboBoxItem runat="server" Text="2019" Value="2019" />
                                        <telerik:RadComboBoxItem runat="server" Text="2020" Value="2020" />
                                        <telerik:RadComboBoxItem runat="server" Text="2021" Value="2021" />
                                    </Items>
                                </telerik:RadComboBox>
                            </td>
                            <td>
                                &nbsp;</td>
                        </tr>
                    </table>
                </asp:Panel>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                    <asp:Label ID="LblErr" runat="server" Text="" ForeColor="Red" Font-Bold="true" 
                        Font-Size="Small"></asp:Label>
            </td>
        </tr>
        <tr>
            <td valign="top" style="height: 334px; width: 1208px;">
                <asp:Panel ID="Panel5" runat="server" Height="100%" ScrollBars="Horizontal" 
                    Style="min-height: 100px; z-index:10000; background-color:#ccc;" 
                    Width="891px">
                <telerik:RadChart ID="RadChart1" runat="server" Skin="DeepBlue" Width="888px" 
                        ScrollBars="Both" 
                        Style="min-height: 100px; z-index:10000; background-color:#ccc;" 
                        AutoTextWrap="True" Legend-Appearance-CompositionType="ColumnTextImage" 
                        DefaultType="Line" Height="315px">
                    <ClientSettings EnableZoom="false" ScrollMode="None" XScale="2" />
                    <Appearance>
                        <FillStyle FillType="ComplexGradient">
                            <FillSettings>
                                <ComplexGradient>
                                    <telerik:GradientElement Color="26, 120, 179" />
                                    <telerik:GradientElement Color="35, 189, 254" Position="0.5" />
                                    <telerik:GradientElement Color="26, 120, 179" Position="1" />
                                </ComplexGradient>
                            </FillSettings>
                        </FillStyle>
                        <Border Color="0, 66, 110" Width="5" />
                    </Appearance>
                    <Series>
                        <telerik:ChartSeries DataYColumn="PERC_PRODUCTION" Name="%" Type="Line">
                            <Appearance>
                                <Border Color="DimGray" />
                                <FillStyle filltype="ComplexGradient" MainColor="213, 247, 255">
                                    <FillSettings>
                                        <ComplexGradient>
                                            <telerik:GradientElement Color="213, 247, 255" />
                                            <telerik:GradientElement Color="193, 239, 252" Position="0.5" />
                                            <telerik:GradientElement Color="157, 217, 238" Position="1" />
                                        </ComplexGradient>
                                    </FillSettings>
                                </FillStyle>
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                                <Border Color="DimGray" />
                            </Appearance>
                        </telerik:ChartSeries>
                    </Series>
                    <Legend>
                        <Appearance Dimensions-Margins="1px, 2%, 12%, 1px">
                            <ItemTextAppearance TextProperties-Color="White">
                            </ItemTextAppearance>
                            <FillStyle GammaCorrection="False" MainColor="37, 255, 255, 255">
                            </FillStyle>
                            <Border Color="76, 255, 255, 255" />
                        </Appearance>
                        <Items>
                            <telerik:LabelItem Name="%">
                                <TextBlock>
                                    <Appearance TextProperties-Color="DimGray">
                                    </Appearance>
                                </TextBlock>
                                <Marker Visible="True">
                                </Marker>
                            </telerik:LabelItem>
                        </Items>
                        <TextBlock>
                            <Appearance Position-AlignedPosition="Top" TextProperties-Color="LightSkyBlue">
                            </Appearance>
                        </TextBlock>
                    </Legend>
                    <PlotArea>
                        <XAxis>
                            <Appearance Color="98, 183, 226" MajorTick-Color="98, 183, 226">
                                <MajorGridLines Color="98, 183, 226" Width="0" />
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                            <AxisLabel>
                                <Appearance Dimensions-Paddings="1px, 1px, 10%, 1px">
                                </Appearance>
                                <TextBlock>
                                    <Appearance AutoTextWrap="True" Dimensions-Width="100" 
                                        TextProperties-Color="LightSkyBlue">
                                    </Appearance>
                                </TextBlock>
                            </AxisLabel>
                        </XAxis>
                        <YAxis>
                            <Appearance Color="98, 183, 226" MajorTick-Color="98, 183, 226" 
                                MinorTick-Color="98, 183, 226">
                                <MajorGridLines Color="120, 209, 248" />
                                <MinorGridLines Color="120, 209, 248" Width="0" />
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                            <AxisLabel>
                                <TextBlock>
                                    <Appearance TextProperties-Color="LightSkyBlue">
                                    </Appearance>
                                </TextBlock>
                            </AxisLabel>
                        </YAxis>
                        <Appearance Dimensions-Margins="19%, 90px, 12%, 9%">
                            <FillStyle MainColor="50, 255, 255, 255" SecondColor="Transparent">
                            </FillStyle>
                            <Border Color="97, 180, 223" />
                        </Appearance>
                    </PlotArea>
                    <ChartTitle>
                        <Appearance Dimensions-Margins="4%, 10px, 14px, 6%">
                            <FillStyle MainColor="">
                            </FillStyle>
                        </Appearance>
                        <TextBlock Text="Overal Production">
                            <Appearance TextProperties-Color="White" TextProperties-Font="Verdana, 14pt">
                            </Appearance>
                        </TextBlock>
                    </ChartTitle>
                </telerik:RadChart>
                </asp:Panel>
            </td>
            <td valign="top" style="height: 334px">
                <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                    
                    Style="min-height: 100px; z-index:10000; background-color:#ccc; margin-left: 182px;" 
                    Width="75%">
                    <telerik:RadGrid ID="GD_N" runat="server" CellSpacing="0" 
    GridLines="None" Skin="Windows7"
                    Width="100%" Height="100%" AutoGenerateColumns="False" 
                        style="margin-left: 0px">
                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                        </HeaderContextMenu>
                        <MasterTableView>
                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                            <CommandItemSettings ExportToPdfText="Export to PDF">
                            </CommandItemSettings>
                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                <HeaderStyle Width="20px" />
                            </RowIndicatorColumn>
                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                <HeaderStyle Width="20px" />
                            </ExpandCollapseColumn>
                            <EditFormSettings>
                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                </EditColumn>
                            </EditFormSettings>
                            <Columns>
                                <telerik:GridBoundColumn UniqueName="MON" DataField="MON" HeaderText="MONTH">
                                    <ItemStyle Font-Bold="True" />
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="MONTH_BUDGET" DataField="MONTH_BUDGET" 
                                HeaderText="BUDGET" DataFormatString="{0:#,#.##}" >
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="ACTUAL_PROD" DataField="ACTUAL_PROD" 
                                HeaderText="ACTUAL" DataFormatString="{0:#,#.##}" >
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="PERC_PRODUCTION" 
                                DataField="PERC_PRODUCTION" HeaderText="% PRODUCTION" 
                                DataFormatString="{0:F2} %" >
                                </telerik:GridBoundColumn>
                            </Columns>
                        </MasterTableView>
                        <FilterMenu EnableImageSprites="False">
                        </FilterMenu>
                    </telerik:RadGrid>
                </asp:Panel>
            </td>
        </tr>
        <tr>
            <td colspan="2" bgcolor="#999999">
                &nbsp;
            </td>
        </tr>
        <tr>
            <td valign="top" style="width: 1208px">
                <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Horizontal" 
                    Style="min-height: 100px; z-index:10000; background-color:#ccc;" 
                    Width="897px">
                <telerik:RadChart ID="RadChart2" runat="server" Skin="DeepBlue" Width="886px" AutoTextWrap="True"
                    Legend-Appearance-CompositionType="ColumnTextImage" DefaultType="Line">
                    <ClientSettings EnableZoom="false" ScrollMode="None" XScale="2" />
                    <Appearance>
                        <FillStyle FillType="ComplexGradient">
                            <FillSettings>
                                <ComplexGradient>
                                    <telerik:GradientElement Color="26, 120, 179" />
                                    <telerik:GradientElement Color="35, 189, 254" Position="0.5" />
                                    <telerik:GradientElement Color="26, 120, 179" Position="1" />
                                </ComplexGradient>
                            </FillSettings>
                        </FillStyle>
                        <Border Color="0, 66, 110" Width="5" />
                    </Appearance>
                    <Series>
                        <telerik:ChartSeries DataYColumn="NEW_PERC" Name="NEW" Type="Line">
                            <Appearance>
                                <FillStyle FillType="ComplexGradient" MainColor="213, 247, 255">
                                    <FillSettings>
                                        <ComplexGradient>
                                            <telerik:GradientElement Color="213, 247, 255" />
                                            <telerik:GradientElement Color="193, 239, 252" Position="0.5" />
                                            <telerik:GradientElement Color="157, 217, 238" Position="1" />
                                        </ComplexGradient>
                                    </FillSettings>
                                </FillStyle>
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                        </telerik:ChartSeries>
                    </Series>
                    <Legend>
                        <Appearance Dimensions-Margins="1px, 2%, 12%, 1px">
                            <ItemTextAppearance TextProperties-Color="White">
                            </ItemTextAppearance>
                            <FillStyle GammaCorrection="False" MainColor="37, 255, 255, 255">
                            </FillStyle>
                            <Border Color="76, 255, 255, 255" />
                        </Appearance>
                        <TextBlock>
                            <Appearance Position-AlignedPosition="Top" TextProperties-Color="LightSkyBlue">
                            </Appearance>
                        </TextBlock>
                    </Legend>
                    <PlotArea>
                        <XAxis>
                            <Appearance Color="98, 183, 226" MajorTick-Color="98, 183, 226">
                                <MajorGridLines Color="98, 183, 226" Width="0" />
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                            <AxisLabel>
                                <Appearance Dimensions-Paddings="1px, 1px, 10%, 1px">
                                </Appearance>
                                <TextBlock>
                                    <Appearance AutoTextWrap="True" Dimensions-Width="100" 
                                        TextProperties-Color="LightSkyBlue">
                                    </Appearance>
                                </TextBlock>
                            </AxisLabel>
                        </XAxis>
                        <YAxis>
                            <Appearance Color="98, 183, 226" MajorTick-Color="98, 183, 226" 
                                MinorTick-Color="98, 183, 226">
                                <MajorGridLines Color="120, 209, 248" />
                                <MinorGridLines Color="120, 209, 248" Width="0" />
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                            <AxisLabel>
                                <TextBlock>
                                    <Appearance TextProperties-Color="LightSkyBlue">
                                    </Appearance>
                                </TextBlock>
                            </AxisLabel>
                        </YAxis>
                        <Appearance Dimensions-Margins="19%, 90px, 12%, 9%">
                            <FillStyle MainColor="50, 255, 255, 255" SecondColor="Transparent">
                            </FillStyle>
                            <Border Color="97, 180, 223" />
                        </Appearance>
                    </PlotArea>
                    <ChartTitle>
                        <Appearance Dimensions-Margins="4%, 10px, 14px, 6%">
                            <FillStyle MainColor="">
                            </FillStyle>
                        </Appearance>
                        <TextBlock Text="NEW BUSINESS">
                            <Appearance TextProperties-Color="White" TextProperties-Font="Verdana, 14pt">
                            </Appearance>
                        </TextBlock>
                    </ChartTitle>
                </telerik:RadChart>
                </asp:Panel>
            </td>
            <td valign="top">
                <asp:Panel ID="Panel8" runat="server" Height="100%" ScrollBars="Both" 
                    
                    Style="min-height: 100px; z-index:10000; background-color:#ccc; margin-left: 178px;" 
                    Width="75%">
                    <telerik:RadGrid ID="GD_N1" runat="server" CellSpacing="0" 
    GridLines="None" Skin="Windows7"
                    Width="100%" Height="100%" AutoGenerateColumns="False" 
                        style="margin-left: 0px">
                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                        </HeaderContextMenu>
                        <MasterTableView>
                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                            <CommandItemSettings ExportToPdfText="Export to PDF">
                            </CommandItemSettings>
                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                <HeaderStyle Width="20px" />
                            </RowIndicatorColumn>
                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                <HeaderStyle Width="20px" />
                            </ExpandCollapseColumn>
                            <EditFormSettings>
                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                </EditColumn>
                            </EditFormSettings>
                            <Columns>
                                <telerik:GridBoundColumn UniqueName="MON" DataField="MON" HeaderText="MONTH">
                                    <ItemStyle Font-Bold="True" />
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="NEW_BUDGET" DataField="NEW_BUDGET" 
                                HeaderText="BUDGET" DataFormatString="{0:#,#.##}" >
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="ACTUAL_NEW" DataField="ACTUAL_NEW" 
                                HeaderText="ACTUAL" DataFormatString="{0:#,#.##}" >
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="NEW_PERC" 
                                DataField="NEW_PERC" HeaderText="% PRODUCTION" 
                                DataFormatString="{0:F2} %" >
                                </telerik:GridBoundColumn>
                            </Columns>
                        </MasterTableView>
                        <FilterMenu EnableImageSprites="False">
                        </FilterMenu>
                    </telerik:RadGrid>
                </asp:Panel>
            </td>
        </tr>
        <tr>
            <td colspan="2" bgcolor="#999999">
                &nbsp;
            </td>
        </tr>
        <tr>
            <td valign="top" style="width: 1208px">
                <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Horizontal" 
                    Style="min-height: 100px; z-index:10000; background-color:#ccc;" 
                    Width="890px">
                <telerik:RadChart ID="RadChart3" runat="server" Skin="DeepBlue" Width="895px" AutoTextWrap="True"
                    Legend-Appearance-CompositionType="ColumnTextImage" DefaultType="Line">
                    <ClientSettings EnableZoom="false" ScrollMode="None" XScale="2" />
                    <Appearance>
                        <FillStyle FillType="ComplexGradient">
                            <FillSettings>
                                <ComplexGradient>
                                    <telerik:GradientElement Color="26, 120, 179" />
                                    <telerik:GradientElement Color="35, 189, 254" Position="0.5" />
                                    <telerik:GradientElement Color="26, 120, 179" Position="1" />
                                </ComplexGradient>
                            </FillSettings>
                        </FillStyle>
                        <Border Color="0, 66, 110" Width="5" />
                    </Appearance>
                    <Series>
                        <telerik:ChartSeries Name="RENEWAL" DataYColumn="RENEWAL_PERC" Type="Line">
                            <Appearance>
                                <FillStyle FillType="ComplexGradient" MainColor="213, 247, 255">
                                    <FillSettings>
                                        <ComplexGradient>
                                            <telerik:GradientElement Color="213, 247, 255" />
                                            <telerik:GradientElement Color="193, 239, 252" Position="0.5" />
                                            <telerik:GradientElement Color="157, 217, 238" Position="1" />
                                        </ComplexGradient>
                                    </FillSettings>
                                </FillStyle>
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                        </telerik:ChartSeries>
                    </Series>
                    <Legend>
                        <Appearance Dimensions-Margins="1px, 2%, 12%, 1px">
                            <ItemTextAppearance TextProperties-Color="White">
                            </ItemTextAppearance>
                            <FillStyle GammaCorrection="False" MainColor="37, 255, 255, 255">
                            </FillStyle>
                            <Border Color="76, 255, 255, 255" />
                        </Appearance>
                        <TextBlock>
                            <Appearance Position-AlignedPosition="Top" TextProperties-Color="LightSkyBlue">
                            </Appearance>
                        </TextBlock>
                    </Legend>
                    <PlotArea>
                        <XAxis>
                            <Appearance Color="98, 183, 226" MajorTick-Color="98, 183, 226">
                                <MajorGridLines Color="98, 183, 226" Width="0" />
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                            <AxisLabel>
                                <Appearance Dimensions-Paddings="1px, 1px, 10%, 1px">
                                </Appearance>
                                <TextBlock>
                                    <Appearance AutoTextWrap="True" Dimensions-Width="100" 
                                        TextProperties-Color="LightSkyBlue">
                                    </Appearance>
                                </TextBlock>
                            </AxisLabel>
                        </XAxis>
                        <YAxis>
                            <Appearance Color="98, 183, 226" MajorTick-Color="98, 183, 226" 
                                MinorTick-Color="98, 183, 226">
                                <MajorGridLines Color="120, 209, 248" />
                                <MinorGridLines Color="120, 209, 248" Width="0" />
                                <TextAppearance TextProperties-Color="White">
                                </TextAppearance>
                            </Appearance>
                            <AxisLabel>
                                <TextBlock>
                                    <Appearance TextProperties-Color="LightSkyBlue">
                                    </Appearance>
                                </TextBlock>
                            </AxisLabel>
                        </YAxis>
                        <Appearance Dimensions-Margins="19%, 90px, 12%, 9%">
                            <FillStyle MainColor="50, 255, 255, 255" SecondColor="Transparent">
                            </FillStyle>
                            <Border Color="97, 180, 223" />
                        </Appearance>
                    </PlotArea>
                    <ChartTitle>
                        <Appearance Dimensions-Margins="4%, 10px, 14px, 6%">
                            <FillStyle MainColor="">
                            </FillStyle>
                        </Appearance>
                        <TextBlock Text="RENEWAL ANALYSIS">
                            <Appearance TextProperties-Font="Verdana, 14pt" TextProperties-Color="White">
                            </Appearance>
                        </TextBlock>
                    </ChartTitle>
                </telerik:RadChart>
                </asp:Panel>
            </td>
            <td valign="top">
                <asp:Panel ID="Panel9" runat="server" Height="100%" ScrollBars="Both" 
                    Style="min-height: 100px; z-index:10000; background-color:#ccc; margin-left: 187px;" 
                    Width="73%">
                    <telerik:RadGrid ID="GD_N2" runat="server" CellSpacing="0" 
    GridLines="None" Skin="Windows7"
                    Width="100%" Height="100%" AutoGenerateColumns="False" 
                        style="margin-left: 0px">
                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                        </HeaderContextMenu>
                        <MasterTableView>
                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                            <CommandItemSettings ExportToPdfText="Export to PDF">
                            </CommandItemSettings>
                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                <HeaderStyle Width="20px" />
                            </RowIndicatorColumn>
                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                <HeaderStyle Width="20px" />
                            </ExpandCollapseColumn>
                            <EditFormSettings>
                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                </EditColumn>
                            </EditFormSettings>
                            <Columns>
                                <telerik:GridBoundColumn UniqueName="MON" DataField="MON" HeaderText="MONTH">
                                    <ItemStyle Font-Bold="True" />
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="RENEWAL_BUDGET" DataField="RENEWAL_BUDGET" 
                                HeaderText="BUDGET" DataFormatString="{0:#,#.##}" >
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="ACTUAL_RENEW" DataField="ACTUAL_RENEW" 
                                HeaderText="ACTUAL" DataFormatString="{0:#,#.##}" >
                                </telerik:GridBoundColumn>
                                <telerik:GridBoundColumn UniqueName="RENEWAL_PERC" 
                                DataField="RENEWAL_PERC" HeaderText="% PRODUCTION" 
                                DataFormatString="{0:F2} %" >
                                </telerik:GridBoundColumn>
                            </Columns>
                        </MasterTableView>
                        <FilterMenu EnableImageSprites="False">
                        </FilterMenu>
                    </telerik:RadGrid>
                </asp:Panel>
            </td>
        </tr>
        <tr>
            <td colspan="2">
            </td>
        </tr>
    </table>
    </div>
</asp:Content>
