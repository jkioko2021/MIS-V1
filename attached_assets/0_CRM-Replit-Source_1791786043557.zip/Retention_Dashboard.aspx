﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retention_Dashboard.aspx.vb" Inherits="Default2" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table>
                <tr>
                    <td align="center" bgcolor="#333333" style="height: 44px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="ACTIVITY TRACKING"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                            MultiPageID="RadMultiPage1" Skin="Outlook" Width="1200px" 
                            SelectedIndex="0">
                            <Tabs>
                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V2" 
                                    Text="View Activities" Selected="True" SelectedIndex="1">
                                </telerik:RadTab>
                                <telerik:RadTab runat="server" PageViewID="V3" Text="Dashboard" 
                                    SelectedIndex="2">
                                </telerik:RadTab>
                            </Tabs>
                        </telerik:RadTabStrip>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1200px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 3043px; font-weight: 700;">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 384px">
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px" 
                                            AutoPostBack="True">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Quarter" Value="Q" />
                                                <telerik:RadComboBoxItem runat="server" Text="Class" Value="C" />
                                                <telerik:RadComboBoxItem runat="server" Text="Per RM" Value="RM" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cboS_1" Runat="server" style="margin-left: 0px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                </table>
                <telerik:RadMultiPage ID="RadMultiPage1" runat="server" 
                style="margin-top: 0px" Width="1200px">
                  <telerik:RadPageView ID="V2" runat="server" Selected="True">
                       <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="VIEW ACTIVITY"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Panel ID="Panel2" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                Height="100%" style="font-weight: 700" Width="1200px">
                                                <table style="width: 99%">
                                                    <tr>
                                                        <td class="style8" colspan="4">
                                                            <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="RD_ACTIVITY" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" Skin="Simple" 
                                                                    Width="100%" PageSize="50">
                                                                   <%-- ' [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]--%>
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="ACTIVITY_ID">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                       
                                                                            <telerik:GridBoundColumn DataField="ACTIVITY_ID" DataType="System.Decimal" 
                                                                                FilterControlAltText="Filter ACTIVITY_ID column" HeaderText="ACTIVITY_ID" ReadOnly="True" 
                                                                                SortExpression="ID" UniqueName="ACTIVITY_ID">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="CORPORATE_NAME" 
                                                                                ItemStyle-Wrap="False" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                ItemStyle-Wrap="False" SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="ACTIVITY_NAME" 
                                                                                FilterControlAltText="Filter ACTIVITY_NAME column" HeaderText="ACTIVITY_NAME" 
                                                                                ItemStyle-Wrap="False" SortExpression="ACTIVITY_NAME" UniqueName="ACTIVITY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="ACT_DATE" 
                                                                                FilterControlAltText="Filter ACT_DATE column" HeaderText="ACT_DATE" 
                                                                                ItemStyle-Wrap="False" SortExpression="ACT_DATE" UniqueName="ACT_DATE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="ACT_PERIOD" 
                                                                                FilterControlAltText="Filter ACT_PERIOD column" HeaderText="ACT_PERIOD" 
                                                                                ItemStyle-Wrap="False" SortExpression="ACT_PERIOD" UniqueName="ACT_PERIOD">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="FILE_NAME" 
                                                                                FilterControlAltText="Filter FILE_NAME column" HeaderText="FILE_NAME" 
                                                                                ItemStyle-Wrap="False" SortExpression="FILE_NAME" UniqueName="FILE_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            
                                                                            <telerik:GridTemplateColumn HeaderText="#" SortExpression="TicketID" AllowFiltering="false">
                                        <ItemTemplate>
                                                                                      <asp:LinkButton ID="lnkView" runat="server" 
                                                                                    CommandArgument='<%# Eval("ACTIVITY_ID") %>' OnClick="View" Text="View"></asp:LinkButton>
                                        </ItemTemplate>
                                    </telerik:GridTemplateColumn>


                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 194px">
                                                            &nbsp;</td>
                                                        <td>
                                                            <asp:Label ID="Label10" runat="server" Text="Minutes"></asp:Label>
                                                        </td>
                                                        <td class="style8" colspan="2">
                                                            <asp:HyperLink ID="minutes" runat="server">[minutes]</asp:HyperLink>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8">
                                                            <asp:Label ID="lbl_id" runat="server" ForeColor="Red"></asp:Label>
                                                        </td>
                                                        <td>
                                                            <asp:Label ID="Label11" runat="server" Text="Notes"></asp:Label>
                                                        </td>
                                                        <td class="style8" colspan="2" rowspan="2">
                                                            <telerik:RadTextBox ID="txtcom1" Runat="server" Height="90px" Skin="Outlook" 
                                                                TextMode="MultiLine" Width="350px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8">
                                                            <asp:HiddenField ID="HiddenField2" runat="server" />
                                                        </td>
                                                        <td>
                                                            <asp:Label ID="lb" runat="server" ForeColor="Red"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" colspan="2">
                                                            &nbsp;</td>
                                                        <td class="style8" style="width: 166px">
                                                            &nbsp;</td>
                                                        <td style="width: 287px" align="right">
                                                            <telerik:RadButton ID="RadButton2" runat="server" Skin="Simple" Text="Delete">
                                                            </telerik:RadButton>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" colspan="4">
                                                            <asp:Panel ID="Panel16" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                Width="1001px">
                                                                <table style="width: 100%">
                                                                    <tr>
                                                                        <td bgcolor="#999999" colspan="4">
                                                                            <asp:Label ID="Label86" runat="server" Text="Report Extract (Entry Date)"></asp:Label>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="width: 199px">
                                                                            &nbsp;</td>
                                                                        <td style="width: 199px">
                                                                            <asp:Label ID="Label81" runat="server" Text="Date From"></asp:Label>
                                                                        </td>
                                                                        <td style="width: 143px">
                                                                            <telerik:RadDatePicker ID="dtDateFrom" Runat="server" Skin="Web20">
                                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                </Calendar>
                                                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                                                </DateInput>
                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                            </telerik:RadDatePicker>
                                                                        </td>
                                                                        <td>
                                                                            &nbsp;</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="width: 199px">
                                                                            &nbsp;</td>
                                                                        <td style="width: 199px">
                                                                            <asp:Label ID="Label82" runat="server" Text="Date To"></asp:Label>
                                                                        </td>
                                                                        <td style="width: 143px">
                                                                            <telerik:RadDatePicker ID="dtDateTo" Runat="server" Skin="Sunset" Width="150px">
                                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                </Calendar>
                                                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                                                </DateInput>
                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                            </telerik:RadDatePicker>
                                                                        </td>
                                                                        <td>
                                                                            <telerik:RadButton ID="RadButton1" runat="server" Skin="Outlook" Text="Generate">
                                                                            </telerik:RadButton>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" colspan="4" style="height: 100%">
                                                           
                                                        </td>
                                                    </tr>
                                                </table>
<asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                                ScrollBars="Horizontal" Width="1000px">
                                                                <asp:Literal ID="ltEmbed" runat="server" />
                                                            </asp:Panel>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                </table>
                                 
                  </telerik:RadPageView>
                  <telerik:RadPageView ID="V3" runat="server" Selected="True" TabIndex="-1">
                                <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <asp:Label ID="Label151" runat="server" Font-Bold="True" 
                                                Text="ACTIVITY DASHBOARD"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Panel ID="Panel18" runat="server" Height="100%" ScrollBars="Both" 
                                                Width="1200px">
                                                <telerik:RadGrid ID="GD_QUOTA" runat="server" AllowPaging="True" 
                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="15" Skin="Simple" 
                                                    Width="100%">
                                                    <%-- ' [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]--%>
                                                    <MasterTableView AutoGenerateColumns="False">
                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        </RowIndicatorColumn>
                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        </ExpandCollapseColumn>
                                                        <Columns>
                                                           <telerik:GridBoundColumn DataField="RE_NAME" 
                                                                FilterControlAltText="Filter RE_NAME column" HeaderText="RE_NAME" 
                                                                ItemStyle-Wrap="False" SortExpression="RE_NAME" UniqueName="RE_NAME">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="FROM_DT" 
                                                                FilterControlAltText="Filter FROM_DT column" HeaderText="FROM_DT" 
                                                                ItemStyle-Wrap="False" SortExpression="FROM_DT" UniqueName="FROM_DT">
                                                            </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="TO_DT" 
                                                                FilterControlAltText="Filter TO_DT column" HeaderText="TO_DT" 
                                                                ItemStyle-Wrap="False" SortExpression="TO_DT" UniqueName="TO_DT">
                                                            </telerik:GridBoundColumn>
                                                         
                                                            <telerik:GridBoundColumn DataField="TOT_CORP_COUNT" 
                                                                FilterControlAltText="Filter TOT_CORP_COUNT column" HeaderText="CNT_CORPORATES" 
                                                                ItemStyle-Wrap="False" SortExpression="TOT_CORP_COUNT" 
                                                                UniqueName="TOT_CORP_COUNT">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="EXP_CNT_ACTIVITY" 
                                                                FilterControlAltText="Filter EXP_CNT_ACTIVITY column" HeaderText="EXP_CNT" 
                                                                ItemStyle-Wrap="False" SortExpression="EXP_CNT_ACTIVITY" 
                                                                UniqueName="EXP_CNT_ACTIVITY">
                                                            </telerik:GridBoundColumn>
                                                              <telerik:GridBoundColumn DataField="ACT_CNT_ACTIVITY" 
                                                                FilterControlAltText="Filter ACT_CNT_ACTIVITY column" HeaderText="ACT_CNT" 
                                                                ItemStyle-Wrap="False" SortExpression="ACT_CNT_ACTIVITY" 
                                                                UniqueName="ACT_CNT_ACTIVITY">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="PERC_PERF" DataFormatString="{0:#%}" 
                                                                FilterControlAltText="Filter PERC_PERF column" HeaderText="PERC_PERF" 
                                                                ItemStyle-Wrap="False" SortExpression="PERC_PERF" UniqueName="PERC_PERF">
                                                            </telerik:GridBoundColumn>
                                                        </Columns>
                                                        <EditFormSettings>
                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                            </EditColumn>
                                                        </EditFormSettings>
                                                    </MasterTableView>
                                                    <PagerStyle Wrap="False" />
                                                    <FilterMenu EnableImageSprites="False">
                                                    </FilterMenu>
                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                    </HeaderContextMenu>
                                                </telerik:RadGrid>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="Label152" runat="server" Font-Bold="True" 
                                                Text="ACTIVITY DASHBOARD-SUMMARY"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                Width="1200px">
                                                <telerik:RadGrid ID="RD_ACTSUMM" runat="server" AllowPaging="True" 
                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="5" Skin="Simple" 
                                                    Width="100%">
                                                    <%-- ' [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]--%>
                                                    <MasterTableView AutoGenerateColumns="False">
                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        </RowIndicatorColumn>
                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        </ExpandCollapseColumn>
                                                        <Columns>
                                                            <telerik:GridBoundColumn DataField="EMP_NAME" 
                                                                FilterControlAltText="Filter EMP_NAME column" HeaderText="EMP_NAME" 
                                                                ItemStyle-Wrap="False" SortExpression="EMP_NAME" UniqueName="EMP_NAME">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="CNT_CORPORATES" 
                                                                FilterControlAltText="Filter CNT_CORPORATES column" HeaderText="CNT_CORPORATES" 
                                                                ItemStyle-Wrap="False" SortExpression="CNT_CORPORATES" 
                                                                UniqueName="CNT_CORPORATES">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="CNT_ACTIVITIES" 
                                                                FilterControlAltText="Filter CNT_ACTIVITIES column" HeaderText="CNT_ACTIVITIES" 
                                                                ItemStyle-Wrap="False" SortExpression="CNT_ACTIVITIES" 
                                                                UniqueName="CNT_ACTIVITIES">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="AVER_PERCENT" DataFormatString="{0:#%}" 
                                                                FilterControlAltText="Filter AVER_PERCENT column" HeaderText="AVER_PERCENT" 
                                                                ItemStyle-Wrap="False" SortExpression="AVER_PERCENT" 
                                                                UniqueName="AVER_PERCENT">
                                                            </telerik:GridBoundColumn>
                                                        </Columns>
                                                        <EditFormSettings>
                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                            </EditColumn>
                                                        </EditFormSettings>
                                                    </MasterTableView>
                                                    <PagerStyle Wrap="False" />
                                                    <FilterMenu EnableImageSprites="False">
                                                    </FilterMenu>
                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                    </HeaderContextMenu>
                                                </telerik:RadGrid>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="Label153" runat="server" Font-Bold="True" 
                                                Text="ACTIVITY DASHBOARD-PER CORP"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Panel ID="Panel5" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                Height="100%" style="font-weight: 700" Width="1200px">
                                                <table style="width: 99%">
                                                    <tr>
                                                        <td class="style8">
                                                            <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="GD_SUMM" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                    Width="100%">
                                                                    <MasterTableView AutoGenerateColumns="False" >
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                                                                  
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="CORPORATE_NAME" 
                                                                                ItemStyle-Wrap="False" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                UniqueName="PROPOSER_DISPLAY_NAME">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>                                                                          
                                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM"   DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_TO"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="Q1" 
                                                                                FilterControlAltText="Filter Q1 column" HeaderText="Q1" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q1" UniqueName="Q1">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="Q2" 
                                                                                FilterControlAltText="Filter Q2 column" HeaderText="Q2" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q2" UniqueName="Q2">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="Q3" 
                                                                                FilterControlAltText="Filter Q3 column" HeaderText="Q3" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q3" UniqueName="Q3">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="Q4" 
                                                                                FilterControlAltText="Filter Q4 column" HeaderText="Q4" 
                                                                                ItemStyle-Wrap="False" SortExpression="Q4" UniqueName="Q4">
                                                                                <ItemStyle Wrap="False" />
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERC_ACT" DataFormatString="{0:#%}"
                                                                                FilterControlAltText="Filter PERC_ACT column" HeaderText="%" 
                                                                                SortExpression="PERC_ACT" UniqueName="PERC_ACT">
                                                                            </telerik:GridBoundColumn>
                                                                                                                              

                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                </table>
                            </telerik:RadPageView>
                </telerik:RadMultiPage>
              
  
        </ContentTemplate>
     
          </asp:UpdatePanel>
</asp:Content>

