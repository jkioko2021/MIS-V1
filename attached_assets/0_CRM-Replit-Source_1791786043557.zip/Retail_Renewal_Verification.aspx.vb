﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports Microsoft.Office.Interop
Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail
    Dim Mytable As DataTable = Nothing
    Dim Reportname As String = ""

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try

                Dim SqlAction As String = ""

                Dim MyDBAction As New DataManagement
                '--SELECT [PERIOD_FROM]      ,[PERIOD_TO]      ,[MONTH_CLOSED]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_MONTHS]
                SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_MONTHS] WHERE [VALIDATED]=0"
                Dim MyDatable As New Data.DataTable
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDatable.Rows.Count > 0 Then
                    DTEXTRFROM.DbSelectedDate = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                    DTEXTRACTTO.DbSelectedDate = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()

                    Session("FrmDT") = DateAdd(DateInterval.Year, -1, DTEXTRFROM.DbSelectedDate)
                    Session("ToDt") = DateAdd(DateInterval.Year, -1, DTEXTRACTTO.DbSelectedDate)

                End If
                LOADGRID()

            Catch ex As Exception

            End Try
        End If
    End Sub

    Public Sub LOADGRID()
        GDSEARCH_2.DataSource = Nothing
        GDSEARCH_2.DataBind()
        GDSEARCH_3.DataSource = Nothing
        GDSEARCH_3.DataBind()

        SqlAction = "SELECT  [PERIOD],[CNT_POLICY],[CNT_LIVES],[IP_RATE],[OP_RATE],[DEN_RATE],[OPT_RATE],[LEVIES],[TOTAL]  FROM [DB_MASTER_RENEWAL].[dbo].[VW_summary_per_Month]  where VALIDATED=0 ORDER BY PERIOD"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH_4.DataSource = MyDatable
            GDSEARCH_4.DataBind()
            Session("DAD_T_1") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH_4.DataSource = Nothing
            GDSEARCH_4.DataBind()
        End If
  
      
    End Sub


    Protected Sub btnsubmit1_Click(sender As Object, e As System.EventArgs) Handles btnsubmit1.Click
        Try

            Session("Report_") = Nothing
            If cborpt.SelectedValue = "SPP" Then
                SqlAction = "SELECT  [MON_FROM],[PLAN_NAME],[CNT_POLICY],[CNT_LIVES],[IP_RATE],[OP_RATE],[DEN_RATE],[OPT_RATE],[LEVIES],[TOTAL]  FROM [DB_MASTER_RENEWAL].[dbo].[VW_summary_per_plan] where    MON_FROM BETWEEN    MONTH(CONVERT(date, '" & CDate(DTEXTRFROM.SelectedDate).ToString("yyyy-MM-dd") & "')) AND MONTH(CONVERT(date, '" & CDate(DTEXTRFROM.SelectedDate).ToString("yyyy-MM-dd") & "'))"
                Session("Report_") = "SUMMARY PER PLAN"
            ElseIf cborpt.SelectedValue = "SSR" Then
                SqlAction = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[PLAN_NAME],[PLAN_CODE],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[FIRST_ENROLLMENT_DATE],[AGENT],[POLICY_MONTH],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[AGE_BAND],[PRODUCT],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[DEN_LIMIT],[OPT_LIMIT]  ,[FAMILY_SIZE],[POLICY_TYPE]   ,[LAST_CLAIM_DATE],[NCD_YEARS],[NCD_RATE],[IP_PREMIUM],[IP_RATE],[IP_NET_NCD],[OP_RATE],[DEN_RATE],[OPT_RATE],[PA_PTD],[SUB_TOTAL],[LEVIES],[TOTAL],[IS_LOADING],[ON_HOLD] ,[M_STATUS],[TERM],[IS_PA],[Ready_To_Process]  FROM [DB_MASTER_RENEWAL].[dbo].[VW_summary_per_Scheme_No_rates_DET] WHERE PERIOD_FROM BETWEEN   '" & CDate(DTEXTRFROM.SelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(DTEXTRACTTO.SelectedDate).ToString("yyyy-MM-dd") & "'"
                Session("Report_") = "MISSING RATES"
            ElseIf cborpt.SelectedValue = "LPP" Then
                SqlAction = "SELECT  [Policy_Code],[Start_Date],[End_Date],[Data_Date],[Annual_Premium],[Earned_Premium],[IP_Claims_Reported],[OP_Claims_Reported],[Total_Claims_Reported],[Total_LR],[Loading],[is_Loading],[POLICY_TYPE]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_REN_Policy_Loss_Ratio] WHERE IS_LOADING=1 AND     Start_Date BETWEEN     '" & CDate(DateAdd(DateInterval.Year, -1, DTEXTRFROM.DbSelectedDate)).ToString("yyyy-MM-dd") & "' AND  '" & CDate(DateAdd(DateInterval.Year, -1, DTEXTRACTTO.DbSelectedDate)).ToString("yyyy-MM-dd") & "'"
                Session("Report_") = "LOADING PER POLICY"
            ElseIf cborpt.SelectedValue = "LPI" Then
                SqlAction = "SELECT [Policy_Code],[Member_No],[Policy_Type],[Policy_Utilization],[Member_Utilization],[Contr_to_claims],[Sharing_Check],[Policy_Loading],[Ind_Loading],[PERIOD_FROM],[PERIOD_TO],[RELATION],[Is_Loading],Member_Status  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_REN_Ind_Loading] WHERE IS_LOADING=1 AND     PERIOD_FROM BETWEEN      '" & CDate(DateAdd(DateInterval.Year, -1, DTEXTRFROM.DbSelectedDate)).ToString("yyyy-MM-dd") & "' AND  '" & CDate(DateAdd(DateInterval.Year, -1, DTEXTRACTTO.DbSelectedDate)).ToString("yyyy-MM-dd") & "'"
                Session("Report_") = "LOADING PER IND"
            ElseIf cborpt.SelectedValue = "RL" Then
                SqlAction = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[PLAN_NAME],[PLAN_CODE],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[FIRST_ENROLLMENT_DATE],[AGENT],[POLICY_MONTH],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[AGE_BAND],[PRODUCT],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[DEN_LIMIT],[OPT_LIMIT]  ,[FAMILY_SIZE],[POLICY_TYPE]   ,[LAST_CLAIM_DATE],[NCD_YEARS],[NCD_RATE],[IP_PREMIUM],[IP_RATE],[IP_NET_NCD],[OP_RATE],[DEN_RATE],[OPT_RATE],[PA_PTD],[SUB_TOTAL],[LEVIES],[TOTAL],TOTAL_PA_INC TOTAL_WITH_PA_PTD,[IS_LOADING],[ON_HOLD] ,[M_STATUS],[TERM],[IS_PA],[Ready_To_Process]  FROM [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_LIST] WHERE PERIOD_FROM BETWEEN   '" & CDate(DTEXTRFROM.SelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(DTEXTRACTTO.SelectedDate).ToString("yyyy-MM-dd") & "'"
                Session("Report_") = "RENEWAL LIST"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            '-----------------------------------------------------------------------------------------------------------------------------------------------------
            Session("EXCEL") = "TO EXCEL"
            If MyDatable.Rows.Count > 0 Then
                Session("DA") = MyDatable
                If Session("DA").Rows.Count > 0 Then
                    Session("Mytable") = Nothing
                    Session("Reportname") = Nothing
                    Session("Mytable") = Session("DA")
                    Session("Reportname") = Session("Report_")
                    ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                    MyDatable = Nothing

                    System.Threading.Thread.Sleep(5000)

                End If
            Else
                lblerror.Text = "Cannot generate Report!"

            End If

            MyDatable = Nothing

        Catch ex As Exception
            lblerror.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnsubmit2_Click(sender As Object, e As System.EventArgs) Handles btnsubmit2.Click
        Try

            If cboverify.SelectedValue = 1 Then
                SqlAction = "SELECT PLAN_NAME FROM [DB_MASTER_RENEWAL].[dbo].[VW_summary_per_Scheme_No_rates] WHERE PERIOD = '" & CDate(DTEXTRFROM.DbSelectedDate).ToString("yyyy-MM") & "'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    lblerror.Text = "You Have Missing Rates!"
                    Exit Sub

                Else
                    UpdateRecord("UPDATE [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_LIST] SET Validated=1,VERIFIED=1,VERIFIED_BY='" & Session("username") & "'  where PERIOD_FROM BETWEEN '" & CDate(DTEXTRFROM.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTEXTRACTTO.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND READY_TO_PROCESS=1")

                    MyDBAction.forward_Renewal_list_v(CDate(DTEXTRFROM.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTEXTRACTTO.SelectedDate).ToString("yyyy-MM-dd"), Session("username"))
                    MyDBAction.forward_Proposer_list_v(CDate(DTEXTRFROM.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTEXTRACTTO.SelectedDate).ToString("yyyy-MM-dd"))
                    UpdateRecord("UPDATE [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_MONTHS] SET Validated=1,MONTH_CLOSED=1   where PERIOD_FROM = '" & CDate(DTEXTRFROM.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO ='" & CDate(DTEXTRACTTO.DbSelectedDate).ToString("yyyy-MM-dd") & "'")

                    lblerror.Text = "Data Validation Successfull"
                End If
            Else
                UpdateRecord("UPDATE [DB_MASTER_RENEWAL].[dbo].[TBL_MIS_RENEWAL_LIST] SET Validated=0,VERIFIED=0,VERIFIED_BY='" & Session("username") & "'  where PERIOD_FROM BETWEEN '" & CDate(DTEXTRFROM.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTEXTRACTTO.DbSelectedDate).ToString("yyyy-MM-dd") & "'  AND READY_TO_PROCESS=1")

            End If
            LOADGRID()
        Catch ex As Exception
            lblerror.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

   

    Protected Sub GDSEARCH_4_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH_4.SelectedIndexChanged
        Try
            ID = (DirectCast(GDSEARCH_4.SelectedItems(0), GridDataItem)).GetDataKeyValue("PERIOD").ToString()
            SqlAction = "SELECT  [PLAN_NAME],[CNT_POLICY],[CNT_LIVES],[IP_RATE],[OP_RATE],[DEN_RATE],[OPT_RATE],[LEVIES],[TOTAL]  FROM [DB_MASTER_RENEWAL].[dbo].[VW_summary_per_plan] where  PERIOD='" & ID & "' AND VALIDATED=0 ORDER BY TOTAL DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_2.DataSource = Nothing
                GDSEARCH_2.DataBind()
            End If


            SqlAction = "SELECT [PLAN_NAME],[SCHEME_NAME],[CNT_POLICY],[CNT_LIVES],[IP_LIMIT],[OP_LIMIT],[IP_RATE],[OP_RATE]  FROM [DB_MASTER_RENEWAL].[dbo].[VW_summary_per_Scheme_No_rates] where  PERIOD='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_3.DataSource = MyDatable
                GDSEARCH_3.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_3.DataSource = Nothing
                GDSEARCH_3.DataBind()
            End If


        Catch ex As Exception

        End Try
    End Sub
End Class
