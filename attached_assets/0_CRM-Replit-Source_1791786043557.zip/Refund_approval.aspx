﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Refund_approval.aspx.vb" Inherits="_Default" %>


<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="REFUND APPROVAL" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td align="right" colspan="4">
                                                    <asp:Panel ID="Panel31" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 192px">
                                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                                </td>
                                                                <td style="width: 143px">
                                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" AllowCustomText="True" 
                                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Web20" Width="190px">
                                                                        <Items>
                                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Family_Code" Value="F" />
                                                                        </Items>
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td style="width: 266px">
                                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Web20" Width="250px">
                                                                    </telerik:RadTextBox>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3">
                                                    <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTrackingRef" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="Refund_No">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                                    <telerik:GridBoundColumn DataField="Refund_No" 
                                                                        FilterControlAltText="Filter Receive_dt column" HeaderText="Refund_No" 
                                                                        SortExpression="Refund_No" UniqueName="Refund_No">
                                                                    </telerik:GridBoundColumn>
                                                                         <telerik:GridBoundColumn DataField="Proposer" 
                                                                        FilterControlAltText="Filter Proposer column" HeaderText="Proposer" 
                                                                        SortExpression="Proposer" UniqueName="Proposer">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Client_Type" 
                                                                        FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                        SortExpression="Client_Type" UniqueName="Client_Type">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Request_Dt" 
                                                                        FilterControlAltText="Filter Request_Dt column" HeaderText="Request_Dt" 
                                                                        SortExpression="Request_Dt" UniqueName="Request_Dt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Payee_Name" 
                                                                        FilterControlAltText="Filter Payee_Name column" HeaderText="Payee_Name" 
                                                                        SortExpression="Payee_Name" UniqueName="Payee_Name">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Amount_Paid" 
                                                                        FilterControlAltText="Filter Amount_Paid column" HeaderText="Amount_Paid" 
                                                                        SortExpression="Amount_Paid" UniqueName="Amount_Paid">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Refund_Amt" 
                                                                        FilterControlAltText="Filter Refund_Amt column" HeaderText="Refund_Amt" 
                                                                        SortExpression="Refund_Amt" UniqueName="Refund_Amt">
                                                                    </telerik:GridBoundColumn>                                                                  
                                                                    <telerik:GridBoundColumn DataField="Refund_Status" 
                                                                        FilterControlAltText="Filter Refund_Status column" HeaderText="Refund_Status" 
                                                                        SortExpression="Refund_Status" UniqueName="Refund_Status">
                                                                    </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="Refund_Type" 
                                                                        FilterControlAltText="Filter Refund_Type column" HeaderText="Refund_Type" 
                                                                        SortExpression="Refund_Type" UniqueName="Refund_Type">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Entered_By" 
                                                                        FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                        SortExpression="Entered_By" UniqueName="Entered_By">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="FILE_NO" runat="server" Font-Bold="True" Font-Size="Small" 
                                                        style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    &nbsp;</td>
                                                <td style="width: 264px">
                                                    <asp:Label ID="lblclient" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1142px">
                                                        <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                        FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                        SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                        DataFormatString="{0:yyyy-MM-dd}" 
                                                                        FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                        SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                        DataFormatString="{0:yyyy-MM-dd}" 
                                                                        FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                        SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="ACTION_TYPE" 
                                                                        FilterControlAltText="Filter ACTION_TYPE column" HeaderText="ACTION_TYPE" 
                                                                        SortExpression="ACTION_TYPE" UniqueName="ACTION_TYPE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="TOTAL_MEMBERS" 
                                                                        FilterControlAltText="Filter TOTAL_MEMBERS column" HeaderText="MEMBERS" 
                                                                        SortExpression="TOTAL_MEMBERS" UniqueName="TOTAL_MEMBERS">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                                        FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                                        SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="TRANSACTION_DATE" 
                                                                        FilterControlAltText="Filter TRANSACTION_DATE column" 
                                                                        HeaderText="TRANSACTION_DATE" SortExpression="TRANSACTION_DATE" 
                                                                        UniqueName="TRANSACTION_DATE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="DR" FilterControlAltText="Filter DR column" 
                                                                        HeaderText="DR" SortExpression="DR" UniqueName="DR">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="CR" FilterControlAltText="Filter CR column" 
                                                                        HeaderText="CR" SortExpression="CR" UniqueName="CR">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <PagerStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 187px; height: 41px;">
                                                    <asp:Label ID="Label165" runat="server" Text="Refund Type"></asp:Label>
                                                </td>
                                                <td colspan="2" style="height: 41px">
                                                    <asp:Label ID="lblREfT" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                                <td style="width: 174px; height: 41px;">
                                                </td>
                                                <td style="height: 41px">
                                                    <telerik:RadButton ID="btnstatement" runat="server" Skin="Simple" 
                                                        Text="Print Statement" Width="240px">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 187px">
                                                    <asp:Label ID="Label160" runat="server" Text="Total DR"></asp:Label>
                                                </td>
                                                <td colspan="2">
                                                    <telerik:RadNumericTextBox ID="txtDR" Runat="server" Enabled="False" 
                                                        Width="150px">
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                                <td style="width: 174px">
                                                    <asp:Label ID="Label161" runat="server" Text="Total CR"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadNumericTextBox ID="txtCR" Runat="server" Enabled="False" 
                                                        Width="150px">
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 187px">
                                                    <asp:Label ID="Label154" runat="server" Text="Payee Name"></asp:Label>
                                                </td>
                                                <td colspan="2">
                                                    <telerik:RadTextBox ID="txtname" Runat="server" Skin="Web20" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td style="width: 174px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 187px">
                                                    <asp:Label ID="Label157" runat="server" Text="Payee eMail"></asp:Label>
                                                </td>
                                                <td colspan="2">
                                                    <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Web20" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td style="width: 174px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 187px">
                                                    <asp:Label ID="Label158" runat="server" Text="Payee Mobile"></asp:Label>
                                                </td>
                                                <td colspan="2">
                                                    <telerik:RadNumericTextBox ID="txtmobile" Runat="server" 
                                                        DataType="System.Int32" Width="225px">
                                                        <NumberFormat DecimalDigits="0" GroupSeparator="" />
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                                <td style="width: 174px">
                                                    &nbsp;</td>
                                                <td>
                                                    <asp:Label ID="lblprop" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red" Visible="False"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="height: 23px; width: 187px;">
                                                    <asp:Label ID="Label155" runat="server" Text="Amount Bal"></asp:Label>
                                                </td>
                                                <td style="width: 379px; height: 23px;">
                                                    <telerik:RadNumericTextBox ID="txtpaid" Runat="server" Width="150px" 
                                                        Enabled="False">
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                                <td style="width: 136px; height: 23px;">
                                                    </td>
                                                <td style="width: 174px; height: 23px;">
                                                    </td>
                                                <td style="height: 23px">
                                                    </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 187px">
                                                    <asp:Label ID="Label156" runat="server" Text="Amount To Refund"></asp:Label>
                                                </td>
                                                <td style="width: 379px">
                                                    <telerik:RadNumericTextBox ID="txtrefund" Runat="server" Width="150px">
                                                    </telerik:RadNumericTextBox>
                                                </td>
                                                <td style="width: 136px">
                                                    &nbsp;</td>
                                                <td style="width: 174px">
                                                    <asp:Label ID="Label159" runat="server" Font-Size="Medium" Text="Refund No"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="RefNo" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <hr />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel34" runat="server">
                                                        <table style="width: 99%">
                                                            <tr>
                                                                <td>
                                                                    <asp:Label ID="Label162" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1100px">
                                                                        <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                            GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                    <HeaderStyle Width="20px" />
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                    <HeaderStyle Width="20px" />
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                                        FilterControlAltText="Filter Select column" Text="Select" UniqueName="Select" 
                                                                                        HeaderText="Select">
                                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                        <ItemStyle Width="50px" />
                                                                                    </telerik:GridButtonColumn>
                                                                                    <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                                        FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                                        SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="File_No" 
                                                                                        FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                                        SortExpression="File_No" UniqueName="File_No">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                                        FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                                        SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                                        FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                                        SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="File_Name" 
                                                                                        FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                                        SortExpression="File_Name" UniqueName="File_Name">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Upload_By" 
                                                                                        FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                                        SortExpression="Upload_By" UniqueName="Upload_By">
                                                                                    </telerik:GridBoundColumn>
                                                                                      <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                                        SortExpression="DOC_ID">
                                                                                        <ItemTemplate>
                                                                                            <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                                CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                                        </ItemTemplate>
                                                                                    </telerik:GridTemplateColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                                        ScrollBars="Horizontal" Width="1071px">
                                                                        <asp:Literal ID="ltEmbed" runat="server" />
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td colspan="5">
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px">
                                                    <asp:Label ID="Label166" runat="server" Text="Attach Schedule"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadTextBox ID="txttitle" Runat="server" Enabled="False" Skin="Web20" 
                                                        Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px">
                                                    &nbsp;</td>
                                                <td>
                                                    <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px">
                                                    &nbsp;</td>
                                                <td>
                                                    <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" Text="Upload">
                                                    </telerik:RadButton>
                                                    <asp:Label ID="lblupload" runat="server" Font-Size="Medium"></asp:Label>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <hr />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px; height: 26px;">
                                                    &nbsp;</td>
                                                <td style="height: 26px">
                                                    <asp:CheckBox ID="chkver" runat="server" Text="Sign Verified" />
                                                </td>
                                                <td style="height: 26px">
                                                    &nbsp;</td>
                                                <td style="width: 193px; height: 26px;">
                                                    &nbsp;</td>
                                                <td style="height: 26px">
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px; height: 26px;">
                                                    <asp:Label ID="Label163" runat="server" Text="Action"></asp:Label>
                                                </td>
                                                <td style="height: 26px">
                                                    <telerik:RadComboBox ID="cboAction" Runat="server" AllowCustomText="True" 
                                                        MarkFirstMatch="True" Skin="Web20" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" 
                                                                Text="Return-Incomplete" Value="RI" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" Text="Approve" 
                                                                Value="A" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="height: 26px">
                                                </td>
                                                <td style="width: 193px; height: 26px;">
                                                </td>
                                                <td style="height: 26px">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px">
                                                    <asp:Label ID="Label152" runat="server" Text="Entered By"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblenteredby" runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="Label167" runat="server" Text="Processed By"></asp:Label>
                                                </td>
                                                <td style="width: 193px">
                                                    <asp:Label ID="lblprocessedby" runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px">
                                                    <asp:Label ID="Label144" runat="server" Text="Notes"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadTextBox ID="txtcomment" Runat="server" Height="50px" Skin="Web20" 
                                                        TextMode="MultiLine" Width="450px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 136px; height: 38px;">
                                                    </td>
                                                <td style="height: 38px;">
                                                    <telerik:RadButton ID="btnforward" runat="server" Skin="Simple" 
                                                        Text="update Refund" Width="200px">
                                                    </telerik:RadButton>
                                                </td>
                                                <td style="height: 38px">
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1129px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                         
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Notes_by" UniqueName="Notes_by">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
        <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
        </Triggers>
            </asp:UpdatePanel>
</asp:Content>

