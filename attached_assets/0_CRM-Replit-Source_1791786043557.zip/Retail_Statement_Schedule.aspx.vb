﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Imports Microsoft.Practices.EnterpriseLibrary.Configuration.Design
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("PRINT") = Nothing
            Session("Report_") = Nothing
        End If

    End Sub
    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try
            GDPROP.DataSource = Nothing
            GDPROP.DataBind()
            GDMEM.DataSource = Nothing
            GDMEM.DataBind()
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()

            Dim MyDatable As New Data.DataTable
            ' SqlAction = "SELECT[PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"
            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT  [PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,PERIOD_FROM,PERIOD_TO,POLICY_STATUS,RM_NAME FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROPOSER_LIST] WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND [CLIENT_TYPE]='RET'"
            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,AGENT,PERIOD_FROM,PERIOD_TO,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE FAMILY_NO  LIKE '%" & Trim(TXTSEARCH.Text) & "%'  AND RELATION='MAIN MEMBER'  AND [GRP_INDV]='I'"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                Session("TAT_5") = MyDatable
                MyDatable = Nothing
            Else
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try
            GDMEM.DataSource = Nothing
            GDMEM.DataBind()

            Session("PROPOSER_ID") = Nothing
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0

            Session("PROPOSER_ID") = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()
            lblid.Text = Session("PROPOSER_ID")
            SqlAction = "SELECT [PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],FIRST_ENROLLMENT_DATE,[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO,POLICY_STATUS,DATA_DATE,AGENT FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "'   order by DISPLAY_MEMBERSHIP_NO"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEM.DataSource = MyDatable
                GDMEM.DataBind()
                Session("TAT_5") = MyDatable
                'lblid.Text = MyDatable.Rows(0).Item("PROPOSER_ID").ToString

                MyDatable = Nothing
            Else
                GDMEM.DataSource = Nothing
                GDMEM.DataBind()
            End If



            SqlAction = "SELECT DISTINCT  [POLICY_CODE], Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_STATE.DataSource = MyDatable
                GD_STATE.DataBind()
                Session("STATE_01") = MyDatable
                DR = Convert.ToInt32(MyDatable.Compute("SUM(DR)", String.Empty))
                CR = Convert.ToInt32(MyDatable.Compute("sum(CR)", String.Empty))
                txtbal.Text = DR - CR
                MyDatable = Nothing
            Else

                GD_STATE.DataSource = Nothing
                GD_STATE.DataBind()
            End If
            Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,RENEWAL_DATE,GETDATE()) DAYS_DUE,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM [DB_MASTER_RENEWAL].dbo.TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE PROPOSER_ID='" & Session("PROPOSER_ID") & "' and PERIOD_TO>=getdate() "
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_REN.DataSource = MyDatable
                GD_REN.DataBind()
                Session("DAD_5") = MyDatable

                MyDatable = Nothing
            Else
                GD_REN.DataSource = Nothing
                GD_REN.DataBind()
            End If



            LoadNotes(lblid.Text)


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GD_REN_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_REN.SelectedIndexChanged
        Try
            HiddenField1.Value = (DirectCast(GD_REN.SelectedItems(0), GridDataItem)).GetDataKeyValue("POLICY_CODE").ToString()

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub LoadNotes(ByVal id As String)
        SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
        End If
    End Sub

    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_STATE.PageIndexChanged
        GD_STATE.CurrentPageIndex = e.NewPageIndex
        GD_STATE.DataSource = Session("STATE_01")
        GD_STATE.DataBind()
    End Sub

    Protected Sub btnstatement_Click(sender As Object, e As System.EventArgs) Handles btnstatement.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable



            Session("PRINT") = "PDF"
            Session("Report_") = "Customer Statement"

            Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR], [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & lblid.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC,REFERENCE_NO"

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub btnschedule_Click(sender As Object, e As System.EventArgs) Handles btnschedule.Click
        Try
            Dim Mytable As DataTable = Nothing
            Dim MyDatable_1 As DataTable = Nothing
            Dim MyDatable_2 As DataTable = Nothing
            Dim MyDatable_3 As DataTable = Nothing
            Session("EMPNAME") = Nothing
            Session("FrmDT") = Nothing
            Session("ToDt") = Nothing
            Session("agentEmail") = Nothing
            Session("RecepientEmail") = ""
            Session("MailSent") = False
            Session("EXPORT_TYPE") = "PDF"

            If HiddenField1.Value = "" Then
                lblerr.Text = "Select Policy Code"
                Exit Sub
            End If

            If cboType.SelectedValue = "S" Then


                Str = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],S_PLUS_PREM,INV_NO,PLAN_NAME,SCHEME_NAME,AGE  FROM [DB_MASTER_RENEWAL].[dbo].[VW_RENEWAL_ADVICE] WHERE   POLICY_CODE='" & HiddenField1.Value & "'  ORDER BY FAMILY_NO"
                MyDatable_1 = Nothing
                MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable_1.Rows.Count > 0 Then

                    'GENERATE_RPT(MyDatable_1)
                    Session("Report_") = "Renewal Schedule"
                    Session("PRINT") = "PDF"
                    'MyDatable_1 = Nothing
                    Session("Mytable") = Nothing
                    Session("Reportname") = Nothing
                    Session("Mytable") = (MyDatable_1)
                    Session("Reportname") = Session("Report_")
                    ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                    Mytable = Nothing
                    System.Threading.Thread.Sleep(5000)
                Else
                    lblerr.Text = "No Data Found"
                    Exit Sub
                End If
            ElseIf cboType.SelectedValue = "A" Then
                'HiddenField1.Value = "KE/17/PA693/000014/03"
                '
                Session("Report_") = "RENEWAL_ADVICE"
                Session("PRINT") = "PDF"
                Session("Reportname") = Session("Report_")
                Session("PolicyCode") = HiddenField1.Value
                ' Redirect to the report viewer
                Response.Redirect("ReportViewer.aspx?Reportname=RENEWAL_ADVICE&PolicyCode=" & Server.UrlEncode(HiddenField1.Value), False)
                HttpContext.Current.ApplicationInstance.CompleteRequest()
                Mytable = Nothing
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
