﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Ret_Retail_RM_Mapping.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="RE- RM MAPPING"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1200px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8">&nbsp;</td>
                                    <td class="style8" style="width: 149px">&nbsp;</td>
                                    <td class="style8">
                                        <asp:Label ID="Label144" runat="server" style="font-weight: 700" Text="Region"></asp:Label>
                                    </td>
                                    <td class="style8">
                                        <telerik:RadComboBox ID="cboregion" Runat="server" AccessibilityMode="True" AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr style="5" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="30" Skin="Outlook" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="USER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridTemplateColumn DataType="System.Boolean" UniqueName="Updated">
                                                            <ItemTemplate>
                                                                <asp:CheckBox ID="chkreturn" runat="server" AutoPostBack="True" 
                                                                    OnCheckedChanged="ToggleRowSelection" />
                                                            </ItemTemplate>
                                                            <HeaderTemplate>
                                                                <asp:CheckBox ID="chkheader" runat="server" AutoPostBack="True" 
                                                                    OnCheckedChanged="ToggleSelectedState" />
                                                            </HeaderTemplate>
                                                        </telerik:GridTemplateColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT_NAME" 
                                                            FilterControlAltText="Filter AGENT_NAME column" HeaderText="AGENT_NAME" 
                                                            ItemStyle-Wrap="False" SortExpression="AGENT_NAME" UniqueName="AGENT_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT_TYPE" 
                                                            FilterControlAltText="Filter AGENT_TYPE column" HeaderText="AGENT_TYPE" 
                                                            SortExpression="AGENT_TYPE" UniqueName="AGENT_TYPE">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="UNIT_NAME" 
        FilterControlAltText="Filter UNIT_NAME column" HeaderText="UNIT_NAME" 
        SortExpression="UNIT_NAME" UniqueName="UNIT_NAME">
    </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="UM_MANAGER" 
                                                            FilterControlAltText="Filter UM_MANAGER column" HeaderText="UM_MANAGER" 
                                                            SortExpression="UM_MANAGER" UniqueName="UM_MANAGER">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="REGION_NAME" 
                                                            FilterControlAltText="Filter REGION_NAME column" HeaderText="REGION_NAME" 
                                                            ItemStyle-Wrap="False" SortExpression="REGION_NAME" UniqueName="REGION_NAME">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px; height: 37px;">
                                        <asp:Label ID="Label143" runat="server" Text="Account RE"></asp:Label>
                                    </td>
                                    <td style="height: 37px; width: 149px;">
                                        <telerik:RadComboBox ID="cbore" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style19" style="width: 233px; height: 37px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 37px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px; height: 31px;">
                                        <asp:Label ID="Label142" runat="server" Text="Account RM"></asp:Label>
                                    </td>
                                    <td style="height: 31px; width: 149px;">
                                        <telerik:RadComboBox ID="cborm" Runat="server" AccessibilityMode="True" AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style19" style="width: 233px; height: 31px;">
                                        &nbsp;</td>
                                    <td class="style8" style="height: 31px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px; height: 31px;">
                                        <asp:Label ID="lblID" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="height: 31px; width: 149px;">
                                        <telerik:RadButton ID="cmdsave" runat="server" Height="37px" Skin="Simple" Text="Save" Width="100px">
                                        </telerik:RadButton>
                                    </td>
                                    <td class="style19" style="width: 233px; height: 31px;">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                    </td>
                                    <td class="style8" style="height: 31px">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        &nbsp;</td>
                                    <td style="width: 149px">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" colspan="2">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        &nbsp;</td>
                                    <td class="style19" style="width: 233px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;<asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                        <asp:Panel ID="Panel16" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                Width="1001px" Height="89px">
                                                                <table style="width: 100%">
                                                                    <tr>
                                                                        <td bgcolor="#999999" colspan="4">
                                                                            <asp:Label ID="Label86" runat="server" Text="Report Extract (Entry Date)"></asp:Label>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="width: 199px; height: 17px;">
                                                                            </td>
                                                                        <td style="width: 199px; height: 17px;">
                                                                        </td>
                                                                        <td style="width: 143px; height: 17px;">
                                                                        </td>
                                                                        <td style="height: 17px">
                                                                            </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="width: 199px">
                                                                            <telerik:RadButton ID="RadButton1" runat="server" Skin="Outlook" 
                                                                                Text="Generate" Width="300px">
                                                                            </telerik:RadButton>
                                                                        </td>
                                                                        <td style="width: 199px">
                                                                            &nbsp;</td>
                                                                        <td style="width: 143px">
                                                                            &nbsp;</td>
                                                                        <td>
                                                                            &nbsp;</td>
                                                                    </tr>
                                                                </table>
                                                            </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>

    </asp:UpdatePanel>
</asp:Content>

