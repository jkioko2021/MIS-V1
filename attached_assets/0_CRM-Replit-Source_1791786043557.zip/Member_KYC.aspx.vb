﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Imports System.Configuration

Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try
            GDPROP.DataSource = Nothing
            GDPROP.DataBind()
            HiddenField1.Value = ""
            Dim MyDatable As New Data.DataTable
            ' SqlAction = "SELECT[PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE PROPOSER_DISPLAY_NAME LIKE '%" & Trim(TXTSEARCH.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT DISTINCT PROPOSER_ID,POLICY_CODE,PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,RM_NAME,POLICY_STATUS FROM [DATA_REPOSITORY_DB].[dbo].MASTER_PROPOSER_LIST WITH (NOLOCK)  WHERE POLICY_CODE LIKE '%" & Trim(TXTSEARCH.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT FAMILY_NO, [PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,AGENT,POLICY_VALID_FROM [PERIOD_FROM],POLICY_VALID_UPTO PERIOD_TO,POLICY_STATUS  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK)  WHERE FAMILY_NO LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND RELATION='MAIN MEMBER'"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                MyDatable = Nothing
            Else
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()
            End If


        Catch ex As Exception
            lbLERROR.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try
            lbLERROR.Text = ""
            HiddenField1.Value = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()
            LOADG()

        Catch ex As Exception
            lbLERROR.Text = ex.Message
        End Try
    End Sub
    Public Sub LOADG()
        gdinvalid.DataSource = Nothing
        gdinvalid.DataBind()
        gdvalid.DataSource = Nothing
        gdvalid.DataBind()

        SqlAction = "SELECT  Member_No,Mobile_No,  ID_Doc_No,ID_Doc_Type,Pin_No,Email  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_KYC_DETAILS] WHERE PROPOSER_ID='" & HiddenField1.Value & "' AND Verified=0 AND VALID=1"
        MyDatable = Nothing
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            Session("DA_N") = Nothing
            gdvalid.DataSource = MyDatable
            gdvalid.DataBind()
            lbLVALIR.Text = MyDatable.Rows.Count()
            Session("gdvalid") = MyDatable

        Else
            gdvalid.DataSource = Nothing
            gdvalid.DataBind()
        End If
        SqlAction = "SELECT  Member_No,Mobile_No,  ID_Doc_No,ID_Doc_Type,Pin_No,Email  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_KYC_DETAILS] WHERE PROPOSER_ID='" & HiddenField1.Value & "' AND Verified=0 AND VALID=0"
        MyDatable = Nothing
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            Session("DA_N") = Nothing
            gdinvalid.DataSource = MyDatable
            gdinvalid.DataBind()
            Session("gdinvalid") = MyDatable
            'lbLERROR.Text = "No of records with INvalid Member Code:" & dtExcelRecords.Rows.Count()
        Else
            gdinvalid.DataSource = Nothing
            gdinvalid.DataBind()
           
        End If
    End Sub
    Private Sub DELETERecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

    End Sub
    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim connectionString As String = ""
        lbLERROR.Text = ""
        Session("DA_N") = Nothing
        Dim SqlAction As String = ""
        Dim searchStr As String = ""
        Dim MyDBAction As New DataManagement
        Dim REC_DATE As Date
        Dim MEMBER_ID As String = ""
        Dim Mobile_No As String = ""
        Dim ID_Doc_No As String = ""
        Dim ID_Doc_Type As String = ""
        Dim Email As String = ""
        Dim Pin_No As String = ""
        Dim member_No As String = ""
        Dim mlen As Integer = 0
        gdinvalid.DataSource = Nothing
        gdinvalid.DataBind()
        gdvalid.DataSource = Nothing
        gdvalid.DataBind()
        Try
            'If FL1.HasFile Then

            '    Dim fileName As String = " {" & CDate(Date.Now).ToString("yyyy-MM-dd") & "-" & CDate(Date.Now).ToString("yyyy-MM-dd") & "}" & Path.GetFileName(FL1.PostedFile.FileName)

            '    Dim fileExtension As String = Path.GetExtension(FL1.PostedFile.FileName)

            '    Dim fileLocation As String = Server.MapPath("~/EXCEL UPLOADS/" & fileName)

            '    FL1.SaveAs(fileLocation)


            '    If fileExtension = ".xls" Then

            '        connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""

            '    ElseIf fileExtension = ".xlsx" Then

            '        connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""

            '    End If
            '    'dtfrom.DbSelectedDate = Session("CUTOFF_FROM")
            '    'dtto.DbSelectedDate = 

            '    Dim con As New OleDbConnection(connectionString)

            '    Dim cmd As New OleDbCommand()

            '    cmd.CommandType = System.Data.CommandType.Text

            '    cmd.Connection = con

            '    Dim dAdapter As New OleDbDataAdapter(cmd)

            '    Dim dtExcelRecords As New DataTable()

            '    con.Open()

            '    Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)

            '    Dim getExcelSheetName As String = dtExcelSheetName.Rows(0)("Table_Name").ToString()

            '    cmd.CommandText = "SELECT  Member_No,Mobile_No,  ID_Doc_No,ID_Doc_Type,Pin_No,Email FROM [" & getExcelSheetName & "] "
            '    dAdapter.SelectCommand = cmd
            '    dAdapter.Fill(dtExcelRecords)
            '    con.Close()
            '    Session("DA_N") = dtExcelRecords
            '    DELETERecord("DELETE FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_KYC_DETAILS]  WHERE PROPOSER_ID='" & HiddenField1.Value & "' AND Verified=0")

            '    If dtExcelRecords.Rows.Count > 1 Then
            '        For Each row In Session("DA_N").rows
            '            MEMBER_ID = ""

            '            SqlAction = "SELECT Member_ID  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK) WHERE DISPLAY_MEMBERSHIP_NO ='" & row("Member_No").ToString & "'"
            '            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            '            If MyDatable.Rows.Count > 0 Then
            '                MEMBER_ID = MyDatable.Rows(0).Item("Member_ID").ToString()
            '                Mobile_No = row("Mobile_No").ToString
            '                Member_No = row("Member_No").ToString
            '                ID_Doc_No = row("ID_Doc_No").ToString
            '                ID_Doc_Type = row("ID_Doc_Type").ToString
            '                Email = row("Email").ToString
            '                Pin_No = row("Pin_No").ToString
            '                mlen = Len(Mobile_No)
            '                If Mobile_No = Nothing Or member_No = Nothing Or ID_Doc_No = Nothing Or ID_Doc_Type = Nothing Or Pin_No = Nothing Or Email = Nothing Or mlen <> 9 Then
            '                    MyDBAction.VALIDATE_MEMBER(HiddenField1.Value, member_No, Mobile_No, MEMBER_ID, ID_Doc_No, row("ID_Doc_Type").ToString, Pin_No, row("Email").ToString, 0, Session("username"))

            '                Else
            '                    Mobile_No = "254" & Mobile_No
            '                    MyDBAction.VALIDATE_MEMBER(HiddenField1.Value, member_No, Mobile_No, MEMBER_ID, ID_Doc_No, ID_Doc_Type, Pin_No, Email, 1, Session("username"))
            '                End If
            '            Else

            '                MEMBER_ID = "NA"
            '                MyDBAction.VALIDATE_MEMBER(HiddenField1.Value, member_No, Mobile_No, MEMBER_ID, ID_Doc_No, row("ID_Doc_Type").ToString, Pin_No, row("Email").ToString, 0, Session("username"))
            '            End If
            '            ' MyDBAction.DEDUCTIONS(row("HRMIS_CODE").ToString, row("PRINCIPLE_AMT"), row("DR"), 0, row("DEDUCTION_CODE").ToString, RECEIPT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("CUTOFF_FROM"), Session("CUTOFF_TO"), Session("username"), "DR")
            '        Next
            '        LOADG()
            '    End If
            'End If


            'Session("EXCEL") = Nothing


            '-------------------------------------------------------------------
            'Member_No	Mobile_No	ID_Doc_No	ID_Doc_Type	Pin_No	Email 
            Dim fileName As String = " {" & CDate(Date.Now).ToString("yyyy-MM-dd") & "-" & CDate(Date.Now).ToString("yyyy-MM-dd") & "}" & Path.GetFileName(FL1.PostedFile.FileName)
            lblupload.Text = ""
            Dim fileExtension As String = Path.GetExtension(FL1.PostedFile.FileName)
            If fileExtension <> ".csv" Then
                lblupload.Text = "YOU MUST UPLOAD CSV FILE"
                Exit Sub
            End If
            Dim csvPath As String = Server.MapPath("~/EXCEL UPLOADS/" & fileName)
            FL1.SaveAs(csvPath)
            Dim dt As New DataTable()
            dt.Columns.AddRange(New DataColumn(5) {
                                New DataColumn("Member_No", GetType(String)),
                                New DataColumn("Mobile_No", GetType(String)),
                                New DataColumn("ID_Doc_No", GetType(String)),
                                New DataColumn("ID_Doc_Type", GetType(String)),
                                New DataColumn("Pin_No", GetType(String)),
                                   New DataColumn("Email", GetType(String))})


            Dim csvData As String = File.ReadAllText(csvPath)
            Dim firstRow As Boolean = True
            For Each row As String In csvData.Split(ControlChars.Lf)
                If firstRow Then
                    firstRow = False
                Else
                    If Not String.IsNullOrEmpty(row) Then
                        dt.Rows.Add()
                        Dim i As Integer = 0
                        For Each cell As String In row.Split(","c)
                            dt.Rows(dt.Rows.Count - 1)(i) = cell.Trim().Replace("""", "").Replace("�", "")
                            i += 1
                        Next
                    End If
                End If
            Next

            DELETERecord("DELETE FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_KYC_DETAILS]  WHERE PROPOSER_ID='" & HiddenField1.Value & "' AND Verified=0")

            Dim dtFinal As DataTable = dt.Clone()
            'dtFinal.Columns.Remove("Times")
            'Member_No	Mobile_No	ID_Doc_No	ID_Doc_Type	Pin_No	Email 
            For Each row As DataRow In dt.Rows
                Dim dr As DataRow = dtFinal.NewRow()
                SqlAction = "SELECT Member_ID  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK) WHERE DISPLAY_MEMBERSHIP_NO ='" & row("Member_No").ToString & "'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    MEMBER_ID = MyDatable.Rows(0).Item("Member_ID").ToString()
                    Mobile_No = row("Mobile_No").ToString
                    member_No = row("Member_No").ToString
                    ID_Doc_No = row("ID_Doc_No").ToString
                    ID_Doc_Type = row("ID_Doc_Type").ToString
                    Email = row("Email").ToString
                    Pin_No = row("Pin_No").ToString
                    mlen = Len(Mobile_No)
                    If Mobile_No = Nothing Or member_No = Nothing Or ID_Doc_No = Nothing Or ID_Doc_Type = Nothing Or Pin_No = Nothing Or Email = Nothing Or mlen <> 9 Then
                        MyDBAction.VALIDATE_MEMBER(HiddenField1.Value, member_No, Mobile_No, MEMBER_ID, ID_Doc_No, row("ID_Doc_Type").ToString, Pin_No, row("Email").ToString, 0, Session("username"))

                    Else
                        Mobile_No = "254" & Mobile_No
                        MyDBAction.VALIDATE_MEMBER(HiddenField1.Value, member_No, Mobile_No, MEMBER_ID, ID_Doc_No, ID_Doc_Type, Pin_No, Email, 1, Session("username"))
                    End If
                Else

                    MEMBER_ID = "NA"
                    MyDBAction.VALIDATE_MEMBER(HiddenField1.Value, member_No, Mobile_No, MEMBER_ID, ID_Doc_No, row("ID_Doc_Type").ToString, Pin_No, row("Email").ToString, 0, Session("username"))
                End If
                ' MyDBAction.DEDUCTIONS(row("HRMIS_CODE").ToString, row("PRINCIPLE_AMT"), row("DR"), 0, row("DEDUCTION_CODE").ToString, RECEIPT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("CUTOFF_FROM"), Session("CUTOFF_TO"), Session("username"), "DR")
            Next
            LOADG()

            'dtFinal.Rows.Add(dr)

            'gdvalid.DataSource = dtFinal
            'gdvalid.DataBind()

            'GD.DataSource = dtFinal
            'GridView1.DataBind()

        Catch ex As Exception
            lbLERROR.Text = ex.Message
        End Try
    End Sub
    Protected Sub gdvalid_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles gdvalid.PageIndexChanged
        gdvalid.CurrentPageIndex = e.NewPageIndex
        gdvalid.DataSource = Session("gdvalid")
        gdvalid.DataBind()
    End Sub
    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles gdinvalid.PageIndexChanged
        gdinvalid.CurrentPageIndex = e.NewPageIndex
        gdinvalid.DataSource = Session("gdinvalid")
        gdinvalid.DataBind()
    End Sub
    Protected Sub RadButton2_Click(sender As Object, e As System.EventArgs) Handles RadButton2.Click
        Try
            Session("Mytable") = Nothing
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String
            Reportname = cboval.Text

            If cboval.SelectedValue = "V" Then
                Session("Mytable") = Session("gdvalid")
            ElseIf cboval.SelectedValue = "I" Then
                Session("Mytable") = Session("gdinvalid")
            End If


            Session("EXCEL") = "TO EXCEL"
            'Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            'Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
            'Reportname = ""

        Catch ex As Exception

        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            If chkverify.Checked = True Then
                UpdateRecord("UPDATE [DATA_REPOSITORY_DB].[dbo].[MASTER_KYC_DETAILS]  SET  [Verified]=1, [Verified_By]='" & Session("username") & "' where PROPOSER_ID='" & HiddenField1.Value & "' AND Verified=0 AND VALID=1")
                'UpdateRecord("UPDATE [DATA_REPOSITORY_DB].[dbo].[MASTER_KYC_DETAILS]  SET  [Verified]=1, [Verified_By]='" & Session("username") & "' where PROPOSER_ID='" & HiddenField1.Value & "' AND Verified=0 AND VALID=1")


                lbLERROR.Text = "Verified & updated Successfull"
                'MyDBAction.update_kyc(HiddenField1.Value)
            End If
            LOADG()

        Catch ex As Exception
            lbLERROR.Text = ex.Message
        End Try
    End Sub
End Class
