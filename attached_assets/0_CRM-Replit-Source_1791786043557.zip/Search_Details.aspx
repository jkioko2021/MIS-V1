﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Search_Details.aspx.vb" Inherits="Default2" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
 <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 94%">
                <tr>
                    <td colspan="2">

                                <table style="width: 93%">
                                    <tr>
                                        <td>
                                            <asp:Label ID="lblstatus" runat="server" ForeColor="#CC0000"></asp:Label>
                                        </td>
                                        <td style="width: 22px">
                                            &nbsp;</td>
                                        <td>
                                            &nbsp;</td>
                                        <td>
                                            &nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">
                                            <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                Width="891px">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td style="width: 500px">
                                                            <asp:Label ID="Label67" runat="server" style="font-weight: 700" 
                                                                Text="Search By"></asp:Label>
                                                        </td>
                                                        <td>
                                                            <telerik:RadComboBox ID="cbosearch" Runat="server">
                                                                <Items>
                                                                    <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                                    <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                                    <telerik:RadComboBoxItem runat="server" Text="File No" Value="F" />
                                                                </Items>
                                                            </telerik:RadComboBox>
                                                        </td>
                                                        <td>
                                                            <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td>
                                                            <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                                            </telerik:RadButton>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td bgcolor="#666666" colspan="4">
                                            &nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">
                                            <asp:Panel ID="Panel7" runat="server" Width="901px" Height="150px" 
                                                ScrollBars="Both">
                                                <telerik:RadGrid ID="GDSEARCH" runat="server" CellSpacing="0" GridLines="None" 
                                                    Skin="Sunset" Height="100%" 
                                                    Width="100%" AllowPaging="True" PageSize="5">
                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                            <HeaderStyle Width="20px" />
                                                        </RowIndicatorColumn>
                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                            <HeaderStyle Width="20px" />
                                                        </ExpandCollapseColumn>
                                                        <Columns>
                                                             <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="50px" />
                                                                        </telerik:GridButtonColumn>
                                                            <telerik:GridBoundColumn DataField="File_No" 
                                                                FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                                SortExpression="File_No" UniqueName="File_No">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="Type" 
                                                                FilterControlAltText="Filter Type column" HeaderText="Type" 
                                                                SortExpression="Type" UniqueName="Type">
                                                            </telerik:GridBoundColumn>                                                       
                                                          <telerik:GridBoundColumn DataField="Population" 
                                                                FilterControlAltText="Filter Type column" HeaderText="Population" 
                                                                SortExpression="Population" UniqueName="Population">
                                                            </telerik:GridBoundColumn>       
                                                            <telerik:GridBoundColumn DataField="Status" 
                                                                FilterControlAltText="Filter Status column" HeaderText="Status" 
                                                                SortExpression="Status" UniqueName="Status">
                                                            </telerik:GridBoundColumn>
                                                        </Columns>
                                                        <EditFormSettings>
                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                            </EditColumn>
                                                        </EditFormSettings>
                                                    </MasterTableView>
                                                    <FilterMenu EnableImageSprites="False">
                                                    </FilterMenu>
                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                    </HeaderContextMenu>
                                                </telerik:RadGrid>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">
                                            <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                Height="750px" style="font-weight: 700" Width="904px">
                                                &nbsp;<table style="width: 99%; height: 626px;">
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label10" runat="server" style="font-weight: 700" 
                                                                Text="Cluster Action"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadTextBox ID="txtaction" Runat="server" Font-Bold="True" 
                                                                Skin="Sunset" style="font-weight: 700" Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label31" runat="server" style="font-weight: 700" Text="Type"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadTextBox ID="txttype" Runat="server" Font-Bold="True" Skin="Sunset" 
                                                                Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label33" runat="server" Text="Proposer Name"></asp:Label>
                                                            &nbsp;</td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadTextBox ID="txtproposer" Runat="server" Font-Bold="True" 
                                                                Skin="Sunset" style="font-weight: 700" Width="250px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label66" runat="server" Text="File No"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadTextBox ID="txtfile" Runat="server" Font-Bold="True" Skin="Sunset" 
                                                                Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#666666" class="style8" colspan="4">
                                                            REGISTRATION</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label32" runat="server" Text="Receive Date"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadDatePicker ID="dtmem_rec" Runat="server" FocusedDate="2017-08-30" 
                                                                Font-Bold="True" MinDate="" SelectedDate="2017-08-30" Skin="Web20">
                                                                <calendar Skin="Sunset" usecolumnheadersasselectors="False" 
                                                                    userowheadersasselectors="False" viewselectortext="x">
                                                                </calendar>
                                                                <dateinput dateformat="dd/MM/yyyy" displaydateformat="dd/MM/yyyy" 
                                                                    selecteddate="2017-08-30">
                                                                </dateinput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label34" runat="server" Text="Receive From"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadTextBox ID="txtReceiveFrom" Runat="server" Font-Bold="True" 
                                                                Skin="Sunset" Width="250px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label59" runat="server" Text="Agent/Broker"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadComboBox ID="cboagent" Runat="server" AccessibilityMode="True" 
                                                                AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" 
                                                                Width="250px">
                                                            </telerik:RadComboBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label13" runat="server" Text="Premium Amt"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadNumericTextBox ID="txtpremium" Runat="server" Font-Bold="True" 
                                                                Skin="Sunset" Width="200px">
                                                            </telerik:RadNumericTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label36" runat="server" Text="Population/Members"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadNumericTextBox ID="txtpopulation" Runat="server" 
                                                                DataType="System.Int32" Font-Bold="True" Skin="Sunset" Width="200px">
                                                                <NumberFormat DecimalDigits="0" />
                                                            </telerik:RadNumericTextBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label35" runat="server" Text="Benefit"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadTextBox ID="txtbenefit" Runat="server" Font-Bold="True" 
                                                                Skin="Sunset" Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label15" runat="server" Text="Returned"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadTextBox ID="txtreturned" Runat="server" Font-Bold="True" 
                                                                Skin="Sunset" Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label18" runat="server" Text="Returned To"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadTextBox ID="txtreturnedto" Runat="server" Font-Bold="True" 
                                                                Skin="Sunset" Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label37" runat="server" Text="Return Date"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadDatePicker ID="dtreturndate" Runat="server" 
                                                                FocusedDate="2017-08-31" Font-Bold="True" MinDate="" SelectedDate="2017-08-31" 
                                                                Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy" 
                                                                    SelectedDate="2017-08-31">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label19" runat="server" Text="Comment"></asp:Label>
                                                        </td>
                                                        <td rowspan="2" style="width: 287px">
                                                            <telerik:RadTextBox ID="txtcomment" Runat="server" Font-Bold="True" 
                                                                Height="50px" Skin="Sunset" TextMode="MultiLine" Width="250px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label38" runat="server" Text="Return Receive date"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadDatePicker ID="dtreturnRec" Runat="server" FocusedDate="2017-08-28" 
                                                                Font-Bold="True" MinDate="" SelectedDate="2017-08-28" Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy" 
                                                                    SelectedDate="2017-08-28">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#666666" class="style8" colspan="4">
                                                            MEMBERSHIP</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label16" runat="server" Text="Executive Allocated"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadTextBox ID="txtallocatedto" Runat="server" Skin="Sunset" 
                                                                Width="250px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label21" runat="server" Text="Date Allocated"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadDatePicker ID="dtallocated" Runat="server" FocusedDate="2017-08-31" 
                                                                MinDate="" SelectedDate="2017-08-31" Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy" 
                                                                    SelectedDate="2017-08-31">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#666666" class="style8" colspan="4">
                                                            <asp:Label ID="Label64" runat="server" Text="CARD"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:CheckBox ID="chkrequest" runat="server" AutoPostBack="True" 
                                                                Text="Card Requested" />
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            &nbsp;</td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label47" runat="server" Text="Request Date"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadDatePicker ID="dtcardreqdate" Runat="server" 
                                                                FocusedDate="2017-08-31" MinDate="" SelectedDate="2017-08-31" Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy" 
                                                                    SelectedDate="2017-08-31">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                        <td style="width: 287px">
                                                            &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:CheckBox ID="chkreceived" runat="server" AutoPostBack="True" 
                                                                Text="Card Received" />
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            &nbsp;</td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label48" runat="server" Text="Receive Date"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadDatePicker ID="dtcardrecdate" Runat="server" 
                                                                FocusedDate="2017-08-31" MinDate="" SelectedDate="2017-08-31" Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy" 
                                                                    SelectedDate="2017-08-31">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:CheckBox ID="chkdispatched" runat="server" AutoPostBack="True" 
                                                                Text="Card Dispatched" />
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            &nbsp;</td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label49" runat="server" Text="Dispatch Date"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadDatePicker ID="dtcarddispdate" Runat="server" 
                                                                FocusedDate="2017-08-31" MinDate="" SelectedDate="2017-08-31" Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy" 
                                                                    SelectedDate="2017-08-31">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label50" runat="server" Text="Dispatch To"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadTextBox ID="txtcarddisto" Runat="server" Skin="Sunset" 
                                                                Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label39" runat="server" Text="Card Activated"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadTextBox ID="txtcardactivate" Runat="server" Skin="Sunset" 
                                                                Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td bgcolor="#999999" class="style8" colspan="4">
                                                            POLICY DOC</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:CheckBox ID="chkpolicydoc" runat="server" AutoPostBack="True" 
                                                                Text="Policy Doc Generated" />
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <asp:CheckBox ID="chkupdated" runat="server" AutoPostBack="True" 
                                                                Text="Closed" />
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label52" runat="server" Text="Generate Date"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadDatePicker ID="dtpoligendate" Runat="server" MinDate="" 
                                                                SelectedDate="2017-08-28" Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy" 
                                                                    SelectedDate="2017-08-28">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:CheckBox ID="chkpolicydisp" runat="server" AutoPostBack="True" 
                                                                Text="Policy Doc Dispatched" />
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            &nbsp;</td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label53" runat="server" Text="Dispatch Date"></asp:Label>
                                                        </td>
                                                        <td style="width: 287px">
                                                            <telerik:RadDatePicker ID="dtpolidispdate" Runat="server" 
                                                                FocusedDate="2017-08-31" MinDate="" Skin="Web20">
                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                </Calendar>
                                                                <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                                </DateInput>
                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                            </telerik:RadDatePicker>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:Label ID="Label54" runat="server" Text="Dispatch To"></asp:Label>
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <telerik:RadTextBox ID="txtpolicydisto" Runat="server" Skin="Sunset" 
                                                                Width="200px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            &nbsp;</td>
                                                        <td rowspan="4" style="width: 287px">
                                                            <telerik:RadTextBox ID="txtOther_Comments" Runat="server" Height="45px" 
                                                                Skin="Sunset" TextMode="MultiLine" Width="250px">
                                                            </telerik:RadTextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            <asp:CheckBox ID="chkfiling" runat="server" AutoPostBack="True" 
                                                                Text="Ready For Filing" />
                                                        </td>
                                                        <td class="style9" style="width: 80px">
                                                            <asp:CheckBox ID="chkfiled" runat="server" AutoPostBack="True" Text="Filed" />
                                                        </td>
                                                        <td class="style8" style="width: 176px">
                                                            &nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" style="width: 262px">
                                                            &nbsp;</td>
                                                        <td class="style9" style="width: 80px">
                                                            &nbsp;</td>
                                                        <td class="style8" style="width: 176px">
                                                            <asp:Label ID="Label55" runat="server" Text="General Comments"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" colspan="3">
                                                            <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="style8" colspan="3">
                                                            &nbsp;</td>
                                                        <td style="width: 287px">
                                                            &nbsp;</td>
                                                    </tr>
                                                </table>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                </table>
                    
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        
                    </td>
                </tr>
                <tr>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
    </asp:UpdatePanel>
</asp:Content>

