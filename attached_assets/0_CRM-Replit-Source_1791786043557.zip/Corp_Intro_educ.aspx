﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Corp_Intro_educ.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table>
                <tr>
                    <td align="center" bgcolor="#333333" style="height: 44px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="ACTIVITY TRACKING"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1235px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 3043px; font-weight: 700;">
                                        <asp:Panel ID="Panel21" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td style="width: 851px">
                                                        &nbsp;</td>
                                                    <td>
                                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Sunset" Width="225px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="search" runat="server" Skin="Simple" Text="Search">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: 700;">
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="0" Skin="Outlook" Width="1200px">
                                            <Tabs>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V1" 
                                                    Selected="True" SelectedIndex="0" Text="Introduction">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V2" 
                                                    Text="Member education">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V3" Text="Activity view">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 3043px; font-weight: 700;">
                                        <telerik:RadMultiPage ID="RadMultiPage1" runat="server" style="margin-top: 0px" 
                                            Width="1200px">
                                            <telerik:RadPageView ID="V1" runat="server" Selected="True">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                Height="100%" style="font-weight: 700" Width="1200px">
                                                                <table style="width: 99%">
                                                                    <tr>
                                                                        <td class="style8">
                                                                            <asp:Label ID="Label149" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                                                Text="Introduction"></asp:Label>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="style8">
                                                                            <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                                                                Width="1200px">
                                                                                <telerik:RadGrid ID="GDINTRO" runat="server" AllowPaging="True" 
                                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="50" Skin="Simple" 
                                                                                    Width="100%">
                                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="CORPORATE_ID">
                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        </RowIndicatorColumn>
                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        </ExpandCollapseColumn>
                                                                                        <Columns>
                                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                                UniqueName="Select">
                                                                                                <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                                <ItemStyle Width="100px" />
                                                                                            </telerik:GridButtonColumn>
                                                                                            <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                                FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                                ItemStyle-Wrap="False" SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                            <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                             <telerik:GridBoundColumn DataField="INTRO_DATE_DUE" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter INTRO_DATE_DUE column" HeaderText="INTRO_DATE_DUE" 
                                                                                                ItemStyle-Wrap="False" SortExpression="INTRO_DATE_DUE" UniqueName="INTRO_DATE_DUE">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                        </Columns>
                                                                                        <EditFormSettings>
                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                            </EditColumn>
                                                                                        </EditFormSettings>
                                                                                    </MasterTableView>
                                                                                    <PagerStyle Wrap="False" />
                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                    </FilterMenu>
                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                    </HeaderContextMenu>
                                                                                </telerik:RadGrid>
                                                                            </asp:Panel>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V2" runat="server">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td>
                                                            <asp:Label ID="Label150" runat="server" Font-Bold="True" 
                                                                Text="Member Education" Font-Size="Medium"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel2" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                Height="100%" style="font-weight: 700" Width="1200px">
                                                                <table style="width: 99%">
                                                                    <tr>
                                                                        <td class="style8">
                                                                            <asp:Panel ID="Panel20" runat="server" Height="100%" ScrollBars="Both" 
                                                                                Width="1200px">
                                                                                <telerik:RadGrid ID="GDMEM" runat="server" AllowPaging="True" 
                                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="50" Skin="Simple" 
                                                                                    Width="100%">
                                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        </RowIndicatorColumn>
                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        </ExpandCollapseColumn>
                                                                                        <Columns>
                                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                                UniqueName="Select">
                                                                                                <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                                <ItemStyle Width="100px" />
                                                                                            </telerik:GridButtonColumn>
                                                                                            <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                                FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                                ItemStyle-Wrap="False" SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                            <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                             <telerik:GridBoundColumn DataField="EDUC_DATE_DUE" 
                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                FilterControlAltText="Filter EDUC_DATE_DUE column" HeaderText="EDUC_DATE_DUE" 
                                                                                                ItemStyle-Wrap="False" SortExpression="EDUC_DATE_DUE" UniqueName="EDUC_DATE_DUE">
                                                                                                <ItemStyle Wrap="False" />
                                                                                            </telerik:GridBoundColumn>
                                                                                        </Columns>
                                                                                        <EditFormSettings>
                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                            </EditColumn>
                                                                                        </EditFormSettings>
                                                                                    </MasterTableView>
                                                                                    <PagerStyle Wrap="False" />
                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                    </FilterMenu>
                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                    </HeaderContextMenu>
                                                                                </telerik:RadGrid>
                                                                            </asp:Panel>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V3" runat="server" Selected="True" TabIndex="-1">
                                                <table style="width: 100%">
                                                    <tr>
                                                        <td>
                                                            <asp:Label ID="Label151" runat="server" Font-Bold="True" 
                                                                Text="View Activity" Font-Size="Medium"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1200px">
                                                                <telerik:RadGrid ID="RD_ACTIVITY" runat="server" AllowPaging="True" 
                                                                    CellSpacing="0" GridLines="None" Height="100%" PageSize="50" Skin="Simple" 
                                                                    Width="100%">
                                                                    <%-- ' [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]--%>
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="ACTIVITY_ID">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridBoundColumn DataField="ACTIVITY_ID" DataType="System.Decimal" 
                                                                                FilterControlAltText="Filter ACTIVITY_ID column" HeaderText="ACTIVITY_ID" 
                                                                                ReadOnly="True" SortExpression="ID" UniqueName="ACTIVITY_ID">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="CORPORATE_NAME" ItemStyle-Wrap="False" 
                                                                                SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                ItemStyle-Wrap="False" SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="ACTIVITY_NAME" 
                                                                                FilterControlAltText="Filter ACTIVITY_NAME column" HeaderText="ACTIVITY_NAME" 
                                                                                ItemStyle-Wrap="False" SortExpression="ACTIVITY_NAME" 
                                                                                UniqueName="ACTIVITY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="ACT_DATE" 
                                                                                FilterControlAltText="Filter ACT_DATE column" HeaderText="ACT_DATE" 
                                                                                ItemStyle-Wrap="False" SortExpression="ACT_DATE" UniqueName="ACT_DATE">
                                                                            </telerik:GridBoundColumn>                                                                        
                                                                            <telerik:GridBoundColumn DataField="FILE_NAME" 
                                                                                FilterControlAltText="Filter FILE_NAME column" HeaderText="FILE_NAME" 
                                                                                ItemStyle-Wrap="False" SortExpression="FILE_NAME" UniqueName="FILE_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="#" 
                                                                                SortExpression="TicketID">
                                                                                <ItemTemplate>
                                                                                    <asp:LinkButton ID="lnkView" runat="server" 
                                                                                        CommandArgument='<%# Eval("ACTIVITY_ID") %>' OnClick="View" Text="View"></asp:LinkButton>
                                                                                </ItemTemplate>
                                                                            </telerik:GridTemplateColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                                ScrollBars="Horizontal" Width="1116px">
                                                                <asp:Literal ID="ltEmbed" runat="server" />
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </telerik:RadPageView>
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-weight: 700;">
                                        <asp:Panel ID="Panel19" runat="server" BorderStyle="Solid" BorderWidth="1px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Label ID="Label154" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                            Text="Document upload"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label155" runat="server" Text="Period From"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" MinDate="" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label156" runat="server" Text="Period To"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="DTto" Runat="server" MinDate="" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label157" runat="server" Text="Activity"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        <telerik:RadComboBox ID="cboactivity" Runat="server" AccessibilityMode="True" 
                                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label158" runat="server" Text="Activity date"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="DTactivity" Runat="server" AutoPostBack="True" 
                                                            MinDate="" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput AutoPostBack="True" DateFormat="dd/MM/yyyy" 
                                                                DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="lblID" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        &nbsp;</td>
                                                    <td class="style8" style="width: 166px">
                                                        &nbsp;</td>
                                                    <td style="width: 287px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="lblIPolicy" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                    </td>
                                                    <td style="width: 169px">
                                                        <asp:Label ID="Label159" runat="server" Text="Minutes"></asp:Label>
                                                    </td>
                                                    <td class="style8" colspan="2">
                                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8">
                                                        &nbsp;</td>
                                                    <td style="width: 169px">
                                                        <asp:Label ID="Label160" runat="server" Text="Notes"></asp:Label>
                                                    </td>
                                                    <td class="style8" colspan="2" rowspan="2">
                                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="90px" 
                                                            Skin="Outlook" TextMode="MultiLine" Width="350px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8">
                                                        &nbsp;</td>
                                                    <td style="width: 169px">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="2">
                                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <telerik:RadButton ID="cmdsave" runat="server" Height="37px" Skin="Simple" 
                                                            Text="Save" Width="179px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td style="width: 287px">
                                                        &nbsp;&nbsp;<asp:HiddenField ID="HiddenField3" runat="server" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                </table>
              
  
        </ContentTemplate>
                          <Triggers>
        <asp:PostBackTrigger ControlID = "cmdsave" />

    </Triggers>
          </asp:UpdatePanel>
</asp:Content>


