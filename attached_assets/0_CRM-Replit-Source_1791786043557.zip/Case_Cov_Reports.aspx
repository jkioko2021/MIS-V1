﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Case_Cov_Reports.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="COV REPORTS" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td style="width: 1364px">
                                                    &nbsp;</td>
                                                <td style="width: 125px">
                                                    <asp:Label ID="Label156" runat="server" Text="Date From"></asp:Label>
                                                </td>
                                                <td style="width: 264px">
                                                    <telerik:RadDatePicker ID="dtfrom" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1364px">
                                                    &nbsp;</td>
                                                <td style="width: 125px">
                                                    <asp:Label ID="Label157" runat="server" Text="Date To"></asp:Label>
                                                </td>
                                                <td style="width: 264px">
                                                    <telerik:RadDatePicker ID="dtto" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1128px">
                                            <telerik:RadGrid ID="GDTracking_0" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Sunset" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                     
                                                        <telerik:GridBoundColumn DataField="Admission_status" 
                                                            FilterControlAltText="Filter Admission_status column" HeaderText="Status" 
                                                            SortExpression="Admission_status" UniqueName="Admission_status">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="cnt_Cases" 
                                                            FilterControlAltText="Filter cnt_Cases column" HeaderText="cnt_Cases" 
                                                            SortExpression="cnt_Cases" UniqueName="cnt_Cases">
                                                        </telerik:GridBoundColumn>                                                      
                                                        <telerik:GridBoundColumn DataField="Pre_Auth_Amt" 
                                                            FilterControlAltText="Filter Pre_Auth_Amt column" HeaderText="Pre_Auth_Amt" 
                                                            SortExpression="Pre_Auth_Amt" UniqueName="Pre_Auth_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Test_Cost" 
                                                            FilterControlAltText="Filter Test_Cost column" HeaderText="Test_Cost" 
                                                            SortExpression="Test_Cost" UniqueName="Test_Cost">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Treatment_Cost" 
                                                            FilterControlAltText="Filter Treatment_Cost column" HeaderText="Treatment_Cost" 
                                                            SortExpression="Treatment_Cost" UniqueName="Treatment_Cost">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Isolation_Cost" 
                                                            FilterControlAltText="Filter Isolation_Cost column" HeaderText="Isolation_Cost" 
                                                            SortExpression="Isolation_Cost" UniqueName="Isolation_Cost">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PPE_Cost" 
                                                            FilterControlAltText="Filter PPE_Cost column" HeaderText="PPE_Cost" 
                                                            SortExpression="PPE_Cost" UniqueName="PPE_Cost">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Other_Charges" 
                                                            FilterControlAltText="Filter Other_Charges column" HeaderText="Other_Charges" 
                                                            SortExpression="Other_Charges" UniqueName="Other_Charges">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_Actual_Cost" 
                                                            FilterControlAltText="Filter Total_Actual_Cost column" 
                                                            HeaderText="Total_Actual_Cost" SortExpression="Total_Actual_Cost" 
                                                            UniqueName="Total_Actual_Cost">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 193px">
                                                    <asp:Label ID="Label158" runat="server" Font-Bold="True" Font-Size="Small" 
                                                        Text="Select"></asp:Label>
                                                </td>
                                                <td style="width: 246px">
                                                    <telerik:RadComboBox ID="cboreposrt" Runat="server" Skin="Outlook" 
                                                        Width="250px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="IP Case List" Value="CL" />
                                                            <telerik:RadComboBoxItem runat="server" Text="OP Case List" Value="OP" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Case Summary-Per Member" 
                                                                Value="CM" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Case Summary-Admitted" 
                                                                Value="CA" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Case Summary-HomeCare" 
                                                                Value="CH" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Case Summary-Closed" Value="CC" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Cost Summary Per Provider" 
                                                                Value="SP" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Cost Summary-Admitted" 
                                                                Value="A" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Comorbidities Per Member" 
                                                                Value="C" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td style="width: 246px">
                                                    <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" 
                                                        Text="Export to Excel">
                                                    </telerik:RadButton>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
       
            </asp:UpdatePanel>
</asp:Content>




