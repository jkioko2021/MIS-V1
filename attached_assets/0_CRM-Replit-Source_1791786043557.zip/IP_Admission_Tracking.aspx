﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="IP_Admission_Tracking.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1141px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="CASE BOOKING"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 261px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" 
                                                        Width="200px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1139px">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                           <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="MEMBERSHIP NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" 
                                                            HeaderText="MEMBER_BIRTH_DATE" SortExpression="MEMBER_BIRTH_DATE" 
                                                            UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FIRST_ENROLLMENT_DATE" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter FIRST_ENROLLMENT_DATE column" 
                                                            HeaderText="JOIN_DATE" SortExpression="FIRST_ENROLLMENT_DATE" 
                                                            UniqueName="FIRST_ENROLLMENT_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                            HeaderText="POLICY_FROM" SortExpression="POLICY_VALID_FROM" 
                                                            UniqueName="POLICY_VALID_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                            HeaderText="POLICY_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                            UniqueName="POLICY_VALID_UPTO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                            FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                            SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                            FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                            SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                        </telerik:GridBoundColumn>
                                                       
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                                          <table style="99%: ;">
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label147" runat="server" style="font-weight: 700" 
                                                          Text="Member Info"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="height: 30px;">
                                                      <asp:Label ID="Label143" runat="server" Text="Member No"></asp:Label>
                                                  </td>
                                                  <td style="width: 19%; height: 30px;">
                                                      <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 13%; height: 30px;">
                                                      &nbsp;<asp:Label ID="Label144" runat="server" Text="Member Name"></asp:Label>
                                                  </td>
                                                  <td style="width: 44%; height: 30px;">
                                                      <telerik:RadTextBox ID="txtname" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 17%">
                                                      <asp:Label ID="Label146" runat="server" Text="Proposer Name"></asp:Label>
                                                  </td>
                                                  <td style="width: 19%">
                                                      <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 13%">
                                                      <asp:Label ID="Label145" runat="server" Text="Client Type"></asp:Label>
                                                  </td>
                                                  <td style="width: 44%">
                                                      <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Text="Corporate" Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Individual" Value="I" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 17%; height: 26px;">
                                                      <asp:Label ID="Label161" runat="server" Text="Mobile No"></asp:Label>
                                                  </td>
                                                  <td style="width: 19%; height: 26px;">
                                                      <telerik:RadTextBox ID="txtmobile" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 13%; height: 26px;">
                                                      <asp:Label ID="Label162" runat="server" Text="Email"></asp:Label>
                                                  </td>
                                                  <td style="height: 26px; width: 44%">
                                                      <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 17%; height: 26px;">
                                                      <asp:Label ID="Label189" runat="server" Text="Agent"></asp:Label>
                                                  </td>
                                                  <td style="width: 19%; height: 26px;">
                                                      <telerik:RadComboBox ID="cboAgent" Runat="server" AllowCustomText="True" 
                                                          Enabled="False" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboAgent" Text="Corporate" 
                                                                  Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cboAgent" Text="Individual" 
                                                                  Value="I" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 13%; height: 26px;">
                                                      <asp:Label ID="Label190" runat="server" Text="RM"></asp:Label>
                                                  </td>
                                                  <td style="height: 26px; width: 44%">
                                                      <telerik:RadComboBox ID="cborm" Runat="server" AllowCustomText="True" 
                                                          Enabled="False" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Corporate" 
                                                                  Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cborm" Text="Individual" 
                                                                  Value="I" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 17%; height: 26px;">
                                                      <asp:Label ID="Label187" runat="server" Text="Case No"></asp:Label>
                                                  </td>
                                                  <td style="width: 19%; height: 26px;">
                                                      <asp:Label ID="lblCode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                                  <td style="width: 13%; height: 26px;">
                                                      &nbsp;</td>
                                                  <td style="height: 26px; width: 44%">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                                          Width="1139px">
                                                          <telerik:RadGrid ID="GD_BENEFIT_0" runat="server" AllowPaging="True" 
                                                              CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                              Width="100%">
                                                              <MasterTableView AutoGenerateColumns="False">
                                                                  <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                  <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                  <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                      <HeaderStyle Width="20px" />
                                                                  </RowIndicatorColumn>
                                                                  <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                      <HeaderStyle Width="20px" />
                                                                  </ExpandCollapseColumn>
                                                                  <Columns>
                                                                      <telerik:GridBoundColumn DataField="BENEFIT" 
                                                                          FilterControlAltText="Filter BENEFIT column" HeaderText="BENEFIT" 
                                                                          SortExpression="BENEFIT" UniqueName="BENEFIT">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="LIMIT_AMT" DataFormatString="{0:### ##0.0}" 
                                                                          FilterControlAltText="Filter LIMIT_AMT column" HeaderText="LIMIT_AMT" 
                                                                          SortExpression="LIMIT_AMT" UniqueName="LIMIT_AMT">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="CONSUMED" DataFormatString="{0:### ##0.0}" 
                                                                          FilterControlAltText="Filter CONSUMED column" HeaderText="CONSUMED" 
                                                                          SortExpression="CONSUMED" UniqueName="CONSUMED">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="BALANCE" DataFormatString="{0:### ##0.0}" 
                                                                          FilterControlAltText="Filter BALANCE column" HeaderText="BALANCE" 
                                                                          SortExpression="BALANCE" UniqueName="BALANCE">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="WAITING_PERIOD" 
                                                                          FilterControlAltText="Filter WAITING_PERIOD column" HeaderText="WAITING_PERIOD" 
                                                                          SortExpression="WAITING_PERIOD" UniqueName="WAITING_PERIOD">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="FUND_MANAGE" 
                                                                          FilterControlAltText="Filter FUND_MANAGE column" HeaderText="FUND_MANAGE" 
                                                                          SortExpression="FUND_MANAGE" UniqueName="FUND_MANAGE">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                                          FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA DATE" 
                                                                          SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                                      </telerik:GridBoundColumn>
                                                                  </Columns>
                                                                  <EditFormSettings>
                                                                      <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                      </EditColumn>
                                                                  </EditFormSettings>
                                                              </MasterTableView>
                                                              <ItemStyle Wrap="False" />
                                                              <PagerStyle Wrap="False" />
                                                              <FilterMenu EnableImageSprites="False">
                                                              </FilterMenu>
                                                              <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                              </HeaderContextMenu>
                                                          </telerik:RadGrid>
                                                      </asp:Panel>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label194" runat="server" style="font-weight: 700" 
                                                          Text="Scheduled Cases"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                          Width="1139px">
                                                          <telerik:RadGrid ID="GDCASE" runat="server" AllowPaging="True" CellSpacing="0" 
                                                              GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                              <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_No">
                                                                  <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                  <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                      <HeaderStyle Width="20px" />
                                                                  </RowIndicatorColumn>
                                                                  <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                      <HeaderStyle Width="20px" />
                                                                  </ExpandCollapseColumn>
                                                                  <Columns>
                                                                      <telerik:GridButtonColumn CommandName="Select" 
                                                                          FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                          UniqueName="Select">
                                                                          <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                          <ItemStyle Width="50px" />
                                                                      </telerik:GridButtonColumn>
                                                                      <telerik:GridBoundColumn DataField="Case_No" 
                                                                          FilterControlAltText="Filter Case_No column" HeaderText="Case_No" 
                                                                          SortExpression="Case_No" UniqueName="Case_No">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Member_No" 
                                                                          FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                          SortExpression="Member_No" UniqueName="Member_No">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Admission_Dt" 
                                                                          DataFormatString="{0:yyyy-MM-dd}" 
                                                                          FilterControlAltText="Filter Admission_Dt column" HeaderText="Admission_Date" 
                                                                          SortExpression="Admission_Dt" UniqueName="Admission_Dt">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Hospital" 
                                                                          FilterControlAltText="Filter Hospital column" HeaderText="Hospital" 
                                                                          SortExpression="Hospital" UniqueName="Hospital">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Pri_Doctor" 
                                                                          FilterControlAltText="Filter Pri_Doctor column" HeaderText="Pri Doctor" 
                                                                          SortExpression="Pri_Doctor" UniqueName="Pri_Doctor">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Case_Status" 
                                                                          FilterControlAltText="Filter Case_Status column" HeaderText="Case Status" 
                                                                          SortExpression="Case_Status" UniqueName="Case_Status">
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Entered_by" 
                                                                          FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                          SortExpression="Entered_by" UniqueName="Entered_by">
                                                                      </telerik:GridBoundColumn>
                                                                  </Columns>
                                                                  <EditFormSettings>
                                                                      <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                      </EditColumn>
                                                                  </EditFormSettings>
                                                              </MasterTableView>
                                                              <FilterMenu EnableImageSprites="False">
                                                              </FilterMenu>
                                                              <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                              </HeaderContextMenu>
                                                          </telerik:RadGrid>
                                                      </asp:Panel>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                                          MultiPageID="RadMultiPage1" Skin="WebBlue" Width="97%" SelectedIndex="0">
                                                          <Tabs>
                                                              <telerik:RadTab runat="server" PageViewID="V1_1" Text="Case Booking" 
                                                                  Selected="True" SelectedIndex="0">
                                                              </telerik:RadTab>
                                                              <telerik:RadTab runat="server" PageViewID="V3" Text="Benefits" TabIndex="1">
                                                              </telerik:RadTab>
                                                              <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V4" 
                                                                  TabIndex="3" Text="Diax History">
                                                              </telerik:RadTab>
                                                              <telerik:RadTab runat="server" PageViewID="V2" Text="Costs Breakup" 
                                                                  TabIndex="4">
                                                              </telerik:RadTab>
                                                              <telerik:RadTab runat="server" PageViewID="V5" Text="Next Of Kin">
                                                              </telerik:RadTab>
                                                              <telerik:RadTab runat="server" PageViewID="V6" Text="Notes update">
                                                              </telerik:RadTab>
                                                          </Tabs>
                                                      </telerik:RadTabStrip>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="1139px" 
                                                          SelectedIndex="1">
                                                          <telerik:RadPageView ID="V1_1" runat="server" Selected="True">
                                                              <asp:Panel ID="Panel32" runat="server">
                                                                  <table style="width: 100%">
                                                                      <tr>
                                                                          <td colspan="4" bgcolor="#999999">
                                                                              <asp:Label ID="Label148" runat="server" style="font-weight: 700" 
                                                                                  Text="Case Info"></asp:Label>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 187px; height: 22px;">
                                                                              <asp:Label ID="Label163" runat="server" Text="Receive date/Time"></asp:Label>
                                                                          </td>
                                                                          <td style="width: 241px; height: 22px">
                                                                              <telerik:RadDateTimePicker ID="DtReceive" Runat="server" Skin="Simple">
                                                                                  <TimeView CellSpacing="-1">
                                                                                  </TimeView>
                                                                                  <TimePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                  <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                      UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                  </Calendar>
                                                                                  <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                  </DateInput>
                                                                                  <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                              </telerik:RadDateTimePicker>
                                                                          </td>
                                                                          <td style="width: 159px; height: 22px">
                                                                              <asp:Label ID="Label164" runat="server" Text="Mode"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 22px">
                                                                              <telerik:RadComboBox ID="cbomode" Runat="server" Skin="Outlook">
                                                                                  <Items>
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Call" Value="Call" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Email" Value="Email" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Walk-In" Value="Walk-In" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Whatsup" Value="Whatsup" />
                                                                                  </Items>
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 187px; height: 24px;">
                                                                              <asp:Label ID="Label149" runat="server" Text="Admission date"></asp:Label>
                                                                          </td>
                                                                          <td style="width: 241px; height: 24px">
                                                                              <telerik:RadDatePicker ID="dtadmin" Runat="server" Skin="Simple" 
                                                                                  style="margin-left: 0px">
                                                                                  <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                      UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                  </Calendar>
                                                                                  <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                  </DateInput>
                                                                                  <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                              </telerik:RadDatePicker>
                                                                          </td>
                                                                          <td style="width: 159px; height: 24px">
                                                                              <asp:Label ID="Label177" runat="server" Text="Discharge date"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 24px">
                                                                              <telerik:RadDatePicker ID="dtdisch" Runat="server" Skin="Simple" 
                                                                                  style="margin-left: 0px">
                                                                                  <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                      UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                  </Calendar>
                                                                                  <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                  </DateInput>
                                                                                  <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                              </telerik:RadDatePicker>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 187px; height: 22px;">
                                                                              <asp:Label ID="Label150" runat="server" Text="Hospital"></asp:Label>
                                                                          </td>
                                                                          <td style="width: 241px; height: 22px">
                                                                              <telerik:RadComboBox ID="cboProvi" Runat="server" AllowCustomText="True" 
                                                                                  MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                                                  <Items>
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboProvi" Text="Corporate" 
                                                                                          Value="C" />
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboProvi" Text="Individual" 
                                                                                          Value="I" />
                                                                                  </Items>
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                          <td style="width: 159px; height: 22px">
                                                                              <asp:Label ID="Label178" runat="server" Text="Attending Doctor"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 22px">
                                                                              <telerik:RadComboBox ID="cboDoc" Runat="server" AllowCustomText="True" 
                                                                                  MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                                                  <Items>
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboDoc" Text="Corporate" 
                                                                                          Value="C" />
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboDoc" Text="Individual" 
                                                                                          Value="I" />
                                                                                  </Items>
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 187px; height: 26px;">
                                                                              <asp:Label ID="Label179" runat="server" Text="Claim Type"></asp:Label>
                                                                          </td>
                                                                          <td style="width: 241px; height: 26px;">
                                                                              <telerik:RadComboBox ID="cboTYPE" Runat="server" Skin="Outlook">
                                                                                  <Items>
                                                                                      <telerik:RadComboBoxItem runat="server" Text="IP" Value="IP" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Day Case" Value="D" />
                                                                                  </Items>
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                          <td style="width: 159px; height: 26px;">
                                                                              &nbsp;</td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 187px; height: 35px;">
                                                                          </td>
                                                                          <td style="height: 35px" colspan="2">
                                                                              <telerik:RadButton ID="btnsave" runat="server" Skin="Simple" Text="Save" 
                                                                                  Width="150px">
                                                                              </telerik:RadButton>
                                                                          </td>
                                                                          <td style="height: 35px">
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 187px; height: 25px;">
                                                                              &nbsp;</td>
                                                                          <td colspan="2" style="height: 25px">
                                                                              <asp:Label ID="lblsave" runat="server" ForeColor="Red"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 25px">
                                                                              &nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td colspan="4">
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                  </table>
                                                              </asp:Panel>
                                                          </telerik:RadPageView>
                                                           <telerik:RadPageView ID="V2" runat="server" TabIndex="2">
                                                              <asp:Panel ID="Panel2" runat="server" Width="1140px">
                                                                  <table style="width: 100%">
                                                                      <tr>
                                                                          <td bgcolor="#999999" colspan="4">
                                                                              <asp:Label ID="Label182" runat="server" style="font-weight: 700" 
                                                                                  Text="Breakdown Items"></asp:Label>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              <asp:Label ID="Label183" runat="server" Text="Category"></asp:Label>
                                                                          </td>
                                                                          <td>
                                                                              <telerik:RadComboBox ID="cboCat" Runat="server" Skin="Outlook">
                                                                                  <Items>
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboCat" Text="Limit Letter" 
                                                                                          Value="L" />
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboCat" Text="Hospital" 
                                                                                          Value="H" />
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboCat" Text="Physician" 
                                                                                          Value="P" />
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboCat" Text="General surgeon" 
                                                                                          Value="GS" />
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboCat" Text="Anesthetist" 
                                                                                          Value="A" />
                                                                                      <telerik:RadComboBoxItem runat="server" Owner="cboCat" Text="Specialist" 
                                                                                          Value="S" />
                                                                                  </Items>
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                          <td style="width: 37px">
                                                                              &nbsp;</td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              <asp:Label ID="Label184" runat="server" Text="Provider"></asp:Label>
                                                                          </td>
                                                                          <td>
                                                                              <telerik:RadTextBox ID="txtprov_1" Runat="server" Skin="Outlook" Width="250px">
                                                                              </telerik:RadTextBox>
                                                                          </td>
                                                                          <td style="width: 37px">
                                                                              <telerik:RadButton ID="RadButton5" runat="server" Skin="Simple" Text="Search">
                                                                              </telerik:RadButton>
                                                                          </td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              &nbsp;</td>
                                                                          <td colspan="2">
                                                                              <telerik:RadGrid ID="GDPROV" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                  GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                  <MasterTableView AutoGenerateColumns="False" DataKeyNames="ORG_ID">
                                                                                      <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                      <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                          <HeaderStyle Width="20px" />
                                                                                      </RowIndicatorColumn>
                                                                                      <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                          <HeaderStyle Width="20px" />
                                                                                      </ExpandCollapseColumn>
                                                                                      <Columns>
                                                                                          <telerik:GridButtonColumn CommandName="Select" 
                                                                                              FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                                              UniqueName="Select">
                                                                                              <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                              <ItemStyle Width="50px" />
                                                                                          </telerik:GridButtonColumn>
                                                                                          <telerik:GridBoundColumn DataField="ORG_ID" 
                                                                                              FilterControlAltText="Filter ORG_ID column" HeaderText="ID" 
                                                                                              SortExpression="ORG_ID" UniqueName="ORG_ID">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="ORG_NAME" 
                                                                                              FilterControlAltText="Filter ORG_NAME column" HeaderText="Provider Name" 
                                                                                              SortExpression="ORG_NAME" UniqueName="ORG_NAME">
                                                                                          </telerik:GridBoundColumn>
                                                                                      </Columns>
                                                                                      <EditFormSettings>
                                                                                          <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                          </EditColumn>
                                                                                      </EditFormSettings>
                                                                                  </MasterTableView>
                                                                                  <ItemStyle Wrap="False" />
                                                                                  <FilterMenu EnableImageSprites="False">
                                                                                  </FilterMenu>
                                                                                  <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                  </HeaderContextMenu>
                                                                              </telerik:RadGrid>
                                                                          </td>
                                                                          <td>
                                                                              <asp:Label ID="lblid" runat="server" Visible="False"></asp:Label>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              <asp:Label ID="Label185" runat="server" Text="Auth Amount"></asp:Label>
                                                                          </td>
                                                                          <td>
                                                                              <telerik:RadNumericTextBox ID="txtauth_1" Runat="server" Culture="en-US" 
                                                                                  Skin="Outlook" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td style="width: 37px">
                                                                              &nbsp;</td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              <asp:Label ID="Label186" runat="server" Text="Notes"></asp:Label>
                                                                          </td>
                                                                          <td colspan="2" rowspan="3">
                                                                              <telerik:RadTextBox ID="txtnotes" Runat="server" Font-Size="Large" 
                                                                                  Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                  TextMode="MultiLine" Width="400px">
                                                                              </telerik:RadTextBox>
                                                                          </td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              &nbsp;</td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              &nbsp;</td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px; height: 35px">
                                                                          </td>
                                                                          <td style="width: 194px; height: 35px">
                                                                              <telerik:RadButton ID="RadButton6" runat="server" Skin="Simple" Text="Update" 
                                                                                  Width="105px">
                                                                              </telerik:RadButton>
                                                                          </td>
                                                                          <td style="width: 37px; height: 35px">
                                                                          </td>
                                                                          <td style="height: 35px">
                                                                              </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              &nbsp;</td>
                                                                          <td style="width: 194px">
                                                                              <asp:Label ID="lblProv" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                          </td>
                                                                          <td style="width: 37px">
                                                                              &nbsp;</td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td colspan="4">
                                                                              <telerik:RadGrid ID="GDLetter" runat="server" AllowPaging="True" 
                                                                                  CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="1135px">
                                                                                  <MasterTableView AutoGenerateColumns="False" DataKeyNames="Id">
                                                                                      <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                      <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                          <HeaderStyle Width="20px" />
                                                                                      </RowIndicatorColumn>
                                                                                      <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                          <HeaderStyle Width="20px" />
                                                                                      </ExpandCollapseColumn>
                                                                                      <Columns>
                                                                                          <telerik:GridButtonColumn CommandName="Select" 
                                                                                              FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                                              UniqueName="Select">
                                                                                              <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                              <ItemStyle Width="50px" />
                                                                                          </telerik:GridButtonColumn>
                                                                                          <telerik:GridBoundColumn DataField="Id" FilterControlAltText="Filter Id column" 
                                                                                              HeaderText="Id" SortExpression="Id" UniqueName="Id">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Prov_Type" 
                                                                                              FilterControlAltText="Filter Prov_Type column" HeaderText="Prov_Type" 
                                                                                              SortExpression="Prov_Type" UniqueName="Prov_Type">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Provider" 
                                                                                              FilterControlAltText="Filter Provider column" HeaderText="Provider Name" 
                                                                                              SortExpression="Provider" UniqueName="Provider">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Case_No" 
                                                                                              FilterControlAltText="Filter Case_No column" HeaderText="Case_No" 
                                                                                              SortExpression="Case_No" UniqueName="Case_No">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Pre_Auth_Amt" 
                                                                                              FilterControlAltText="Filter Pre_Auth_Amt column" HeaderText="Pre Amt" 
                                                                                              SortExpression="Pre_Auth_Amt" UniqueName="Pre_Auth_Amt">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Pre_Auth_Dt" 
                                                                                              FilterControlAltText="Filter Pre_Auth_Dt column" HeaderText="Pre_Auth Dt" 
                                                                                              SortExpression="Pre_Auth_Dt" UniqueName="Pre_Auth_Dt">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Pre_Auth_By" 
                                                                                              FilterControlAltText="Filter Pre_Auth_By column" HeaderText="Pre_Auth_By" 
                                                                                              SortExpression="Pre_Auth_By" UniqueName="Pre_Auth_By">
                                                                                          </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Letter_Gen" 
                                                                                              FilterControlAltText="Filter Letter_Gen column" HeaderText="Letter_Gen" 
                                                                                              SortExpression="Letter_Gen" UniqueName="Letter_Gen">
                                                                                          </telerik:GridBoundColumn>
                                                                                      </Columns>
                                                                                      <EditFormSettings>
                                                                                          <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                          </EditColumn>
                                                                                      </EditFormSettings>
                                                                                  </MasterTableView>
                                                                                  <ItemStyle Wrap="False" />
                                                                                  <FilterMenu EnableImageSprites="False">
                                                                                  </FilterMenu>
                                                                                  <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                  </HeaderContextMenu>
                                                                              </telerik:RadGrid>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td colspan="4">
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 108px">
                                                                              <telerik:RadButton ID="RadButton8" runat="server" Skin="Simple" Text="Generate">
                                                                              </telerik:RadButton>
                                                                          </td>
                                                                          <td style="width: 194px">
                                                                              <asp:Label ID="lblLetter" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                          </td>
                                                                          <td style="width: 37px">
                                                                              &nbsp;</td>
                                                                          <td>
                                                                              &nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td colspan="4">
                                                                              <asp:Panel ID="Panel40" runat="server" Height="100%" ScrollBars="Both" 
                                                                                  Width="1139px">
                                                                                  <telerik:RadGrid ID="GDDOC_NOTES" runat="server" AllowPaging="True" 
                                                                                      CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Sunset" 
                                                                                      Width="100%">
                                                                                      <MasterTableView AutoGenerateColumns="False">
                                                                                          <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                          <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                          </RowIndicatorColumn>
                                                                                          <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                          </ExpandCollapseColumn>
                                                                                          <Columns>
                                                                                              <telerik:GridBoundColumn DataField="Note_date" 
                                                                                                  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                  FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                                                                  ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                                                                  <ItemStyle Width="100px" />
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Note_From" 
                                                                                                  FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                                                                  ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                                                                  <ItemStyle Width="100px" />
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Note_Type" 
                                                                                                  FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type " 
                                                                                                  SortExpression="Note_Type" UniqueName="Note_Type">
                                                                                                  <ItemStyle Width="100px" />
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Notes" 
                                                                                                  FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                                                  SortExpression="Notes" UniqueName="Notes">
                                                                                              </telerik:GridBoundColumn>
                                                                                          </Columns>
                                                                                          <EditFormSettings>
                                                                                              <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                              </EditColumn>
                                                                                          </EditFormSettings>
                                                                                      </MasterTableView>
                                                                                      <ItemStyle Wrap="True" />
                                                                                      <FilterMenu EnableImageSprites="False">
                                                                                      </FilterMenu>
                                                                                      <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                      </HeaderContextMenu>
                                                                                  </telerik:RadGrid>
                                                                              </asp:Panel>
                                                                          </td>
                                                                      </tr>
                                                                  </table>
                                                              </asp:Panel>
                                                          </telerik:RadPageView>
                                                              <telerik:RadPageView ID="V3" runat="server" Width="1121px" 
                                                              TabIndex="3">
                                                <asp:Panel ID="Panel5" runat="server" Width="1140px">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td bgcolor="#999999">
                                                                <asp:Label ID="Label193" runat="server" style="font-weight: 700" 
                                                                    Text="Benefit Booking"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1139px">
                                                                    <telerik:RadGrid ID="GD_BENEFIT" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="BENEFIT">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                                    UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="BENEFIT" 
                                                                                    FilterControlAltText="Filter BENEFIT column" HeaderText="Benefit" 
                                                                                    SortExpression="BENEFIT" UniqueName="BENEFIT">
                                                                                </telerik:GridBoundColumn>
                                                                               
                                                                                <telerik:GridBoundColumn DataField="CONSUMED" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter CONSUMED column" HeaderText="Limit Amt" 
                                                                                    SortExpression="CONSUMED" UniqueName="CONSUMED">
                                                                                </telerik:GridBoundColumn>
                                                                             
                                                                               
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel35" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="width: 176px">
                                                                                <asp:Label ID="Label192" runat="server" Text="Benefit" Font-Bold="True" 
                                                                                    Font-Size="Medium"></asp:Label>
                                                                            </td>
                                                                            <td colspan="3">
                                                                                <asp:Label ID="lblbenefit" runat="server" Font-Size="Medium"></asp:Label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 176px; height: 31px;">
                                                                                <asp:Label ID="Label155" runat="server" Text="Limit Amount" Font-Size="Medium"></asp:Label>
                                                                                </td>
                                                                            <td style="width: 358px; height: 31px;">
                                                                                <telerik:RadNumericTextBox ID="txtauth" Runat="server" Culture="en-US" 
                                                                                    Skin="Outlook" Value="0" Width="125px">
                                                                                </telerik:RadNumericTextBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 31px;">
                                                                                </td>
                                                                            <td style="height: 31px">
                                                                                </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 176px; height: 39px;">
                                                                                </td>
                                                                            <td style="height: 39px;" colspan="3">
                                                                                <telerik:RadButton ID="RadButton7" runat="server" Skin="Simple" Text="Update" 
                                                                                    Width="105px">
                                                                                </telerik:RadButton>
                                                                                <asp:Label ID="lblsave_1" runat="server" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                                </td>
                                                                            <td style="height: 39px">
                                                                                </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="6">
                                                                                <asp:Panel ID="Panel36" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1139px">
                                                                                    <telerik:RadGrid ID="GD_BENEFIT_1" runat="server" AllowPaging="True" 
                                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                                        Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                <telerik:GridBoundColumn DataField="Benefit_Id" 
                                                                                                    FilterControlAltText="Filter Benefit_Id column" HeaderText="Benefit_Id" 
                                                                                                    SortExpression="Benefit_Id" UniqueName="Benefit_Id">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Benefit_Name" 
                                                                                                    FilterControlAltText="Filter Benefit_Name column" HeaderText="Benefit" 
                                                                                                    SortExpression="Benefit_Name" UniqueName="Benefit_Name">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Pre_auth_Amt" DataFormatString="{0:### ##0.0}" 
                                                                                                    FilterControlAltText="Filter Pre_auth_Amt column" HeaderText="Pre_auth_Amt" 
                                                                                                    SortExpression="Pre_auth_Amt" UniqueName="Pre_auth_Amt">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Pre_auth_By" 
                                                                                                    FilterControlAltText="Filter Booked_By column" HeaderText="Pre_auth_By" 
                                                                                                    SortExpression="Pre_auth_By" UniqueName="Pre_auth_By">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Pre_auth_Dt" 
                                                                                                    FilterControlAltText="Filter Pre_auth_Dt column" HeaderText="Pre_auth_Dt" 
                                                                                                    SortExpression="Pre_auth_Dt" UniqueName="Pre_auth_Dt">
                                                                                                </telerik:GridBoundColumn>
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <ItemStyle Wrap="False" />
                                                                                        <PagerStyle Wrap="False" />
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                                  <telerik:RadPageView ID="V4" runat="server" Width="1121px" TabIndex="4">
                                                <asp:Panel ID="Panel3" runat="server" Width="1140px">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td bgcolor="#999999">
                                                                <asp:Label ID="Label1" runat="server" style="font-weight: 700" 
                                                                    Text="DIAX Booking"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel7" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="height: 13px;">
                                                                                &nbsp;</td>
                                                                            <td style="width: 586px">
                                                                                <telerik:RadTextBox ID="txtDiag" Runat="server" Skin="Outlook" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                                <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Search">
                                                                                </telerik:RadButton>
                                                                            </td>
                                                                            <td style="width: 98px; height: 13px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 13px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px;">
                                                                                &nbsp;</td>
                                                                            <td>
                                                                                <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="100%">
                                                                                    <telerik:RadGrid ID="GDDIAG" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                        GridLines="None" Height="100%" PageSize="5" Skin="Simple" Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Disease_code">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                                    FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                                                    UniqueName="Select">
                                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                                    <ItemStyle Width="50px" />
                                                                                                </telerik:GridButtonColumn>
                                                                                                <telerik:GridBoundColumn DataField="Disease_code" 
                                                                                                    FilterControlAltText="Filter Disease_code column" HeaderText="Disease_code" 
                                                                                                    SortExpression="Disease_code" UniqueName="Disease_code">
                                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Discription" 
                                                                                                    FilterControlAltText="Filter Discription column" HeaderText="Discription" 
                                                                                                    SortExpression="Discription" UniqueName="Discription">
                                                                                                </telerik:GridBoundColumn>
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <ItemStyle Wrap="False" />
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                            <td colspan="2" style="width: 176px; height: 13px;">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 39px;">
                                                                                <asp:Label ID="Label166" runat="server" Text="Diagnosis Notes"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 586px; " rowspan="2">
                                                                                <telerik:RadTextBox ID="txtDiaxnotes" Runat="server" Height="100px" 
                                                                                    TextMode="MultiLine" Width="100%">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 39px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 39px;">
                                                                                &nbsp;</td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 39px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 39px;">
                                                                                &nbsp;</td>
                                                                            <td style="width: 586px; height: 39px;">
                                                                                <telerik:RadButton ID="RadButton2" runat="server" Skin="Simple" Text="Update" 
                                                                                    Width="105px">
                                                                                </telerik:RadButton>
                                                                                <asp:Label ID="lbldiax" runat="server" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                            </td>
                                                                            <td style="height: 39px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                <asp:Panel ID="Panel37" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1139px">
                                                                                    <telerik:RadGrid ID="GDCOMORM" runat="server" AllowPaging="True" 
                                                                                        CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="Id">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                <telerik:GridBoundColumn DataField="Id" FilterControlAltText="Filter Id column" 
                                                                                                    HeaderText="Id" SortExpression="Id" UniqueName="Id">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Dx_Date" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                    FilterControlAltText="Filter Dx_Date column" HeaderText="Dx_Date" 
                                                                                                    SortExpression="Dx_Date" UniqueName="Dx_Date">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Name" 
                                                                                                    FilterControlAltText="Filter Name column" HeaderText="Name" 
                                                                                                    SortExpression="Name" UniqueName="Name">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Other_Doctor" 
                                                                                                    FilterControlAltText="Filter Other_Doctor column" HeaderText="Provider" 
                                                                                                    SortExpression="Other_Doctor" UniqueName="Other_Doctor">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                    FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                    SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                                                                    ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                                                                    Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                                                    <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                                                    <ItemStyle CssClass="ButtonColumn" />
                                                                                                </telerik:GridButtonColumn>
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                <asp:Panel ID="Panel39" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1139px">
                                                                                    <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" 
                                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Sunset" 
                                                                                        Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                <telerik:GridBoundColumn DataField="Note_date" 
                                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                    FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                                                                    ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                                                                    <ItemStyle Width="100px" />
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Note_From" 
                                                                                                    FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                                                                    ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                                                                    <ItemStyle Width="100px" />
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Note_Type" 
                                                                                                    FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type " 
                                                                                                    SortExpression="Note_Type" UniqueName="Note_Type">
                                                                                                    <ItemStyle Width="100px" />
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Notes" 
                                                                                                    FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                                                    SortExpression="Notes" UniqueName="Notes">
                                                                                                </telerik:GridBoundColumn>
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <ItemStyle Wrap="True" />
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                                </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                              <telerik:RadPageView ID="V5" runat="server" Width="1121px" 
                                                              TabIndex="3">
                                                <asp:Panel ID="Panel4" runat="server" Width="1140px">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td bgcolor="#999999">
                                                                <asp:Label ID="Label2" runat="server" style="font-weight: 700" 
                                                                    Text="NEXT OF KIN "></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel10" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="width: 164px; height: 31px;">
                                                                                <asp:Label ID="Label3" runat="server" Font-Size="Small" Text="Name" 
                                                                                    Font-Bold="False"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 334px; height: 31px;">
                                                                                <telerik:RadTextBox ID="txtnokname" Runat="server" Skin="Outlook" Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 31px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 31px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 164px; height: 31px;">
                                                                                <asp:Label ID="Label5" runat="server" Font-Size="Small" Text="Relationship"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 334px; height: 31px;">
                                                                                <telerik:RadComboBox ID="cborela" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Father" Value="Father" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Mother" Value="Mother" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Spouse" Value="Spouse" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Other Relative" 
                                                                                            Value="Other Relative" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Other" Value="Other" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 31px;">
                                                                            </td>
                                                                            <td style="height: 31px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 164px; height: 31px;">
                                                                                <asp:Label ID="Label195" runat="server" Font-Size="Small" Text="Email"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 334px; height: 31px;">
                                                                                <telerik:RadTextBox ID="txtemail_nok" Runat="server" Skin="Outlook" 
                                                                                    Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 31px;">
                                                                                &nbsp;&nbsp;</td>
                                                                            <td style="height: 31px">
                                                                                &nbsp;&nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 164px; height: 31px;">
                                                                                <asp:Label ID="Label196" runat="server" Font-Size="Small" Text="Mobile"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 334px; height: 31px;">
                                                                                <telerik:RadTextBox ID="txtnokmobile" Runat="server" Skin="Outlook" 
                                                                                    Width="250px">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 31px;">
                                                                            </td>
                                                                            <td style="height: 31px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 164px; height: 31px;">
                                                                                <asp:CheckBox ID="chknotify" runat="server" Text="Notified" />
                                                                            </td>
                                                                            <td style="width: 334px; height: 31px;">
                                                                                <telerik:RadDateTimePicker ID="dtnokdate" Runat="server" Skin="Simple">
                                                                                    <TimeView CellSpacing="-1">
                                                                                    </TimeView>
                                                                                    <TimePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDateTimePicker>
                                                                            </td>
                                                                            <td style="width: 98px; height: 31px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 31px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 164px; height: 39px;">
                                                                            </td>
                                                                            <td colspan="3" style="height: 39px;">
                                                                                <telerik:RadButton ID="RadButton3" runat="server" Skin="Simple" Text="Update" 
                                                                                    Width="105px">
                                                                                </telerik:RadButton>
                                                                                <asp:Label ID="lblnok" runat="server" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                            </td>
                                                                            <td style="height: 39px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="6">
                                                                                <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                                                                    Width="1135px">
                                                                                    <telerik:RadGrid ID="GDNOK" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </RowIndicatorColumn>
                                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                <HeaderStyle Width="20px" />
                                                                                            </ExpandCollapseColumn>
                                                                                            <Columns>
                                                                                                <telerik:GridBoundColumn DataField="Nok_Id" 
                                                                                                    FilterControlAltText="Filter Nok_Id column" HeaderText="Nok_Id" 
                                                                                                    SortExpression="Nok_Id" UniqueName="Nok_Id">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Name" 
                                                                                                    FilterControlAltText="Filter Name column" HeaderText="Name" 
                                                                                                    SortExpression="Name" UniqueName="Name">
                                                                                                </telerik:GridBoundColumn>
                                                                                                  <telerik:GridBoundColumn DataField="Relation" 
                                                                                                    FilterControlAltText="Filter Relation column" HeaderText="Relation" 
                                                                                                    SortExpression="Relation" UniqueName="Relation">
                                                                                                </telerik:GridBoundColumn>
                                                                                                  <telerik:GridBoundColumn DataField="Mobile_no" 
                                                                                                    FilterControlAltText="Filter Mobile_no column" HeaderText="Mobile" 
                                                                                                    SortExpression="Mobile_no" UniqueName="Mobile_no">
                                                                                                </telerik:GridBoundColumn>
                                                                                                    <telerik:GridBoundColumn DataField="Email" 
                                                                                                    FilterControlAltText="Filter Email column" HeaderText="Email" 
                                                                                                    SortExpression="Email" UniqueName="Email">
                                                                                                </telerik:GridBoundColumn>
                                                                                                           <telerik:GridBoundColumn DataField="Notified" 
                                                                                                    FilterControlAltText="Filter Notified column" HeaderText="Notified" 
                                                                                                    SortExpression="Notified" UniqueName="Notified">
                                                                                                </telerik:GridBoundColumn>
                                                                                          
                                                                                                <telerik:GridBoundColumn DataField="Notify_By" 
                                                                                                    FilterControlAltText="Filter Notify_By column" HeaderText="Notified_By" 
                                                                                                    SortExpression="Notify_By" UniqueName="Notify_By">
                                                                                                </telerik:GridBoundColumn>
                                                                                                <telerik:GridBoundColumn DataField="Notify_date" 
                                                                                                    FilterControlAltText="Filter Notify_date column" HeaderText="Notify_date" 
                                                                                                    SortExpression="Notify_date" UniqueName="Notify_date">
                                                                                                </telerik:GridBoundColumn>
                                                                                            </Columns>
                                                                                            <EditFormSettings>
                                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                </EditColumn>
                                                                                            </EditFormSettings>
                                                                                        </MasterTableView>
                                                                                        <ItemStyle Wrap="False" />
                                                                                        <PagerStyle Wrap="False" />
                                                                                        <FilterMenu EnableImageSprites="False">
                                                                                        </FilterMenu>
                                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                        </HeaderContextMenu>
                                                                                    </telerik:RadGrid>
                                                                                </asp:Panel>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                                   <telerik:RadPageView ID="V6" runat="server" Width="1121px" TabIndex="4">
                                                <asp:Panel ID="Panel9" runat="server" Width="1140px">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td bgcolor="#999999">
                                                                <asp:Label ID="Label4" runat="server" style="font-weight: 700" 
                                                                    Text="Notes/Status Update "></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel12" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="height: 13px; width: 110px;">
                                                                                <asp:Label ID="Label197" runat="server" Text="Action"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 586px">
                                                                                <telerik:RadComboBox ID="cboaction" Runat="server" Skin="Outlook">
                                                                                    <Items>
                                                                                        <telerik:RadComboBoxItem runat="server" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Discharged" Value="D" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Admitted" Value="A" />
                                                                                        <telerik:RadComboBoxItem runat="server" Text="Notes Update" Value="N" />
                                                                                    </Items>
                                                                                </telerik:RadComboBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 13px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 13px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 13px; width: 110px;">
                                                                                <asp:Label ID="Label198" runat="server" Text="Date"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 586px">
                                                                                <telerik:RadDateTimePicker ID="dtaction" Runat="server" Skin="Simple">
                                                                                    <TimeView CellSpacing="-1">
                                                                                    </TimeView>
                                                                                    <TimePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDateTimePicker>
                                                                            </td>
                                                                            <td style="width: 98px; height: 13px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 13px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 39px; width: 110px;">
                                                                                <asp:Label ID="Label6" runat="server" Text="Notes"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 586px; " rowspan="2">
                                                                                <telerik:RadTextBox ID="txtnotesadm" Runat="server" Height="100px" 
                                                                                    TextMode="MultiLine" Width="100%">
                                                                                </telerik:RadTextBox>
                                                                            </td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 39px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 39px; width: 110px;">
                                                                                &nbsp;</td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                                &nbsp;</td>
                                                                            <td style="height: 39px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="height: 39px; width: 110px;">
                                                                                &nbsp;</td>
                                                                            <td style="width: 586px; height: 39px;">
                                                                                <telerik:RadButton ID="RadButton9" runat="server" Skin="Simple" Text="Update" 
                                                                                    Width="105px">
                                                                                </telerik:RadButton>
                                                                                <asp:Label ID="lblnotes" runat="server" ForeColor="Red"></asp:Label>
                                                                            </td>
                                                                            <td style="width: 98px; height: 39px;">
                                                                            </td>
                                                                            <td style="height: 39px">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="4">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                                      </telerik:RadMultiPage>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label188" runat="server" style="font-weight: 700" Text="Notes"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td colspan="4">
                                                      <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                                          Width="1140px">
                                                          <telerik:RadGrid ID="GDNOTES_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                              GridLines="None" Height="100%" PageSize="20" Skin="Sunset" Width="100%">
                                                              <MasterTableView AutoGenerateColumns="False">
                                                                  <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                  <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                  </RowIndicatorColumn>
                                                                  <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                  </ExpandCollapseColumn>
                                                                  <Columns>
                                                                      <telerik:GridBoundColumn DataField="Note_date" 
                                                                          DataFormatString="{0:yyyy-MM-dd}" 
                                                                          FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                                          ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                                          <ItemStyle Width="100px" />
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Note_From" 
                                                                          FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                                          ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                                          <ItemStyle Width="100px" />
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Note_Type" 
                                                                          FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type " 
                                                                          SortExpression="Note_Type" UniqueName="Note_Type">
                                                                          <ItemStyle Width="100px" />
                                                                      </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Notes" 
                                                                          FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                          SortExpression="Notes" UniqueName="Notes">
                                                                      </telerik:GridBoundColumn>
                                                                  </Columns>
                                                                  <EditFormSettings>
                                                                      <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                      </EditColumn>
                                                                  </EditFormSettings>
                                                              </MasterTableView>
                                                              <ItemStyle Wrap="True" />
                                                              <FilterMenu EnableImageSprites="False">
                                                              </FilterMenu>
                                                              <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                              </HeaderContextMenu>
                                                          </telerik:RadGrid>
                                                      </asp:Panel>
                                                  </td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>


