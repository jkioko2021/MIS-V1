﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()

            Str = ""

            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROVIDER_LIST]  WHERE  [TERMINATED]='NO' ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboprovider
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With
            With cboprovid
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With
            Str = ""
            MyDatatable = Nothing

            loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        'Dim PROCESSED As Integer = 0
        'Dim TO_FINANCE As Integer = 0
        Dim FILENO As String
        Dim app As Integer = 0



        Dim receivedate As String
        Try

            If cbotype.SelectedValue = "" Then
                lblerr.Text = "You have not selected the benefit type!"
                Exit Sub
            End If

            If HiddenField1.Value = "" Then

                Dim searchStr As String = ""
                Dim MyDBAction As New DataManagement
                Dim DEPART As String = ""

                Dim RandomClass As New Random()
                'Dim RandomNumber = RandomClass.Next(1, 99999)
                'FILENO = "C-" & RandomNumber
                Dim RandomNumber As Long = Now.Day & Now.Month & Now.Hour & Now.Minute & Now.Second


                lblfile.Text = "IP/OP-" & Month(Date.Now) & "-" & RandomNumber


                STS = 0
                MyDBAction.Register_Claims_rec(lblfile.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), cbotype.SelectedValue, txtinv_cnt.Text, txtinv_amt.Text, cboprovider.SelectedValue, Trim(txtProvider_Name.Text), txtcomment.Text, Session("username"), STS)

                'lblfile.Text = FILENO
                lblerr.Text = "Saved Successfully!"
                'cmdsave.Enabled = False
                HiddenField1.Value = ""
            Else
                STS = 1
                MyDBAction.Register_Claims_rec(lblfile.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), cbotype.SelectedValue, txtinv_cnt.Text, txtinv_amt.Text, cboprovider.SelectedValue, Trim(txtProvider_Name.Text), txtcomment.Text, Session("username"), STS)
                lblerr.Text = "Updated Successfully!"
                FILENO = ""
            End If
            loadGrid()
            cmdsave.Enabled = False
            'loadGrid_OTH(txtinv_no.Text)
            HiddenField1.Value = ""

            dtreceive.DbSelectedDate = Date.Now()
            cbotype.Text = ""
            txtProvider_Name.Text = ""
            HiddenField1.Value = ""
            lblfile.Enabled = False
            dtreceive.Enabled = False

            'txtbarcode.Text = ""

            txtcomment.Text = ""
            txtinv_amt.Text = ""
            txtinv_cnt.Text = ""


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT [ID],[FILE_NO],[RECEIVE_DT],[INVOICE_CNT],[INVOICE_AMT],[COMMENT] FROM [MISREPORTS].[dbo].[TBL_MIS_RECEIVED_CLAIM_REG] WHERE ACTIVE=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""

        cboprovider.SelectedValue = ""
        cboprovider.Text = ""
        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT [ID],[FILE_NO],[RECEIVE_DT],[CLAIM_TYPE],[INVOICE_CNT],[INVOICE_AMT],[PROVIDER_ID],[COMMENT],PROVIDER_NAME  FROM [MISREPORTS].[dbo].[TBL_MIS_RECEIVED_CLAIM_REG] WITH (NOLOCK) WHERE ID ='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then

                lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()

                'txtbarcode.Text = MyDatable.Rows(0).Item("BARCODE").ToString()
                cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                txtinv_cnt.Text = MyDatable.Rows(0).Item("INVOICE_CNT").ToString()
                txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                txtProvider_Name.Text = MyDatable.Rows(0).Item("PROVIDER_NAME").ToString()
                cboprovider.SelectedValue = MyDatable.Rows(0).Item("PROVIDER_ID").ToString()
                txtcomment.Text = MyDatable.Rows(0).Item("COMMENT").ToString()


                lblfile.Enabled = False
                dtreceive.Enabled = False


                'txtbarcode.Enabled = False
                cbotype.Enabled = False
                txtinv_cnt.Enabled = False

                txtinv_amt.Enabled = False
                txtcomment.Enabled = False

                cboprovider.Enabled = False

                txtcomment.Enabled = False


            End If
            HiddenField1.Value = 1
            Session("DAD_5") = Nothing

        End If
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If cboprovid.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [ID],[FILE_NO],[RECEIVE_DT],[INVOICE_CNT],[INVOICE_AMT],[COMMENT] FROM [MISREPORTS].[dbo].[TBL_MIS_RECEIVED_CLAIM_REG] WHERE ACTIVE=1 AND PROVIDER_ID = '" & Trim(cboprovid.SelectedValue) & "'"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT [ID],[FILE_NO],[RECEIVE_DT],[INVOICE_CNT],[INVOICE_AMT],[COMMENT] FROM [MISREPORTS].[dbo].[TBL_MIS_RECEIVED_CLAIM_REG] WHERE ACTIVE=1 AND FILE_NO = '" & Trim(cboprovid.Text) & "'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDSEARCH.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("ID").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim ID_N As Integer

            Try

                Dim MyDatable As New Data.DataTable


                SqlAction = "SELECT [ID],[FILE_NO] FROM [MISREPORTS].[dbo].[TBL_MIS_RECEIVED_CLAIM_REG] WHERE ACTIVE=1 AND ID = '" & HiddenField1.Value & "'"


                MyDataTable = TryCast(MyDBAction.DBAction(MySqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDataTable.Rows.Count > 0 Then
                    File_No = MyDataTable.Rows(0).Item("[ID]")

                End If
            Catch ex As Exception

            End Try

            'AUDIT TRAIL-------
            Dim audit As New DataManagement
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Delete Claim register", "Successfully Deleted File :- File deleted is: FleNO - " & File_No & ", proposer - " & Proposer_Name & ".", _
            Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            '----END AUDIT TRAIL-----


            UpdateRecord("Delete from  [MISREPORTS].[dbo].TBL_MIS_RECEIVED_CLAIM_REG where ID= '" & HiddenField1.Value.ToString & "'")

            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid()

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        cmdsave.Enabled = True
        lblfile.Enabled = True
        dtreceive.Enabled = True

        'txtbarcode.Enabled = True
        cbotype.Enabled = True
        txtinv_cnt.Enabled = True


        txtcomment.Enabled = True
        txtinv_amt.Enabled = True
        cboprovider.Enabled = True

        txtinv_amt.Enabled = True
        txtcomment.Enabled = True


        txtinv_amt.Enabled = True


    End Sub

    Protected Sub cmdnew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdnew.Click
        HiddenField1.Value = ""
        cmdsave.Enabled = True
        lblfile.Enabled = False
        dtreceive.Enabled = True

        'txtbarcode.Text = ""
        cbotype.Text = ""
        txtinv_cnt.Text = ""


        txtcomment.Text = ""
        txtinv_amt.Text = ""

        txtinv_amt.Text = ""
        txtcomment.Text = ""


        txtinv_amt.Text = ""

        'txtbarcode.Enabled = True
        cmdsave.Enabled = True
        lblfile.Enabled = True
        dtreceive.Enabled = True

        'txtbarcode.Enabled = True
        cbotype.Enabled = True
        txtinv_cnt.Enabled = True


        txtcomment.Enabled = True
        txtinv_amt.Enabled = True
        cboprovider.Enabled = True

        txtinv_amt.Enabled = True
        txtcomment.Enabled = True


        txtinv_amt.Enabled = True


        txtinv_amt.Enabled = True

    End Sub

    Protected Sub cboprovider_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboprovider.SelectedIndexChanged
        txtProvider_Name.Text = cboprovider.Text
    End Sub
End Class
