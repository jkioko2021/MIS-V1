﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Business_Allocated_Clapi.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="MEMBERSHIP UPDATE-INVOICE" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td style="width: 1025px" align="right">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" AllowCustomText="True" 
                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Text="File No." Value="F" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 264px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Sunset" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search" Skin="Simple">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="FILE_NO" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    &nbsp;</td>
                                                <td style="width: 264px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Label ID="Label175" runat="server" style="font-weight: 700" 
                                                        Text="Business update"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTracking" runat="server" AllowPaging="True" ShowFooter="true"
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Sunset" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                                    <telerik:GridBoundColumn DataField="Receive_dt" 
                                                                        FilterControlAltText="Filter Receive_dt column" HeaderText="Receive_dt" 
                                                                        SortExpression="Receive_dt" UniqueName="Receive_dt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Allocate_dt" 
                                                                        FilterControlAltText="Filter Allocate_dt column" HeaderText="Allocate_dt" 
                                                                        SortExpression="Allocate_dt" UniqueName="Allocate_dt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="File_No" 
                                                                        FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                                        SortExpression="File_No" UniqueName="File_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                        FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                        SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Client_Type" 
                                                                        FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                        SortExpression="Client_Type" UniqueName="Client_Type">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Business_Type" 
                                                                        FilterControlAltText="Filter Business_Type column" HeaderText="Type" 
                                                                        SortExpression="Business_Type" UniqueName="Business_Type">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="File_Status" 
                                                                        FilterControlAltText="Filter File_Status column" HeaderText="Status" 
                                                                        SortExpression="File_Status" UniqueName="File_Status">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Allocated_to" 
                                                                        FilterControlAltText="Filter Allocated_to column" HeaderText="Allocated_to" 
                                                                        SortExpression="Allocated_to" UniqueName="Allocated_to">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Walk_in_Client" 
                                                                        FilterControlAltText="Filter Walk_in_Client column" HeaderText="Walk_in" 
                                                                        SortExpression="Walk_in_Client" UniqueName="Walk_in_Client">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Lateral_Movement" 
                                                                        FilterControlAltText="Filter Lateral_Movement column" HeaderText="Waiver" 
                                                                        SortExpression="Lateral_Movement" UniqueName="Lateral_Movement">
                                                                    </telerik:GridBoundColumn>
                                                                         <telerik:GridBoundColumn DataField="Product" 
                                                                        FilterControlAltText="Filter Product column" HeaderText="Product" 
                                                                        SortExpression="Product" UniqueName="Product">
                                                                    </telerik:GridBoundColumn>
                                                                           <telerik:GridBoundColumn DataField="Syst" 
                                                                        FilterControlAltText="Filter Syst column" HeaderText="System" 
                                                                        SortExpression="Syst" UniqueName="Syst">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="0" Skin="Sunset" Width="100%">
                                            <Tabs>
                                                <telerik:RadTab runat="server" Text="Register" Selected="True" 
                                                    SelectedIndex="0">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Text="Documentation">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V3" Text="Payment">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V4" Text="AAR Protect">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Text="Member List" PageViewID="V5">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="1100px">
                                            <telerik:RadPageView ID="V1" runat="server" Selected="True">
                                                <asp:Panel ID="Panel29" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td bgcolor="#999999" colspan="4">
                                                                <asp:Label ID="Label148" runat="server" Text="Details"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label32" runat="server" Text="Receive Date"></asp:Label>
                                                            </td>
                                                            <td style="width: 172px">
                                                                <telerik:RadDatePicker ID="dtreceivedate" Runat="server" Enabled="False" 
                                                                    MinDate="" Skin="Web20">
                                                                    <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                    </Calendar>
                                                                    <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                                    </DateInput>
                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                </telerik:RadDatePicker>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label149" runat="server" Text="Client Type"></asp:Label>
                                                            </td>
                                                            <td style="width: 172px">
                                                                <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Sunset" Width="190px">
                                                                    <Items>
                                                                        <telerik:RadComboBoxItem runat="server" />
                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboclient" Text="Retail" 
                                                                            Value="R" />
                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboclient" Text="SME" 
                                                                            Value="S" />
                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboclient" Text="Corporate" 
                                                                            Value="C" />
                                                                    </Items>
                                                                </telerik:RadComboBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label10" runat="server" Text="Business Type"></asp:Label>
                                                            </td>
                                                            <td style="width: 172px">
                                                                <telerik:RadComboBox ID="cboBusiness" Runat="server" MarkFirstMatch="True" 
                                                                    Skin="Sunset" Width="190px">
                                                                    <Items>
                                                                        <telerik:RadComboBoxItem runat="server" />
                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" Text="New" 
                                                                            Value="N" />
                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" Text="Renewal" 
                                                                            Value="R" />
                                                                        <telerik:RadComboBoxItem runat="server" Text="Addon" Value="A" />
                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" Text="Termination" 
                                                                            Value="T" />
                                                                        <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" 
                                                                            Text="Reinstatement" Value="RT" />
                                                                        <telerik:RadComboBoxItem runat="server" Text="Category Change" Value="CC" />
                                                                        <telerik:RadComboBoxItem runat="server" Text="Premium Recon" Value="PR" />
                                                                        <telerik:RadComboBoxItem runat="server" Text="Nill_Endr" Value="NE" />
                                                                        <telerik:RadComboBoxItem runat="server" Text="Fund_Topup" Value="FT" />
                                                                        <telerik:RadComboBoxItem runat="server" Text="Suspension" Value="SU" />
                                                                        <telerik:RadComboBoxItem runat="server" Text="Lift Suspension" Value="LS" />
                                                                    </Items>
                                                                </telerik:RadComboBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label30" runat="server" Text="Proposer Name"></asp:Label>
                                                            </td>
                                                            <td>
                                                                <telerik:RadTextBox ID="txtProposer" Runat="server" Skin="Sunset" Width="250px">
                                                                </telerik:RadTextBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label142" runat="server" Text="Family Code"></asp:Label>
                                                            </td>
                                                            <td style="width: 172px">
                                                                <telerik:RadTextBox ID="txtFamily" Runat="server" Skin="Sunset" Width="150px">
                                                                </telerik:RadTextBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label14" runat="server" Text="Agent/Broker"></asp:Label>
                                                            </td>
                                                            <td style="width: 172px">
                                                                <telerik:RadComboBox ID="cboagent" Runat="server" AccessibilityMode="True" 
                                                                    AllowCustomText="True" MarkFirstMatch="True" Skin="Sunset" Width="300px">
                                                                </telerik:RadComboBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                &nbsp;</td>
                                                            <td>
                                                                <asp:CheckBox ID="chkmtiba" runat="server" Text="Is Mtiba" />
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label13" runat="server" Text="Premium Amt"></asp:Label>
                                                            </td>
                                                            <td>
                                                                <telerik:RadNumericTextBox ID="txtpremium" Runat="server" Culture="en-US" 
                                                                    Skin="Sunset" Value="0" Width="200px">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label169" runat="server" Text="Cheque/EFT No/Mpesa"></asp:Label>
                                                            </td>
                                                            <td>
                                                                <telerik:RadTextBox ID="txtrefno" Runat="server" Skin="Sunset" Width="250px">
                                                                </telerik:RadTextBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label172" runat="server" Text="Amt To Receipt"></asp:Label>
                                                            </td>
                                                            <td>
                                                                <telerik:RadNumericTextBox ID="txtreceiptamt" Runat="server" Culture="en-US" 
                                                                    Skin="Sunset" Value="0" Width="200px">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                <asp:Label ID="Label154" runat="server" Text="Benefit Verified"></asp:Label>
                                                            </td>
                                                            <td>
                                                                <asp:Label ID="LBLBEN" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                                    style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 158px">
                                                                &nbsp;</td>
                                                            <td>
                                                                <asp:CheckBox ID="chkwaiver" runat="server" Font-Bold="True" Font-Size="Small" 
                                                                    Text="New Waiver-Lateral Movement" />
                                                            </td>
                                                            <td style="width: 155px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <hr style="width: 1128px" />
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V2" runat="server" Width="1144px">
                                                <asp:Panel ID="Panel2" runat="server">
                                                    <table style="width: 99%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label147" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1100px">
                                                                    <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                            
                                                                                <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                                    FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                                    SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="File_No" 
                                                                                    FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                                    SortExpression="File_No" UniqueName="File_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                                    FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                                    SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                                    FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                                    SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="File_Name" 
                                                                                    FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                                    SortExpression="File_Name" UniqueName="File_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                     <telerik:GridBoundColumn DataField="Doc_Ref" 
                                                                                    FilterControlAltText="Filter Doc_Ref column" HeaderText="Doc_Ref" 
                                                                                    SortExpression="Doc_Ref" UniqueName="Doc_Ref">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Upload_By" 
                                                                                    FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                                    SortExpression="Upload_By" UniqueName="Upload_By">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                                    SortExpression="DOC_ID">
                   <ItemTemplate>
                  <asp:LinkButton ID="lnkDownload" runat="server" Text="Download" OnClick="DownloadFile"
                    CommandArgument='<%# Eval("DOC_ID") %>'></asp:LinkButton>
                  </ItemTemplate>
                                                                                </telerik:GridTemplateColumn>
                                                                                  <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                                        ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                                        Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                        <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                        <ItemStyle CssClass="ButtonColumn" />
                                                                    </telerik:GridButtonColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                                    ScrollBars="Horizontal" Width="1071px">
                                                                    <asp:Literal ID="ltEmbed" runat="server" />
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="height: 17px;">
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V3" runat="server" Width="1144px">
                                                <asp:Panel ID="Panel3" runat="server">
                                                    <table style="width: 99%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label1" runat="server" Font-Bold="True" Text="Payment Details"></asp:Label>
                                                                <asp:Button ID="Button1" runat="server" Text="Button" />
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel32" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1128px">
                                                                    <telerik:RadGrid ID="GD_Pay" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Sunset" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="File_No" 
                                                                                    FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                                                    SortExpression="File_No" UniqueName="File_No">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                    FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                    SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Client_Type" 
                                                                                    FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                                    SortExpression="Client_Type" UniqueName="Client_Type">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter Premium column" HeaderText="Premium" 
                                                                                    SortExpression="Premium" UniqueName="Premium">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Paid_Amt" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid_Amt" 
                                                                                    SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Pay_Ref_No" 
                                                                                    FilterControlAltText="Filter Pay_Ref_No column" HeaderText="Pay_Ref_No" 
                                                                                    SortExpression="Pay_Ref_No" UniqueName="Pay_Ref_No">
                                                                                </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="File_Status" 
                                                                                    FilterControlAltText="Filter File_Status column" HeaderText="File_Status" 
                                                                                    SortExpression="File_Status" UniqueName="File_Status">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label173" runat="server" Text="Total Paid Amt:"></asp:Label>
                                                                &nbsp;<telerik:RadNumericTextBox ID="txtpaid" Runat="server" Culture="en-US" 
                                                                    Skin="Sunset" Value="0" Width="200px">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                              <telerik:RadPageView ID="V4" runat="server" Width="1144px">
                                                <asp:Panel ID="Panel4" runat="server">
                                                    <table style="width: 99%">
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label2" runat="server" Font-Bold="True" Text="AAR Protect"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Panel ID="Panel5" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1128px">
                                                                    <telerik:RadGrid ID="GD_PROTECT" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Sunset" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>

                                                                                <telerik:GridBoundColumn DataField="Payment_Unique_ID" 
                                                                                    FilterControlAltText="Filter Payment_Unique_ID column" HeaderText="File_No" 
                                                                                    SortExpression="Payment_Unique_ID" UniqueName="Payment_Unique_ID">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Application_ID" 
                                                                                    FilterControlAltText="Filter Application_ID column" HeaderText="Application_ID" 
                                                                                    SortExpression="Application_ID" UniqueName="Application_ID">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="Application_Date" 
                                                                                    FilterControlAltText="Filter Application_Date column" HeaderText="Application_Date" 
                                                                                    SortExpression="Application_Date" UniqueName="Application_Date">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ID_Number" 
                                                                                    FilterControlAltText="Filter ID_Number column" HeaderText="ID_Number" 
                                                                                    SortExpression="ID_Number" UniqueName="ID_Number">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="Name" 
                                                                                    FilterControlAltText="Filter Name column" HeaderText="Name" 
                                                                                    SortExpression="Name" UniqueName="Name">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="KRA_Pin" 
                                                                                    FilterControlAltText="Filter KRA_Pin column" HeaderText="KRA_Pin" 
                                                                                    SortExpression="KRA_Pin" UniqueName="KRA_Pin">
                                                                                </telerik:GridBoundColumn>
                                                                                             <telerik:GridBoundColumn DataField="Gender" 
                                                                                    FilterControlAltText="Filter Gender column" HeaderText="Gender" 
                                                                                    SortExpression="Gender" UniqueName="Gender">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Email" 
                                                                                    FilterControlAltText="Filter Email column" HeaderText="Email" 
                                                                                    SortExpression="Email" UniqueName="Email">
                                                                                </telerik:GridBoundColumn>
                                                                                            <telerik:GridBoundColumn DataField="Phone" 
                                                                                    FilterControlAltText="Filter Phone column" HeaderText="Phone" 
                                                                                    SortExpression="Phone" UniqueName="Phone">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Period" 
                                                                                    FilterControlAltText="Filter Period column" HeaderText="Period" 
                                                                                    SortExpression="Period" UniqueName="Period">
                                                                                </telerik:GridBoundColumn>
                                                                                           <telerik:GridBoundColumn DataField="Dob" 
                                                                                    FilterControlAltText="Filter Dob column" HeaderText="Dob" 
                                                                                    SortExpression="Dob" UniqueName="Dob">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Agent_Name" 
                                                                                    FilterControlAltText="Filter Agent_Name column" HeaderText="Agent_Name" 
                                                                                    SortExpression="Agent_Name" UniqueName="Agent_Name">
                                                                                </telerik:GridBoundColumn>
                                                                                       <telerik:GridBoundColumn DataField="Next_of_Kin" 
                                                                                    FilterControlAltText="Filter Next_of_Kin column" HeaderText="Next_of_Kin" 
                                                                                    SortExpression="Next_of_Kin" UniqueName="Next_of_Kin">
                                                                                </telerik:GridBoundColumn>                                                                            
                                                                                <telerik:GridBoundColumn DataField="Limit" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter Limit column" HeaderText="Limit" 
                                                                                    SortExpression="Limit" UniqueName="Limit">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="Premium_Amount" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter Premium_Amount column" HeaderText="Premium_Amount" 
                                                                                    SortExpression="Premium_Amount" UniqueName="Premium_Amount">
                                                                                </telerik:GridBoundColumn>                                                                              
                                                                                <telerik:GridBoundColumn DataField="Amount_Paid" DataFormatString="{0:### ##0.0}" 
                                                                                    FilterControlAltText="Filter Amount_Paid column" HeaderText="Amount_Paid" 
                                                                                    SortExpression="Amount_Paid" UniqueName="Amount_Paid">
                                                                                </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Cover_Start_Date" 
                                                                                    FilterControlAltText="Filter Cover_Start_Date column" HeaderText="Start_Date" 
                                                                                    SortExpression="Cover_Start_Date" UniqueName="Cover_Start_Date">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="[Cover_ End_Date]" 
                                                                                    FilterControlAltText="Filter Cover_End_Date column" HeaderText="End_Date" 
                                                                                    SortExpression="Cover_End_Date" UniqueName="Cover_End_Date">
                                                                                </telerik:GridBoundColumn>
                                                                               
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <asp:Label ID="Label3" runat="server" Text="Total Paid Amt:"></asp:Label>
                                                                &nbsp;<telerik:RadNumericTextBox ID="RadNumericTextBox1" Runat="server" Culture="en-US" 
                                                                    Skin="Sunset" Value="0" Width="200px">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>  
                                            <telerik:RadPageView ID="V5" runat="server" Width="1144px">

                                                <table style="width: 100%">
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel35" runat="server" Height="100%">
                                                                <table style="width: 100%">
                                                                    <tr>
                                                                        <td>
                                                                            <asp:Label ID="Label177" runat="server" style="font-weight: 700" 
                                                                                Text="Client Type"></asp:Label>
                                                                        </td>
                                                                        <td style="width: 271px">
                                                                            <telerik:RadComboBox ID="cbotype" Runat="server" AutoPostBack="True">
                                                                                <Items>
                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbotype" Text="Retail" 
                                                                                        Value="R" />
                                                                                    <telerik:RadComboBoxItem runat="server" Text="Corporate/SME" Value="C" />
                                                                                </Items>
                                                                            </telerik:RadComboBox>
                                                                        </td>
                                                                        <td>
                                                                            &nbsp;</td>
                                                                        <td>
                                                                            &nbsp;</td>
                                                                        <td>
                                                                            &nbsp;</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="height: 36px">
                                                                            <asp:Label ID="Label139" runat="server" style="font-weight: 700" Text="Select"></asp:Label>
                                                                        </td>
                                                                        <td style="width: 271px; height: 36px">
                                                                            <telerik:RadComboBox ID="cbosearch_1" Runat="server" AutoPostBack="True">
                                                                                <Items>
                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Family Code" 
                                                                                        Value="F" />
                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" 
                                                                                        Text="Proposer Name" Value="PN" />
                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Policy Code" 
                                                                                        Value="PC" />
                                                                                </Items>
                                                                            </telerik:RadComboBox>
                                                                        </td>
                                                                        <td style="height: 36px">
                                                                            <telerik:RadTextBox ID="TXTSEARCH_1" Runat="server" 
                                                                                Skin="Outlook" Width="250px">
                                                                            </telerik:RadTextBox>
                                                                        </td>
                                                                        <td style="height: 36px">
                                                                            <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                                                Width="157px">
                                                                            </telerik:RadButton>
                                                                        </td>
                                                                        <td style="height: 36px">
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1142px">
                                                                <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                                Text="Select" UniqueName="Select">
                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                <ItemStyle Width="50px" />
                                                                            </telerik:GridButtonColumn>
                                                                            <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                UniqueName="PROPOSER_DISPLAY_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="AGENT" 
                                                                                FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                                                SortExpression="AGENT" UniqueName="AGENT">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Panel ID="Panel14" runat="server" Height="100%" ScrollBars="Both" 
                                                                Width="1142px">
                                                                <telerik:RadGrid ID="GDMEM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                    GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                    <MasterTableView AutoGenerateColumns="False" 
                                                                        DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </RowIndicatorColumn>
                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                            <HeaderStyle Width="20px" />
                                                                        </ExpandCollapseColumn>
                                                                        <Columns>
                                                                        
                                                                            <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                                FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                                                HeaderText="MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                                                UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter MEMBER_BIRTH_DATE column" HeaderText="DOB" 
                                                                                SortExpression="MEMBER_BIRTH_DATE" UniqueName="MEMBER_BIRTH_DATE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="FIRST_ENROLLMENT_DATE" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter FIRST_ENROLLMENT_DATE column" HeaderText="JOIN DT" 
                                                                                SortExpression="FIRST_ENROLLMENT_DATE" UniqueName="FIRST_ENROLLMENT_DATE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter POLICY_VALID_FROM column" HeaderText="PERIOD_FROM" 
                                                                                SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                FilterControlAltText="Filter POLICY_VALID_UPTO column" HeaderText="PERIOD_TO" 
                                                                                SortExpression="POLICY_VALID_UPTO" UniqueName="POLICY_VALID_UPTO">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                                                FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                                                SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                                                UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="RELATION" 
                                                                                FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                SortExpression="RELATION" UniqueName="RELATION">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                                FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                                                SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                                                FilterControlAltText="Filter POLICY_STATUS column" HeaderText="POLICY_STATUS" 
                                                                                SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                                                FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                                                SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                                                FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                                                SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                                                FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                                                SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                                            </telerik:GridBoundColumn>
                                                                            <telerik:GridBoundColumn DataField="ID_DOC_NO" 
                                                                                FilterControlAltText="Filter ID_DOC_NO column" HeaderText="ID_DOC_NO" 
                                                                                SortExpression="ID_DOC_NO" UniqueName="ID_DOC_NO">
                                                                            </telerik:GridBoundColumn>
                                                                        </Columns>
                                                                        <EditFormSettings>
                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                            </EditColumn>
                                                                        </EditFormSettings>
                                                                    </MasterTableView>
                                                                    <ItemStyle Wrap="False" />
                                                                    <PagerStyle Wrap="False" />
                                                                    <FilterMenu EnableImageSprites="False">
                                                                    </FilterMenu>
                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                    </HeaderContextMenu>
                                                                </telerik:RadGrid>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <telerik:RadButton ID="cmdview_1" runat="server" Skin="Simple" 
                                                                Text="Export To excel" Width="157px">
                                                            </telerik:RadButton>
                                                            <asp:Label ID="LBLID" runat="server" style="font-weight: 700" Visible="False"></asp:Label>
                                                        </td>
                                                    </tr>
                                                </table>

                                             </telerik:RadPageView>  
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td style="width: 246px">
                                                    &nbsp;</td>
                                                <td>
                                                    <asp:Label ID="Label153" runat="server" Text="Invoice/Cr No"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadTextBox ID="txtinv" Runat="server" Skin="Sunset" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td style="width: 246px">
                                                    &nbsp;</td>
                                                <td>
                                                    <asp:Label ID="Label158" runat="server" Text="Policy Code"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadTextBox ID="txtpolicy" Runat="server" Skin="Sunset" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <hr />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    <asp:Label ID="Label155" runat="server" Text="Payment"></asp:Label>
                                                </td>
                                                <td style="width: 246px">
                                                    <telerik:RadComboBox ID="cbopayment" Runat="server" MarkFirstMatch="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbopayment" Text="FULL-PAID" 
                                                                Value="FULL-PAID" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbopayment" Text="PART-PAID" 
                                                                Value="PART-PAID" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cbopayment" Text="NOT-PAID" 
                                                                Value="NOT-PAID" />
                                                            <telerik:RadComboBoxItem runat="server" Text="CREDIT NOTE" Value="CR" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    <asp:Label ID="Label150" runat="server" Text="Action"></asp:Label>
                                                </td>
                                                <td style="width: 246px">
                                                    <telerik:RadComboBox ID="cboAction" Runat="server" AllowCustomText="True" 
                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" Text="Cashier" 
                                                                Value="C" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Medical UW" Value="MU" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Closed" Value="CL" />
                                                            <telerik:RadComboBoxItem runat="server" Text="IT Support" Value="IT" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Return-Incomplete" Value="RI" />
                                                            <telerik:RadComboBoxItem runat="server" Text="RM" Value="RM" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    <asp:Label ID="Label152" runat="server" Text="Entered By"></asp:Label>
                                                </td>
                                                <td style="width: 246px">
                                                    <asp:Label ID="lblenteredby" runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    <asp:Label ID="Label144" runat="server" Text="Notes"></asp:Label>
                                                </td>
                                                <td rowspan="2">
                                                    <telerik:RadTextBox ID="txtcomment" Runat="server" Height="50px" Skin="Sunset" 
                                                        TextMode="MultiLine" Width="450px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td colspan="2">
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td colspan="2">
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 193px; height: 38px;">
                                                </td>
                                                <td style="height: 38px;">
                                                    <telerik:RadButton ID="btnforward" runat="server" Skin="Simple" Text="Forward " 
                                                        Width="200px">
                                                    </telerik:RadButton>
                                                </td>
                                                <td colspan="2" style="height: 38px">
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="150px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="True" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
           
            </asp:UpdatePanel>
</asp:Content>

