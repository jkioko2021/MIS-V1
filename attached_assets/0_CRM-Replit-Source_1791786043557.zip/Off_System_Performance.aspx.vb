﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim empcode As String
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
             
                empcode = ""
                Session("EXCEL") = Nothing

                Load_Grid()
                dtfrom.DbSelectedDate = Date.Now()
                dtto.DbSelectedDate = Date.Now()

            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Load_Grid()
        Try

            GDSUM.DataSource = Nothing
            GDSUM.DataBind()
            GDRM_1.DataSource = Nothing
            GDRM_1.DataBind()
            GD_M.DataSource = Nothing
            GD_M.DataBind()

            SqlAction = " SELECT   [Entered_by],[Total_Tracked],[Invoice_Attached],[Perc_Attached],[Billed],[Perc_Billed],[With_Issues],[Perc_Issues]  FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_PERC_STATUS_SUM] ORDER BY Total_Tracked DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSUM.DataSource = MyDatable
                GDSUM.DataBind()
            Else
                GDSUM.DataSource = Nothing
                GDSUM.DataBind()
            End If

            SqlAction = "SELECT DISTINCT  sum([Total_Tracked])[Total_Tracked],sum([Invoice_Attached])[Invoice_Attached]," & _
                "FORMAT(sum(cast([Invoice_Attached] as numeric(18,0)))/sum(cast(Total_Tracked as numeric(18,0))), 'P')  [Perc_Attached]," & _
               "sum([Billed])[Billed],   FORMAT(sum(cast(Billed as numeric(18,0)))/sum(cast( Total_Tracked as numeric(18,0))), 'P') Perc_Billed," & _
                 "sum([With_Issues])[With_Issues], FORMAT(sum(cast( With_Issues as numeric(18,0)))/sum(cast( Total_Tracked as numeric(18,0))), 'P')  Perc_Issues " & _
               "FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_PERC_STATUS_SUM_N] "
            '"WHERE  [Entry_Date]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'" & _
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_M.DataSource = MyDatable
                GD_M.DataBind()
            Else
                GD_M.DataSource = Nothing
                GD_M.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDRM_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSUM.SelectedIndexChanged
        Try
            GDRM_1.DataSource = Nothing
            GDRM_1.DataBind()
            HiddenField1.Value = ""

            HiddenField1.Value = (DirectCast(GDSUM.SelectedItems(0), GridDataItem)).GetDataKeyValue("Entered_by").ToString()
            SqlAction = "SELECT  [Entered_by],[Entry_Yr],[Entry_Mon],[Total_Tracked],[Invoice_Attached],[Billed],[Issues]  FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_PERC_STATUS_DET]  with(nolock)   WHERE Entered_by ='" & HiddenField1.Value & "' "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDRM_1.DataSource = MyDatable
                GDRM_1.DataBind()
            Else
                GDRM_1.DataSource = Nothing
                GDRM_1.DataBind()
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    

    Protected Sub export_Click1(sender As Object, e As System.EventArgs) Handles export.Click
        Try
            Dim Str As String = ""
            Session("EXCEL") = "TO EXCEL"

            Dim Reportname As String = "Off_System_PERFOMANCE"
            SqlAction = " SELECT   [Entered_by],[Total_Tracked],[Invoice_Attached],[Perc_Attached],[Billed],[Perc_Billed],[With_Issues],[Perc_Issues]  FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_PERC_STATUS_SUM]"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (MyDatable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            MyDatable = Nothing
            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        GD_M.DataSource = Nothing
        GD_M.DataBind()
        GDSUM.DataSource = Nothing
        GDSUM.DataBind()
        SqlAction = "SELECT DISTINCT  sum([Total_Tracked])[Total_Tracked],sum([Invoice_Attached])[Invoice_Attached]," & _
                 "FORMAT(sum(cast([Invoice_Attached] as numeric(18,0)))/sum(cast(Total_Tracked as numeric(18,0))), 'P')  [Perc_Attached]," & _
                "sum([Billed])[Billed],   FORMAT(sum(cast(Billed as numeric(18,0)))/sum(cast( Total_Tracked as numeric(18,0))), 'P') Perc_Billed," & _
                  "sum([With_Issues])[With_Issues], FORMAT(sum(cast( With_Issues as numeric(18,0)))/sum(cast( Total_Tracked as numeric(18,0))), 'P')  Perc_Issues " & _
                "FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_PERC_STATUS_SUM_N] " & _
                "WHERE  [Entry_Date]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"


        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_M.DataSource = MyDatable
            GD_M.DataBind()
        Else
            GD_M.DataSource = Nothing
            GD_M.DataBind()
            End If

        SqlAction = "SELECT DISTINCT [Entered_by],sum([Total_Tracked])[Total_Tracked],sum([Invoice_Attached])[Invoice_Attached]," & _
              "FORMAT(sum(cast([Invoice_Attached] as numeric(18,0)))/sum(cast(Total_Tracked as numeric(18,0))), 'P')  [Perc_Attached]," & _
             "sum([Billed])[Billed],   FORMAT(sum(cast(Billed as numeric(18,0)))/sum(cast( Total_Tracked as numeric(18,0))), 'P') Perc_Billed," & _
               "sum([With_Issues])[With_Issues], FORMAT(sum(cast( With_Issues as numeric(18,0)))/sum(cast( Total_Tracked as numeric(18,0))), 'P')  Perc_Issues " & _
             "FROM [CRM].[dbo].[vw_MIS_CRM_OFF_SYSTEM_PERC_STATUS_SUM_N] " & _
             "WHERE  [Entry_Date]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'" & _
              "group by [Entered_by]"

        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSUM.DataSource = MyDatable
            GDSUM.DataBind()
        Else
            GDSUM.DataSource = Nothing
            GDSUM.DataBind()
        End If
    End Sub

 
 
End Class
