﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="UW_Loading_Member.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:MultiView ID="MultiView1" runat="server">
    </asp:MultiView>
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table>
                <tr>
                    <td align="center" bgcolor="#333333" style="height: 44px">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="Member Loading"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1023px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 3043px; font-weight: 700;">
                                        &nbsp;</td>
                                    <td style="width: 384px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Label ID="Label161" runat="server" Text="Loading Type"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cborevise" Runat="server">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="New Loading" Value="0" />
                                                <telerik:RadComboBoxItem runat="server" Text="Revise loading" Value="1" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 3043px; font-weight: 700;">
                                        &nbsp;</td>
                                    <td style="width: 384px">
                                        &nbsp;</td>
                                    <td>
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Member No"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5" style="font-weight: 700;">
                                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" style="font-weight: 700" Width="1010px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1001px">
                                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="ID" DataType="System.Decimal" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="ID" ReadOnly="True" 
                                                                            SortExpression="ID" UniqueName="ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                            FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                            ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                            FilterControlAltText="Filter PERIOD_FROM column" 
                                                                            HeaderText="PERIOD_FROM" ItemStyle-Wrap="False" 
                                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                            <ItemStyle Wrap="False" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                            FilterControlAltText="Filter PERIOD_TO column" 
                                                                            HeaderText="PERIOD_TO" SortExpression="PERIOD_TO" 
                                                                            UniqueName="PERIOD_TO">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label126" runat="server" Text="Member No."></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="txtno" Runat="server" Skin="Sunset" Width="200px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label144" runat="server" Text="Member Name"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label140" runat="server" Text="Period From"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" MinDate="" Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label141" runat="server" Text="Period To"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadDatePicker ID="DTto" Runat="server" MinDate="" Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label148" runat="server" Text="Age"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadNumericTextBox ID="txtage" Runat="server" DataType="System.Single" 
                                                            Skin="Sunset">
                                                            <NumberFormat DecimalDigits="0" />
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label157" runat="server" Text="Relation"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadTextBox ID="txtrela" Runat="server" Skin="Sunset" Width="200px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td bgcolor="#666666" class="style8" colspan="4">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label151" runat="server" Text="IP Premiums"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadNumericTextBox ID="txtipprem" Runat="server" Culture="en-US" 
                                                            Skin="Sunset" Value="0" Width="200px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label152" runat="server" Text="OP Premiums"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadNumericTextBox ID="txtopprem" Runat="server" Culture="en-US" 
                                                            Skin="Sunset" Value="0" Width="200px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td bgcolor="#666666" class="style8" colspan="4">
                                                        <asp:Label ID="Label160" runat="server" Text="Loading %"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label153" runat="server" Text="OP  Rate"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadNumericTextBox ID="txtoprate" Runat="server" AutoPostBack="True" 
                                                            Culture="en-US" Skin="Sunset" Value="0" Width="125px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label155" runat="server" Text="Premiums"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadNumericTextBox ID="txtLopprem" Runat="server" Culture="en-US" 
                                                            Skin="Sunset" Value="0" Width="200px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="Label154" runat="server" Text="IP  Rate"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadNumericTextBox ID="txtiprate" Runat="server" AutoPostBack="True" 
                                                            Culture="en-US" Skin="Sunset" Value="0" Width="125px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <asp:Label ID="Label156" runat="server" Text="Premiums"></asp:Label>
                                                    </td>
                                                    <td style="width: 287px">
                                                        <telerik:RadNumericTextBox ID="txtLIPPrem" Runat="server" Culture="en-US" 
                                                            Skin="Sunset" Value="0" Width="200px">
                                                        </telerik:RadNumericTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" style="width: 194px">
                                                        <asp:Label ID="lblID" runat="server" ForeColor="Red"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <asp:Label ID="LBLSCHEME" runat="server"></asp:Label>
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        &nbsp;</td>
                                                    <td style="width: 287px">
                                                        <asp:Label ID="LBLPOLICY" runat="server"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8">
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label147" runat="server" Text="Notes"></asp:Label>
                                                    </td>
                                                    <td class="style8" colspan="2" rowspan="2">
                                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="90px" Skin="Sunset" 
                                                            TextMode="MultiLine" Width="350px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="2">
                                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                                    </td>
                                                    <td class="style8" style="width: 166px">
                                                        <telerik:RadButton ID="cmdsave" runat="server" Height="37px" Skin="Simple" 
                                                            Text="Save" Width="100px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td style="width: 287px">
                                                        &nbsp;<telerik:RadButton ID="cmdedit" runat="server" Skin="Simple" Text="Edit" 
                                                            Width="100px">
                                                        </telerik:RadButton>
                                                        &nbsp;<telerik:RadButton ID="cmdnew" runat="server" Skin="Simple" Text="New" 
                                                            Width="80px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="style8" colspan="4">
                                                        <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1001px">
                                                            <telerik:RadGrid ID="RD_LOAD" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                                <%-- ' [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]--%>
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                                            HeaderText="ID" ReadOnly="True" SortExpression="ID" UniqueName="ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                            FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                            ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="AGE" 
                                                                            FilterControlAltText="Filter AGE column" HeaderText="AGE" 
                                                                            ItemStyle-Wrap="False" SortExpression="AGE" UniqueName="AGE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="OP_L_RATE" 
                                                                            FilterControlAltText="Filter OP_L_RATE column" HeaderText="OP_L_RATE" 
                                                                            ItemStyle-Wrap="False" SortExpression="OP_L_RATE" UniqueName="OP_L_RATE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="IP_L_RATE" 
                                                                            FilterControlAltText="Filter IP_L_RATE column" HeaderText="IP_L_RATE" 
                                                                            ItemStyle-Wrap="False" SortExpression="IP_L_RATE" UniqueName="IP_L_RATE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="IP_PREMIUM" 
                                                                            FilterControlAltText="Filter IP_PREMIUM column" HeaderText="IP_PREMIUM" 
                                                                            ItemStyle-Wrap="False" SortExpression="IP_PREMIUM" UniqueName="IP_PREMIUM">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="OP_PREMIUM" 
                                                                            FilterControlAltText="Filter OP_PREMIUM column" HeaderText="OP_PREMIUM" 
                                                                            ItemStyle-Wrap="False" SortExpression="OP_PREMIUM" UniqueName="OP_PREMIUM">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="LOADED_IP_PREM" 
                                                                            FilterControlAltText="Filter LOADED_IP_PREM column" HeaderText="LOADED_IP_PREM" 
                                                                            ItemStyle-Wrap="False" SortExpression="LOADED_IP_PREM" 
                                                                            UniqueName="LOADED_IP_PREM">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="LOADED_OP_PREM" 
                                                                            FilterControlAltText="Filter LOADED_OP_PREM column" HeaderText="LOADED_OP_PREM" 
                                                                            ItemStyle-Wrap="False" SortExpression="LOADED_OP_PREM" 
                                                                            UniqueName="LOADED_OP_PREM">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="CURRENT_IP_CLAIMS" 
                                                                            FilterControlAltText="Filter CURRENT_IP_CLAIMS column" 
                                                                            HeaderText="CURRENT_IP_CLAIMS" ItemStyle-Wrap="False" 
                                                                            SortExpression="CURRENT_IP_CLAIMS" UniqueName="CURRENT_IP_CLAIMS">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="CURRENT_OP_CLAIMS" 
                                                                            FilterControlAltText="Filter CURRENT_OP_CLAIMS column" 
                                                                            HeaderText="CURRENT_OP_CLAIMS" ItemStyle-Wrap="False" 
                                                                            SortExpression="CURRENT_OP_CLAIMS" UniqueName="CURRENT_OP_CLAIMS">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                            ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                            ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="LOAD_DATE" 
                                                                            FilterControlAltText="Filter LOAD_DATE column" HeaderText="LOAD_DATE" 
                                                                            ItemStyle-Wrap="False" SortExpression="LOAD_DATE" UniqueName="LOAD_DATE">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="#" 
                                                                            SortExpression="TicketID">
                                                                        </telerik:GridTemplateColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <PagerStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td bgcolor="#999999" colspan="4">
                                                        <asp:Label ID="Label3" runat="server" Text="Report Extract (Entry Date)"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 199px">
                                                        <asp:Label ID="Label159" runat="server" Text="Select"></asp:Label>
                                                    </td>
                                                    <td style="width: 199px">
                                                        <telerik:RadComboBox ID="cboreport" Runat="server" Skin="Simple">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="Renewal List" Value="R" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Claims List" Value="C" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="width: 143px">
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 199px">
                                                        &nbsp;</td>
                                                    <td style="width: 199px">
                                                        <asp:Label ID="Label4" runat="server" Text="Date From"></asp:Label>
                                                    </td>
                                                    <td style="width: 143px">
                                                        <telerik:RadDatePicker ID="dtF" Runat="server" Skin="Web20">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 199px">
                                                        &nbsp;</td>
                                                    <td style="width: 199px">
                                                        <asp:Label ID="Label5" runat="server" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td style="width: 143px">
                                                        <telerik:RadDatePicker ID="DTt" Runat="server" Skin="Web20" Width="150px">
                                                            <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="RadButton3" runat="server" Skin="Sunset" Text="Generate">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1001px">
                                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                                            ItemStyle-Width="50" SortExpression="Note_From" UniqueName="Note_From">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                            SortExpression="Notes" UniqueName="Notes">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="False" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                </table>
              
  
        </ContentTemplate>
                       
          </asp:UpdatePanel>
</asp:Content>

