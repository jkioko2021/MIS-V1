﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            empcode = ""
            cboRE.SelectedValue = ""
            cboyear.SelectedValue = Session("YEAR")
            Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                'empcode = "0114"
            Else
                lbltext.Text = "You are not authorized to view this page"
                Exit Sub
            End If
            Str = "SELECT RE_NAME,RE_CODE FROM TBL_MIS_CRM_RMS where IS_ACTIVE=1 AND YEAR='" & cboyear.SelectedValue & "' AND RE_CODE='" & empcode & "' AND C_CODE='R' ORDER BY RE_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboRE
                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()

            End With

          

            Session("EXCEL") = Nothing

            SqlAction = "SELECT  MIN([DATE_FROM])DATE_FROM,MIN([DATE_TO])DATE_TO FROM [SALES].[dbo].[TBL_MIS_PROD_MONTHS] WHERE [MONTH_CLOSED] =0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                dtDateFrom.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_FROM")).ToString("yyyy-MM-dd")
                dtDateTo.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()
               
            End If

            LOADGRID()
        End If
    End Sub
    Public Sub LOADGRID()

        GD_MED_POLICY.DataSource = Nothing
        GD_MED_POLICY.DataBind()
        GD_NON_POLICY.DataSource = Nothing
        GD_NON_POLICY.DataBind()

        SqlAction = "SELECT  [RM_CODE],[RM_NAME], CLASS_CODE, SUM([M_CNT_POLICY])[M_CNT_POLICY],SUM([M_PREM])[M_PREM],SUM([M_CNT_LIVES])[M_CNT_LIVES],SUM([M_EARNED_PREMIUM])[M_EARNED_PREMIUM],SUM([M_CLAIM_RATIO])[M_CLAIM_RATIO],SUM([MED_CLAIMS])[MED_CLAIMS],SUM([NON_PREM])[NON_PREM],SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE]  WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND [RM_CODE]='" & cboRE.SelectedValue & "'   GROUP BY [RM_CODE],[RM_NAME],CLASS_CODE"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_RM_PORT.DataSource = MyDatable
            GD_RM_PORT.DataBind()
            'Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GD_RM_PORT.DataSource = Nothing
            GD_RM_PORT.DataBind()
        End If

        SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME, P.RM_CODE, sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_CORP_PORTFOLIO P  INNER JOIN dbo.TBL_CRM_CORPORATE_MAPPING M ON P.CORPORATE_ID = M.CORPORATE_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "' AND  P.BUSINESS='MEDICAL' group by M.PROPOSER_DISPLAY_NAME, P.RM_CODE,P.BUSINESS,s.AGENT_NAME"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_MED_POLICY.DataSource = MyDatable
            GD_MED_POLICY.DataBind()
            Session("DAD_5_4") = MyDatable
            MyDatable = Nothing
        Else
           
                GD_MED_POLICY.DataSource = Nothing
                GD_MED_POLICY.DataBind()

        End If

        SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME,  sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_RETAIL_PORTFOLIO P  INNER JOIN [dbo].[TBL_CRM_RETAIL_MAPPING] M ON P.PROPOSER_ID = M.PROPOSER_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "'  AND  P.BUSINESS='MEDICAL'   group by M.PROPOSER_DISPLAY_NAME,P.BUSINESS,s.AGENT_NAME"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_NON_POLICY.DataSource = MyDatable
            GD_NON_POLICY.DataBind()
            Session("DAD_5_5") = MyDatable
            MyDatable = Nothing
        Else
            GD_NON_POLICY.DataSource = Nothing
            GD_NON_POLICY.DataBind()
        End If
    End Sub
    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click

      
        GD_MED_POLICY.DataSource = Nothing
        GD_MED_POLICY.DataBind()
        GD_NON_POLICY.DataSource = Nothing
        GD_NON_POLICY.DataBind()

        Try
            SqlAction = "SELECT  [RM_CODE],[RM_NAME],CLASS_CODE, SUM([M_CNT_POLICY])[M_CNT_POLICY],SUM([M_PREM])[M_PREM],SUM([M_CNT_LIVES])[M_CNT_LIVES],SUM([M_EARNED_PREMIUM])[M_EARNED_PREMIUM],SUM([M_CLAIM_RATIO])[M_CLAIM_RATIO],SUM([MED_CLAIMS])[MED_CLAIMS],SUM([NON_PREM])[NON_PREM],SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE]  WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND [RM_CODE]='" & cboRE.SelectedValue & "'   GROUP BY [RM_CODE],[RM_NAME],CLASS_CODE"

                      MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_RM_PORT.DataSource = MyDatable
                GD_RM_PORT.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_RM_PORT.DataSource = Nothing
                GD_RM_PORT.DataBind()
            End If
            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME, P.RM_CODE, sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_CORP_PORTFOLIO P  INNER JOIN dbo.TBL_CRM_CORPORATE_MAPPING M ON P.CORPORATE_ID = M.CORPORATE_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "' AND  P.BUSINESS='MEDICAL' group by M.PROPOSER_DISPLAY_NAME, P.RM_CODE,P.BUSINESS,s.AGENT_NAME"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_MED_POLICY.DataSource = MyDatable
                GD_MED_POLICY.DataBind()
                Session("DAD_5_4") = MyDatable
                MyDatable = Nothing
            Else
                GD_MED_POLICY.DataSource = Nothing
                GD_MED_POLICY.DataBind()
            End If

            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME,  sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_RETAIL_PORTFOLIO P  INNER JOIN [dbo].[TBL_CRM_RETAIL_MAPPING] M ON P.PROPOSER_ID = M.PROPOSER_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "'  AND  P.BUSINESS='MEDICAL'   group by M.PROPOSER_DISPLAY_NAME,P.BUSINESS,s.AGENT_NAME"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_NON_POLICY.DataSource = MyDatable
                GD_NON_POLICY.DataBind()
                Session("DAD_5_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_NON_POLICY.DataSource = Nothing
                GD_NON_POLICY.DataBind()
            End If
        Catch ex As Exception
        End Try
    End Sub



    Protected Sub GD_MED_POLICY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_MED_POLICY.PageIndexChanged
        GD_MED_POLICY.CurrentPageIndex = e.NewPageIndex
        GD_MED_POLICY.DataSource = Session("DAD_5_4")
        GD_MED_POLICY.DataBind()
    End Sub
    Protected Sub GD_NON_POLICY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_NON_POLICY.PageIndexChanged
        GD_NON_POLICY.CurrentPageIndex = e.NewPageIndex
        GD_NON_POLICY.DataSource = Session("DAD_5_5")
        GD_NON_POLICY.DataBind()
    End Sub
    Protected Sub GD_RM_PORT_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_RM_PORT.PageIndexChanged
        GD_RM_PORT.CurrentPageIndex = e.NewPageIndex
        GD_RM_PORT.DataSource = Session("GD_RM_PORT")
        GD_RM_PORT.DataBind()
    End Sub

    Protected Sub GD_RM_PORT_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GD_RM_PORT.SelectedIndexChanged
        Dim USER_ID As String = ""

        GD_RM_PORT_1.DataSource = Nothing
        GD_RM_PORT_1.DataBind()
        Try
            USER_ID = (DirectCast(GD_RM_PORT.SelectedItems(0), GridDataItem)).GetDataKeyValue("RM_CODE").ToString()
            SqlAction = "SELECT [MONTH_FROM],[MONTH_TO],[M_CNT_POLICY],[M_PREM],[M_CNT_LIVES],[M_EARNED_PREMIUM],[M_CLAIM_RATIO],[MED_CLAIMS] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE] WHERE  [RM_CODE]='" & USER_ID & "'  AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' and CLASS_CODE='" & Session("class_code") & "' ORDER BY MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_RM_PORT_1.DataSource = MyDatable
                GD_RM_PORT_1.DataBind()
                MyDatable = Nothing
            Else
                GD_RM_PORT_1.DataSource = Nothing
                GD_RM_PORT_1.DataBind()
            End If

            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME, P.RM_CODE, sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_CORP_PORTFOLIO P  INNER JOIN dbo.TBL_CRM_CORPORATE_MAPPING M ON P.CORPORATE_ID = M.CORPORATE_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "' AND  P.BUSINESS='MEDICAL' group by M.PROPOSER_DISPLAY_NAME, P.RM_CODE,P.BUSINESS,s.AGENT_NAME"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_MED_POLICY.DataSource = MyDatable
                GD_MED_POLICY.DataBind()
                Session("DAD_5_4") = MyDatable
                MyDatable = Nothing
            Else
                GD_MED_POLICY.DataSource = Nothing
                GD_MED_POLICY.DataBind()
            End If

            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME,  sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_RETAIL_PORTFOLIO P  INNER JOIN [dbo].[TBL_CRM_RETAIL_MAPPING] M ON P.PROPOSER_ID = M.PROPOSER_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "'  AND  P.BUSINESS='MEDICAL'   group by M.PROPOSER_DISPLAY_NAME,P.BUSINESS,s.AGENT_NAME"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_NON_POLICY.DataSource = MyDatable
                GD_NON_POLICY.DataBind()
                Session("DAD_5_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_NON_POLICY.DataSource = Nothing
                GD_NON_POLICY.DataBind()
            End If


        Catch ex As Exception

        End Try

    End Sub
    
    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String
        Session("Mytable") = Nothing
        Session("Reportname") = Nothing

        Session("EXCEL") = "TO EXCEL"
        If cbotype.SelectedValue = "CM" Then
            Reportname = "Corp_Medical-List As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME, sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_CORP_PORTFOLIO P  INNER JOIN dbo.TBL_CRM_CORPORATE_MAPPING M ON P.CORPORATE_ID = M.CORPORATE_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "' AND  P.BUSINESS='MEDICAL' group by M.PROPOSER_DISPLAY_NAME, P.BUSINESS,s.AGENT_NAME"
        ElseIf cbotype.SelectedValue = "CN" Then
            Reportname = "Corp_NonMed-List As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME, sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_CORP_PORTFOLIO P  INNER JOIN dbo.TBL_CRM_CORPORATE_MAPPING M ON P.CORPORATE_ID = M.CORPORATE_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "' AND  P.BUSINESS='NON-MED' group by M.PROPOSER_DISPLAY_NAME,P.BUSINESS,s.AGENT_NAME"
        ElseIf cbotype.SelectedValue = "RM" Then
            Reportname = "Ret_Medical-List As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME,  sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_RETAIL_PORTFOLIO P  INNER JOIN [dbo].[TBL_CRM_RETAIL_MAPPING] M ON P.PROPOSER_ID = M.PROPOSER_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "'  AND  P.BUSINESS='MEDICAL'   group by M.PROPOSER_DISPLAY_NAME,P.BUSINESS,s.AGENT_NAME"
        ElseIf cbotype.SelectedValue = "RN" Then
            Reportname = "Ret_NonMed-List As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "SELECT distinct M.PROPOSER_DISPLAY_NAME,  sum(P.PREMIUMS)PREMIUMS, sum(isnull(P.LIVES,0))LIVES, P.BUSINESS, sum(P.EARNED_PREMIUM)EARNED_PREMIUM, sum(P.CLAIMS)CLAIMS, avg(P.CLAIM_RATIO)CLAIM_RATIO, S.AGENT_NAME FROM   dbo.TBL_MIS_CRM_RETAIL_PORTFOLIO P  INNER JOIN [dbo].[TBL_CRM_RETAIL_MAPPING] M ON P.PROPOSER_ID = M.PROPOSER_ID INNER JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS S ON P.AGENCY_CODE=S.USER_ID WHERE [RM_CODE]='" & cboRE.SelectedValue & "'  AND  P.BUSINESS='NON-MED'   group by M.PROPOSER_DISPLAY_NAME,P.BUSINESS,s.AGENT_NAME"

        End If
        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If Mytable.Rows.Count > 0 Then
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
        End If
    End Sub



End Class
