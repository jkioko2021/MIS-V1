﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Complain_Enq_Status.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="COMPLAINT REGISTER"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" style="height: 202px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 982px">
                                                    &nbsp;</td>
                                                <td style="width: 200px" class="style17">
                                                    <asp:Label ID="Label141" runat="server" Text="Member No"></asp:Label>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" 
                                                        Width="200px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1140px">
                                                        <telerik:RadGrid ID="GD_DUE" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_no">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                   
                                                                    <telerik:GridBoundColumn DataField="Case_no" 
                                                                        FilterControlAltText="Filter Case_no column" HeaderText="Case_no" 
                                                                        SortExpression="Case_no" UniqueName="Case_no">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Date_Received" 
                                                                        FilterControlAltText="Filter Date_Received column" HeaderText="Date_Received" 
                                                                        SortExpression="Date_Received" UniqueName="Date_Received">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Mode_of_Receipt" 
                                                                        DataFormatString="{0:dd-MM-yyyy}" 
                                                                        FilterControlAltText="Filter Mode_of_Receipt column" 
                                                                        HeaderText="Mode_of_Receipt" SortExpression="Mode_of_Receipt" 
                                                                        UniqueName="Mode_of_Receipt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Membership_No" 
                                                                        FilterControlAltText="Filter Membership_No column" HeaderText="Membership_No" 
                                                                        SortExpression="Membership_No" UniqueName="Membership_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Issue_Name" 
                                                                        FilterControlAltText="Filter Issue_Name column" HeaderText="Complain" 
                                                                        SortExpression="Issue_Name" UniqueName="Issue_Name">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Action_Taken" 
                                                                        FilterControlAltText="Filter Action_Taken column" HeaderText="Action" 
                                                                        SortExpression="Action_Taken" UniqueName="Action_Taken">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Customer_Name" 
                                                                        FilterControlAltText="Filter Customer_Name column" HeaderText="Customer_Name" 
                                                                        SortExpression="Customer_Name" UniqueName="Customer_Name">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Contacts" 
                                                                        FilterControlAltText="Filter Contacts column" HeaderText="Contacts" 
                                                                        SortExpression="Contacts" UniqueName="Contacts">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Entered_By" 
                                                                        FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                        SortExpression="Entered_By" UniqueName="Entered_By">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Escalated_To" 
                                                                        FilterControlAltText="Filter Escalated_To column" HeaderText="Escalated_To" 
                                                                        SortExpression="Escalated_To" UniqueName="Escalated_To">
                                                                    </telerik:GridBoundColumn>
                                                                      <telerik:GridBoundColumn DataField="Due_Dt" 
                                                            FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Date" 
                                                            SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                        </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                                        MultiPageID="RadMultiPage1" SelectedIndex="0">
                                                        <Tabs>
                                                            <telerik:RadTab runat="server" PageViewID="V1" Text="Open Cases" 
                                                                Selected="True">
                                                            </telerik:RadTab>
                                                            <telerik:RadTab runat="server" PageViewID="V2" Text="Resolved Cases">
                                                            </telerik:RadTab>
                                                            <telerik:RadTab runat="server" PageViewID="V3" Text="Closed">
                                                            </telerik:RadTab>
                                                        </Tabs>
                                                    </telerik:RadTabStrip>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="100%">
                                                        <telerik:RadPageView ID="V1" runat="server" Selected="True">
                                                            <table style="width: 100%">
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="Label181" runat="server" Font-Bold="True" Text="Open Cases"></asp:Label>
                                                                    </td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                                                            Width="1140px">
                                                                            <telerik:RadGrid ID="GD_OPEN" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_no">
                                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </RowIndicatorColumn>
                                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </ExpandCollapseColumn>
                                                                                    <Columns>
                                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                            UniqueName="Select">
                                                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                            <ItemStyle Width="50px" />
                                                                                        </telerik:GridButtonColumn>
                                                                                        <telerik:GridBoundColumn DataField="Case_no" 
                                                                                            FilterControlAltText="Filter Case_no column" HeaderText="Case_no" 
                                                                                            SortExpression="Case_no" UniqueName="Case_no">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Date_Received" 
                                                                                            FilterControlAltText="Filter Date_Received column" HeaderText="Date_Received" 
                                                                                            SortExpression="Date_Received" UniqueName="Date_Received">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Mode_of_Receipt" 
                                                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                                                            FilterControlAltText="Filter Mode_of_Receipt column" 
                                                                                            HeaderText="Mode_of_Receipt" SortExpression="Mode_of_Receipt" 
                                                                                            UniqueName="Mode_of_Receipt">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Membership_No" 
                                                                                            FilterControlAltText="Filter Membership_No column" HeaderText="Membership_No" 
                                                                                            SortExpression="Membership_No" UniqueName="Membership_No">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Issue_Name" 
                                                                                            FilterControlAltText="Filter Issue_Name column" HeaderText="Complain" 
                                                                                            SortExpression="Issue_Name" UniqueName="Issue_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Action_Taken" 
                                                                                            FilterControlAltText="Filter Action_Taken column" HeaderText="Action" 
                                                                                            SortExpression="Action_Taken" UniqueName="Action_Taken">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Customer_Name" 
                                                                                            FilterControlAltText="Filter Customer_Name column" HeaderText="Customer_Name" 
                                                                                            SortExpression="Customer_Name" UniqueName="Customer_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Contacts" 
                                                                                            FilterControlAltText="Filter Contacts column" HeaderText="Contacts" 
                                                                                            SortExpression="Contacts" UniqueName="Contacts">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Entered_By" 
                                                                                            FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                                            SortExpression="Entered_By" UniqueName="Entered_By">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Escalated_To" 
                                                                                            FilterControlAltText="Filter Escalated_To column" HeaderText="Escalated_To" 
                                                                                            SortExpression="Escalated_To" UniqueName="Escalated_To">
                                                                                        </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Due_Dt" 
                                                            FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Date" 
                                                            SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="Over_Due" 
                                                            FilterControlAltText="Filter Over_Due column" HeaderText="Over_Due" 
                                                            SortExpression="Over_Due" UniqueName="Over_Due">
                                                        </telerik:GridBoundColumn>
                                                                                    </Columns>
                                                                                    <EditFormSettings>
                                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                        </EditColumn>
                                                                                    </EditFormSettings>
                                                                                </MasterTableView>
                                                                                <ItemStyle Wrap="False" />
                                                                                <FilterMenu EnableImageSprites="False">
                                                                                </FilterMenu>
                                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                </HeaderContextMenu>
                                                                            </telerik:RadGrid>
                                                                        </asp:Panel>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </telerik:RadPageView>
                                                        <telerik:RadPageView ID="V2" runat="server">
                                                            <table style="width: 100%">
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="Label182" runat="server" Font-Bold="True" Text="Resolved Cases"></asp:Label>
                                                                    </td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <asp:Panel ID="Panel2" runat="server" Height="100%" ScrollBars="Both" 
                                                                            Width="1140px">
                                                                            <telerik:RadGrid ID="GD_RESOLVED" runat="server" AllowPaging="True" 
                                                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_no">
                                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </RowIndicatorColumn>
                                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </ExpandCollapseColumn>
                                                                                    <Columns>
                                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                            UniqueName="Select">
                                                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                            <ItemStyle Width="50px" />
                                                                                        </telerik:GridButtonColumn>
                                                                                        <telerik:GridBoundColumn DataField="Case_no" 
                                                                                            FilterControlAltText="Filter Case_no column" HeaderText="Case_no" 
                                                                                            SortExpression="Case_no" UniqueName="Case_no">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Date_Received" 
                                                                                            FilterControlAltText="Filter Date_Received column" HeaderText="Date_Received" 
                                                                                            SortExpression="Date_Received" UniqueName="Date_Received">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Mode_of_Receipt" 
                                                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                                                            FilterControlAltText="Filter Mode_of_Receipt column" 
                                                                                            HeaderText="Mode_of_Receipt" SortExpression="Mode_of_Receipt" 
                                                                                            UniqueName="Mode_of_Receipt">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Membership_No" 
                                                                                            FilterControlAltText="Filter Membership_No column" HeaderText="Membership_No" 
                                                                                            SortExpression="Membership_No" UniqueName="Membership_No">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Issue_Name" 
                                                                                            FilterControlAltText="Filter Issue_Name column" HeaderText="Complain" 
                                                                                            SortExpression="Issue_Name" UniqueName="Issue_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Action_Taken" 
                                                                                            FilterControlAltText="Filter Action_Taken column" HeaderText="Action" 
                                                                                            SortExpression="Action_Taken" UniqueName="Action_Taken">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Customer_Name" 
                                                                                            FilterControlAltText="Filter Customer_Name column" HeaderText="Customer_Name" 
                                                                                            SortExpression="Customer_Name" UniqueName="Customer_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Contacts" 
                                                                                            FilterControlAltText="Filter Contacts column" HeaderText="Contacts" 
                                                                                            SortExpression="Contacts" UniqueName="Contacts">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Entered_By" 
                                                                                            FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                                            SortExpression="Entered_By" UniqueName="Entered_By">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Escalated_To" 
                                                                                            FilterControlAltText="Filter Escalated_To column" HeaderText="Escalated_To" 
                                                                                            SortExpression="Escalated_To" UniqueName="Escalated_To">
                                                                                        </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Due_Dt" 
                                                            FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Date" 
                                                            SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                        </telerik:GridBoundColumn>
                                                                                    </Columns>
                                                                                    <EditFormSettings>
                                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                        </EditColumn>
                                                                                    </EditFormSettings>
                                                                                </MasterTableView>
                                                                                <ItemStyle Wrap="False" />
                                                                                <FilterMenu EnableImageSprites="False">
                                                                                </FilterMenu>
                                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                </HeaderContextMenu>
                                                                            </telerik:RadGrid>
                                                                        </asp:Panel>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </telerik:RadPageView>
                                                        <telerik:RadPageView ID="V3" runat="server">
                                                            <table style="width: 100%">
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="Label183" runat="server" Font-Bold="True" Text="Closed Cases"></asp:Label>
                                                                    </td>
                                                                    <td>
                                                                        &nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="2">
                                                                        <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                                                            Width="1140px">
                                                                            <telerik:RadGrid ID="GD_CLOSED" runat="server" AllowPaging="True" 
                                                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Case_no">
                                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </RowIndicatorColumn>
                                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </ExpandCollapseColumn>
                                                                                    <Columns>
                                                                                      
                                                                                        <telerik:GridBoundColumn DataField="Case_no" 
                                                                                            FilterControlAltText="Filter Case_no column" HeaderText="Case_no" 
                                                                                            SortExpression="Case_no" UniqueName="Case_no">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Date_Received" 
                                                                                            FilterControlAltText="Filter Date_Received column" HeaderText="Date_Received" 
                                                                                            SortExpression="Date_Received" UniqueName="Date_Received">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Mode_of_Receipt" 
                                                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                                                            FilterControlAltText="Filter Mode_of_Receipt column" 
                                                                                            HeaderText="Mode_of_Receipt" SortExpression="Mode_of_Receipt" 
                                                                                            UniqueName="Mode_of_Receipt">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Membership_No" 
                                                                                            FilterControlAltText="Filter Membership_No column" HeaderText="Membership_No" 
                                                                                            SortExpression="Membership_No" UniqueName="Membership_No">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Issue_Name" 
                                                                                            FilterControlAltText="Filter Issue_Name column" HeaderText="Complain" 
                                                                                            SortExpression="Issue_Name" UniqueName="Issue_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Action_Taken" 
                                                                                            FilterControlAltText="Filter Action_Taken column" HeaderText="Action" 
                                                                                            SortExpression="Action_Taken" UniqueName="Action_Taken">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Customer_Name" 
                                                                                            FilterControlAltText="Filter Customer_Name column" HeaderText="Customer_Name" 
                                                                                            SortExpression="Customer_Name" UniqueName="Customer_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Contacts" 
                                                                                            FilterControlAltText="Filter Contacts column" HeaderText="Contacts" 
                                                                                            SortExpression="Contacts" UniqueName="Contacts">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Entered_By" 
                                                                                            FilterControlAltText="Filter Entered_By column" HeaderText="Entered_By" 
                                                                                            SortExpression="Entered_By" UniqueName="Entered_By">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Escalated_To" 
                                                                                            FilterControlAltText="Filter Escalated_To column" HeaderText="Escalated_To" 
                                                                                            SortExpression="Escalated_To" UniqueName="Escalated_To">
                                                                                        </telerik:GridBoundColumn>
                                                                                          <telerik:GridBoundColumn DataField="Due_Dt" 
                                                            FilterControlAltText="Filter Due_Dt column" HeaderText="Due_Date" 
                                                            SortExpression="Due_Dt" UniqueName="Due_Dt">
                                                        </telerik:GridBoundColumn>
                                                                                    </Columns>
                                                                                    <EditFormSettings>
                                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                        </EditColumn>
                                                                                    </EditFormSettings>
                                                                                </MasterTableView>
                                                                                <ItemStyle Wrap="False" />
                                                                                <FilterMenu EnableImageSprites="False">
                                                                                </FilterMenu>
                                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                </HeaderContextMenu>
                                                                            </telerik:RadGrid>
                                                                        </asp:Panel>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </telerik:RadPageView>
                                                    </telerik:RadMultiPage>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                                          <table style="width: 100%">
                                              <tr>
                                                  <td style="height: 13px;" align="center" bgcolor="#666666" colspan="5">
                                                      <asp:Label ID="Label176" runat="server" Font-Bold="True" ForeColor="White" 
                                                          Text="Complaint Details"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 28px;">
                                                      <asp:Label ID="Label178" runat="server" Text="Department"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 28px;">
                                                      <telerik:RadComboBox ID="cbodepart" Runat="server" AllowCustomText="True" 
                                                          AutoPostBack="True" MarkFirstMatch="True" Skin="Outlook" Width="264px">
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 28px;">
                                                      <asp:Label ID="Label167" runat="server" Text="Issue Summary"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 28px;">
                                                      <telerik:RadComboBox ID="cbissue" Runat="server" AllowCustomText="True" 
                                                          EnableOverlay="False" Height="400px" MarkFirstMatch="True" MaxHeight="400px" 
                                                          Skin="Outlook" Width="300px">
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 28px;">
                                                  </td>
                                                  <td style="height: 28px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 28px;">
                                                      <asp:Label ID="Label156" runat="server" Text="Issue Description"></asp:Label>
                                                  </td>
                                                  <td colspan="2" rowspan="2">
                                                      <telerik:RadTextBox ID="txtdescr" Runat="server" Font-Size="Large" 
                                                          Height="50px" Rows="3" Skin="Outlook" style="font-size: medium" 
                                                          TextMode="MultiLine" Width="400px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 28px;">
                                                      &nbsp;</td>
                                                  <td style="height: 28px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 24px;">
                                                      <asp:Label ID="Label169" runat="server" Text="Action Taken"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 24px;">
                                                      <telerik:RadComboBox ID="cboaction" Runat="server" 
                                                          Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Closed" Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Selected="True" Text="Re-Open" 
                                                                  Value="R" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="height: 24px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 272px; height: 24px;">
                                                      <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                                  <td style="width: 131px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="height: 24px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#666666" colspan="5" style="height: 24px;">
                                                      <asp:Label ID="Label177" runat="server" Font-Bold="True" ForeColor="White" 
                                                          Text="Notes"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 27px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 27px;">
                                                      &nbsp;</td>
                                                  <td rowspan="3">
                                                      <telerik:RadTextBox ID="txtcomment" Runat="server" Font-Size="Large" 
                                                          Height="50px" Rows="3" Skin="Outlook" style="font-size: medium" 
                                                          TextMode="MultiLine" Width="300px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px; height: 27px;">
                                                      &nbsp;</td>
                                                  <td style="height: 27px">
                                                      <asp:Label ID="lblesc" runat="server"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 27px;">
                                                  </td>
                                                  <td style="width: 129px; height: 27px;">
                                                      <asp:Label ID="Label179" runat="server" Text="Short Notes"></asp:Label>
                                                  </td>
                                                  <td style="width: 131px; height: 27px;">
                                                  </td>
                                                  <td style="height: 27px">
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 26px;">
                                                      </td>
                                                  <td style="width: 129px; height: 26px;">
                                                      </td>
                                                  <td style="width: 131px; height: 26px;">
                                                      </td>
                                                  <td style="height: 26px">
                                                      </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 14px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 129px; height: 24px;">
                                                      &nbsp;</td>
                                                  <td style="width: 272px; height: 24px;">
                                                      <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" 
                                                          Text="Save" Width="150px">
                                                      </telerik:RadButton>
                                                      &nbsp;
                                                      </td>
                                                  <td style="height: 24px;" colspan="2">
                                                      <asp:Label ID="lblerr" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        <asp:Panel ID="Panel36" runat="server" Height="142px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td bgcolor="#666666" colspan="3">
                                                        <asp:Label ID="Label185" runat="server" ForeColor="White" Text="Reports"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 100px">
                                                        <asp:Label ID="Label6" runat="server" Text="Date From"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadDatePicker ID="dtFrom" Runat="server" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 100px">
                                                        <asp:Label ID="Label184" runat="server" Text="Date To"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadDatePicker ID="dtTo" Runat="server" Skin="Outlook">
                                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 100px">
                                                        <asp:Label ID="Label186" runat="server" Text="Status"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadComboBox ID="cboreport" Runat="server" Skin="Outlook" Width="250px">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="All" Value="A" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Open" Value="OPEN" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Resolved" Value="Resolved" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Closed" Value="Closed" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 100px">
                                                        &nbsp;</td>
                                                    <td>
                                                        <telerik:RadButton ID="btnupload0" runat="server" Skin="Simple" Text="Export" 
                                                            Width="150px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8" bgcolor="#666666">
                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" Text="Notes" 
                                            ForeColor="White"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666" class="style8">
                                        <asp:Label ID="Label180" runat="server" ForeColor="White" 
                                            style="font-weight: 700" Text="Documents"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1135px">
                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                            SortExpression="DOC_ID">
                                                                                                            <ItemTemplate>
                  <asp:LinkButton ID="lnkDownload" runat="server" Text="Download" OnClick="DownloadFile"
                    CommandArgument='<%# Eval("DOC_ID") %>'></asp:LinkButton>
                  </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                            ScrollBars="Horizontal" Width="1071px">
                                            <asp:Literal ID="ltEmbed" runat="server" />
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate> 
            </asp:UpdatePanel>
</asp:Content>

