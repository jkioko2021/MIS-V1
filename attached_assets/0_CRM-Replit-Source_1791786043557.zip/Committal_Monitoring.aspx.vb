﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim AB As Integer
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("PRINT") = Nothing
            Session("Report_") = Nothing
            Session("EXCEL") = Nothing
            HiddenField1.Value = 0
            DtEff.DbSelectedDate = Date.Now
            DtDue.DbSelectedDate = Date.Now
            Dtfrom.DbSelectedDate = Date.Now
            Dtto.DbSelectedDate = Date.Now
            DUE()
            LoadGrid()
            btnsave.Enabled = False
            txtprem.Enabled = False
            txtcomm.Enabled = False
            LBLFAMNO.Enabled = False
            txtcredit.Enabled = False
            DtEff.Enabled = False
            txtproposer.Enabled = False

            'txtmanager.Text = ""
            txtinvoice.Enabled = False
            txtnotesenr.Enabled = False

        End If

    End Sub
    Public Sub LoadGrid()

        GD_ENR.DataSource = Nothing
        GD_ENR.DataBind()
        GD_WITHIN.DataSource = Nothing
        GD_WITHIN.DataBind()
        GD_PAST.DataSource = Nothing
        GD_PAST.DataBind()
        GD_ARREARS.DataSource = Nothing
        GD_ARREARS.DataBind()
        GD_SUS.DataSource = Nothing
        GD_SUS.DataBind()
        GD_SUMM.DataSource = Nothing
        GD_SUMM.DataBind()
        GD_SUMM_STATUS.DataSource = Nothing
        GD_SUMM_STATUS.DataBind()
        ltEmbed.Text = ""
        SqlAction = "SELECT [Committal_Status],sum([Cnt_Committal])[Cnt_Committal],sum([Premium_Amt])[Premium_Amt],sum([Paid_Amt])[Paid_Amt],SUM([OS_Bal_Amt])[OS_Bal_Amt]  FROM [CRM].[dbo].[vw_MIS_CRM_COMMITTAL] GROUP BY [Committal_Status]"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_SUMM_STATUS.DataSource = MyDatable
            GD_SUMM_STATUS.DataBind()

            MyDatable = Nothing
        Else
            GD_SUMM_STATUS.DataSource = Nothing
            GD_SUMM_STATUS.DataBind()
        End If

        SqlAction = "SELECT [Mon],sum([Cnt_Committal])[Cnt_Committal],sum([Premium_Amt])[Premium_Amt],sum([Paid_Amt])[Paid_Amt],SUM([OS_Bal_Amt])[OS_Bal_Amt]  FROM [CRM].[dbo].[vw_MIS_CRM_COMMITTAL] WHERE    terminated=0 GROUP BY [Mon] "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_SUMM.DataSource = MyDatable
            GD_SUMM.DataBind()
            MyDatable = Nothing
        Else
            GD_SUMM.DataSource = Nothing
            GD_SUMM.DataBind()
        End If

        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Business,Agent_Name,Committal_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Enriched= 0 and committal_status<>'CLOSED' ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_ENR.DataSource = MyDatable
            GD_ENR.DataBind()
            Session("GD_ENR") = MyDatable
            MyDatable = Nothing
        Else
            GD_ENR.DataSource = Nothing
            GD_ENR.DataBind()
        End If

        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Business,Agent_Name,Committal_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Committal_Status= 'WITHIN_PERIOD'  and Enriched=1  ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_WITHIN.DataSource = MyDatable
            GD_WITHIN.DataBind()
            Session("GD_WITHIN") = MyDatable
            MyDatable = Nothing
        Else
            GD_WITHIN.DataSource = Nothing
            GD_WITHIN.DataBind()
        End If

        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Notice_Susp_Dt,ON_Notice,Notice_Date,Business,Agent_Name,Committal_Type   FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Committal_Status= 'PAST_DUE'  and Enriched=1 ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_PAST.DataSource = MyDatable
            GD_PAST.DataBind()
            Session("GD_PAST") = MyDatable
            MyDatable = Nothing
        Else
            GD_PAST.DataSource = Nothing
            GD_PAST.DataBind()
        End If

        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Termination_Dt,On_Demand,On_Notice,Notice_Date,Business,Agent_Name,Committal_Type   FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Committal_Status= 'IN_ARREARS'  and Enriched=1  ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_ARREARS.DataSource = MyDatable
            GD_ARREARS.DataBind()
            Session("GD_ARREARS") = MyDatable
            MyDatable = Nothing
        Else
            GD_ARREARS.DataSource = Nothing
            GD_ARREARS.DataBind()
        End If

        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Business,Agent_Name,Committal_Type   FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE suspended=1  and  Terminated=0   and Enriched=1 ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_SUS.DataSource = MyDatable
            GD_SUS.DataBind()
            Session("GD_SUS") = MyDatable
            MyDatable = Nothing
        Else
            GD_SUS.DataSource = Nothing
            GD_SUS.DataBind()
        End If

        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Business,Agent_Name,Committal_Type   FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Terminated=1   and Enriched=1 ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_TERM.DataSource = MyDatable
            GD_TERM.DataBind()
            Session("GD_TERM") = MyDatable
            MyDatable = Nothing
        Else
            GD_TERM.DataSource = Nothing
            GD_TERM.DataBind()
        End If
        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Business,Agent_Name,Committal_Type   FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Committal_Status= 'CLOSED'  and Enriched=1  ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_CLOSED.DataSource = MyDatable
            GD_CLOSED.DataBind()
            Session("GD_CLOSED") = MyDatable
            MyDatable = Nothing
        Else
            GD_CLOSED.DataSource = Nothing
            GD_CLOSED.DataBind()
        End If
    End Sub
    Public Sub Load_Notes()
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        GD_DOCS.DataSource = Nothing
        GD_DOCS.DataBind()
        SqlAction = "SELECT [Note_id],[Notes],[Note_From],[Note_Date],[Note_Type] FROM  [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL_NOTES] WHERE  Ref_No ='" & LBLFAMNO.Text & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If

        MyDatable = Nothing
        SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By],Doc_Ref FROM [Doc_Arc_DB].[dbo].[TBL_MIS_COMMITTAL_DOCS] WHERE  File_No ='" & LBLFAMNO.Text & "' AND Active=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
            MyDatable = Nothing
        Else
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
        End If

    End Sub
    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        LBLFAMNO.Text = ""
        ltEmbed.Text = ""
        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Requested_by],[Manager],[New_Client],Committal_Status,Business,Agent_Name,Committal_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Proposer_Name LIKE  '%" & Trim(TXTSEARCH.Text) & "%' ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_ENR.DataSource = MyDatable
            GD_ENR.DataBind()
            MyDatable = Nothing
        Else
            GD_ENR.DataSource = Nothing
            GD_ENR.DataBind()
        End If
        Load_Notes()
    End Sub
    Protected Sub GD_ENR_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_ENR.SelectedIndexChanged
        Try
            LBLFAMNO.Text = ""
            ltEmbed.Text = ""
            LBLFAMNO.Text = (DirectCast(GD_ENR.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()
            SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[Request],[Manager],[New_Client],Invoice_no,Requested_by  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Ref_No ='" & LBLFAMNO.Text & "' ORDER BY Commit_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                txtprem.Text = MyDatable.Rows(0).Item("Premium_Amt").ToString()
                'txtpaid.Text = MyDatable.Rows(0).Item("Paid_Amt").ToString()
                txtcomm.Text = MyDatable.Rows(0).Item("OS_Bal_Amt").ToString()
                txtcredit.Text = MyDatable.Rows(0).Item("Credit_Period").ToString()
                DtEff.DbSelectedDate = MyDatable.Rows(0).Item("Effective_Dt").ToString()
                DtDue.DbSelectedDate = MyDatable.Rows(0).Item("Due_Dt").ToString()
                'lblNo_enr.Text = MyDatable.Rows(0).Item("Ref_No").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
               
                txtinvoice.Text = MyDatable.Rows(0).Item("Invoice_no").ToString()

                btnsave.Enabled = False
                txtprem.Enabled = False
                txtcomm.Enabled = False
                LBLFAMNO.Enabled = False
                txtcredit.Enabled = False
                DtEff.Enabled = False
                txtproposer.Enabled = False

                'txtmanager.Text = ""
                txtinvoice.Enabled = False
                txtnotesenr.Enabled = False

                Load_Notes()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GD_ENR_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_ENR.PageIndexChanged
        GD_ENR.CurrentPageIndex = e.NewPageIndex
        GD_ENR.DataSource = Session("GD_ENR")
        GD_ENR.DataBind()
    End Sub

    Protected Sub GD_PAST_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_PAST.PageIndexChanged
        GD_PAST.CurrentPageIndex = e.NewPageIndex
        GD_PAST.DataSource = Session("GD_PAST")
        GD_PAST.DataBind()
    End Sub
    Protected Sub GD_WITHIN_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_WITHIN.PageIndexChanged
        GD_WITHIN.CurrentPageIndex = e.NewPageIndex
        GD_WITHIN.DataSource = Session("GD_WITHIN")
        GD_WITHIN.DataBind()
    End Sub
    Protected Sub GD_ARREARS_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_ARREARS.PageIndexChanged
        GD_ARREARS.CurrentPageIndex = e.NewPageIndex
        GD_ARREARS.DataSource = Session("GD_ARREARS")
        GD_ARREARS.DataBind()
    End Sub
    Protected Sub GD_TERM_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_TERM.PageIndexChanged
        GD_TERM.CurrentPageIndex = e.NewPageIndex
        GD_TERM.DataSource = Session("GD_TERM")
        GD_TERM.DataBind()
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)
    End Sub



    Protected Sub RadButton7_Click(sender As Object, e As System.EventArgs) Handles RadButton7.Click
        Try
            If LBLFAMNO.Text = "" Then
                lblerr.Text = "You Must select Record!"
                Exit Sub
            End If

            If txtnotespast.Text = "" Then
                lblerr.Text = "You Must enter some Notes!"
                Exit Sub
            End If

            If chksusp.Checked = True Then
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] SET suspended=1,committal_status='SUSPENDED' where [Ref_No]='" & LBLFAMNO.Text & "'")

            End If
            MyDBAction.TRACKING_COMMITTAL_MESSAGES(LBLFAMNO.Text, txtnotespast.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMMITTAL")
            txtnotespast.Text = ""
            lblerr.Text = "Saved Successfully!"
            LoadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_WITHIN_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_WITHIN.SelectedIndexChanged
        Try
            LBLFAMNO.Text = ""
            LBLFAMNO.Text = (DirectCast(GD_WITHIN.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()
            Load_Notes()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_ARREARS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_ARREARS.SelectedIndexChanged
        Try
            LBLFAMNO.Text = ""
            ltEmbed.Text = ""
            LBLFAMNO.Text = (DirectCast(GD_ARREARS.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()
            SqlAction = "SELECT Proposer_ID,AGENT_NAME,RM_Name,PROPOSER_PRI_ADD,Effective_Dt,Due_dt,proposer_name,OS_Bal_Amt,Termination_Dt,Town  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Ref_No ='" & LBLFAMNO.Text & "' ORDER BY Commit_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                txtaddress_2.Text = MyDatable.Rows(0).Item("PROPOSER_PRI_ADD").ToString()
                txtproposer_2.Text = MyDatable.Rows(0).Item("proposer_name").ToString()
                txttown_2.Text = MyDatable.Rows(0).Item("Town").ToString()
                DtEff_2.DbSelectedDate = MyDatable.Rows(0).Item("Effective_Dt").ToString()
                Dtdue_2.DbSelectedDate = MyDatable.Rows(0).Item("Due_dt").ToString()
                txtBal_2.Text = MyDatable.Rows(0).Item("OS_Bal_Amt").ToString()
                DtTerm.DbSelectedDate = MyDatable.Rows(0).Item("Termination_Dt").ToString()
            End If

            Load_Notes()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_PAST_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_PAST.SelectedIndexChanged
        Try
            LBLFAMNO.Text = ""
            ltEmbed.Text = ""
            LBLFAMNO.Text = (DirectCast(GD_PAST.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()

            SqlAction = "SELECT Proposer_ID,AGENT_NAME,RM_Name,PROPOSER_PRI_ADD,Effective_Dt,Due_dt,proposer_name,OS_Bal_Amt,Notice_Susp_Dt,Town  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Ref_No ='" & LBLFAMNO.Text & "' ORDER BY Commit_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                txtaddress_1.Text = MyDatable.Rows(0).Item("PROPOSER_PRI_ADD").ToString()
                txtproposer_1.Text = MyDatable.Rows(0).Item("proposer_name").ToString()
                txttown_1.Text = MyDatable.Rows(0).Item("Town").ToString()
                DtEff_1.DbSelectedDate = MyDatable.Rows(0).Item("Effective_Dt").ToString()
                Dtdue_1.DbSelectedDate = MyDatable.Rows(0).Item("Due_dt").ToString()
                txtBal_1.Text = MyDatable.Rows(0).Item("OS_Bal_Amt").ToString()
                DtSusp.DbSelectedDate = MyDatable.Rows(0).Item("Notice_Susp_Dt").ToString()

            End If


            Load_Notes()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GD_SUS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_SUS.SelectedIndexChanged
        Try
            LBLFAMNO.Text = ""
            ltEmbed.Text = ""
            LBLFAMNO.Text = (DirectCast(GD_SUS.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()
            Load_Notes()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try

            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String
            If cboreport.SelectedValue = "A" Then
                SqlAction = "SELECT [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client],[Entered_By],[Entry_Date],[Committal_Status],[Period_From],[Period_To],[Proposer_ID],[Invoice_No],[Enriched],[Suspended],[Supend_By],[Data_Date],Requested_by,Request,Agent_Name,Committal_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] ORDER BY Commit_Id DESC"
                Reportname = cboreport.Text
            Else
                SqlAction = "SELECT [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client],[Entered_By],[Entry_Date],[Committal_Status],[Period_From],[Period_To],[Proposer_ID],[Invoice_No],[Enriched],[Suspended],[Supend_By],[Data_Date],Requested_by,Request,Agent_Name,Committal_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Committal_Status='" & cboreport.Text & "' ORDER BY Commit_Id DESC"
                Reportname = cboreport.Text
            End If
            Session("EXCEL") = "TO EXCEL"
            Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
            'Reportname = ""
        Catch ex As Exception

        End Try
    End Sub

    Public Sub DUE()
        SqlAction = "SELECT [Mon],sum([Cnt_Committal])[Cnt_Committal],sum([Premium_Amt])[Premium_Amt],sum([Paid_Amt])[Paid_Amt],SUM([OS_Bal_Amt])[OS_Bal_Amt]  FROM [CRM].[dbo].[vw_MIS_CRM_COMMITTAL] WHERE  CONVERT(DATE,effective_dt)  BETWEEN '" & CDate(Dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(Dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY [Mon] "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_SUMM.DataSource = MyDatable
            GD_SUMM.DataBind()
            MyDatable = Nothing
        Else
            GD_SUMM.DataSource = Nothing
            GD_SUMM.DataBind()
        End If

        SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client],Committal_Status ,Notice_Date FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE  (On_Notice=1 or On_Demand=1) and datediff(DAY,Notice_Date,getdate())>0 AND Enriched= 1 and committal_status<>'CLOSED' and terminated=0 ORDER BY Commit_Id DESC"

        ' SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client],Committal_Status  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE CONVERT(DATE,Due_Dt)  BETWEEN '" & CDate(Dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(Dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Enriched= 1 and committal_status<>'CLOSED' ORDER BY Commit_Id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then

            GD_DUE.DataSource = MyDatable
            GD_DUE.DataBind()
            Session("GD_ENR") = MyDatable
            MyDatable = Nothing
        Else
            GD_DUE.DataSource = Nothing
            GD_DUE.DataBind()
        End If
    End Sub

    Protected Sub cmdview0_Click(sender As Object, e As System.EventArgs) Handles cmdview0.Click
        Try
            LBLFAMNO.Text = ""
            ltEmbed.Text = ""
            SqlAction = "SELECT [Mon_Due],sum([Cnt_Committal])[Cnt_Committal],sum([Premium_Amt])[Premium_Amt],sum([Paid_Amt])[Paid_Amt],SUM([OS_Bal_Amt])[OS_Bal_Amt]  FROM [CRM].[dbo].[vw_MIS_CRM_COMMITTAL] WHERE  CONVERT(DATE,Due_Dt)  BETWEEN '" & CDate(Dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(Dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND [Committal_Status]<>'CLOSED' GROUP BY [Mon_Due] "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GD_SUMM.DataSource = MyDatable
                GD_SUMM.DataBind()
                MyDatable = Nothing
            Else
                GD_SUMM.DataSource = Nothing
                GD_SUMM.DataBind()
            End If

            SqlAction = "SELECT  [Commit_Id],[Ref_No],[Proposer_Name],[Premium_Amt],[Paid_Amt],[OS_Bal_Amt],[Credit_Period],[Effective_Dt],[Due_Dt],[RM_Name],[Manager],[New_Client],Committal_Status  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE CONVERT(DATE,Due_Dt)  BETWEEN '" & CDate(Dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(Dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Enriched= 1 and committal_status<>'CLOSED' ORDER BY Commit_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                GD_DUE.DataSource = MyDatable
                GD_DUE.DataBind()
                Session("GD_ENR") = MyDatable
                MyDatable = Nothing
            Else
                GD_DUE.DataSource = Nothing
                GD_DUE.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/File_Commital.ashx?Id="), id)
    End Sub

    Protected Sub RadButton8_Click(sender As Object, e As System.EventArgs) Handles RadButton8.Click
        Try
            If LBLFAMNO.Text = "" Then
                lblerr.Text = "You Must select Record!"
                Exit Sub
            End If

            If chknotice.Checked = True Then
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] SET Notice_Date='" & CDate(DtSusp.DbSelectedDate).ToString("yyyy-MM-dd") & "', [ON_Notice]=1,Notice_Susp_Dt='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "',Town='" & txttown_1.Text & "',PROPOSER_PRI_ADD='" & Trim(txtaddress_1.Text) & "' where [Ref_No]='" & LBLFAMNO.Text & "'")

                SqlAction = "SELECT Ref_No, Proposer_ID,AGENT_NAME,RM_Name,PROPOSER_PRI_ADD,Effective_Dt,Due_dt,proposer_name,OS_Bal_Amt,Notice_Date,Town  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Ref_No ='" & LBLFAMNO.Text & "' ORDER BY Commit_Id DESC"
                MyDatable = Nothing
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    Session("Report_") = "Notice_Letter"
                    'GENERATE_RPT(MyDatable_1)

                    Session("PRINT") = "PDF"
                    'MyDatable_1 = Nothing
                    Session("Mytable") = Nothing
                    Session("Reportname") = Nothing
                    Session("Mytable") = (MyDatable)
                    Session("Reportname") = Session("Report_")
                    ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                    MyDatable = Nothing
                    System.Threading.Thread.Sleep(5000)
                End If

                MyDBAction.TRACKING_COMMITTAL_MESSAGES(LBLFAMNO.Text, "Generated Suspension Notice", Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMMITTAL")
                LoadGrid()
                'ShowReport()
            End If

        Catch ex As Exception
            lblerr.Text = "Error No data found"
        End Try
    End Sub

   

    Protected Sub RadButton9_Click(sender As Object, e As System.EventArgs) Handles RadButton9.Click
        Try
            If LBLFAMNO.Text = "" Then
                lblerr.Text = "You Must select Record!"
                Exit Sub
            End If

            If chkterminate.Checked = True Then
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] SET  Notice_Date='" & CDate(DtTerm.DbSelectedDate).ToString("yyyy-MM-dd") & "', [On_demand]=1,Termination_Dt='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "',Town='" & txttown_2.Text & "',PROPOSER_PRI_ADD='" & Trim(txtaddress_2.Text) & "' where [Ref_No]='" & LBLFAMNO.Text & "'")

                SqlAction = "SELECT Ref_No, Proposer_ID,AGENT_NAME,RM_Name,PROPOSER_PRI_ADD,Effective_Dt,Due_dt,proposer_name,OS_Bal_Amt,Termination_Dt,Notice_Date,Town  FROM [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] WHERE Ref_No ='" & LBLFAMNO.Text & "' ORDER BY Commit_Id DESC"
                MyDatable = Nothing
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    Session("Report_") = "Demand_Letter"
                    'GENERATE_RPT(MyDatable_1)

                    Session("PRINT") = "PDF"
                    'MyDatable_1 = Nothing
                    Session("Mytable") = Nothing
                    Session("Reportname") = Nothing
                    Session("Mytable") = (MyDatable)
                    Session("Reportname") = Session("Report_")
                    ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                    MyDatable = Nothing
                    System.Threading.Thread.Sleep(5000)
                End If
                MyDBAction.TRACKING_COMMITTAL_MESSAGES(LBLFAMNO.Text, "Generated Demand Letter", Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMMITTAL")
                LoadGrid()
                'ShowReport()
            End If


        Catch ex As Exception
            lblerr.Text = "Error No data found"
        End Try
    End Sub
    Protected Sub GD_PAST_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GD_PAST.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then

            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("ON_Notice")
            If myCell.Text = 1 Then
                dataItem.BackColor = Drawing.Color.SkyBlue
            End If
        End If
    End Sub
    Protected Sub GD_ARREARS_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GD_ARREARS.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then

            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("On_demand")
            If myCell.Text = 1 Then
                dataItem.BackColor = Drawing.Color.Red
            End If

            Dim myCell_1 As TableCell = dataItem("ON_Notice")
            If myCell_1.Text = 1 Then
                dataItem.BackColor = Drawing.Color.SkyBlue
            End If
        End If
    End Sub
    Protected Sub GD_DUE_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GD_DUE.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then

            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("Committal_Status")
            If myCell.Text = "IN_ARREARS" Then
                dataItem.BackColor = Drawing.Color.Red
            End If

            Dim myCell_1 As TableCell = dataItem("Committal_Status")
            If myCell_1.Text = "PAST_DUE" Then
                dataItem.BackColor = Drawing.Color.SkyBlue
            End If
        End If
    End Sub

    Protected Sub RadButton12_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try
            If txtnotesenr.Text = "" Then
                lblerr.Text = "You Must enter some Notes!"
                Exit Sub
            End If
            If LBLFAMNO.Text = "" Then
                lblerr.Text = "You Must select Record!"
                Exit Sub
            End If

            If txtinvoice.Text <> "" Then
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] SET suspended=0, Enriched=1,  Invoice_No='" & Trim(txtinvoice.Text.ToUpper) & "' , [Due_Dt]='" & CDate(DtDue.DbSelectedDate).ToString("yyyy-MM-dd") & "',committal_status='', [effective_Dt]='" & CDate(DtEff.DbSelectedDate).ToString("yyyy-MM-dd") & "', [Credit_Period]='" & txtcredit.Text & "' ,[Premium_Amt]='" & txtprem.Text & "' where [Ref_No]='" & LBLFAMNO.Text & "'")
                MyDBAction.TRACKING_COMMITTAL_UPDATE(LBLFAMNO.Text)

            Else
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] SET suspended=0, Enriched=0,  Invoice_No='" & Trim(txtinvoice.Text.ToUpper) & "',  [Due_Dt]='" & CDate(DtDue.DbSelectedDate).ToString("yyyy-MM-dd") & "',committal_status='WITHIN_PERIOD', [effective_Dt]='" & CDate(DtEff.DbSelectedDate).ToString("yyyy-MM-dd") & "', [Credit_Period]='" & txtcredit.Text & "' ,[Premium_Amt]='" & txtprem.Text & "' where [Ref_No]='" & LBLFAMNO.Text & "'")
            End If



            MyDBAction.TRACKING_COMMITTAL_MESSAGES(LBLFAMNO.Text, txtnotesenr.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMMITTAL")
            lblerr.Text = "Saved Successfull"
            txtprem.Text = ""
            txtcomm.Text = ""
            LBLFAMNO.Text = ""
            txtcredit.Text = 0
            DtEff.DbSelectedDate = Date.Now()
            txtproposer.Text = ""

            'txtmanager.Text = ""
            txtinvoice.Text = ""
            txtnotesenr.Text = ""
            LoadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton11_Click(sender As Object, e As System.EventArgs) Handles RadButton11.Click
        Try
            If LBLFAMNO.Text = "" Then
                lblerr.Text = "You Must select Record!"
                Exit Sub
            End If

            If txtnotesterm.Text = "" Then
                lblerr.Text = "You Must enter some Notes!"
                Exit Sub
            End If

            If chkterm.Checked = True Then
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] SET Terminated=1,committal_status='TERMINATED' where [Ref_No]='" & LBLFAMNO.Text & "'")

            End If
            MyDBAction.TRACKING_COMMITTAL_MESSAGES(LBLFAMNO.Text, txtnotesterm.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMMITTAL")
            txtnotesterm.Text = ""
            lblerr.Text = "Saved Successfully!"
            LoadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton10_Click(sender As Object, e As System.EventArgs) Handles RadButton10.Click
        Try
            If LBLFAMNO.Text = "" Then
                lblerr.Text = "You Must select Record!"
                Exit Sub
            End If

            If txtnoteslift.Text = "" Then
                lblerr.Text = "You Must enter some Notes!"
                Exit Sub
            End If

            If chklift.Checked = True Then
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_COMMITTAL] SET suspended=0,committal_status='PAST_DUE' where [Ref_No]='" & LBLFAMNO.Text & "'")

            End If
            MyDBAction.TRACKING_COMMITTAL_MESSAGES(LBLFAMNO.Text, txtnoteslift.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMMITTAL")
            txtnoteslift.Text = ""
            lblerr.Text = "Saved Successfully!"
            LoadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub txtcredit_TextChanged(sender As Object, e As System.EventArgs) Handles txtcredit.TextChanged
        Try
            Dim IN_1 As Integer = txtcredit.Text


            DtDue.DbSelectedDate = DateAdd(DateInterval.Day, IN_1, DtEff.DbSelectedDate())
        Catch ex As Exception

        End Try
    End Sub
 

    Protected Sub GD_TERM_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_TERM.SelectedIndexChanged
        Try
            LBLFAMNO.Text = ""
            LBLFAMNO.Text = (DirectCast(GD_TERM.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()

            Load_Notes()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    

    Protected Sub DtDue_SelectedDateChanged(sender As Object, e As Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs) Handles DtDue.SelectedDateChanged
        Try
            Dim st As Integer
            txtcredit.Text = DateDiff(DateInterval.Day, DtEff.DbSelectedDate, DtDue.DbSelectedDate)
        Catch ex As Exception

        End Try
    End Sub

 

    Protected Sub GD_CLOSED_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_CLOSED.SelectedIndexChanged
        Try
            LBLFAMNO.Text = ""
            LBLFAMNO.Text = (DirectCast(GD_CLOSED.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()

            Load_Notes()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton13_Click(sender As Object, e As System.EventArgs) Handles btnedit.Click
        btnsave.Enabled = True
        txtprem.Enabled = True
        txtcomm.Enabled = True
        LBLFAMNO.Enabled = True
        txtcredit.Enabled = True
        DtEff.Enabled = True
        txtproposer.Enabled = True

        'txtmanager.Text = ""
        txtinvoice.Enabled = True
        txtnotesenr.Enabled = True

    End Sub
End Class
