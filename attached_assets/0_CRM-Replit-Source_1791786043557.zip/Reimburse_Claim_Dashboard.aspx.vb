﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing

                dtfrom.DbSelectedDate = Date.Now()
                dtto.DbSelectedDate = Date.Now()
                Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 and department='CLAIMS' and profileid=21" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboNAME
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                    .DataValueField = MyDatatable.Columns("username").ToString
                    .DataBind()
                End With

                cboNAME.SelectedValue = Session("username")
                loadGrid_N()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If

    End Sub
    Public Sub loadGrid_N()

        SqlAction = "SELECT[Allocate_To],sum([RETURNED])[RETURNED],sum([NOT_SUBMITTED])[NOT_SUBMITTED],sum([SUBMITTED])[SUBMITTED],sum([SCANNING])[SCANNING],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([NOT_PROCESSED])[NOT_PROCESSED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([SIGNATORY])[SIGNATORY],sum([PAID])[PAID],sum([MEMBERSHIP_ISSUE])[MEMBERSHIP_ISSUE]  FROM [CRM].[dbo].[vw_MIS_CRM_MED_ASS_CLAIM_STATUS] WITH(NOLOCK) WHERE Allocate_To='" & Session("username") & "'  GROUP BY Allocate_To"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_0.DataSource = MyDatable
            GDTracking_0.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
        End If
    End Sub

    Public Sub loadGrid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable

        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        Try

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [dbo].[TBL_MIS_CRM_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub



    Protected Sub GDTracking_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTracking.SelectedIndexChanged
        Try
            HiddenField1.Value = 1
            ID = (DirectCast(GDTracking.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            SqlAction = "SELECT [File_No],Allocate_To,entered_by   FROM [CRM].[dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) WHERE File_No='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                FILE_NO.Text = MyDatable.Rows(0).Item("File_No").ToString()
                lblenteredby.Text = MyDatable.Rows(0).Item("entered_by").ToString()
                lblupdateby.Text = MyDatable.Rows(0).Item("Allocate_to").ToString()
                loadGrid(FILE_NO.Text)
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDTracking.DataSource = Nothing
            GDTracking.DataBind()
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            If chkdate.Checked = True And chkname.Checked = False Then
                SqlAction = "SELECT [Allocate_To],sum([RETURNED])[RETURNED],sum([NOT_SUBMITTED])[NOT_SUBMITTED],sum([SUBMITTED])[SUBMITTED],sum([SCANNING])[SCANNING],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([NOT_PROCESSED])[NOT_PROCESSED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([SIGNATORY])[SIGNATORY],sum([PAID])[PAID],sum([MEMBERSHIP_ISSUE])[MEMBERSHIP_ISSUE]  FROM [CRM].[dbo].[vw_MIS_CRM_MED_ASS_CLAIM_STATUS] WITH(NOLOCK) WHERE   [Receive_dt]  Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY Allocate_To"

            ElseIf chkdate.Checked = False And chkname.Checked = True Then
                SqlAction = "SELECT [Allocate_To],sum([RETURNED])[RETURNED],sum([NOT_SUBMITTED])[NOT_SUBMITTED],sum([SUBMITTED])[SUBMITTED],sum([SCANNING])[SCANNING],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([NOT_PROCESSED])[NOT_PROCESSED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([SIGNATORY])[SIGNATORY],sum([PAID])[PAID],sum([MEMBERSHIP_ISSUE])[MEMBERSHIP_ISSUE]   FROM [CRM].[dbo].[vw_MIS_CRM_MED_ASS_CLAIM_STATUS] WITH(NOLOCK) WHERE   Allocate_To ='" & cboNAME.SelectedValue & "' GROUP BY Allocate_To"

            ElseIf chkdate.Checked = True And chkname.Checked = True Then
                SqlAction = "SELECT [Allocate_To],sum([RETURNED])[RETURNED],sum([NOT_SUBMITTED])[NOT_SUBMITTED],sum([SUBMITTED])[SUBMITTED],sum([SCANNING])[SCANNING],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([NOT_PROCESSED])[NOT_PROCESSED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([SIGNATORY])[SIGNATORY],sum([PAID])[PAID],sum([MEMBERSHIP_ISSUE])[MEMBERSHIP_ISSUE]   FROM [CRM].[dbo].[vw_MIS_CRM_MED_ASS_CLAIM_STATUS] WITH(NOLOCK) WHERE   Allocate_To ='" & cboNAME.SelectedValue & "' and Entry_Date Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' GROUP BY Allocate_To"

            Else
                SqlAction = "SELECT [Allocate_To],sum([RETURNED])[RETURNED],sum([NOT_SUBMITTED])[NOT_SUBMITTED],sum([SUBMITTED])[SUBMITTED],sum([SCANNING])[SCANNING],sum([NOT_ALLOCATED])[NOT_ALLOCATED],sum([NOT_PROCESSED])[NOT_PROCESSED],sum([PROCESSED])[PROCESSED],sum([AUDITED])[AUDITED],sum([SIGNATORY])[SIGNATORY],sum([PAID])[PAID],sum([MEMBERSHIP_ISSUE])[MEMBERSHIP_ISSUE]   FROM [CRM].[dbo].[vw_MIS_CRM_MED_ASS_CLAIM_STATUS] WITH(NOLOCK)  GROUP BY Allocate_To"

            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking_0.DataSource = MyDatable
                GDTracking_0.DataBind()
                Session("DAD_T_0") = MyDatable
                MyDatable = Nothing
            Else
                GDTracking_0.DataSource = Nothing
                GDTracking_0.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDTracking_0_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDTracking_0.NeedDataSource

    End Sub

    Protected Sub GDTracking_0_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTracking_0.SelectedIndexChanged
        Try
            GDTracking.DataSource = Nothing
            GDTracking.DataBind()
            HiddenField1.Value = 1
            ID = (DirectCast(GDTracking_0.SelectedItems(0), GridDataItem)).GetDataKeyValue("Allocate_To").ToString()
            SqlAction = "SELECT Receive_dt,File_No,Member_No,Member_Name,Invoice_Amt,Invoice_No,Inv_Status, [Allocate_To] FROM CRM.[dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) where   Active=1 and Allocate_To='" & ID & "' AND Receive_dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' order by INV_Status"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking.DataSource = MyDatable
                GDTracking.DataBind()
                Session("DAD_T_1") = MyDatable
                MyDatable = Nothing
            Else
                SqlAction = "SELECT Receive_dt,File_No,Member_No,Member_Name,Invoice_Amt,Invoice_No,Inv_Status, [Allocate_To] FROM CRM.[dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) where   Active=1 and Allocate_To IS NULL AND Receive_dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' order by INV_Status"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDTracking.DataSource = MyDatable
                    GDTracking.DataBind()
                    Session("DAD_T_1") = MyDatable
                    MyDatable = Nothing
                Else
                    GDTracking.DataSource = Nothing
                    GDTracking.DataBind()
                End If

            
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDTracking_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTracking.PageIndexChanged
        GDTracking.CurrentPageIndex = e.NewPageIndex
        GDTracking.DataSource = Session("DAD_T_1")
        GDTracking.DataBind()
    End Sub
    Protected Sub GDTracking_0_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTracking_0.PageIndexChanged
        GDTracking_0.CurrentPageIndex = e.NewPageIndex
        GDTracking_0.DataSource = Session("DAD_T_0")
        GDTracking_0.DataBind()
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "Reimbursement_List"

        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        If chkdate.Checked = True And chkname.Checked = False Then
            SqlAction = "SELECT [File_No],[Receive_dt],[Service_dt],[Claim_Type],[Member_No],[Member_Name],[Invoice_No],[Invoice_Amt],[Reason],[Rm],[Proposer],[Mobile_No],[Email],[Inv_Status] ,[Allocate_To],[Submitted],[Submitted_By],[Submit_dt],[Ready_To_Process],[Returned],[Returned_Dt],[Returned_By],[Decline_dt],[Decline_By],[Approved],[Approved_By],[Approve_Dt],[Indexed],[Bar_code],[Index_Dt],[Allocated],Allocate_Dt,[Receive_dt],[Allocate_To],[Allocate_By],[Processed],[Process_Dt],[Processed_By],[Payable_Amt],[Inadmissable_Amt],[Audited],[Audit_Dt],[Audit_By],[e_Claim_Provider],[Posting],[Posting_Date],[Posting_By],[Pay_Ref_No],[Mode_Of_Payment],[Signed],[Sign_Dt],[Dispatched],[Dispatch_Dt],[Dispatch_By],[Comments],[Active],[Is_Appeal],[Is_Special],[Appeal_Dt],[Special_Req_Dt]  FROM [CRM].[dbo].[TBL_MIS_REIMB_TRACKING] with(nolock) WHERE    Active=1 and  Receive_dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
        ElseIf chkdate.Checked = False And chkname.Checked = True Then
            SqlAction = "SELECT [File_No],[Receive_dt],[Service_dt],[Claim_Type],[Member_No],[Member_Name],[Invoice_No],[Invoice_Amt],[Reason],[Rm],[Proposer],[Mobile_No],[Email],[Inv_Status] ,[Allocate_To],[Submitted],[Submitted_By],[Submit_dt],[Ready_To_Process],[Returned],[Returned_Dt],[Returned_By],[Decline_dt],[Decline_By],[Approved],[Approved_By],[Approve_Dt],[Indexed],[Bar_code],[Index_Dt],[Allocated],Allocate_Dt,[Receive_dt],[Allocate_To],[Allocate_By],[Processed],[Process_Dt],[Processed_By],[Payable_Amt],[Inadmissable_Amt],[Audited],[Audit_Dt],[Audit_By],[e_Claim_Provider],[Posting],[Posting_Date],[Posting_By],[Pay_Ref_No],[Mode_Of_Payment],[Signed],[Sign_Dt],[Dispatched],[Dispatch_Dt],[Dispatch_By],[Comments],[Active],[Is_Appeal],[Is_Special],[Appeal_Dt],[Special_Req_Dt]  FROM [CRM].[dbo].[TBL_MIS_REIMB_TRACKING] with(nolock) WHERE    Active=1 and  Allocate_To ='" & cboNAME.SelectedValue & "'"
        ElseIf chkdate.Checked = True And chkname.Checked = True Then
            SqlAction = "SELECT [File_No],[Receive_dt],[Service_dt],[Claim_Type],[Member_No],[Member_Name],[Invoice_No],[Invoice_Amt],[Reason],[Rm],[Proposer],[Mobile_No],[Email],[Inv_Status] ,[Allocate_To],[Submitted],[Submitted_By],[Submit_dt],[Ready_To_Process],[Returned],[Returned_Dt],[Returned_By],[Decline_dt],[Decline_By],[Approved],[Approved_By],[Approve_Dt],[Indexed],[Bar_code],[Index_Dt],[Allocated],Allocate_Dt,[Receive_dt],[Allocate_To],[Allocate_By],[Processed],[Process_Dt],[Processed_By],[Payable_Amt],[Inadmissable_Amt],[Audited],[Audit_Dt],[Audit_By],[e_Claim_Provider],[Posting],[Posting_Date],[Posting_By],[Pay_Ref_No],[Mode_Of_Payment],[Signed],[Sign_Dt],[Dispatched],[Dispatch_Dt],[Dispatch_By],[Comments],[Active],[Is_Appeal],[Is_Special],[Appeal_Dt],[Special_Req_Dt]  FROM [CRM].[dbo].[TBL_MIS_REIMB_TRACKING] with(nolock) WHERE    Active=1 and  Allocate_To ='" & cboNAME.SelectedValue & "' and Receive_dt Between '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
        Else
            SqlAction = "SELECT [File_No],[Receive_dt],[Service_dt],[Claim_Type],[Member_No],[Member_Name],[Invoice_No],[Invoice_Amt],[Reason],[Rm],[Proposer],[Mobile_No],[Email],[Inv_Status] ,[Allocate_To],[Submitted],[Submitted_By],[Submit_dt],[Ready_To_Process],[Returned],[Returned_Dt],[Returned_By],[Decline_dt],[Decline_By],[Approved],[Approved_By],[Approve_Dt],[Indexed],[Bar_code],[Index_Dt],[Allocated],Allocate_Dt,[Receive_dt],[Allocate_To],[Allocate_By],[Processed],[Process_Dt],[Processed_By],[Payable_Amt],[Inadmissable_Amt],[Audited],[Audit_Dt],[Audit_By],[e_Claim_Provider],[Posting],[Posting_Date],[Posting_By],[Pay_Ref_No],[Mode_Of_Payment],[Signed],[Sign_Dt],[Dispatched],[Dispatch_Dt],[Dispatch_By],[Comments],[Active],[Is_Appeal],[Is_Special],[Appeal_Dt],[Special_Req_Dt]  FROM [CRM].[dbo].[TBL_MIS_REIMB_TRACKING] with(nolock) where  Active=1 "
        End If


        Session("EXCEL") = "TO EXCEL"
        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
        'Reportname = ""
    End Sub


End Class
