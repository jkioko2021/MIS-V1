﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
          
            Load_Grid()
          
            Session("EXCEL") = Nothing
        End If
    End Sub

    Protected Sub Search_Click(sender As Object, e As System.EventArgs) Handles Search.Click
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
          

            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],LOADING_RATE,[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE],POLICY_CODE,ON_HOLD  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE FAMILY_NO = '" & Trim(txtsearch.Text) & "' AND  VERIFIED=1 and APPROVED=0"
            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                RDHOLD.DataSource = MyDatable
                RDHOLD.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                RDHOLD.DataSource = MyDatable
                RDHOLD.DataBind()
            End If
        Catch ex As Exception
            lblhold.Text = ex.Message
        End Try
    End Sub

    Protected Sub RDHOLD_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles RDHOLD.SelectedIndexChanged
        Dim ID As String = ""
        Session("IP_L_RATE") = Nothing
        Session("LOADED_IP_PREM") = Nothing
        Session("LOADED_OP_PREM") = Nothing
        Session("MEMBER_NO") = Nothing
        Session("POLICY_VALID_FROM") = Nothing
        Session("POLICY_VALID_UPTO") = Nothing
        Session("POLICY_CODE") = Nothing

        ID = (DirectCast(RDHOLD.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT [ID],COMMENTS,ON_HOLD,POLICY_CODE,MEMBER_NO  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE ID = '" & ID & "' AND  VERIFIED=1   and APPROVED=0"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                txthold.Text = MyDatable.Rows(0).Item("COMMENTS").ToString()
                chkhD.Checked = MyDatable.Rows(0).Item("ON_HOLD").ToString()
                lblpOlicy.Text = MyDatable.Rows(0).Item("POLICY_CODE").ToString()
                lblmem.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
            End If
        End If
    End Sub

    Protected Sub RadButton8_Click(sender As Object, e As System.EventArgs) Handles RadButton8.Click
        Dim HOLD As Integer = 0

        If chkhD.Checked = True Then
            HOLD = 1
        End If
        lblhold.Text = ""
        Try
            updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  ON_HOLD='" & HOLD & "' where  POLICY_CODE = '" & Trim(lblpOlicy.Text) & "'  and VERIFIED=1 and APPROVED=0")
            If txthold.Text <> "" Then
                MyDBAction.TRACKING_UW_MESSAGES(lblmem.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txthold.Text)
            End If

            Load_Grid()
            lblhold.Text = "Saved Successfully!"
        Catch ex As Exception
            lblhold.Text = ex.Message
        End Try
    End Sub

    Private Sub updateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

        'ShowGridDetails()
    End Sub

    Public Sub Load_Grid()
        SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],LOADING_RATE,[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE],POLICY_CODE,ON_HOLD  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE ON_HOLD=1  AND  VERIFIED=1 and APPROVED=0 AND RELATION='MAIN MEMBER'"
        Dim MyDatable As New Data.DataTable
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            RDHOLD_1.DataSource = MyDatable
            RDHOLD_1.DataBind()
            Session("RDHOLD_1_5") = MyDatable
            MyDatable = Nothing
        Else
            RDHOLD_1.DataSource = MyDatable
            RDHOLD_1.DataBind()
        End If
        SqlAction = "SELECT   [Note_id],[Member_No],[Notes],[Note_From],[Note_Date],[Note_Type],[Active]  FROM [CRM].[dbo].[TBL_MIS_CRM_LOADING_NOTES] WHERE  Member_No ='" & lblmem.Text & "' ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
        End If
    End Sub
    Protected Sub RDHOLD_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RDHOLD.PageIndexChanged
        RDHOLD.CurrentPageIndex = e.NewPageIndex
        RDHOLD.DataSource = Session("RDHOLD_1_5")
        RDHOLD.DataBind()
    End Sub

    Protected Sub RadButton7_Click(sender As Object, e As System.EventArgs) Handles RadButton7.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String = "ON_HOLD LIST"

            Session("EXCEL") = "TO EXCEL"
            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],LOADING_RATE,[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE],POLICY_CODE,ON_HOLD  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE ON_HOLD=1  AND  VERIFIED=1 and APPROVED=0 AND RELATION='MAIN MEMBER'"

            Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
        Catch ex As Exception
            lblhold.Text = ex.Message
        End Try

        System.Threading.Thread.Sleep(5000)
    End Sub
End Class
