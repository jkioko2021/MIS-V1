﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
'Imports Microsoft.Office.Interop.Word
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Configuration

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyDatatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim Str As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            DTactivity.DbSelectedDate = Date.Now()
            dtfrom.DbSelectedDate = Date.Now()
            DTto.DbSelectedDate = Date.Now()

            HiddenField1.Value = ""

            Str = ""
            Session("emp_code") = "0106"


            Str = "SELECT  [ACTIVITY_CODE],[ACTIVITY_NAME]  FROM CRM.[dbo].[TBL_MIS_RET_ACTIVITY]"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboactivity

                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ACTIVITY_NAME").ToString
                .DataValueField = MyDatatable.Columns("ACTIVITY_CODE").ToString
                .DataBind()

            End With

            MyDatatable = Nothing


            loadGrid()
            loadGrid_act()
        End If
    End Sub

    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        MyDatable = Nothing
        SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP] WHERE [RM_CODE]='" & Session("emp_code") & "' AND (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE())) AND BUSINESS='MEDICAL' AND POLICY_STATUS='ACTIVE'"

        'SqlAction = "SELECT [ID],[CORPORATE_NAME],[POLICY_CODE],[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUM],[LIVES],CNT_ACTIVITIES FROM CRM.[dbo].[TBL_MIS_RET_CORP] WHERE [RM_CODE]='" & Session("emp_code") & "' AND (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE()))"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
        SqlAction = "SELECT  DISTINCT  [PERIOD_FROM],[PERIOD_TO],[PROPOSER_DISPLAY_NAME],[EMP_NAME],[Q1],[Q2],[Q3],[Q4],[PERC_ACT]  FROM [CRM].[dbo].[VW_RET_DASHBOARD] WHERE RM_CODE='" & Session("emp_code") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GD_SUMM.DataSource = MyDatable
            GD_SUMM.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GD_SUMM.DataSource = MyDatable
            GD_SUMM.DataBind()
        End If

        SqlAction = "SELECT DISTINCT EMP_NAME,RM_CODE,AVG(PERC_ACT) AVER_PERCENT,COUNT([PROPOSER_DISPLAY_NAME])CNT_CORPORATES,CAST(SUM(ISNULL(Q1,0)+ISNULL(Q2,0)+ISNULL(Q3,0)+ISNULL(Q4,0)) AS NUMERIC) CNT_ACTIVITIES  FROM [VW_RET_DASHBOARD] WHERE RM_CODE = '" & Session("emp_code") & "' GROUP BY EMP_NAME,RM_CODE"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            RD_ACTSUMM.DataSource = MyDatable
            RD_ACTSUMM.DataBind()

            MyDatable = Nothing
        Else
            RD_ACTSUMM.DataSource = MyDatable
            RD_ACTSUMM.DataBind()
        End If

        SqlAction = "SELECT [FROM_DT],[TO_DT],[RE_CODE],[RE_NAME],[CLASS_CODE],[TOT_CORP_COUNT],[EXP_CNT_ACTIVITY],[ACT_CNT_ACTIVITY],[PERC_PERF],[NSM_CODE]  FROM [CRM].[dbo].[TBL_MIS_CRM_ACT_PRODUCTION] WHERE RE_CODE = '" & Session("emp_code") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_QUOTA.DataSource = MyDatable
            GD_QUOTA.DataBind()

            MyDatable = Nothing
        Else
            GD_QUOTA.DataSource = MyDatable
            GD_QUOTA.DataBind()
        End If
    End Sub
    Public Sub loadGrid_act()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        MyDatable = Nothing
        'SqlAction = "SELECT [ID],[CORPORATE_NAME],[POLICY_CODE],[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUM],[LIVES]  FROM CRM.[dbo].[TBL_MIS_RET_CORP] WHERE  (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE()))"

        SqlAction = "SELECT  [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[FILE_NAME]  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE [RM_CODE]='" & Session("emp_code") & "' ORDER BY ACT_DATE"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
            Session("DAD_6") = MyDatable
            MyDatable = Nothing
        Else
            RD_ACTIVITY.DataSource = MyDatable
            RD_ACTIVITY.DataBind()
        End If
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        ltEmbed.Text = ""
        Dim CURDATE As Date = CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd")
        cboactivity.SelectedValue = ""
        cboactivity.Text = ""
        lblerr.Text = ""
        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("CORPORATE_ID").ToString()
        Dim SqlAction As String = ""
        Session("status_1") = Nothing
        lblIQ.Text = ""
        'SqlAction = "SELECT CORPORATE_ID,PROPOSER_DISPLAY_NAME,[PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO],[PREMIUMS],[LIVES],ISNULL(CNT_ACTIVITIES,0) FROM CRM.[dbo].[TBL_MIS_RET_CORP] WHERE [RM_CODE]='" & Session("emp_code") & "' AND (MONTH(Q1_TO_DATE)=MONTH(GETDATE()) OR MONTH(Q2_TO)=MONTH(GETDATE()) OR MONTH(Q3_TO)=MONTH(GETDATE()) OR MONTH(Q4_TO)=MONTH(GETDATE())) AND BUSINESS='MEDICAL' AND POLICY_STATUS='ACTIVE'"

        SqlAction = "SELECT CORPORATE_ID,[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[PERIOD_FROM] ,[PERIOD_TO] ,Q1_FROM,[Q1_TO_DATE],Q2_FROM,[Q2_TO],Q3_FROM,[Q3_TO],Q4_FROM,[Q4_TO],[PREMIUMS],[LIVES]  FROM CRM.[dbo].[TBL_MIS_RET_CORP] WHERE [CORPORATE_ID]='" & ID & "'"
        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                lblID.Text = MyDatable.Rows(0).Item("CORPORATE_ID").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()

                Dim Q1_FROM = MyDatable.Rows(0).Item("Q1_FROM").ToString()
                Dim Q1_TO_DATE = MyDatable.Rows(0).Item("Q1_TO_DATE").ToString()
                Dim Q2_FROM = MyDatable.Rows(0).Item("Q2_FROM").ToString()
                Dim Q2_TO = MyDatable.Rows(0).Item("Q2_TO").ToString()
                Dim Q3_FROM = MyDatable.Rows(0).Item("Q3_FROM").ToString()
                Dim Q3_TO = MyDatable.Rows(0).Item("Q3_TO").ToString()
                Dim Q4_FROM = MyDatable.Rows(0).Item("Q4_FROM").ToString()
                Dim Q4_TO = MyDatable.Rows(0).Item("Q4_TO").ToString()
                Select Case CURDATE
                    Case Q1_FROM To Q1_TO_DATE
                        lblIQ.Text = "Q1"
                    Case Q2_FROM To Q2_TO
                        lblIQ.Text = "Q2"
                    Case Q3_FROM To Q3_TO
                        lblIQ.Text = "Q3"
                    Case Q4_FROM To Q4_TO
                        lblIQ.Text = "Q4"
                End Select
            End If
            'HiddenField1.Value = 1
            txtproposer.Enabled = False

            dtfrom.Enabled = False
            DTto.Enabled = False
        End If
    End Sub
    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub


    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0

     
        Dim FILENO As String

        If cboactivity.SelectedValue = "" Then
            lblerr.Text = "You must select an activity"
            Exit Sub
        End If
        If FL1.PostedFile.FileName = "" Then
            lblerr.Text = "You must upload a reference pdf file!"
            Exit Sub
        End If

        Dim filePath As String = FL1.PostedFile.FileName

        Dim filename As String = Path.GetFileName(filePath)

        Dim ext As String = Path.GetExtension(filename)

        Dim contenttype As String = String.Empty

        Dim fs As Stream = FL1.PostedFile.InputStream

        Dim br As New BinaryReader(fs)

        'Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))
        Dim bytes As Byte() = br.ReadBytes(Convert.ToInt32(fs.Length))
        Dim app As Integer = 0
        Try
         
            If ext <> ".pdf" Or ext <> ".PDF" Then
                lblerr.Text = "You must attach a pdf document"
                'Exit Sub
            End If
            Select Case ext
                Case ".pdf"
                    contenttype = "application/pdf"
                Case ".PDF"
                    contenttype = "application/PDF"
                    Exit Select
                Case Else
                    lblerr.Text = "You must upload a pdf format!"
                    Exit Sub

            End Select

            If contenttype <> String.Empty Then

                Dim fileLocation As String = ""
                'FL1.SaveAs(fileLocation)
                MyDBAction.Retention_Register_corp(bytes, filename, contenttype, "", lblID.Text, cboactivity.SelectedValue, CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd"), lblIQ.Text, Session("username"), txtcomment.Text, fileLocation, CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"))
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblerr.ForeColor = System.Drawing.Color.Green
                lblerr.Text = "File Uploaded Successfully"

            Else
                filename = ""
                MyDBAction.Retention_Register_corp(bytes, filename, contenttype, "", lblID.Text, cboactivity.SelectedValue, CDate(DTactivity.DbSelectedDate).ToString("yyyy-MM-dd"), lblIQ.Text, Session("username"), txtcomment.Text, "", CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"))

                lblerr.ForeColor = System.Drawing.Color.Red
                lblerr.Text = "data Saved Successfully"
                lblerr.Text = "File format not recognised." + " Upload Image/PDF"

            End If


            loadGrid_act()
            loadGrid()

            lblID.Text = ""
            txtproposer.Text = ""

            cboactivity.SelectedValue = ""
            dtfrom.DbSelectedDate = ""
            DTto.DbSelectedDate = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

    Private Sub deleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try
            GD_SUMM.DataSource = Nothing
            GD_SUMM.DataBind()
            GDSEARCH.DataSource = Nothing
            GDSEARCH.DataBind()
            RD_ACTIVITY.DataSource = Nothing
            RD_ACTIVITY.DataBind()
            RD_ACTSUMM.DataSource = Nothing
            RD_ACTSUMM.DataBind()

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

     
            SqlAction = "SELECT CORPORATE_ID, [PROPOSER_DISPLAY_NAME], [PERIOD_FROM],[PERIOD_TO],[Q1_TO_DATE],[Q2_TO],[Q3_TO],[Q4_TO], [LIVES]  FROM CRM.[dbo].[TBL_MIS_RET_CORP] WHERE PROPOSER_DISPLAY_NAME Like '%" & Trim(txtsearch.Text) & "%' AND [RM_CODE]='" & Session("emp_code") & "'"
            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If

            SqlAction = "SELECT  DISTINCT  [PERIOD_FROM],[PERIOD_TO],[PROPOSER_DISPLAY_NAME],[EMP_NAME],[Q1],[Q2],[Q3],[Q4],[PERC_ACT]  FROM [CRM].[dbo].[VW_RET_DASHBOARD] WHERE RM_CODE='" & Session("emp_code") & "' AND PROPOSER_DISPLAY_NAME Like '%" & Trim(txtsearch.Text) & "%'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GD_SUMM.DataSource = MyDatable
                GD_SUMM.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_SUMM.DataSource = MyDatable
                GD_SUMM.DataBind()
            End If

            SqlAction = "SELECT  [ACTIVITY_ID],[PROPOSER_DISPLAY_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES]  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE PROPOSER_DISPLAY_NAME Like '%" & Trim(txtsearch.Text) & "%' AND [RM_CODE]='" & Session("emp_code") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                RD_ACTIVITY.DataSource = MyDatable
                RD_ACTIVITY.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing


            Else
                RD_ACTIVITY.DataSource = MyDatable
                RD_ACTIVITY.DataBind()
            End If

            SqlAction = "SELECT DISTINCT EMP_NAME,RM_CODE,AVG(PERC_ACT) AVER_PERCENT,COUNT([PROPOSER_DISPLAY_NAME])CNT_CORPORATES,CAST(SUM(ISNULL(Q1,0)+ISNULL(Q2,0)+ISNULL(Q3,0)+ISNULL(Q4,0)) AS NUMERIC) CNT_ACTIVITIES  FROM [VW_RET_DASHBOARD] WHERE RM_CODE = '" & Session("emp_code") & "' GROUP BY EMP_NAME,RM_CODE"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_ACTSUMM.DataSource = MyDatable
                RD_ACTSUMM.DataBind()

                MyDatable = Nothing
            Else
                RD_ACTSUMM.DataSource = MyDatable
                RD_ACTSUMM.DataBind()
            End If

            SqlAction = "SELECT [FROM_DT],[TO_DT],[RE_CODE],[RE_NAME],[CLASS_CODE],[TOT_CORP_COUNT],[EXP_CNT_ACTIVITY],[ACT_CNT_ACTIVITY],[PERC_PERF],[NSM_CODE]  FROM [CRM].[dbo].[TBL_MIS_CRM_ACT_PRODUCTION] WHERE RE_CODE = '" & Session("emp_code") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_QUOTA.DataSource = MyDatable
                GD_QUOTA.DataBind()

                MyDatable = Nothing
            Else
                GD_QUOTA.DataSource = MyDatable
                GD_QUOTA.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

   



    Protected Sub RD_ACTIVITY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_ACTIVITY.PageIndexChanged
        RD_ACTIVITY.CurrentPageIndex = e.NewPageIndex
        RD_ACTIVITY.DataSource = Session("DAD_6")
        RD_ACTIVITY.DataBind()
    End Sub



    Protected Sub RD_ACTIVITY_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RD_ACTIVITY.SelectedIndexChanged
        Dim ID As String = ""
        cboactivity.SelectedValue = ""
        cboactivity.Text = ""
        lblerr.Text = ""


        ID = (DirectCast(RD_ACTIVITY.SelectedItems(0), GridDataItem)).GetDataKeyValue("ACTIVITY_ID").ToString()
        Dim SqlAction As String = ""
        Session("status_1") = Nothing

        SqlAction = "SELECT  [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES],ACT_NOTES,PERIOD_FROM,PERIOD_TO  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE [ACTIVITY_ID]='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then

                lblID.Text = MyDatable.Rows(0).Item("ACTIVITY_ID").ToString()
                'txtproposer1.Text = MyDatable.Rows(0).Item("CORPORATE_NAME").ToString()
                'txtpolicy1.Text = MyDatable.Rows(0).Item("POLICY_CODE").ToString()

                'dtfrom1.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
                'dtto1.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()
                minutes.NavigateUrl = MyDatable.Rows(0).Item("ACT_MINUTES").ToString()
                txtcom1.Text = MyDatable.Rows(0).Item("ACT_NOTES").ToString()
                'Session("path") = MyDatable.Rows(0).Item("ACT_MINUTES").ToString()
                Session("path") = MyDatable.Rows(0).Item("ACTIVITY_ID").ToString()

                'SqlAction = "SELECT  [ACTIVITY_ID],[FILE_NAME]  FROM CRM.[dbo].[TBL_MIS_RET_CORP_ACTIVITY] WHERE [ACTIVITY_ID]='" & ID & "'"
                'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                'If MyDatable.Rows.Count > 0 Then
                '    GD1.DataSource = MyDatable
                '    GD1.DataBind()
                '    MyDatable = Nothing
                'Else
                '    GD1.DataSource = MyDatable
                '    GD1.DataBind()
                'End If
            End If
            'HiddenField1.Value = 1
            Session("DAD_5") = Nothing

            txtproposer.Enabled = False


            dtfrom.Enabled = False
            DTto.Enabled = False

        End If
    End Sub


    Protected Sub View(ByVal sender As Object, ByVal e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""800px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""http://get.adobe.com/reader/"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileVB.ashx?Id="), id)
    End Sub




    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String = "RETENTION As -& " & cbosearch.Text & ""

            Session("EXCEL") = "TO EXCEL"

            Str = "SELECT [ACTIVITY_ID],[CORPORATE_NAME],[POLICY_CODE],[ACTIVITY_NAME],[ACT_DATE],[ACT_PERIOD],[ACT_MINUTES],[ACT_NOTES], EmployeeName,[PERIOD_FROM],[PERIOD_TO],[FILE_NAME]  FROM CRM.[dbo].[VW_RETENTION_ACTIVITY] WHERE ACT_DATE between  '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND [RM_CODE]='" & Session("emp_code") & "'"
            Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing

            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception

        End Try


    End Sub

    Protected Sub RadButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton2.Click
        Dim audit As New DataManagement
        audit.AddAdminAuditTrail(Session("UserName").ToString, "Delete activity", "Successfully Deleted File :- File deleted is: activity_id - " & lblID.Text & "", _
        Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
        '----END AUDIT TRAIL-----


        deleteRecord("DELETE FROM  [dbo].[TBL_MIS_RET_CORP_ACTIVITY]  where  ACTIVITY_ID= '" & lblID.Text & "'")

        HiddenField1.Value = ""

        'ResetDisplayed("NewRecord")
        lblerr.Text = "Record Deleted!"
        'CmdSave.Enabled = False

        loadGrid_act()
    End Sub

    Protected Sub DTactivity_SelectedDateChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.Calendar.SelectedDateChangedEventArgs) Handles DTactivity.SelectedDateChanged
        If DTactivity.DbSelectedDate < DateAdd(DateInterval.Day, -7, Date.Now()) Or DTactivity.DbSelectedDate > Date.Now() Then

            DTactivity.DbSelectedDate = Date.Now
            lblerr.Text = "Activity date can only be within 7 days from the activity date!"

        Else
            lblerr.Text = ""
        End If

    End Sub

    Protected Sub GDSEARCH_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub

    Protected Sub RD_ACTIVITY_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles RD_ACTIVITY.NeedDataSource

    End Sub
End Class
