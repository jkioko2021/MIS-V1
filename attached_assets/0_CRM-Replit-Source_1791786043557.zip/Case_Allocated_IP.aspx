﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Case_Allocated_IP.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td style="width: 105px">
                        <asp:Label ID="Label6" runat="server" style="font-weight: 700" 
                            Text="IP Allocate"></asp:Label>
                    </td>
                    <td colspan="2">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="979px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 2808px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 445px">
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Invoice No" Value="I" />
                                                <telerik:RadComboBoxItem runat="server" Text="File No" Value="F" />
                                                <telerik:RadComboBoxItem runat="server" Text="Provider" Value="P" />
                                                <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="5">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1010px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1001px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="30" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FILE_NO" 
                                                            FilterControlAltText="Filter FILE_NO column" HeaderText="FILE_NO" 
                                                            SortExpression="FILE_NO" UniqueName="FILE_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="INVOICE_NO" 
                                                            FilterControlAltText="Filter INVOICE_NO column" HeaderText="INVOICE_NO" 
                                                            SortExpression="INVOICE_NO" UniqueName="INVOICE_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="INVOICE_AMT" 
                                                            FilterControlAltText="Filter INVOICE_AMT column" HeaderText="INVOICE_AMT" 
                                                            SortExpression="INVOICE_AMT" UniqueName="INVOICE_AMT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                            FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                            SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label102" runat="server" Text="Receive Date"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        <telerik:RadDatePicker ID="dtreceive" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 193px">
                                        <asp:Label ID="Label122" runat="server" Text="Provider"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadComboBox ID="cboprovider" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Outlook" 
                                            Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label104" runat="server" Text="Care Manager"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        <telerik:RadComboBox ID="cbocareManager" Runat="server" 
                                            AccessibilityMode="True" AllowCustomText="True" Enabled="False" 
                                            MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 193px">
                                        <asp:Label ID="Label131" runat="server" Text="Provider Name"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtProvider_Name" Runat="server" Skin="Outlook" 
                                            Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label139" runat="server" Text="Query To"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        <telerik:RadComboBox ID="cboqueryto" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Outlook" 
                                            Width="200px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboqueryto" Text="IT Query" 
                                                    Value="IT Query" />
                                                <telerik:RadComboBoxItem runat="server" Owner="cboqueryto" 
                                                    Text="Membership Query" Value="Membership Query" />
                                                <telerik:RadComboBoxItem runat="server" Text="Retention" Value="Retention" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 193px">
                                        <asp:Label ID="Label140" runat="server" Text="Staff Name"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtstaff" Runat="server" Skin="Outlook" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label141" runat="server" Text="BarCode"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        <asp:Label ID="lblbarcode" runat="server"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 193px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label123" runat="server" Text="Status"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        <telerik:RadComboBox ID="cbostatus" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Outlook" 
                                            Width="250px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Open" Value="Open" />
                                                <telerik:RadComboBoxItem runat="server" Text="Resolved" Value="Resolved" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 193px">
                                        <asp:Label ID="Label124" runat="server" Text="Date Resolved"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtresolved" Runat="server" Enabled="False" 
                                            MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#333333" class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="IDlbl" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        <asp:Label ID="FILENO" runat="server"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 193px">
                                        <asp:Label ID="Label121" runat="server" Text="Comments"></asp:Label>
                                    </td>
                                    <td rowspan="3" style="width: 287px">
                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="70px" Skin="Outlook" 
                                            TextMode="MultiLine" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 193px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 193px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 193px">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadButton ID="cmdsave" runat="server" Skin="Simple" Text="Save" 
                                            Width="80px" Height="37px">
                                        </telerik:RadButton>
                                        &nbsp;<telerik:RadButton ID="cmdedit" runat="server" Skin="Simple" Text="Edit" 
                                            Width="80px">
                                        </telerik:RadButton>
                                        &nbsp;<telerik:RadButton ID="cmdnew" runat="server" Skin="Simple" Text="New" 
                                            Width="80px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>

    </asp:UpdatePanel>
</asp:Content>


