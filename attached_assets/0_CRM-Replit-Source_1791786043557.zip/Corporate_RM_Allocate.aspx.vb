﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""

    Dim MyDatatable As DataTable : Dim Str As String



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Str = ""

            Str = "SELECT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1 AND C_CODE='C'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cborm
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()
            End With
            MyDatatable = Nothing

            MyDatatable = Nothing

            loadGrid()

        End If
    End Sub
    Protected Sub ToggleRowSelection(ByVal sender As Object, ByVal e As EventArgs)
        Dim Total As Decimal

        TryCast(TryCast(sender, CheckBox).NamingContainer, GridItem).Selected = TryCast(sender, CheckBox).Checked
        Dim checkHeader As Boolean = True
        For Each dataItem As GridDataItem In GDSEARCH.MasterTableView.Items
            If Not TryCast(dataItem.FindControl("chkreturn"), CheckBox).Checked Then
                checkHeader = False

                Exit For
            End If

        Next
        Dim headerItem As GridHeaderItem = TryCast(GDSEARCH.MasterTableView.GetItems(GridItemType.Header)(0), GridHeaderItem)
        TryCast(headerItem.FindControl("chkheader"), CheckBox).Checked = checkHeader

    End Sub

    Protected Sub ToggleSelectedState(ByVal sender As Object, ByVal e As EventArgs)
        Dim headerCheckBox As CheckBox = TryCast(sender, CheckBox)

        For Each dataItem As GridDataItem In GDSEARCH.MasterTableView.Items
            TryCast(dataItem.FindControl("chkreturn"), CheckBox).Checked = headerCheckBox.Checked
            dataItem.Selected = headerCheckBox.Checked

        Next
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        SqlAction = "SELECT V.USER_ID,  V.AGENT_NAME, V.AGENT_TYPE, V.UM_MANAGER ,V.BRANCH_NAME FROM COMMISSION.dbo.VW_MIS_AGENTS_LISTING V LEFT JOIN dbo.TBL_MIS_CRM_RMS E ON V.RMS_CODE_CORP = E.RE_CODE  WHERE (RMS_CODE_CORP IS NULL OR RMS_CODE_CORP='') AND ACTIVE=1 AND TERMINATED=0 AND UNIT_CODE IS NOT NULL"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub


    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""

        ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("USER_ID").ToString()
        Dim SqlAction As String = ""
        Session("status_1") = Nothing

        SqlAction = "SELECT USER_ID,  AGENT_NAME, AGENT_TYPE, UM_MANAGER ,REGION_NAME,RMS_CODE_CORP  FROM COMMISSION.dbo.VW_MIS_AGENTS_LISTING V LEFT JOIN dbo.TBL_MIS_CRM_RMS E ON V.RMS_CODE_CORP = E.RE_CODE  WHERE USER_ID ='" & ID & "'"
        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                lblfile.Text = MyDatable.Rows(0).Item("USER_ID").ToString()

                cborm.SelectedValue = MyDatable.Rows(0).Item("RMS_CODE_CORP").ToString()

            End If

            HiddenField1.Value = 1
            Session("DAD_5") = Nothing

        End If
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0

        Dim FILENO As String
        Dim app As Integer = 0
        Try
            If cborm.SelectedValue = "" Then
                lblerr.Text = "Select The RM"
                Exit Sub
            End If

            For Each dataItem As GridDataItem In GDSEARCH.MasterTableView.Items
                Dim chkSelect As CheckBox = DirectCast(dataItem.FindControl("chkreturn"), CheckBox)
                If chkSelect.Checked Then
                    Dim ID As String = dataItem.GetDataKeyValue("USER_ID").ToString()
                    UpdateRecord("UPDATE [TBL_MIS_RET_CORP] SET [RM_CODE]='" & cborm.SelectedValue & "'  WHERE [AGENCY_CODE]='" & Trim(ID) & "' AND PERIOD_TO>=GETDATE()")
                    UpdateRecord("UPDATE COMMISSION.dbo.TBL_MIS_SALES_AGENTS SET [RMS_CODE_CORP]='" & cborm.SelectedValue & "'  WHERE [USER_ID]='" & Trim(ID) & "'")
                    UpdateRecord("UPDATE dbo.TBL_VALID_LIST SET [RMS_CODE]='" & cborm.SelectedValue & "'  WHERE [USER_ID]='" & Trim(ID) & "' AND [GRP_INDV]<>'I'")
                    UpdateRecord("UPDATE SALES.dbo.TBL_MIS_SALES_PRODUCTION SET [RM_CORP_CODE]='" & cborm.SelectedValue & "'  WHERE [AGENT_ID]='" & Trim(ID) & "'")

                End If
            Next

            lblerr.Text = "updated successfully"


            lblerr.Text = "updated successfully"
            lblfile.Text = ""
            cborm.SelectedValue = ""
            cborm.Text = ""
            loadGrid()
        Catch ex As Exception
            lblerr.Text = ex.Message

        End Try



    End Sub

    

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String = "CORPORATE UNMAPPED "

            Session("EXCEL") = "TO EXCEL"

            Str = "SELECT AGENT_NAME, AGENT_TYPE, UM_MANAGER ,REGION_NAME,E.RE_NAME  FROM COMMISSION.dbo.VW_MIS_AGENTS_LISTING V LEFT JOIN dbo.TBL_MIS_CRM_RMS E ON V.RMS_CODE_CORP = E.RE_CODE  WHERE RMS_CODE_CORP IS NULL AND ACTIVE=1 AND TERMINATED=0"

            Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing

            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub
End Class
