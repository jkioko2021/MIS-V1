﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim searchStr As String = ""
    Dim STS As Integer = 0
    Dim MailSent As Boolean = False
    Dim msg As Integer = 0



    

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                '
                SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] WHERE SIGNOFF_PERIOD=0"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    Session("PERIOD_FROM") = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                    Session("PERIOD_TO") = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()

                    dtF_1.DbSelectedDate = Session("PERIOD_FROM")
                    DTt_1.DbSelectedDate = Session("PERIOD_TO")
                    Session("Month") = MonthName(Month(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd")))
                End If
                LOADGRIDS()
            Catch ex As Exception

            End Try

        End If
    End Sub
    Public Sub LOADGRIDS()
        Try
            Session("DAD_VA") = Nothing
            Dim MyDatable As New Data.DataTable

            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],LOADING_RATE,[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE  PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND IP_RATE =0 AND POLICY_TYPE='F' AND VERIFIED=0  AND RELATION='MAIN MEMBER'"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDENRI.DataSource = MyDatable
                GDENRI.DataBind()
                Session("DAD_E") = MyDatable
                MyDatable = Nothing


            Else
                GDENRI.DataSource = MyDatable
                GDENRI.DataBind()
            End If
            SqlAction = ""
            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],LOADING_RATE,[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE  PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED =0 AND VALIDATED=0 AND IS_REVISED=0 AND ON_HOLD=0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDVERIFY.DataSource = MyDatable
                GDVERIFY.DataBind()
                Session("DAD_V") = MyDatable

                txtlives.Text = Convert.ToInt32(MyDatable.Compute("COUNT(MEMBER_NO)", String.Empty))
                MyDatable = Nothing
            Else
                GDVERIFY.DataSource = MyDatable
                GDVERIFY.DataBind()
            End If

            SqlAction = ""
            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],LOADING_RATE,[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND  VERIFIED =1 AND MED_VERIFIED=1 AND NCD_UPDATED=1 AND IS_SUMMATION=1 AND VALIDATED=0 AND  IS_REVISED=0 AND ON_HOLD=0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDVALIDATE.DataSource = MyDatable
                GDVALIDATE.DataBind()
                Session("DAD_VA") = MyDatable
                txtvallive.Text = Convert.ToInt32(MyDatable.Compute("COUNT(MEMBER_NO)", String.Empty))
                MyDatable = Nothing
            Else
                GDVALIDATE.DataSource = MyDatable
                GDVALIDATE.DataBind()
            End If
            SqlAction = ""
            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],LOADING_RATE,[RELATION],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND  VERIFIED =1 AND [MED_VERIFIED]=1  AND NCD_UPDATED=1 AND IS_SUMMATION=0 AND  VALIDATED=0 AND  IS_REVISED=0 AND ON_HOLD=0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDTOTALS.DataSource = MyDatable
                GDTOTALS.DataBind()
                Session("DAD_T") = MyDatable
                txtvallive.Text = Convert.ToInt32(MyDatable.Compute("COUNT(MEMBER_NO)", String.Empty))
                MyDatable = Nothing
            Else
                GDTOTALS.DataSource = MyDatable
                GDTOTALS.DataBind()
            End If
            SqlAction = ""
            SqlAction = "SELECT [PERIOD_FROM],[PERIOD_TO],[RENEWAL_LIST],[CLAIMS_DATA],LOADING_DATA,[PREMIUMS_IND],[PREMIUMS_SHARED],[VERIFIED],[MED_VERIFICATION],[VALIDATION],[NCD],[SIGN_OFF_TOTAL],[APPROVAL],[EMAIL_NOTIFICATION],[SIGNOFF_PERIOD]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] WITH (NOLOCK) WHERE   PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSUMM.DataSource = MyDatable
                GDSUMM.DataBind()
                Session("DAD_SUM") = MyDatable
                'txtvallive.Text = Convert.ToInt32(MyDatable.Compute("COUNT(MEMBER_NO)", String.Empty))
                MyDatable = Nothing
            Else
                GDSUMM.DataSource = MyDatable
                GDSUMM.DataBind()
            End If


            SqlAction = ""
            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[POLICY_VALID_FROM],LOADING_RATE,[POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE  PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED =1 AND [MED_VERIFIED]=1  AND NCD_UPDATED=0 AND  VALIDATED=0 AND  IS_REVISED=0 AND IS_SUMMATION=0 AND ON_HOLD=0"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GD_NCD.DataSource = MyDatable
                GD_NCD.DataBind()
                Session("DAD_SUM") = MyDatable
                'txtvallive.Text = Convert.ToInt32(MyDatable.Compute("COUNT(MEMBER_NO)", String.Empty))
                MyDatable = Nothing
            Else
                GD_NCD.DataSource = MyDatable
                GD_NCD.DataBind()
            End If

            SqlAction = ""
            SqlAction = "SELECT [ID],[MEMBER_NO],POLICY_CODE, [MEMBER_NAME],[RELATION],LOADING_RATE,[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE   VERIFIED =1 AND MED_VERIFIED=1 AND NCD_UPDATED=1 AND VALIDATED=0 AND  ON_HOLD=0 AND APPROVED=0 AND IS_REVISED=1"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                RD_REVISE.DataSource = MyDatable
                RD_REVISE.DataBind()
                Session("DAD_RE") = MyDatable
                'txtvallive.Text = Convert.ToInt32(MyDatable.Compute("COUNT(MEMBER_NO)", String.Empty))
                MyDatable = Nothing
            Else
                RD_REVISE.DataSource = MyDatable
                RD_REVISE.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDENRI_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDENRI.PageIndexChanged
        GDENRI.CurrentPageIndex = e.NewPageIndex
        GDENRI.DataSource = Session("DAD_E")
        GDENRI.DataBind()
    End Sub
    Protected Sub GDVERIFY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDVERIFY.PageIndexChanged
        GDENRI.CurrentPageIndex = e.NewPageIndex
        GDENRI.DataSource = Session("DAD_V")
        GDENRI.DataBind()
    End Sub
    Protected Sub GDVALIDATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDVALIDATE.PageIndexChanged
        GDVALIDATE.CurrentPageIndex = e.NewPageIndex
        GDVALIDATE.DataSource = Session("DAD_VA")
        GDVALIDATE.DataBind()
    End Sub
    Protected Sub GDTOTALS_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDTOTALS.PageIndexChanged
        GDTOTALS.CurrentPageIndex = e.NewPageIndex
        GDTOTALS.DataSource = Session("DAD_T")
        GDTOTALS.DataBind()
    End Sub
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdENsave.Click
        Try
            If txtscheme.Text = "" Or cboprod.SelectedValue = "" Then
                lblerr.Text = "Missing Scheme name"
                Exit Sub

            End If

            updateRecord("UPDATE [MISREPORTS].dbo.[TBL_MIS_RENEWAL_LIST] SET  SCHEME_NAME='" & txtscheme.Text & "',PRODUCT='" & cboprod.SelectedValue & "', IP_RATE='" & txtipprem.Text & "',OP_RATE='" & txtopprem.Text & "', OP_LIMIT ='" & txtoplimit.Text & "',IP_LIMIT='" & txtiplimit.Text & "',SPLUS_IP_LIMIT='" & txtsplusiplim.Text & "',SILVER_PLUS_IP_PREMIUM='" & txtipsplusra.Text & "',NCD_RATE='" & txtncd.Text & "',ENRICHMENT_BY='" & Session("username") & "' ,ENRICHMENT_DATE='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',VALIDATED=0,APPROVED=0,IP_NET_NCD=0,SUB_TOTAL=0,TOTAL=0,IS_SUMMATION=0, IS_REVISED=1  where ID= '" & lblE_ID.Text & "' ")
            lblerr.Text = "Data Saved successfully"
            txtno.Text = "" : txtname.Text = "" : txtage.Text = 0 : txtipprem.Text = 0 : txtopprem.Text = 0 : txtiplimit.Text = 0 : txtoplimit.Text = 0 : txtsplusiplim.Text = 0 : txtipsplusra.Text = 0 : txtncd.Text = 0 : cboprod.Text = ""
            LOADGRIDS()

            Session("DA_N_1") = Nothing
            HiddenField1.Value = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    Private Sub updateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

        'ShowGridDetails()
    End Sub
    Protected Sub btnrenexpo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnrenexpo.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String


        Session("EXCEL") = "TO EXCEL"

        Reportname = "RenewalList-& " & dtF_1.DbSelectedDate & ""
        SqlAction = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[PERIOD_FROM],[PERIOD_TO],[FIRST_ENROLLMENT_DATE],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[PROPOSER_PRI_PIN],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID],[UNIT],[BRANCH],[REGION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_ADD_LINE2],[POSTAL_CODE],[ADDRESS],[PROPOSER_PRI_MOBILE],[RENEWAL_DATE],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[AGE_BAND],[PRODUCT],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[SPLUS_IP_LIMIT],[FAMILY_SIZE],[POLICY_TYPE],[PRESENT_IP],[PRESENT_OP],[LAST_IP_DATE],[LAST_OP_DATE],[CURRENT_CLAIM],[IP_2016_2017],[LAST_CLAIM_DATE],[NCD_YEARS],[NCD_RATE],[IP_RATE],[IP_NET_NCD],[OP_RATE],[PA_PTD],[SILVER_PLUS_IP_PREMIUM],[SILVER_PLUS_NET_NCD],[SUB_TOTAL],[SUB_TOTAL_2],[LEVIES],[LEVIES_2],[TOTAL],[TOTAL_2],[IS_LOADING],[MED_VERIFIED] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub


    Protected Sub GDENRI_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDENRI.SelectedIndexChanged
        Dim ID As String = ""

        lblerr.Text = ""

        ID = (DirectCast(GDENRI.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT [ID],[MEMBER_NO],PRODUCT,[SCHEME_NAME],[MEMBER_NAME],[RELATION],[PERIOD_FROM],[PERIOD_TO],[AGE],NCD_RATE,[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],SPLUS_IP_LIMIT,SILVER_PLUS_IP_PREMIUM,[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE ID ='" & ID & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then

                lblE_ID.Text = MyDatable.Rows(0).Item("ID").ToString()
                txtscheme.Text = MyDatable.Rows(0).Item("SCHEME_NAME").ToString()
                txtno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtrela.Text = MyDatable.Rows(0).Item("RELATION").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("PERIOD_TO").ToString()
                txtage.Text = MyDatable.Rows(0).Item("AGE").ToString()
                txtipprem.Text = MyDatable.Rows(0).Item("IP_RATE").ToString()
                txtopprem.Text = MyDatable.Rows(0).Item("OP_RATE").ToString()

                txtiplimit.Text = MyDatable.Rows(0).Item("IP_LIMIT").ToString()
                txtoplimit.Text = MyDatable.Rows(0).Item("OP_LIMIT").ToString()

                txtncd.Text = MyDatable.Rows(0).Item("NCD_RATE").ToString()

                txtipsplusra.Text = MyDatable.Rows(0).Item("SILVER_PLUS_IP_PREMIUM").ToString()

                txtsplusiplim.Text = MyDatable.Rows(0).Item("SPLUS_IP_LIMIT").ToString()
                cboprod.SelectedValue = MyDatable.Rows(0).Item("PRODUCT").ToString()

                txtno.Enabled = False : txtname.Enabled = False : txtage.Enabled = False
                txtage.Enabled = False : txtrela.Enabled = False : dtfrom.Enabled = False : DTto.Enabled = False : txtscheme.Enabled = True

                If txtipprem.Text = "" Then
                    txtipprem.Text = 0
                End If
                If txtopprem.Text = "" Then
                    txtopprem.Text = 0
                End If

                If txtiplimit.Text = "" Then
                    txtiplimit.Text = 0
                End If

                If txtoplimit.Text = "" Then
                    txtoplimit.Text = 0
                End If
            End If
            Session("DAD_E") = Nothing

            HiddenField1.Value = ""
        End If
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub

            End If
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE]   FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE  MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "S" Then
                SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE   PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND IP_RATE =0 AND POLICY_TYPE='F' AND VERIFIED=0  AND RELATION='MAIN MEMBER'"
            ElseIf cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[OP_LIMIT],[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE   PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND IP_RATE =0 AND POLICY_TYPE='I' AND VERIFIED=0"
            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDENRI.DataSource = MyDatable
                GDENRI.DataBind()
                Session("DAD_E") = MyDatable
                MyDatable = Nothing
            Else
                GDENRI.DataSource = MyDatable
                GDENRI.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub btnverexpo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnverexpo.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String


        Session("EXCEL") = "TO EXCEL"

        Reportname = "Ren_Verify-& " & dtF_1.DbSelectedDate & ""
        SqlAction = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[FIRST_ENROLLMENT_DATE],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[PROPOSER_PRI_PIN],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID],[UNIT],[BRANCH],[REGION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_ADD_LINE2],[POSTAL_CODE],[ADDRESS],[PROPOSER_PRI_MOBILE],[RENEWAL_DATE],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[AGE_BAND],[PRODUCT],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[SPLUS_IP_LIMIT],[FAMILY_SIZE],[POLICY_TYPE],[PRESENT_IP],[PRESENT_OP],[LAST_IP_DATE],[LAST_OP_DATE],[CURRENT_CLAIM],[IP_2016_2017],[LAST_CLAIM_DATE],[NCD_YEARS],[NCD_RATE],[IP_RATE],[IP_NET_NCD],[OP_RATE],[PA_PTD],[SILVER_PLUS_IP_PREMIUM],[SILVER_PLUS_NET_NCD],[SUB_TOTAL],[SUB_TOTAL_2],[LEVIES],[LEVIES_2],[TOTAL],[TOTAL_2],[IS_LOADING],[MED_VERIFIED] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE  VERIFIED=0"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub

    Protected Sub btnverify_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnverify.Click
        Try

            Session("Path") = ""

            If chkverified.Checked = True Then
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  [VERIFIED]=1,VERIFIED_BY='" & Session("username") & "' WHERE  [VERIFIED]=0 AND PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] SET  [VERIFIED]=1 WHERE  [VERIFIED]=0 AND PERIOD_FROM = '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO= '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
                lblVER.Text = "updated successfully!"


                Session("MessageSubject") = Session("Month") & "-Renewal Loading"
                msg = 1
                MailSent = SendLoginDetails("Medical Team", Session("Path"), "ekuhunya@aar.co.ke", "", msg)

                LOADGRIDS()
            End If
        Catch ex As Exception
            lblVER.Text = ex.Message
        End Try

    End Sub

    Protected Sub btnvalexpo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnvalexpo.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String


        Session("EXCEL") = "TO EXCEL"

        Reportname = "Ren_validated-& " & dtF_1.DbSelectedDate & ""
        SqlAction = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[FIRST_ENROLLMENT_DATE],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[PROPOSER_PRI_PIN],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID],[UNIT],[BRANCH],[REGION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_ADD_LINE2],[POSTAL_CODE],[ADDRESS],[PROPOSER_PRI_MOBILE],[RENEWAL_DATE],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[AGE_BAND],[PRODUCT],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[SPLUS_IP_LIMIT],[FAMILY_SIZE],[POLICY_TYPE],[PRESENT_IP],[PRESENT_OP],[LAST_IP_DATE],[LAST_OP_DATE],[CURRENT_CLAIM],[IP_2016_2017],[LAST_CLAIM_DATE],[NCD_YEARS],[NCD_RATE],[IP_RATE],[IP_NET_NCD],[OP_RATE],[PA_PTD],[SILVER_PLUS_IP_PREMIUM],[SILVER_PLUS_NET_NCD],[SUB_TOTAL],[SUB_TOTAL_2],[LEVIES],[LEVIES_2],[TOTAL],[TOTAL_2],[IS_LOADING],[MED_VERIFIED] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' and VERIFIED=1 AND MED_VERIFIED=1 AND VALIDATED=0"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub

    Protected Sub btnvalidate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnvalidate.Click
        Dim da As DataTable = Nothing
        'da = Session("DAD_VA")
        Try
            If chkvalidate.Checked = True Then
                'If chkvalidate.Checked = True Then
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  [VALIDATED]=1,VALIDATED_BY='" & Session("username") & "' WHERE  [VALIDATED]=0 AND VERIFIED=1 AND MED_VERIFIED=1 AND PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
                updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] SET  [VALIDATION]=1 WHERE  [VALIDATION]=0 AND PERIOD_FROM = '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO= '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
                'lblVER.Text = "updated successfully!"

                MyDBAction.forward_Renewal_list(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd"), Session("username"))
                MyDBAction.forward_Proposer_list(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd"))

                Session("MessageSubject") = Session("Month") & "-Renewal List"
                msg = 2
                'MailSent = SendLoginDetails("Retention Team", Session("Path"), "Relationship-Managers@aar.co.ke", "awanga@aar.co.ke", msg)

                LOADGRIDS()

                lblval.Text = "Renewal List Validated and Forwarded!"
            End If
        Catch ex As Exception
            lblval.Text = ex.Message
        End Try
    End Sub

    Protected Sub btntotals_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btntotals.Click
        Try
            MyDBAction.import_Renewal_Totals(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd"))
            updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] SET  [SIGN_OFF_TOTAL]=1 WHERE  [SIGN_OFF_TOTAL]=0 AND PERIOD_FROM = '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO= '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
            lbltotal.Text = "Premium sum computed successfully!"
            LOADGRIDS()
        Catch ex As Exception
            lbltotal.Text = ex.Message
        End Try

    End Sub

    Protected Sub BTNUPLOAD_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BTNUPLOAD.Click
        Dim connectionString As String = ""
        Session("DA_N") = Nothing
        Dim SqlAction As String = ""
        Dim FILENO As String = ""
        Dim searchStr As String = ""
        Dim MyDBAction As New DataManagement

        'btnSave.Enabled = True

        Try


            If FL1.HasFile Then

                HiddenField1.Value = 1
                Dim fileName As String = " {" & CDate(Date.Now).ToString("yyyy-MM-dd") & "-" & Path.GetFileName(FL1.PostedFile.FileName)

                Dim fileExtension As String = Path.GetExtension(FL1.PostedFile.FileName)

                Dim fileLocation As String = Server.MapPath("~/RENEWAL UPLOAD/" & fileName)

                FL1.SaveAs(fileLocation)


                If fileExtension = ".xls" Then

                    connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 8.0;HDR=Yes;IMEX=2"""

                ElseIf fileExtension = ".xlsx" Then

                    connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & fileLocation & ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""

                End If
                'dtfrom.DbSelectedDate = Session("CUTOFF_FROM")
                'dtto.DbSelectedDate = 

                Dim con As New OleDbConnection(connectionString)

                Dim cmd As New OleDbCommand()

                cmd.CommandType = System.Data.CommandType.Text

                cmd.Connection = con

                Dim dAdapter As New OleDbDataAdapter(cmd)

                Dim dtExcelRecords As New DataTable()

                con.Open()

                Dim dtExcelSheetName As DataTable = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)

                Dim getExcelSheetName As String = dtExcelSheetName.Rows(0)("Table_Name").ToString()

                cmd.CommandText = "MEMBER_NO, MEMBER_NAME, RELATION, SCHEME_NAME, MEMBER_BIRTH_DATE, MEMBER_ADMINISTRATIVE_SEX, POLICY_VALID_FROM, POLICY_VALID_UPTO, FIRST_ENROLLMENT_DATE, PERIOD_FROM, PERIOD_TO, AGE, FAMILY_NO, AGE_BAND, PRODUCT, OP_LIMIT, IP_LIMIT, SPLUS_IP_LIMIT, FAMILY_SIZE, POLICY_TYPE, LAST_CLAIM_DATE, NCD_YEARS, NCD_RATE, IP_RATE, IP_NET_NCD, OP_RATE, PA_PTD, SILVER_PLUS_IP_PREMIUM FROM  [" & getExcelSheetName & "] "

                dAdapter.SelectCommand = cmd

                dAdapter.Fill(dtExcelRecords)

                con.Close()
                Session("DA_N_1") = dtExcelRecords
                lblerr.ForeColor = Drawing.Color.Blue
                lblerr.Text = "Uload successfull!"
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub

    Protected Sub cmdncd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdncd.Click
        Try
            SqlAction = ""
            SqlAction = "SELECT MED_VERIFIED  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WHERE MED_VERIFIED=0 AND  PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                lblncd.Text = "Medical sigh-off has not been Finalized!"
                Exit Sub
            End If


            '[SP_REN_CLAIMS_UPDATE_NCD]
            MyDBAction.UPDATE_Renewal_CLAIMS(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd"))
            MyDBAction.UPDATE_NCD_CLAIMS(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd"))

            updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] SET  NCD=1 WHERE  NCD=0 AND PERIOD_FROM = '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO = '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")

            updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  NCD_UPDATED=1 WHERE  PERIOD_FROM BETWEEN  '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND  '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
            lblncd.Text = "NCD  computed successfully!"
            LOADGRIDS()
        Catch ex As Exception
            lblncd.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnncdexp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnncdexp.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String


        Session("EXCEL") = "TO EXCEL"

        Reportname = "Ren_validated-& " & dtF_1.DbSelectedDate & ""
        SqlAction = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[MEMBER_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_FNAME],[MEMBER_LNAME],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[FIRST_ENROLLMENT_DATE],[MEMBERSHIP_STATUS],[AGENT],[POLICY_MONTH],[MEMBER_PRI_ADD_LINE1],[PROPOSER_PRI_PIN],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID],[UNIT],[BRANCH],[REGION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_ADD_LINE2],[POSTAL_CODE],[ADDRESS],[PROPOSER_PRI_MOBILE],[RENEWAL_DATE],[PERIOD_FROM],[PERIOD_TO],[AGE],[FAMILY_NO],[AGE_BAND],[PRODUCT],[LOADING_RATE],[OP_LIMIT],[IP_LIMIT],[SPLUS_IP_LIMIT],[FAMILY_SIZE],[POLICY_TYPE],[PRESENT_IP],[PRESENT_OP],[LAST_IP_DATE],[LAST_OP_DATE],[CURRENT_CLAIM],[IP_2016_2017],[LAST_CLAIM_DATE],[NCD_YEARS],[NCD_RATE],[IP_RATE],[IP_NET_NCD],[OP_RATE],[PA_PTD],[SILVER_PLUS_IP_PREMIUM],[SILVER_PLUS_NET_NCD],[SUB_TOTAL],[SUB_TOTAL_2],[LEVIES],[LEVIES_2],[TOTAL],[TOTAL_2],[IS_LOADING],[MED_VERIFIED] FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE PERIOD_FROM BETWEEN '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "' and VERIFIED=1 AND MED_VERIFIED=1 AND VALIDATED=0"

        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing
        System.Threading.Thread.Sleep(5000)
    End Sub
    Private Function SendLoginDetails(ByVal EmployeeName As String, ByVal path As String, ByVal RecepientEmail As String, ByVal ccEmail As String, ByVal msg As Integer) As Boolean

        Dim MailSent As Boolean = False

        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""

        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""



        Try

            LoginFromEmail = "customerservice@aar.co.ke"
            LoginDisplayName = "AAR INSURANCE KENYA LTD"
            LoginSubject = "MEDICAL COVER-POLICY RENEWAL"
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailUserName = "customerservice@aar.co.ke"
            EmailPassword = "!Cu$T0mer$$2018"
            MessageSubject = Session("MessageSubject") '" Medical Cover-Policy Renewal"

        Catch ex As Exception

        End Try


        Try

            Dim strHTML As New StringBuilder


            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("<td>")
            strHTML = strHTML.Append("</td>")
            strHTML = strHTML.Append("</tr>")
            strHTML = strHTML.Append("<tr>")
            If msg = 1 Then
                strHTML = strHTML.Append("<td colspan='3'>")
                'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
                strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Dear Medical Team, </b> </span>")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append(" This is to inform  you that renewal list for '" & Session("Month") & "' is ready for Loading.You are expected to Finalize and Load Members  withing the next 14 days.")
            ElseIf msg = 2 Then
                strHTML = strHTML.Append("<td colspan='3'>")
                'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
                strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Dear Retention Team, </b> </span>")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append(" This is to inform  you that renewal list for '" & Session("Month") & "' is ready for Printing and dispatch.You are expected to Print  Renewal Letters,schedules and distpatch withing the next 14 days.")
            ElseIf msg = 3 Then
                strHTML = strHTML.Append("<td colspan='3'>")
                'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
                strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Dear Retention Team, </b> </span>")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append("<br />")
                strHTML = strHTML.Append(" This is to inform  you that Rates for some members have been revised list  is ready for printing and dispatch.You are expected to Print  Renewal Letters,schedules and distpatch immediately.")


            End If
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")

            'RecepientEmail = "jmwaniki@aar.co.ke"
            'ccEmail = "jmwaniki@aar.co.ke"
            Dim mymail As New Emailing

            MailSent = mymail.SendNotification(path, MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccEmail)


            Session("MailSent") = MailSent


        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False

        End Try

        Return MailSent
    End Function

    Protected Sub btntotals_rev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btntotals_rev.Click
        Try
            MyDBAction.import_Revise_Totals(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd"))
            'updateRecord("UPDATE [TBL_MIS_RENEWAL_PROCESS] SET  [SIGN_OFF_TOTAL]=1 WHERE  [SIGN_OFF_TOTAL]=0 AND PERIOD_FROM = '" & CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND PERIOD_TO= '" & CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd") & "'")
            REV.Text = "Premium sum computed successfully!"
            LOADGRIDS()
        Catch ex As Exception
            REV.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click
        Dim da As DataTable = Nothing
        Dim REVISED As Integer = 0
        Dim row As DataRow
        Dim MnuCount As Int16 = 0
        Dim RECEIPT As String = ""
        Dim cn As Integer = 0
        Dim MyDatatable As System.Data.DataTable : Dim Str As String
        'da = Session("DAD_VA")
        Try
            If chkrevise.Checked = True Then

                If Not Session("DAD_RE") Is Nothing Then

                    'POLICY_CODE, DISPLAY_MEMBERSHIP_NO

                    For Each row In Session("DAD_RE").rows
                        MyDBAction.forward_Revised_rates(row("POLICY_CODE").ToString, row("MEMBER_NO").ToString, Session("username"))
                        updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] SET  APPROVED=1, [VALIDATED]=1,VALIDATED_BY='" & Session("username") & "' WHERE  [VALIDATED]=0 AND IS_REVISED=1 AND IS_SUMMATION=1 AND MEMBER_NO='" & row("MEMBER_NO").ToString & "'")
                        cn = cn + 1
                    Next
                End If
            End If

            MyDBAction.forward_Proposer_list(CDate(dtF_1.SelectedDate).ToString("yyyy-MM-dd"), CDate(DTt_1.SelectedDate).ToString("yyyy-MM-dd"))


            Session("MessageSubject") = Session("Month") & "-Renewal List"
            msg = 3
            MailSent = SendLoginDetails("Retention Team", Session("Path"), "Relationship-Managers@aar.co.ke", "awanga@aar.co.ke", msg)

            REV.Text = "Revised List Validated and Forwarded!"

            LOADGRIDS()
        Catch ex As Exception
            REV.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDENRI_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDENRI.NeedDataSource

    End Sub
End Class
