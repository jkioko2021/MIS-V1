﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retail_ReAllocation_x.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="ALLOCATE-RETAIL"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1200px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 3043px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 384px">
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Proposer" Value="P" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                    <td>
                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search" Skin="Simple">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1200px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="30" Skin="Outlook" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID"> 
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                       <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridButtonColumn>
                                                     
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" HeaderText="PROPOSER_NAME" 
                                                            SortExpression="PROPOSER_DISPLAY_NAME" UniqueName="PROPOSER_DISPLAY_NAME" ItemStyle-Wrap="False">
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="PREMIUMS" DataType="System.Decimal" 
                                                              FilterControlAltText="Filter PREMIUMS column" HeaderText="PREMIUM" 
                                                              SortExpression="PREMIUMS" UniqueName="PREMIUMS">
                                                          </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="LIVES" DataType="System.Decimal" 
                                                              FilterControlAltText="Filter LIVES column" HeaderText="LIVES" 
                                                              SortExpression="LIVES" UniqueName="LIVES">
                                                          </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM" ItemStyle-Wrap="False">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO" ItemStyle-Wrap="False">
                                                        </telerik:GridBoundColumn>
                                                                                                               
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                           
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label126" runat="server" Text="Proposer"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtproposer" Runat="server" Skin="Outlook" 
                                            Width="280px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label140" runat="server" Text="Period From"></asp:Label>
                                    </td>
                                    <td style="width: 41px">
                                        <telerik:RadDatePicker ID="dtfrom" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label141" runat="server" Text="Period To"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="DTto" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label143" runat="server" Text="Agent"></asp:Label>
                                    </td>
                                    <td style="width: 41px">
                                        <telerik:RadComboBox ID="cboagent" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label144" runat="server" Text="Policy Code"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtpolicy" Runat="server" Skin="Outlook" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <hr style="5" />
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label102" runat="server" Text="Q1 From Date"></asp:Label>
                                    </td>
                                    <td style="width: 41px">
                                        <telerik:RadDatePicker ID="dtq1from" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label128" runat="server" Text="Q1 To Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="DTQ1TO" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label134" runat="server" Text="Q2 From Date"></asp:Label>
                                    </td>
                                    <td style="width: 41px">
                                        <telerik:RadDatePicker ID="DTQ2FROM" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label135" runat="server" Text="Q2 To Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtQ2TO" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label136" runat="server" Text="Q3 From Date"></asp:Label>
                                    </td>
                                    <td style="width: 41px">
                                        <telerik:RadDatePicker ID="dTQ3FROM" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label137" runat="server" Text="Q3 To Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtQ3TO" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label138" runat="server" Text="Q4 From Date"></asp:Label>
                                    </td>
                                    <td style="width: 41px">
                                        <telerik:RadDatePicker ID="dtQ4FROM" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label139" runat="server" Text="Q4 To Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="DTQ4TO" Runat="server" MinDate="" Skin="Outlook">
                                            <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label145" runat="server" Text="Lives"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txtlives" Runat="server" Culture="en-US" 
                                            DataType="System.Int64" Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="Label106" runat="server" Text="Premium"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txtpremium" Runat="server" Culture="en-US" 
                                            Value="0" Width="125px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        <asp:Label ID="Label142" runat="server" Text="Account RM"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadComboBox ID="cborm" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        <asp:Label ID="lblID" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 41px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                    </td>
                                    <td class="style8">
                                        &nbsp;</td>
                                    <td class="style8">
                                        <telerik:RadButton ID="cmdsave" runat="server" Height="37px" Skin="Simple" 
                                            Text="Save" Width="100px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 194px">
                                        &nbsp;</td>
                                    <td style="width: 41px">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" colspan="2">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 166px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                        <asp:Panel ID="Panel16" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                Width="1001px">
                                                                <table style="width: 100%">
                                                                    <tr>
                                                                        <td bgcolor="#999999" colspan="4">
                                                                            <asp:Label ID="Label86" runat="server" Text="Report Extract (Entry Date)"></asp:Label>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="width: 199px">
                                                                            &nbsp;</td>
                                                                        <td style="width: 199px">
                                                                            <asp:Label ID="Label81" runat="server" Text="Date From"></asp:Label>
                                                                        </td>
                                                                        <td style="width: 143px">
                                                                            <telerik:RadDatePicker ID="dtDateFrom" Runat="server" Skin="Web20">
                                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                </Calendar>
                                                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                                                </DateInput>
                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                            </telerik:RadDatePicker>
                                                                        </td>
                                                                        <td>
                                                                            &nbsp;</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="width: 199px">
                                                                            &nbsp;</td>
                                                                        <td style="width: 199px">
                                                                            <asp:Label ID="Label82" runat="server" Text="Date To"></asp:Label>
                                                                        </td>
                                                                        <td style="width: 143px">
                                                                            <telerik:RadDatePicker ID="dtDateTo" Runat="server" Skin="Sunset" Width="150px">
                                                                                <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                </Calendar>
                                                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                                                </DateInput>
                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                            </telerik:RadDatePicker>
                                                                        </td>
                                                                        <td>
                                                                            <telerik:RadButton ID="RadButton1" runat="server" Skin="Outlook" Text="Generate">
                                                                            </telerik:RadButton>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>

    </asp:UpdatePanel>
</asp:Content>

