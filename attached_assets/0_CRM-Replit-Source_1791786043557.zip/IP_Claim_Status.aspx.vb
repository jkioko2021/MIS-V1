﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            Str = ""
         
        End If
    End Sub
   

    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_IP_CLAIM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_IP_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""

        'cboprovider.SelectedValue 

        'cboprovider.Text = ""
        lblerr.Text = ""
        Session("Audited") = 0
        Session("Posting") = 0
        lblfile.Text = ""
        Try


            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT  [ID],[FILE_NO],Allocated,member_name,Discharge_By, [MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],Invoice_type,Country,P_I_Amount,Proposer,RECEIVE_DT,SERVICE_DT,Amt_Payable_Ben,  INV_STATUS,BAR_CODE FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]   WITH (NOLOCK)  WHERE File_No ='" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                    dtservice.DbSelectedDate = MyDatable.Rows(0).Item("SERVICE_DT").ToString()
                    txtbarcode.Text = MyDatable.Rows(0).Item("BAR_CODE").ToString()
                    'cboprovider.SelectedValue = MyDatable.Rows(0).Item("ORG_NAME").ToString()
                    'cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                    txtmemno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()

                    txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                    txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("member_name").ToString()
                    txtpayable.Text = MyDatable.Rows(0).Item("Amt_Payable_Ben").ToString()
                    txtpayP_I.Text = MyDatable.Rows(0).Item("P_I_Amount").ToString()
                    cbocountry.SelectedValue = MyDatable.Rows(0).Item("Country").ToString()
                    cbotype.SelectedValue = MyDatable.Rows(0).Item("Invoice_type").ToString()
                    txtproposer.Text = MyDatable.Rows(0).Item("Proposer").ToString()
                    Disch.Text = MyDatable.Rows(0).Item("Discharge_By").ToString()
                    'Session("Audited") = MyDatable.Rows(0).Item("Audited").ToString()
                    Session("Allocated") = MyDatable.Rows(0).Item("Allocated").ToString()
                    load_Grid(lblfile.Text)



                    If txtpayable.Text = "" Then
                        txtpayable.Text = 0
                    End If
                    If txtpayP_I.Text = "" Then
                        txtpayP_I.Text = 0
                    End If

                    cbotype.Enabled = False
                    '  txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False
                    dtservice.Enabled = False
                    txtproposer.Text = False
                    'txtbarcode.Enabled = False
                    '  cbotype.Enabled = False
                    txtmemno.Enabled = False

                    txtinv_no.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False

                    ' txtname.Enabled = False
                    txtinv_no.Enabled = False

                    txtinv_amt.Enabled = False
                    'txtcomment.Enabled = False


                    txtinv_amt.Enabled = False



                End If
                HiddenField1.Value = 1
                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub

    Protected Sub SEARCH_Click(sender As Object, e As System.EventArgs) Handles SEARCH.Click
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT  [ID],[FILE_NO],Submit_dt,[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Member_Name,Invoice_type,Discharge_By FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]  WHERE   INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%' and active=1 and audited=0"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT  [ID],[FILE_NO],Submit_dt,[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Member_Name,Invoice_type,Discharge_By FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]    WITH (NOLOCK) WHERE    MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%'   and active=1 and audited=0"
            ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT  [ID],[FILE_NO],Submit_dt,[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Member_Name,Invoice_type,Discharge_By FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]     WITH (NOLOCK) WHERE     MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%'  and active=1 and audited=0"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [ID],[FILE_NO],Submit_dt,[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,Provider_Name,Member_Name,Invoice_type,Discharge_By FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING]    WITH (NOLOCK) WHERE    FILE_NO Like '%" & Trim(txtsearch.Text) & "%'  and active=1 and audited=0"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
