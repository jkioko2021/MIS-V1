﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail
    Dim dr As Decimal = 0
    Dim cr As Decimal = 0
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""

                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing
                Session("med") = 0
                Session("Allocate") = 0
                Session("INVOICED") = 0
                dtinvoice.DbSelectedDate = Date.Now()

                'ltEmbed.Text = ""


                Str = "SELECT  [DOC_CODE],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] WHERE ACTIVE=1 AND CODE=5"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbodoc
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("DOC_NAME").ToString
                    .DataValueField = MyDatatable.Columns("DOC_CODE").ToString
                    .DataBind()
                End With

                Load_Ref()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
    Private Sub Load_Ref()
        SqlAction = "SELECT Proposer, [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By,Client_Type FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE Requested=1 and Allocated =1 and Processed=1 AND Approved=1 and Verified=1 AND [Fin_Approved]=0  AND Is_Active=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTrackingRef.DataSource = MyDatable
            GDTrackingRef.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing

        Else
            GDTrackingRef.DataSource = Nothing
            GDTrackingRef.DataBind()
        End If
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            If cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT Proposer, [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By,Client_Type FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE Refund_No  like '" & txtsearch.Text & "' and Requested=1 and Allocated =1 and Processed=1 and Approved=1 and [Verified]=1 AND [Fin_Approved]=0 AND   Is_Active=1 "
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT Proposer, [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By,Client_Type FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE Payee_Name  like '" & txtsearch.Text & "' and Requested=1 and Allocated =1 and Processed=1  and Approved=1 and [Verified]=1 AND [Fin_Approved]=0 AND Is_Active=1 "
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTrackingRef.DataSource = MyDatable
                GDTrackingRef.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDTrackingRef.DataSource = Nothing
                GDTrackingRef.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Public Sub loadGrid_Decline(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()


            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = Nothing
                GD_DOCS.DataBind()
            End If


            'Notes


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Public Sub LoadNotes(ByVal id As String)
        If lblREfT.Text = "DECLINE" Then
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] Notes_by,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_BUS_TRACKING_NOTES] WHERE  File_No ='" & FILE_NO.Text & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If
        Else
            SqlAction = "SELECT PROPOSER_DISPLAY_NAME, REFERENCE_NO,INVOICE_DATE,PERIOD_FROM,PERIOD_TO,REC_AMOUNT FROM [DATA_REPOSITORY_DB].dbo.[MASTER_STATEMENT_REFUNDS] WHERE PROCESSED=0 AND PROPOSER_ID= '" & lblprop.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_STATE_1.DataSource = MyDatable
                GD_STATE_1.DataBind()
            Else
                GD_STATE_1.DataSource = Nothing
                GD_STATE_1.DataBind()
            End If

            If lblclient.Text = "RET" Then
                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            ElseIf lblclient.Text = "CORP" Then
                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_CORPORATE_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            End If
            SqlAction = "SELECT DISTINCT  [POLICY_CODE], Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & lblprop.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_STATE.DataSource = MyDatable
                GD_STATE.DataBind()
                Session("STATE_01") = MyDatable
                dr = Convert.ToInt32(MyDatable.Compute("SUM(DR)", String.Empty))
                cr = Convert.ToInt32(MyDatable.Compute("sum(CR)", String.Empty))
                txtDR.Text = dr
                txtCR.Text = cr

                txtpaid.Text = dr - cr
                txtrefund.Text = txtpaid.Text
            Else
                GD_STATE.DataSource = Nothing
                GD_STATE.DataBind()
            End If
        End If
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub btnforward_Click(sender As Object, e As System.EventArgs) Handles btnforward.Click
        Try
            'Str = "SELECT EMAIL FROM employees WHERE username='" & cboAllocateto.SelectedValue & "'" '"
            'MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            'If MyDatatable.Rows.Count > 0 Then

            '    Session("email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
            '    Session("msg") = "Kindly note that you have been Allocated the below Refund for Approval."
            'End If

            If cboAction.SelectedValue = "RI" Then
                UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET  Refund_Status='RETURNED',Processed=0,Approved=0,REQUESTED=0,Verified=0 WHERE [Refund_No]='" & RefNo.Text & "'")

                Session("email") = Session("cc_email")
                Session("to") = lblenteredby.Text
                Session("msg") = "Kindly note that the above Refund has been returned as Incomplete From Finance!"

            ElseIf cboAction.SelectedValue = "P" Then
                If lblREfT.Text = "DECLINE" Then
                    UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET Posted_Amt='" & txtrefund.Text & "', Refund_Status='FINANCE-APPROVED',[Fin_Approved]=1,[Fin_Approved_Dt]='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',[Fin_Approved_By]='" & Session("username") & "'    WHERE [Refund_No]='" & RefNo.Text & "'")
                    Session("to") = lblenteredby.Text
                    Session("email") = "jchebet@aar.co.ke"
                    Session("msg") = "Kindly note that the above Refund has been Approved and forwarded for Payment!"
                    ' MailSent = SendLoginDetails(cboAllocateto.SelectedValue, Session("cc_email"), Session("email"))
                    GD_DOCS.DataSource = Nothing
                    GD_DOCS.DataBind()
                    lblerr.Text = "Submitted SuccessFully!"
                Else

                    MyDBAction.SAVE_REFUND_AMT(RefNo.Text, CDate(Date.Now).ToString("yyyy-MM-dd"), txtrefund.Text, lblprop.Text, Session("username"))

                End If

            ElseIf cboAction.SelectedValue = "D" Then
                UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET Refund_Status='DECLINED',Verified=0,[Approved]=0   WHERE [Refund_No]='" & RefNo.Text & "'")
                Session("email") = Session("cc_email")

                Session("to") = lblenteredby.Text
                Session("msg") = "Kindly note that the above Refund has been DECLINED by Finance!"
                '   MailSent = SendLoginDetails(cboAllocateto.SelectedValue, Session("cc_email"), Session("email"))

            End If

            MailSent = SendLoginDetails(lblenteredby.Text, Session("email"), Session("cc_email"))

            If txtcomment.Text <> "" Then
                If lblREfT.Text = "DECLINE" Then
                    MyDBAction.TRACKING_MESSAGES(FILE_NO.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)

                Else
                    If lblclient.Text = "RET" Then
                        MyDBAction.TASK_MESSAGES(FILE_NO.Text, txtcomment.Text, Session("username"), Date.Now(), "PREM-REFUND", "RETAIL")

                    ElseIf lblclient.Text = "CORP" Then
                        MyDBAction.TASK_MESSAGES_CORP(FILE_NO.Text, txtcomment.Text, Session("username"), Date.Now(), "PREM-REFUND", "CORPORATE")
                    End If
                End If



            End If

            lblerr.Text = "Submitted successfull!"
            Load_Ref()
            LoadNotes(lblprop.Text)

            RefNo.Text = ""
            FILE_NO.Text = ""
            txtname.Text = ""
            lblREfT.Text = ""
            txtemail.Text = ""
            txtmobile.Text = ""
            txtrefund.Text = 0
            txtpaid.Text = 0
            txtDR.Text = 0
            txtCR.Text = 0
            txtcomment.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GDTrackingRef_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTrackingRef.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            GD_STATE_1.DataSource = Nothing
            GD_STATE_1.DataBind()
            'ltEmbed.Text = ""
            stst = (DirectCast(GDTrackingRef.SelectedItems(0), GridDataItem)).GetDataKeyValue("Refund_No").ToString()
            SqlAction = "SELECT Request_Dt, [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By,Client_Type,Proposer_Id,[Process_By] FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE  Refund_No ='" & stst & "' AND Is_Active=1 "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txtname.Text = MyDatable.Rows(0).Item("Payee_Name").ToString()
                txtemail.Text = MyDatable.Rows(0).Item("Payee_eMail").ToString()
                txtmobile.Text = MyDatable.Rows(0).Item("Payee_Mobile").ToString()
                txtpaid.Text = MyDatable.Rows(0).Item("Amount_Paid").ToString()
                txtrefund.Text = MyDatable.Rows(0).Item("Refund_Amt").ToString()
                lblenteredby.Text = MyDatable.Rows(0).Item("Entered_By").ToString()
                RefNo.Text = MyDatable.Rows(0).Item("Refund_No").ToString()
                FILE_NO.Text = MyDatable.Rows(0).Item("File_No").ToString()
                lblREfT.Text = MyDatable.Rows(0).Item("Refund_Type").ToString()
                lblprop.Text = MyDatable.Rows(0).Item("Proposer_id").ToString()
                lblprocessedby.Text = MyDatable.Rows(0).Item("Process_By").ToString()
                dtinvoice.DbSelectedDate = MyDatable.Rows(0).Item("Request_Dt").ToString()
                lblclient.Text = MyDatable.Rows(0).Item("Client_Type").ToString()
                LoadNotes(FILE_NO.Text)
                loadGrid_Decline(FILE_NO.Text)

                SqlAction = "SELECT DISTINCT  [POLICY_CODE], Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & lblprop.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_STATE.DataSource = MyDatable
                    GD_STATE.DataBind()
                    Session("STATE_01") = MyDatable
                    dr = Convert.ToInt32(MyDatable.Compute("SUM(DR)", String.Empty))
                    cr = Convert.ToInt32(MyDatable.Compute("sum(CR)", String.Empty))
                    txtDR.Text = dr
                    txtCR.Text = cr
                Else
                    GD_STATE.DataSource = Nothing
                    GD_STATE.DataBind()
                End If

                

                Str = "SELECT EMAIL FROM employees WHERE username='" & lblenteredby.Text & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    Session("cc_email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                Else
                    Str = "SELECT EMAIL FROM SALES.dbo.employees WHERE username='" & lblenteredby.Text & "'" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    If MyDatatable.Rows.Count > 0 Then
                        Session("cc_email") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                    Else
                        Session("cc_email") = "relationship-managers@aar.co.ke"
                    End If

                End If

            End If
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_STATE.PageIndexChanged
        GD_STATE.CurrentPageIndex = e.NewPageIndex
        GD_STATE.DataSource = Session("STATE_01")
        GD_STATE.DataBind()
    End Sub

    Protected Sub btnstatement_Click(sender As Object, e As System.EventArgs) Handles btnstatement.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable




            Session("PRINT") = "PDF"
            Session("Report_") = "Customer Statement"

            Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR], [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & LBLPROP.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC,REFERENCE_NO"

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileDoc.ashx?Id="), id)
    End Sub
    
    Protected Sub GDTrackingRef_ItemDataBound(ByVal s As Object, ByVal e As GridItemEventArgs) Handles GDTrackingRef.ItemDataBound
        If TypeOf e.Item Is GridDataItem Then

            Dim dataItem As GridDataItem = e.Item
            Dim myCell As TableCell = dataItem("Refund_Type")
            If myCell.Text = "DECLINE" Then
                dataItem.BackColor = Drawing.Color.Red
            End If
        End If
    End Sub
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            'LoginSubject = "BUSINESS ALLOCATION"
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>ATT:" & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = "'" & lblREfT.Text & ":REFUND-" & txtname.Text & "-" & FILE_NO.Text & " ' "
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Refund No:" & RefNo.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Payee Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Submitted By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

    Protected Sub GD_DOCS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_DOCS.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""
            'ltEmbed.Text = ""
            stst = (DirectCast(GD_DOCS.SelectedItems(0), GridDataItem)).GetDataKeyValue("DOC_ID").ToString()
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM  [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  DOC_ID ='" & stst & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                HiddenField1.Value = MyDatable.Rows(0).Item("DOC_ID").ToString()
            End If
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnforward0_Click(sender As Object, e As System.EventArgs) Handles btnforward0.Click
        Try
            lblerr.Text = ""
            If RefNo.Text = "" Then
                lblerr.Text = "Select the Refund"
                Exit Sub
            End If

            MyDBAction.POST_REFUND_AMT(RefNo.Text, lblprop.Text, Session("username"))

            UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET Refund_Status='FINANCE-APPROVED',[Fin_Approved]=1,[Fin_Approved_Dt]='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',[Fin_Approved_By]='" & Session("username") & "'    WHERE [Refund_No]='" & RefNo.Text & "'")
            Session("to") = lblenteredby.Text
            Session("email") = "jchebet@aar.co.ke"
            Session("msg") = "Kindly note that the above Refund has been Approved by Finance and forwarded for Payment!"
            MailSent = SendLoginDetails(lblenteredby.Text, Session("email"), Session("cc_email"))

            LoadNotes(lblprop.Text)
            lblerr.Text = "Submitted SuccessFully!"
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            GD_STATE_1.DataSource = Nothing
            GD_STATE_1.DataBind()
            Load_Ref()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String

        lblupload.Text = ""
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If

            If cbodoc.Text = "" Then
                lblerr.Text = "Select Document Title"
                Exit Sub
            End If



            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                ' MyDBAction.UPLOAD_File_DOCS(bytes, filename, contenttype, FILE_NO.Text, Trim(cbodoc.Text.ToUpper), CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), cbodoc.SelectedValue)
                MyDBAction.UPLOAD_File_DOC_INVOIC(bytes, filename, contenttype, FILE_NO.Text, Trim(cbodoc.Text.ToUpper), CDate(Date.Now()).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), cbodoc.SelectedValue, Trim(lblREfT.Text))

                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green

                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If


            loadGrid_Decline(FILE_NO.Text)

        Catch ex As Exception
            lblupload.Text = ex.Message
        End Try

    End Sub
End Class
