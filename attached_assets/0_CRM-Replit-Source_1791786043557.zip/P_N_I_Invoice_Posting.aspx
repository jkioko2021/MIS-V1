﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="P_N_I_Invoice_Posting.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="P AND I POSTING"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1096px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 2924px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 154px">
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                <telerik:RadComboBoxItem runat="server" Text="File_No" Value="F" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1121px">
                            <table style="width: 97%">
                                <tr>
                                    <td class="style8" colspan="5">
                                        <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDSEARCH_1" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                            ItemStyle-Wrap="False" SortExpression="Member_Name" UniqueName="Member_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Provider_Name" 
                                                            FilterControlAltText="Filter Provider_Name column" HeaderText="Provider_Name" 
                                                            SortExpression="Provider_Name" UniqueName="Provider_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Inv_Status" 
                                                            FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
                                                            SortExpression="Inv_Status" UniqueName="Inv_Status">
                                                        </telerik:GridBoundColumn>
                                                     
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 2137px" class="style19">
                                        <asp:Label ID="Label148" runat="server" Text="File Number"></asp:Label>
                                    </td>
                                    <td style="width: 809px">
                                        <asp:Label ID="lblfile" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 2137px" class="style19">
                                        <asp:Label ID="Label102" runat="server" Text="Receive Date"></asp:Label>
                                    </td>
                                    <td style="width: 809px">
                                        <telerik:RadDatePicker ID="dtreceive" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label128" runat="server" Text="Service Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtservice" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 2137px" class="style19">
                                        <asp:Label ID="Label126" runat="server" Text="Member No."></asp:Label>
                                    </td>
                                    <td style="width: 809px">
                                        <telerik:RadTextBox ID="txtmemno" Runat="server" EmptyMessage="KE123456700" 
                                            Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label132" runat="server" Text="Provider"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadComboBox ID="cboprovider" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" 
                                            Width="250px" Enabled="False">
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 2137px" class="style19">
                                        <asp:Label ID="Label135" runat="server" Text="Member Name"></asp:Label>
                                    </td>
                                    <td style="width: 809px">
                                        <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label154" runat="server" Text="Corporate"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666" colspan="5">
                                        <asp:Label ID="Label155" runat="server" Text="Posting"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDSEARCH_2" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_No" 
                                                            FilterControlAltText="Filter Invoice_No column" HeaderText="Invoice_No" 
                                                            ItemStyle-Wrap="False" SortExpression="Invoice_No" UniqueName="Invoice_No">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="Invoice_Dt" 
                                                            FilterControlAltText="Filter Invoice_Dt column" HeaderText="Invoice_Dt" 
                                                            SortExpression="Invoice_Dt" UniqueName="Invoice_Dt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_Amt"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Invoice_Amt column" HeaderText="Invoice_Amt" 
                                                            SortExpression="Invoice_Amt" UniqueName="Invoice_Amt">
                                                        </telerik:GridBoundColumn>
                                                       
                                                        <telerik:GridBoundColumn DataField="Total_Bill"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Total_Bill column" HeaderText="Total_Bill" 
                                                            SortExpression="Inv_Status" UniqueName="Total_Bill">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Cover_Limit"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Cover_Limit column" HeaderText="Cover_Limit" 
                                                            SortExpression="Cover_Limit" UniqueName="Cover_Limit">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Overshot"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Overshot column" HeaderText="Overshot" 
                                                            SortExpression="Overshot" UniqueName="Overshot">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Admin_Fee"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Admin_Fee column" HeaderText="Admin_Fee" 
                                                            SortExpression="Admin_Fee" UniqueName="Admin_Fee">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Pay_N_Invoice"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Pay_N_Invoice column" HeaderText="Pay_N_Invoice" 
                                                            SortExpression="Pay_N_Invoice" UniqueName="Pay_N_Invoice">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Sage_Inv_No" 
                                                            FilterControlAltText="Filter Sage_Inv_No column" HeaderText="Sage_Inv_No" SortExpression="Sage_Inv_No" 
                                                            UniqueName="Sage_Inv_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Posting_Dt" 
                                                            FilterControlAltText="Filter Posting_Dt column" HeaderText="Posting_Dt" SortExpression="Posting_Dt" 
                                                            UniqueName="Posting_Dt">
                                                        </telerik:GridBoundColumn>
                                                       
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 2137px" class="style19">
                                        <asp:Label ID="Label156" runat="server" Text="Posting Date"></asp:Label>
                                    </td>
                                    <td style="width: 809px">
                                        <telerik:RadDatePicker ID="dtdoa" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 2137px" class="style19">
                                        <asp:Label ID="Label158" runat="server" Text="Accpac Inv No"></asp:Label>
                                    </td>
                                    <td style="width: 809px">
                                        <telerik:RadTextBox ID="txtinvno" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 2137px" class="style19">
                                        <asp:Label ID="Label161" runat="server" Text="Upload Docs"></asp:Label>
                                    </td>
                                    <td style="width: 809px">
                                        <telerik:RadComboBox ID="cbodoc" Runat="server" MarkFirstMatch="True" 
                                            Skin="Sunset" Width="250px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td class="style19" style="width: 2137px">
                                        &nbsp;</td>
                                    <td style="width: 809px">
                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                    </td>
                                    <td class="style8" colspan="2">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td class="style19" style="width: 2137px">
                                        &nbsp;</td>
                                    <td style="width: 809px">
                                        <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" Text="Upload">
                                        </telerik:RadButton>
                                        <asp:Label ID="lblupload" runat="server" Font-Size="Medium"></asp:Label>
                                    </td>
                                    <td class="style8" colspan="2">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        <asp:Panel ID="Panel32" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" Width="1109px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label151" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1100px">
                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                            SortExpression="DOC_ID">
                                                                            <ItemTemplate>
                                                                                <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                    CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                            </ItemTemplate>
                                                                        </telerik:GridTemplateColumn>
                                                                        <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                                            ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                                            Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                            <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                            <ItemStyle CssClass="ButtonColumn" />
                                                                        </telerik:GridButtonColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                            ScrollBars="Horizontal" Width="1100px">
                                                            <asp:Literal ID="ltEmbed" runat="server" />
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#999999" colspan="5">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; ">
                                        &nbsp;</td>
                                    <td style="width: 2137px; " class="style19">
                                        <asp:Label ID="Label160" runat="server" Text="Status"></asp:Label>
                                    </td>
                                    <td style="width: 809px; ">
                                        <telerik:RadComboBox ID="cbopost" Runat="server" Skin="Sunset">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" />
                                                <telerik:RadComboBoxItem runat="server" Text="Posted" Value="P" />
                                                <telerik:RadComboBoxItem runat="server" Text="Return" Value="R" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 172px; ">
                                        &nbsp;</td>
                                    <td style="width: 287px; ">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 2137px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 809px; height: 41px;">
                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="70px" Rows="1" 
                                            Skin="Sunset" TextMode="MultiLine" Width="400px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 41px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 2137px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 809px; height: 41px;">
                                        <telerik:RadButton ID="cmdsave" runat="server" Height="35px" Skin="Simple" 
                                            Text="Post" Width="140px">
                                        </telerik:RadButton>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 41px;">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td style="width: 287px; height: 41px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                        <asp:Panel ID="Panel36" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        &nbsp;</td>
                                </tr>
                            </table>
                            <table style="width: 97%">
                                <tr>
                                    <td style="height: 13px">
                                        &nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
             <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
          </Triggers>
    </asp:UpdatePanel>
</asp:Content>

