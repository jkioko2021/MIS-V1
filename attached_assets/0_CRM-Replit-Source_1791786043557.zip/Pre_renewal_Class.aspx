﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Pre_renewal_Class.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <telerik:RadTabStrip ID="RadTabStrip1" runat="server" Width="1160px" 
                MultiPageID="RadMultiPage1" SelectedIndex="0" Skin="Office2007">
                <Tabs>
                    <telerik:RadTab runat="server" PageViewID="V1" Text="Pre-Renewal" 
                        Selected="True" SelectedIndex="0">
                    </telerik:RadTab>
                    <telerik:RadTab runat="server" PageViewID="V2" Text="Post-Renewal">
                    </telerik:RadTab>
                    <telerik:RadTab runat="server" PageViewID="V3" Text="Lapsed Renewals">
                    </telerik:RadTab>
                </Tabs>
            </telerik:RadTabStrip>
            <telerik:RadMultiPage ID="RadMultiPage1" runat="server">
                <telerik:RadPageView ID="V1" runat="server" Selected="True">
                    <table style="height: 100%;">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="#CCCCCC" style="font-weight: 700" 
                            Text="VIEW PRE-RENEWALS"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="center" style="text-align: left; width: 685px;">
                        <telerik:RadComboBox ID="cboRM" Runat="server" Skin="Outlook" Width="227px" 
                            AutoPostBack="True" style="margin-left: 0px">
                        </telerik:RadComboBox>
                    </td>
                    <td align="center">
                        <telerik:RadComboBox ID="cboclass" Runat="server" AutoPostBack="True" 
                            Skin="Outlook" style="margin-left: 0px" Width="227px">
                        </telerik:RadComboBox>
                    </td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1162px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel16" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GD_PROP_0" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="RMS_CODE">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="RE_NAME" 
                                                            FilterControlAltText="Filter RE_NAME column" HeaderText="NAME" 
                                                            SortExpression="RE_NAME" UniqueName="RE_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CNT_POLICIES" 
                                                            FilterControlAltText="Filter CNT_POLICIES column" 
                                                            HeaderText="CNT_POLICIES" SortExpression="CNT_POLICIES" 
                                                            UniqueName="CNT_POLICIES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                      
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel2" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GD_PROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FAMILY_NO" 
                                                            FilterControlAltText="Filter FAMILY_NO column" HeaderText="FAMILY_NO" 
                                                            SortExpression="FAMILY_NO" UniqueName="FAMILY_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DAYS_DUE" 
                                                            FilterControlAltText="Filter DAYS_DUE column" HeaderText="DAYS_DUE" 
                                                            SortExpression="DAYS_DUE" UniqueName="DAYS_DUE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT" 
                                                            FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                            SortExpression="AGENT" UniqueName="AGENT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MOBILE_NO" 
                                                            FilterControlAltText="Filter MOBILE_NO column" HeaderText="MOBILE_NO" 
                                                            SortExpression="MOBILE_NO" UniqueName="MOBILE_NO">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label104" runat="server" Text="Total Premiums"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txttotal" Runat="server" Width="155px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblPolicy" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="lblproposer" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                    </td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#333333" colspan="4">
                                        <asp:Label ID="Label135" runat="server" 
                                            style="font-weight: 700; color: #FFFFFF;" Text="Print"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        <telerik:RadButton ID="BTNprint0" runat="server" Skin="Simple" 
                                            Text="Export List">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 151px; height: 11px;">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        <telerik:RadButton ID="BTNprint" runat="server" Skin="Simple" 
                                            Text="Print Schedule">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
                    </telerik:RadPageView>
                    <telerik:RadPageView ID="V2" runat="server">
                    <table style="height: 100%;">
                <tr>
                    <td align="center" bgcolor="#333333">
                        <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="#CCCCCC" style="font-weight: 700" 
                            Text="VIEW POST-RENEWALS"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1162px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel3" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GD_PROP_LAP" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="RMS_CODE">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="RE_NAME" 
                                                            FilterControlAltText="Filter RE_NAME column" HeaderText="NAME" 
                                                            SortExpression="RE_NAME" UniqueName="RE_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CNT_POLICIES" 
                                                            FilterControlAltText="Filter CNT_POLICIES column" HeaderText="CNT_POLICIES" 
                                                            SortExpression="CNT_POLICIES" UniqueName="CNT_POLICIES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel4" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GD_DET" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FAMILY_NO" 
                                                            FilterControlAltText="Filter FAMILY_NO column" HeaderText="FAMILY_NO" 
                                                            SortExpression="FAMILY_NO" UniqueName="FAMILY_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DAYS_DUE" 
                                                            FilterControlAltText="Filter DAYS_DUE column" HeaderText="DAYS_DUE" 
                                                            SortExpression="DAYS_DUE" UniqueName="DAYS_DUE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT" 
                                                            FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                            SortExpression="AGENT" UniqueName="AGENT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MOBILE_NO" 
                                                            FilterControlAltText="Filter MOBILE_NO column" HeaderText="MOBILE_NO" 
                                                            SortExpression="MOBILE_NO" UniqueName="MOBILE_NO">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblPol" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#333333" colspan="4">
                                        <asp:Label ID="Label7" runat="server" style="font-weight: 700; color: #FFFFFF;" 
                                            Text="Print"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        <telerik:RadButton ID="RadButton3" runat="server" Skin="Simple" 
                                            Text="Export List">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 151px; height: 11px;">
                                    </td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        <telerik:RadButton ID="btnpostprint" runat="server" Skin="Simple" 
                                            Text="Print Schedule">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 287px; height: 11px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="Label8" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
                    </telerik:RadPageView>
                    <telerik:RadPageView ID="V3" runat="server">
                    <table style="height: 100%;">
                <tr>
                    <td align="center" bgcolor="#333333">
                        <asp:Label ID="Label2" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="#CCCCCC" style="font-weight: 700" 
                            Text="VIEW LASPED-RENEWALS"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Panel ID="Panel5" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1162px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GD_LAPSE" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="RMS_CODE">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="RE_NAME" 
                                                            FilterControlAltText="Filter RE_NAME column" HeaderText="NAME" 
                                                            SortExpression="RE_NAME" UniqueName="RE_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CNT_POLICIES" 
                                                            FilterControlAltText="Filter CNT_POLICIES column" HeaderText="CNT_POLICIES" 
                                                            SortExpression="CNT_POLICIES" UniqueName="CNT_POLICIES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GD_LAPSE_DED" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="FAMILY_NO" 
                                                            FilterControlAltText="Filter FAMILY_NO column" HeaderText="FAMILY_NO" 
                                                            SortExpression="FAMILY_NO" UniqueName="FAMILY_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DAYS_DUE" 
                                                            FilterControlAltText="Filter DAYS_DUE column" HeaderText="DAYS_DUE" 
                                                            SortExpression="DAYS_DUE" UniqueName="DAYS_DUE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT" 
                                                            FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                            SortExpression="AGENT" UniqueName="AGENT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MOBILE_NO" 
                                                            FilterControlAltText="Filter MOBILE_NO column" HeaderText="MOBILE_NO" 
                                                            SortExpression="MOBILE_NO" UniqueName="MOBILE_NO">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td>
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="Label3" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#333333" colspan="4">
                                        <asp:Label ID="Label4" runat="server" style="font-weight: 700; color: #FFFFFF;" 
                                            Text="Print"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" 
                                            Text="Export List">
                                        </telerik:RadButton>
                                    </td>
                                    <td style="width: 151px; height: 11px;">
                                    </td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 11px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="Label5" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
                    </telerik:RadPageView>
            </telerik:RadMultiPage>

            
              <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1165px">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>

