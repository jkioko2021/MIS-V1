﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retail_Statement_Schedule.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1162px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" Text="Select"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadComboBox ID="cbosearch" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="Family Code" Value="F" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RM_NAME" 
                                                            FilterControlAltText="Filter RM_NAME column" HeaderText="RM_NAME" 
                                                            SortExpression="RM_NAME" UniqueName="RM_NAME">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="AGENT" 
      FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
      SortExpression="AGENT" UniqueName="AGENT">
  </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel14" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GDMEM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" 
                                                    DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                              
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" HeaderText="DOB" 
                                                            SortExpression="MEMBER_BIRTH_DATE" UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="FIRST_ENROLLMENT_DATE" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter FIRST_ENROLLMENT_DATE column" HeaderText="JOIN DT" 
                                                            SortExpression="FIRST_ENROLLMENT_DATE" UniqueName="FIRST_ENROLLMENT_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="POLICY_VALID_UPTO" UniqueName="POLICY_VALID_UPTO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                            FilterControlAltText="Filter POLICY_STATUS column" HeaderText="POLICY_STATUS" 
                                                            SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                            FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                            SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                            FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                            SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                        </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="AGENT" 
    FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
    SortExpression="AGENT" UniqueName="AGENT">
</telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                            FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA_DATE" 
                                                            SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                        </telerik:GridBoundColumn>

                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="LBLFAMNO" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="LBLFAMNO0" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="3" Skin="Office2007">
                                            <Tabs>
                                                <telerik:RadTab runat="server" PageViewID="V2" Text="Member Statement">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V4" Text="Renewal Schedule">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server">
                                            <telerik:RadPageView ID="V2" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel1" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="3">
                                                                <asp:Label ID="Label144" runat="server" Text="View Retail Statement"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>                                                                           
                                                                                <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                    SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                    SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                    SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ACTION_TYPE" 
                                                                                    FilterControlAltText="Filter ACTION_TYPE column" HeaderText="ACTION_TYPE" 
                                                                                    SortExpression="ACTION_TYPE" UniqueName="ACTION_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="TOTAL_MEMBERS" 
                                                                                    FilterControlAltText="Filter TOTAL_MEMBERS column" HeaderText="MEMBERS" 
                                                                                    SortExpression="TOTAL_MEMBERS" UniqueName="TOTAL_MEMBERS">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                                                    FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                                                    SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="TRANSACTION_DATE" 
                                                                                    FilterControlAltText="Filter TRANSACTION_DATE column" HeaderText="TRANSACTION_DATE" 
                                                                                    SortExpression="TRANSACTION_DATE" UniqueName="TRANSACTION_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                                      <telerik:GridBoundColumn DataField="DR" 
                                                                                    FilterControlAltText="Filter DR column" HeaderText="DR" 
                                                                                    SortExpression="DR" UniqueName="DR">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="CR" 
                                                                                    FilterControlAltText="Filter CR column" HeaderText="CR" 
                                                                                    SortExpression="CR" UniqueName="CR">
                                                                                </telerik:GridBoundColumn>
                                                                                 
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px; height: 37px;">
                                                                <telerik:RadButton ID="btnstatement" runat="server" Skin="Simple" 
                                                                    Text="Print Statement" Width="276px">
                                                                </telerik:RadButton>
                                                            </td>
                                                            <td style="width: 215px; height: 37px;" align="right">
                                                                <asp:Label ID="Label145" runat="server" Font-Bold="True" Text="O/S balance"></asp:Label>
                                                            </td>
                                                            <td style="width: 223px; height: 37px;">
                                                                <telerik:RadNumericTextBox ID="txtbal" Runat="server" Enabled="False" 
                                                                    Skin="Simple">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td style="height: 37px">
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="lblid" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                            </td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V4" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel3" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel18" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_REN" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="POLICY_CODE">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridButtonColumn CommandName="Select" 
                                                                                    FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                    UniqueName="Select">
                                                                                    <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                    <ItemStyle Width="50px" />
                                                                                </telerik:GridButtonColumn>
                                                                                <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                    SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                                                    FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                                                    HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                                                    UniqueName="PROPOSER_DISPLAY_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="FAMILY_NO" 
                                                                                    FilterControlAltText="Filter FAMILY_NO column" HeaderText="FAMILY_NO" 
                                                                                    SortExpression="FAMILY_NO" UniqueName="FAMILY_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                    SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                    SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="DAYS_DUE" 
                                                                                    FilterControlAltText="Filter DAYS_DUE column" HeaderText="DAYS_OVERDUE" 
                                                                                    SortExpression="DAYS_DUE" UniqueName="DAYS_DUE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="AGENT" 
                                                                                    FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                                                    SortExpression="AGENT" UniqueName="AGENT">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                                                    DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                                                    HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                                                    UniqueName="TOTAL_PREMIUM">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MOBILE_NO" 
                                                                                    FilterControlAltText="Filter MOBILE_NO column" HeaderText="MOBILE_NO" 
                                                                                    SortExpression="MOBILE_NO" UniqueName="MOBILE_NO">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px; height: 34px;">
                                                                <telerik:RadComboBox ID="cboType" Runat="server" AutoPostBack="True">
                                                                    <Items>
                                                                        <telerik:RadComboBoxItem runat="server" Text="Renewal Schedule" Value="S" />
                                                                        <telerik:RadComboBoxItem runat="server" Selected="True" Text="Renewal Advice" Value="A" />
                                                                    </Items>
                                                                </telerik:RadComboBox>
                                                            </td>
                                                            <td style="width: 215px; height: 34px;">
                                                                </td>
                                                            <td style="width: 223px; height: 34px;">
                                                                </td>
                                                            <td style="height: 34px">
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <telerik:RadButton ID="btnschedule" runat="server" Skin="Simple" Text="Print Schedule" Width="276px">
                                                                </telerik:RadButton>
                                                            </td>
                                                            <td style="width: 215px">&nbsp;</td>
                                                            <td style="width: 223px">&nbsp;</td>
                                                            <td>&nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel19" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_Date" 
                                                            FilterControlAltText="Filter Note_Date column" HeaderText="Note date" 
                                                            ItemStyle-Width="50" SortExpression="Note_Date" UniqueName="Note_Date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type" 
                                                            ItemStyle-Width="50" SortExpression="Note_Type" UniqueName="Note_Type">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes_by" 
                                                            FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                            ItemStyle-Width="50" SortExpression="Notes_by" UniqueName="Notes_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>


