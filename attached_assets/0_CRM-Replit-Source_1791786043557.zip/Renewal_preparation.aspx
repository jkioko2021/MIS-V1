﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Renewal_preparation.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">

            <ContentTemplate>
                            <table>
                    <tr>
                        <td>
                            <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                Width="1133px">
                                <table style="width: 100%">
                                    <tr>
                                        <td bgcolor="#999999" colspan="5" align="center">
                                            <asp:Label ID="Label132" runat="server" Font-Bold="True" 
                                                Text="PREPARE RETAIL RENEWAL LIST"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 2449px">
                                            &nbsp;</td>
                                        <td style="width: 350px">
                                            <asp:Label ID="Label143" runat="server" style="font-weight: 700" 
                                                Text="Period From"></asp:Label>
                                        </td>
                                        <td>
                                            <telerik:RadDatePicker ID="dtF_1" Runat="server" Skin="Web20">
                                                <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                </Calendar>
                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                </DateInput>
                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                            </telerik:RadDatePicker>
                                        </td>
                                        <td class="style8" style="width: 222px">
                                            <asp:Label ID="Label144" runat="server" style="font-weight: 700" 
                                                Text="Period To"></asp:Label>
                                        </td>
                                        <td>
                                            <telerik:RadDatePicker ID="DTt_1" Runat="server" Skin="Web20" Width="150px">
                                                <Calendar Skin="Web20" UseColumnHeadersAsSelectors="False" 
                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                </Calendar>
                                                <DateInput DateFormat="M/d/yyyy" DisplayDateFormat="M/d/yyyy">
                                                </DateInput>
                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                            </telerik:RadDatePicker>
                                        </td>
                                    </tr>
                                </table>
                            </asp:Panel>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                Height="100%" style="font-weight: 700" Width="1139px">
                                <table style="width: 1136px">
                                    <tr>
                                        <td align="center" bgcolor="#666666" colspan="3" style="height: 34px;">
                                            <asp:Label ID="Label142" runat="server" Text="Data Import"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style8" style="height: 34px;" colspan="3">
                                            <asp:Panel ID="Panel15" runat="server" Height="200px" ScrollBars="Both" 
                                                Width="1095px">
                                                <telerik:RadGrid ID="GDSUMM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                    GridLines="None" Height="100%" Skin="Simple" Width="100%" PageSize="5">
                                                    <MasterTableView AutoGenerateColumns="False">
                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        </RowIndicatorColumn>
                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        </ExpandCollapseColumn>
                                                        <Columns>
                                                          
                                                            <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                ItemStyle-Wrap="False" SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="RENEWAL_LIST" DataType="System.Int32" 
                                                                FilterControlAltText="Filter RENEWAL_LIST column" HeaderText="RENEWAL_LIST" 
                                                                ItemStyle-Wrap="False" SortExpression="RENEWAL_LIST" UniqueName="RENEWAL_LIST">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                               <telerik:GridBoundColumn DataField="CLAIMS_DATA" DataType="System.Int32" 
                                                                FilterControlAltText="Filter CLAIMS_DATA column" HeaderText="CLAIMS_DATA" 
                                                                ItemStyle-Wrap="False" SortExpression="CLAIMS_DATA" UniqueName="CLAIMS_DATA">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                             <telerik:GridBoundColumn DataField="LOADING_DATA" DataType="System.Int32" 
                                                                FilterControlAltText="Filter LOADING_DATA column" HeaderText="LOADING_DATA" 
                                                                ItemStyle-Wrap="False" SortExpression="LOADING_DATA" UniqueName="LOADING_DATA">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="PREMIUMS_IND" DataType="System.Int32" 
                                                                FilterControlAltText="Filter PREMIUMS_IND column" HeaderText="PREMIUMS_IND" 
                                                                ItemStyle-Wrap="False" SortExpression="PREMIUMS_IND" UniqueName="PREMIUMS_IND">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                                     <telerik:GridBoundColumn DataField="PREMIUMS_SHARED" DataType="System.Int32" 
                                                                FilterControlAltText="Filter PREMIUMS_SHARED column" HeaderText="PREMIUMS_SHARED" 
                                                                ItemStyle-Wrap="False" SortExpression="PREMIUMS_SHARED" UniqueName="PREMIUMS_SHARED">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                    
                                                                        <telerik:GridBoundColumn DataField="VERIFIED" DataType="System.Int32" 
                                                                FilterControlAltText="Filter VERIFIED column" HeaderText="VERIFIED" 
                                                                ItemStyle-Wrap="False" SortExpression="VERIFIED" UniqueName="VERIFIED">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                                       <telerik:GridBoundColumn DataField="MED_VERIFICATION" DataType="System.Int32" 
                                                                FilterControlAltText="Filter MED_VERIFICATION column" HeaderText="MED_VERIFICATION" 
                                                                ItemStyle-Wrap="False" SortExpression="MED_VERIFICATION" UniqueName="MED_VERIFICATION">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                                   <telerik:GridBoundColumn DataField="NCD" DataType="System.Int32" 
                                                                FilterControlAltText="Filter NCD column" HeaderText="NCD" 
                                                                ItemStyle-Wrap="False" SortExpression="NCD" UniqueName="NCD">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="SIGN_OFF_TOTAL" DataType="System.Int32" 
                                                                FilterControlAltText="Filter SIGN_OFF_TOTAL column" HeaderText="SIGN_OFF_TOTAL" 
                                                                ItemStyle-Wrap="False" SortExpression="SIGN_OFF_TOTAL" UniqueName="SIGN_OFF_TOTAL">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                                          <telerik:GridBoundColumn DataField="VALIDATION" DataType="System.Int32" 
                                                                FilterControlAltText="Filter VALIDATION column" HeaderText="VALIDATION" 
                                                                ItemStyle-Wrap="False" SortExpression="VALIDATION" UniqueName="VALIDATION">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="APPROVAL" DataType="System.Int32" 
                                                                FilterControlAltText="Filter APPROVAL column" HeaderText="APPROVAL" 
                                                                ItemStyle-Wrap="False" SortExpression="APPROVAL" UniqueName="APPROVAL">
                                                                <ItemStyle Wrap="False" />
                                                            </telerik:GridBoundColumn>
                                                        </Columns>
                                                        <EditFormSettings>
                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                            </EditColumn>
                                                        </EditFormSettings>
                                                    </MasterTableView>
                                                    <PagerStyle Wrap="False" />
                                                    <FilterMenu EnableImageSprites="False">
                                                    </FilterMenu>
                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                    </HeaderContextMenu>
                                                </telerik:RadGrid>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style8" style="width: 180px">
                                            &nbsp;&nbsp;</td>
                                        <td>
                                            <asp:Label ID="lblstatus" runat="server" ForeColor="Red"></asp:Label>
                                        </td>
                                        <td style="width: 287px; ">
                                            <telerik:RadButton ID="btnrenexpo" runat="server" Text="Export List" 
                                                Width="218px" Skin="Simple">
                                            </telerik:RadButton>
                                        </td>
                                        <td class="style8" bgcolor="#CCCCCC" colspan="3">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style8" colspan="3">
                                            <telerik:RadTabStrip ID="RadTabStrip1" runat="server" Width="1121px" 
                                                MultiPageID="RadMultiPage1" SelectedIndex="0" Skin="Simple">
                                                <Tabs>
                                                    <telerik:RadTab runat="server" Text="Data Enrichment" PageViewID="V0" 
                                                        Selected="True">
                                                    </telerik:RadTab>
                                                    <telerik:RadTab runat="server" Text="List Verification" PageViewID="V1">
                                                    </telerik:RadTab>
                                                    <telerik:RadTab runat="server" Text="Update NCD" PageViewID="V1_2">
                                                    </telerik:RadTab>
                                                    <telerik:RadTab runat="server" PageViewID="V1_1" Text="Run Totals">
                                                    </telerik:RadTab>
                                                    <telerik:RadTab runat="server" Text="List Validation" PageViewID="V2">
                                                    </telerik:RadTab>
                                                    <telerik:RadTab runat="server" PageViewID="V2_1" Text="Revised Rates">
                                                    </telerik:RadTab>
                                                </Tabs>
                                            </telerik:RadTabStrip>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="style8" colspan="3">
                                            <telerik:RadMultiPage ID="RadMultiPage1" Runat="server">
                                                <telerik:RadPageView ID="V0" runat="server" Width="1131px">
                                                    <asp:Panel ID="Panel1" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td align="center" bgcolor="#999999">
                                                                    <asp:Label ID="Label1" runat="server" Text="Data Enrichment"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel3" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                        Width="1008px">
                                                                        <table style="width: 100%">
                                                                            <tr>
                                                                                <td style="width: 3043px; font-weight: 700;">
                                                                                    <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                                                                        Text="Search By"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 384px">
                                                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                                                                        <Items>
                                                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                                                            <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                                                            <telerik:RadComboBoxItem runat="server" Text="Ind Policy" Value="I" />
                                                                                            <telerik:RadComboBoxItem runat="server" Text="Shared" Value="S" />
                                                                                        </Items>
                                                                                    </telerik:RadComboBox>
                                                                                </td>
                                                                                <td>
                                                                                    &nbsp;</td>
                                                                                <td>
                                                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                                                                    </telerik:RadTextBox>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                                                                    </telerik:RadButton>
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel2" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1121px">
                                                                        <telerik:RadGrid ID="GDENRI" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                            GridLines="None" Height="100%" Skin="Simple" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="ID">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                                        FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                                        UniqueName="Select">
                                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                        <ItemStyle Width="100px" />
                                                                                    </telerik:GridButtonColumn>
                                                                                    <telerik:GridBoundColumn DataField="ID" DataType="System.Decimal" 
                                                                                        FilterControlAltText="Filter ID column" HeaderText="ID" ReadOnly="True" 
                                                                                        SortExpression="ID" UniqueName="ID">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                                        FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                        FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="RELATION" 
                                                                                        FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                        ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                        FilterControlAltText="Filter PERIOD_FROM column" 
                                                                                        HeaderText="PERIOD_FROM" ItemStyle-Wrap="False" 
                                                                                        SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                        FilterControlAltText="Filter PERIOD_TO column" 
                                                                                        HeaderText="PERIOD_TO" SortExpression="PERIOD_TO" 
                                                                                        UniqueName="PERIOD_TO">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_LIMIT" 
                                                                                        FilterControlAltText="Filter OP_LIMIT column" HeaderText="OP_LIMIT" 
                                                                                        SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_LIMIT" 
                                                                                        FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP_LIMIT" 
                                                                                        SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_IP" 
                                                                                        FilterControlAltText="Filter PRESENT_IP column" HeaderText="PRESENT_IP" 
                                                                                        SortExpression="PRESENT_IP" UniqueName="PRESENT_IP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_OP" 
                                                                                        FilterControlAltText="Filter PRESENT_OP column" HeaderText="PRESENT_OP" 
                                                                                        SortExpression="PRESENT_OP" UniqueName="PRESENT_OP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_RATE" 
                                                                                        FilterControlAltText="Filter IP_RATE column" HeaderText="IP_RATE" 
                                                                                        SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_RATE" 
                                                                                        FilterControlAltText="Filter OP_RATE column" HeaderText="OP_RATE" 
                                                                                        SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <PagerStyle Wrap="False" />
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel14" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                                        Height="100%" style="font-weight: 700" Width="1119px">
                                                                        <table style="width: 99%">
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label126" runat="server" Text="Member No."></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadTextBox ID="txtno" Runat="server" Skin="Sunset" Width="200px">
                                                                                    </telerik:RadTextBox>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label160" runat="server" Text="Member Name"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                                                                    </telerik:RadTextBox>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label140" runat="server" Text="Period From"></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadDatePicker ID="dtfrom" Runat="server" MinDate="" Skin="Sunset">
                                                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                        </Calendar>
                                                                                        <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                                                        </DateInput>
                                                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                    </telerik:RadDatePicker>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label141" runat="server" Text="Period To"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadDatePicker ID="DTto" Runat="server" MinDate="" Skin="Sunset">
                                                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                        </Calendar>
                                                                                        <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                                                        </DateInput>
                                                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                    </telerik:RadDatePicker>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label161" runat="server" Text="Age"></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadNumericTextBox ID="txtage" Runat="server" DataType="System.Single" 
                                                                                        Skin="Sunset">
                                                                                        <NumberFormat DecimalDigits="0" />
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label157" runat="server" Text="Relation"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadTextBox ID="txtrela" Runat="server" Skin="Sunset" Width="200px">
                                                                                    </telerik:RadTextBox>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label165" runat="server" Text="Scheme"></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadTextBox ID="txtscheme" Runat="server" Skin="Sunset" Width="250px">
                                                                                    </telerik:RadTextBox>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label169" runat="server" Text="Product"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadComboBox ID="cboprod" Runat="server" Skin="Sunset">
                                                                                        <Items>
                                                                                            <telerik:RadComboBoxItem runat="server" />
                                                                                            <telerik:RadComboBoxItem runat="server" Text="GOLD" Value="GOLD" />
                                                                                            <telerik:RadComboBoxItem runat="server" Text="SILVER" Value="SILVER" />
                                                                                            <telerik:RadComboBoxItem runat="server" Text="BRONZE" Value="BRONZE" />
                                                                                            <telerik:RadComboBoxItem runat="server" Text="COVERME" Value="COVERME" />
                                                                                        </Items>
                                                                                    </telerik:RadComboBox>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label168" runat="server" Text="NCD"></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadNumericTextBox ID="txtncd" Runat="server" Culture="en-US" 
                                                                                        DataType="System.Decimal" Skin="Sunset" Value="0" Width="125px">
                                                                                        <NumberFormat DecimalDigits="2" />
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label167" runat="server" Text="Age Band"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <asp:Label ID="lblE_b" runat="server" ForeColor="Red"></asp:Label>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td bgcolor="#666666" class="style8" colspan="4">
                                                                                    &nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label162" runat="server" Text="IP Limit"></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadNumericTextBox ID="txtiplimit" Runat="server" Culture="en-US" 
                                                                                        Skin="Sunset" Value="0" Width="200px">
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label151" runat="server" Text="IP Premiums"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadNumericTextBox ID="txtipprem" Runat="server" Culture="en-US" 
                                                                                        Skin="Sunset" Value="0" Width="200px">
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label163" runat="server" Text="OP Limit"></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadNumericTextBox ID="txtoplimit" Runat="server" Culture="en-US" 
                                                                                        Skin="Sunset" Value="0" Width="200px">
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label164" runat="server" Text="OP Premiums"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadNumericTextBox ID="txtopprem" Runat="server" Culture="en-US" 
                                                                                        Skin="Sunset" Value="0" Width="200px">
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td bgcolor="#666666" class="style8" colspan="4">
                                                                                    <asp:Label ID="Label166" runat="server" Text="S-PLUS"></asp:Label>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    <asp:Label ID="Label3" runat="server" Text="IP Limit"></asp:Label>
                                                                                </td>
                                                                                <td>
                                                                                    <telerik:RadNumericTextBox ID="txtsplusiplim" Runat="server" Culture="en-US" 
                                                                                        Skin="Sunset" Value="0" Width="200px">
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="Label4" runat="server" Text="IP Premiums"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadNumericTextBox ID="txtipsplusra" Runat="server" Culture="en-US" 
                                                                                        Skin="Sunset" Value="0" Width="200px">
                                                                                    </telerik:RadNumericTextBox>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" style="width: 194px">
                                                                                    &nbsp;</td>
                                                                                <td>
                                                                                    &nbsp;</td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <asp:Label ID="lblE_ID" runat="server" ForeColor="Red"></asp:Label>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    &nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td bgcolor="#666666" class="style8" colspan="4">
                                                                                    &nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" colspan="2">
                                                                                    <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    <telerik:RadButton ID="BTNUPLOAD" runat="server" Text="Upload ">
                                                                                    </telerik:RadButton>
                                                                                </td>
                                                                                <td style="width: 287px">
                                                                                    <telerik:RadButton ID="cmdENsave" runat="server" Height="37px" Skin="Simple" 
                                                                                        Text="Save" Width="150px">
                                                                                    </telerik:RadButton>
                                                                                </td>
                                                                                <td class="style8" style="height: 6px;">
                                                                                    &nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="style8" colspan="2">
                                                                                    <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                                                                    <asp:HiddenField ID="HiddenField1" runat="server" />
                                                                                </td>
                                                                                <td class="style8" style="width: 166px">
                                                                                    &nbsp;</td>
                                                                                <td style="width: 287px">
                                                                                    &nbsp;&nbsp;</td>
                                                                                <td class="style8" style="height: 6px;">
                                                                                    &nbsp;</td>
                                                                            </tr>
                                                                        </table>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </telerik:RadPageView>
                                                <telerik:RadPageView ID="V1" runat="server" Width="1131px">
                                                    <asp:Panel ID="Panel10" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td align="center" bgcolor="#999999" colspan="4">
                                                                    <asp:Label ID="Label145" runat="server" Text="Renewal List Verification"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="4">
                                                                    <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1121px">
                                                                        <telerik:RadGrid ID="GDVERIFY" runat="server" AllowPaging="True" 
                                                                            CellSpacing="0" GridLines="None" Height="100%" Skin="Simple" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                                        FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                        FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="RELATION" 
                                                                                        FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                        ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                                        HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                                        SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                                        HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                                        UniqueName="POLICY_VALID_UPTO">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="LOADING_RATE" 
                                                                                        FilterControlAltText="Filter LOADING_RATE column" HeaderText="LOADING_RATE" 
                                                                                        SortExpression="LOADING_RATE" UniqueName="LOADING_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_LIMIT" 
                                                                                        FilterControlAltText="Filter OP_LIMIT column" HeaderText="OP_LIMIT" 
                                                                                        SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_LIMIT" 
                                                                                        FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP_LIMIT" 
                                                                                        SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_IP" 
                                                                                        FilterControlAltText="Filter PRESENT_IP column" HeaderText="PRESENT_IP" 
                                                                                        SortExpression="PRESENT_IP" UniqueName="PRESENT_IP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_OP" 
                                                                                        FilterControlAltText="Filter PRESENT_OP column" HeaderText="PRESENT_OP" 
                                                                                        SortExpression="PRESENT_OP" UniqueName="PRESENT_OP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_RATE" 
                                                                                        FilterControlAltText="Filter IP_RATE column" HeaderText="IP_RATE" 
                                                                                        SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_RATE" 
                                                                                        FilterControlAltText="Filter OP_RATE column" HeaderText="OP_RATE" 
                                                                                        SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <PagerStyle Wrap="False" />
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 184px">
                                                                    <asp:Label ID="Label148" runat="server" Text="No Of Lives"></asp:Label>
                                                                </td>
                                                                <td style="width: 213px">
                                                                    <telerik:RadNumericTextBox ID="txtlives" Runat="server" Skin="Simple">
                                                                    </telerik:RadNumericTextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:CheckBox ID="chkverified" runat="server" Text="Verified" />
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnverify" runat="server" Skin="Simple" Text="update" 
                                                                        Width="150px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 184px">
                                                                    <telerik:RadButton ID="btnverexpo" runat="server" Skin="Simple" 
                                                                        Text="Export List" Width="218px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td style="width: 213px">
                                                                    <asp:Label ID="lblVER" runat="server" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </telerik:RadPageView>
                                                <telerik:RadPageView ID="V1_2" runat="server" Width="1131px">
                                                    <asp:Panel ID="Panel6" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td align="center" bgcolor="#999999" colspan="4">
                                                                    <asp:Label ID="Label5" runat="server" Text="Update NCD"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="4">
                                                                    <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1121px">
                                                                        <telerik:RadGrid ID="GD_NCD" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                            GridLines="None" Height="100%" Skin="Simple" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                                        FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                        FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="RELATION" 
                                                                                        FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                        ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                                        HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                                        SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                                        HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                                        UniqueName="POLICY_VALID_UPTO">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="LOADING_RATE" 
                                                                                        FilterControlAltText="Filter LOADING_RATE column" HeaderText="LOADING_RATE" 
                                                                                        SortExpression="LOADING_RATE" UniqueName="LOADING_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_LIMIT" 
                                                                                        FilterControlAltText="Filter OP_LIMIT column" HeaderText="OP_LIMIT" 
                                                                                        SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_LIMIT" 
                                                                                        FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP_LIMIT" 
                                                                                        SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_IP" 
                                                                                        FilterControlAltText="Filter PRESENT_IP column" HeaderText="PRESENT_IP" 
                                                                                        SortExpression="PRESENT_IP" UniqueName="PRESENT_IP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_OP" 
                                                                                        FilterControlAltText="Filter PRESENT_OP column" HeaderText="PRESENT_OP" 
                                                                                        SortExpression="PRESENT_OP" UniqueName="PRESENT_OP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_RATE" 
                                                                                        FilterControlAltText="Filter IP_RATE column" HeaderText="IP_RATE" 
                                                                                        SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_RATE" 
                                                                                        FilterControlAltText="Filter OP_RATE column" HeaderText="OP_RATE" 
                                                                                        SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <PagerStyle Wrap="False" />
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    <telerik:RadButton ID="cmdncd" runat="server" Skin="Simple" Text="update" 
                                                                        Width="243px">
                                                                    </telerik:RadButton>
                                                                    <asp:Label ID="lblncd" runat="server" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnncdexp" runat="server" Skin="Simple" 
                                                                        Text="Export List" Width="218px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </telerik:RadPageView>
                                                <telerik:RadPageView ID="V1_1" runat="server" Width="1131px">
                                                    <asp:Panel ID="Panel4" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td align="center" bgcolor="#999999" colspan="4">
                                                                    <asp:Label ID="Label2" runat="server" Text="Run Totals"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="4">
                                                                    <asp:Panel ID="Panel5" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1121px">
                                                                        <telerik:RadGrid ID="GDTOTALS" runat="server" AllowPaging="True" 
                                                                            CellSpacing="0" GridLines="None" Height="100%" Skin="Simple" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                                        FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                        FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="RELATION" 
                                                                                        FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                        ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                                        HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                                        SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                                        HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                                        UniqueName="POLICY_VALID_UPTO">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="LOADING_RATE" 
                                                                                        FilterControlAltText="Filter LOADING_RATE column" HeaderText="LOADING_RATE" 
                                                                                        SortExpression="LOADING_RATE" UniqueName="LOADING_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_LIMIT" 
                                                                                        FilterControlAltText="Filter OP_LIMIT column" HeaderText="OP_LIMIT" 
                                                                                        SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_LIMIT" 
                                                                                        FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP_LIMIT" 
                                                                                        SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_IP" 
                                                                                        FilterControlAltText="Filter PRESENT_IP column" HeaderText="PRESENT_IP" 
                                                                                        SortExpression="PRESENT_IP" UniqueName="PRESENT_IP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_OP" 
                                                                                        FilterControlAltText="Filter PRESENT_OP column" HeaderText="PRESENT_OP" 
                                                                                        SortExpression="PRESENT_OP" UniqueName="PRESENT_OP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_RATE" 
                                                                                        FilterControlAltText="Filter IP_RATE column" HeaderText="IP_RATE" 
                                                                                        SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_RATE" 
                                                                                        FilterControlAltText="Filter OP_RATE column" HeaderText="OP_RATE" 
                                                                                        SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <PagerStyle Wrap="False" />
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    <telerik:RadButton ID="btntotals" runat="server" Skin="Simple" Text="Compute" 
                                                                        Width="243px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    <asp:Label ID="lbltotal" runat="server" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </telerik:RadPageView>
                                                <telerik:RadPageView ID="V2" runat="server" Width="1131px">
                                                    <asp:Panel ID="Panel11" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td align="center" bgcolor="#999999" colspan="4">
                                                                    <asp:Label ID="Label146" runat="server" Text="List Validation"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="4">
                                                                    <asp:Panel ID="Panel13" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1121px">
                                                                        <telerik:RadGrid ID="GDVALIDATE" runat="server" AllowPaging="True" 
                                                                            CellSpacing="0" GridLines="None" Height="100%" Skin="Simple" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                                        FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                        FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="RELATION" 
                                                                                        FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                        ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                                        HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                                        SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                                        HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                                        UniqueName="POLICY_VALID_UPTO">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="LOADING_RATE" 
                                                                                        FilterControlAltText="Filter LOADING_RATE column" HeaderText="LOADING_RATE" 
                                                                                        SortExpression="LOADING_RATE" UniqueName="LOADING_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_LIMIT" 
                                                                                        FilterControlAltText="Filter OP_LIMIT column" HeaderText="OP_LIMIT" 
                                                                                        SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_LIMIT" 
                                                                                        FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP_LIMIT" 
                                                                                        SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_IP" 
                                                                                        FilterControlAltText="Filter PRESENT_IP column" HeaderText="PRESENT_IP" 
                                                                                        SortExpression="PRESENT_IP" UniqueName="PRESENT_IP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_OP" 
                                                                                        FilterControlAltText="Filter PRESENT_OP column" HeaderText="PRESENT_OP" 
                                                                                        SortExpression="PRESENT_OP" UniqueName="PRESENT_OP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_RATE" 
                                                                                        FilterControlAltText="Filter IP_RATE column" HeaderText="IP_RATE" 
                                                                                        SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_RATE" 
                                                                                        FilterControlAltText="Filter OP_RATE column" HeaderText="OP_RATE" 
                                                                                        SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <PagerStyle Wrap="False" />
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Label ID="Label150" runat="server" Text="No Of Lives"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadNumericTextBox ID="txtvallive" Runat="server" Skin="Simple">
                                                                    </telerik:RadNumericTextBox>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    <asp:CheckBox ID="chkvalidate" runat="server" Text="Validate &amp; Forward" />
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnvalidate" runat="server" Skin="Simple" Text="update" 
                                                                        Width="150px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <telerik:RadButton ID="btnvalexpo" runat="server" Skin="Simple" 
                                                                        Text="Export List" Width="218px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td>
                                                                    <asp:Label ID="lblval" runat="server" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </telerik:RadPageView>
                                                <telerik:RadPageView ID="V2_1" runat="server" Width="1131px">
                                                    <asp:Panel ID="Panel16" runat="server">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td align="center" bgcolor="#999999" colspan="4">
                                                                    <asp:Label ID="Label6" runat="server" Text="Rate Revised"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="4">
                                                                    <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1121px">
                                                                        <telerik:RadGrid ID="RD_REVISE" runat="server" AllowPaging="True" 
                                                                            CellSpacing="0" GridLines="None" Height="100%" Skin="Simple" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NO" 
                                                                                        FilterControlAltText="Filter MEMBER_NO column" HeaderText="MEMBER_NO" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NO" UniqueName="MEMBER_NO">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                        FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                        ItemStyle-Wrap="False" SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="RELATION" 
                                                                                        FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                        ItemStyle-Wrap="False" SortExpression="RELATION" UniqueName="RELATION">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                                                        HeaderText="POLICY_VALID_FROM" ItemStyle-Wrap="False" 
                                                                                        SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                                        <ItemStyle Wrap="False" />
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                        FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                                                        HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                                                        UniqueName="POLICY_VALID_UPTO">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="LOADING_RATE" 
                                                                                        FilterControlAltText="Filter LOADING_RATE column" HeaderText="LOADING_RATE" 
                                                                                        SortExpression="LOADING_RATE" UniqueName="LOADING_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_LIMIT" 
                                                                                        FilterControlAltText="Filter OP_LIMIT column" HeaderText="OP_LIMIT" 
                                                                                        SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_LIMIT" 
                                                                                        FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP_LIMIT" 
                                                                                        SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_IP" 
                                                                                        FilterControlAltText="Filter PRESENT_IP column" HeaderText="PRESENT_IP" 
                                                                                        SortExpression="PRESENT_IP" UniqueName="PRESENT_IP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="PRESENT_OP" 
                                                                                        FilterControlAltText="Filter PRESENT_OP column" HeaderText="PRESENT_OP" 
                                                                                        SortExpression="PRESENT_OP" UniqueName="PRESENT_OP">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="IP_RATE" 
                                                                                        FilterControlAltText="Filter IP_RATE column" HeaderText="IP_RATE" 
                                                                                        SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="OP_RATE" 
                                                                                        FilterControlAltText="Filter OP_RATE column" HeaderText="OP_RATE" 
                                                                                        SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                                                    </telerik:GridBoundColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <PagerStyle Wrap="False" />
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <telerik:RadButton ID="btntotals_rev" runat="server" Skin="Simple" 
                                                                        Text="Compute" Width="243px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    <asp:CheckBox ID="chkrevise" runat="server" Text="Validate &amp; Forward" />
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="update" 
                                                                        Width="150px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <telerik:RadButton ID="RadButton2" runat="server" Skin="Simple" 
                                                                        Text="Export List" Width="218px">
                                                                    </telerik:RadButton>
                                                                </td>
                                                                <td>
                                                                    <asp:Label ID="REV" runat="server" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </telerik:RadPageView>
                                            </telerik:RadMultiPage>
                                        </td>
                                    </tr>
                                </table>
                            </asp:Panel>
                        </td>
                    </tr>
                </table>

            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>


