﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail

Partial Class Default2
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String


    'Dim MyDBAction As New DataManagement
    'Dim MyDatable As New Data.DataTable

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
            Dim region_code As String = ""
            dtreceivedate.DbSelectedDate = Date.Now
            dtreceivedate.Enabled = False
            'dtcollected.DbSelectedDate = Date.Now
            HiddenField1.Value = ""
            Session("empcode") = Nothing
            Session("agentemail") = Nothing
            cmddelete.Enabled = False
            cmdedit.Enabled = False

            Str = "SELECT Emp_Code,email,EmployeeName FROM	employees  WHERE username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                Session("empcode") = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                Session("agentemail") = MyDatatable.Rows(0).Item("email").ToString()
                    'Session("empcode") = "0150"
            Else
                lblerr.Text = "You are not authorized to view this page"
                Exit Sub
            End If

            MyDatatable = Nothing
            Str = "SELECT DISTINCT UNIT_CODE,UM_NAME,EMAIL FROM COMMISSION.dbo.TBL_MIS_SALES_UM WHERE MIS_EMP_CODE='" & Session("empcode") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                unit_code = MyDatatable.Rows(0).Item("UNIT_CODE").ToString()
                    Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1  ORDER BY AGENT_NAME" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboagent
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                    .DataValueField = MyDatatable.Columns("USER_ID").ToString
                    .DataBind()
                End With


            Else
                Str = "SELECT DISTINCT R_CODE,RM_NAME,EMAIL FROM COMMISSION.dbo.TBL_MIS_SALES_RM WHERE MIS_EMP_CODE='" & Session("empcode") & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    unit_code = MyDatatable.Rows(0).Item("R_CODE").ToString()

                        Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1  ORDER BY AGENT_NAME" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    With cboagent
                        .Items.Clear()
                        .DataSource = MyDatatable
                        .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                        .DataValueField = MyDatatable.Columns("USER_ID").ToString
                        .DataBind()
                        End With
                    Else
                        Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1  ORDER BY AGENT_NAME" '"
                        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                        With cboagent
                            .Items.Clear()
                            .DataSource = MyDatatable
                            .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                            .DataValueField = MyDatatable.Columns("USER_ID").ToString
                            .DataBind()
                        End With
                    End If

            End If

            LoadGrid()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If

    End Sub

    
    Public Sub LoadGrid()
        Str = ""
        Try
            Session("DAD_4") = Nothing

            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Member_No],Assigned_TO,Status  FROM  MISREPORTS.[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE Ack=0 and Entered_by='" & Session("UserName").ToString & "'"

            'SqlAction = "SELECT [File_No],[Proposer_Name],[Assigned_To],Status  FROM [SALES].[dbo].[TBL_MIS_CORPORATE_TRACKING] WHERE  Closed=1 AND Policy_Doc_Gen=1 and Policy_Dispatched=0 and To_Filing=0  ORDER BY Date_assigned Desc"


            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_4") = MyDatable
                MyDatable = Nothing


            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    



    Protected Sub cmdedit_Click(sender As Object, e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        If Session("status_1") = "NEW REGISTERED" Then

            cborenewnew.Enabled = True
            txtproposer.Enabled = True
            cbotype.Enabled = True
            cboagent.Enabled = True
            txtReceiveFrom.Enabled = True
            txtagent.Enabled = True
            cboBenefit.Enabled = True
            txtpopulation.Enabled = True
            txtpremium.Enabled = True
            txtcomment.Enabled = True
            cmdsave.Enabled = True

            dtreceivedate.Enabled = True
            chkaarcredit.Enabled = True


        Else
            lblerr.Text = "Business already allocated!!"
        End If



    End Sub

    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim FILENO As String
        If cbotype.SelectedValue = "" Then
            lblerr.Text = "Enter Type of the Business"
            Exit Sub
        End If

        If cboagent.SelectedValue = "" Then
            lblerr.Text = "select Agent of the Business"
            Exit Sub
        End If

        If txtproposer.Text = "" Then
            lblerr.Text = "select Proposer of the Business"
            Exit Sub
        End If

        If txtpremium.Text = "" Then
            lblerr.Text = "Enter Premium of the Business"
            Exit Sub
        End If
        If txtpopulation.Text = "" Then
            lblerr.Text = "Enter Population of the Business"
            Exit Sub
        End If

        If txtReceiveFrom.Text = "" Then
            lblerr.Text = "Enter Receive from of the Business"
            Exit Sub
        End If

        'Dim FILENO As String = "C-" & RandomString(4)

        Dim receivedate As String
        Try

            If dtreceivedate.DbSelectedDate Is Nothing Then
                'dtreceivedate.DbSelectedDate = "1900-01-01"
            End If

            If chkaarcredit.Checked = True Then
                aar = 1
            Else
                aar = 0
            End If


            If HiddenField1.Value = "" Then
                Dim RandomClass As New Random()
                'Dim RandomNumber = RandomClass.Next(1, 99999)
                'FILENO = "C-" & RandomNumber
                Dim RandomNumber As Long = Now.Day & Now.Month & Now.Hour & Now.Minute & Now.Second
                FILENO = "AAR-" & cbotype.SelectedValue & "-" & RandomNumber


                STS = 0
                ' CDate(dtreceivedate.SelectedDate).ToString("yyyy-MM-dd")
                MyDBAction.MEMBERSHIP_ENROLL_BUSINESS(FILENO, txtretail.Text, 0, CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), cborenewnew.SelectedValue, txtproposer.Text, cbotype.SelectedValue, CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), txtReceiveFrom.Text, cboagent.SelectedValue, cboBenefit.Text, txtpopulation.Text, txtpremium.Text, 0, 0, 0, txtcomment.Text, "", CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), "", CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), "NEW REGISTERED", STS, Session("UserName").ToString, aar, 0, 0)
                'MyDBAction.REGISTER_BUSINESS(FILENO, cborenewnew.SelectedValue, txtproposer.Text, cbotype.SelectedValue, CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), txtReceiveFrom.Text, txtagent.Text, cboBenefit.Text, txtpopulation.Text, txtpremium.Text, txtcomment.Text, STS)


                lblfileno.Text = FILENO
                lblerr.Text = "Updated Successfully!"

                cborenewnew.SelectedValue = ""
                txtproposer.Text = ""
                cbotype.SelectedValue = ""
                cboagent.Text = ""
                txtReceiveFrom.Text = ""
                txtagent.Text = ""
                cboBenefit.SelectedValue = ""
                txtpopulation.Text = 0
                txtpremium.Text = 0
                txtcomment.Text = ""
                dtreceivedate.DbSelectedDate = ""


                cmdsave.Enabled = False
                HiddenField1.Value = ""
            Else
                STS = 1
                MyDBAction.MEMBERSHIP_ENROLL_BUSINESS(lblfileno.Text, txtretail.Text, 0, CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), cborenewnew.SelectedValue, txtproposer.Text, cbotype.SelectedValue, CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), txtReceiveFrom.Text, cboagent.SelectedValue, cboBenefit.Text, txtpopulation.Text, txtpremium.Text, 0, 0, 0, txtcomment.Text, "", CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), "", CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), "NEW REGISTERED", STS, Session("UserName").ToString, aar, 0, 0)


                'MyDBAction.REGISTER_BUSINESS(lblfileno.Text, cborenewnew.SelectedValue, txtproposer.Text, cbotype.SelectedValue, CDate(dtreceivedate.SelectedDate).ToString("yyyy-MM-dd"), txtReceiveFrom.Text, txtagent.Text, cboBenefit.Text, txtpopulation.Text, txtpremium.Text, txtcomment.Text, STS)


                lblerr.Text = "Updated Successfully!"

                cborenewnew.SelectedValue = ""
                txtproposer.Text = ""
                cbotype.SelectedValue = ""
                cboagent.Text = ""
                txtReceiveFrom.Text = ""
                txtagent.Text = ""
                cboBenefit.SelectedValue = ""
                txtpopulation.Text = 0
                txtpremium.Text = 0
                txtcomment.Text = ""
                dtreceivedate.DbSelectedDate = ""

                cmdedit.Enabled = False



            End If
            LoadGrid()
            HiddenField1.Value = ""

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub


    Public Function RandomString(ByVal length As Integer) As String
        Dim sb As New System.Text.StringBuilder
        Dim chars() As String = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", _
               "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "X", _
               "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}
        Dim upperBound As Integer = UBound(chars)

        For x As Integer = 1 To length
            sb.Append(chars(Int(Rnd() * upperBound)))
        Next

        Return sb.ToString

    End Function









    'Protected Sub cboFile_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboFile.SelectedIndexChanged
    '    SqlAction = "SELECT  File_No,Business_Type,Receive_Date,Proposer_Name,Type,Agent,Receive_From,Benefit,Population,Premium,Comment,  FROM [SALES].[dbo].[TBL_MIS_CORPORATE_TRACKING] where File_No ='" & cboFile.SelectedValue & "' AND STATUS=0"

    '    If SqlAction <> "" Then
    '        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
    '        If SqlAction <> "" Then
    '            'Session("Application") = MyDatable
    '            cborenewnew.SelectedValue = MyDatable.Rows(0).Item("Business_Type").ToString()
    '            txtproposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
    '            dtreceivedate.DbSelectedDate = MyDatable.Rows(0).Item("Receive_Date").ToString()
    '            cbotype.SelectedValue = MyDatable.Rows(0).Item("Type").ToString()
    '            cboagent.Text = MyDatable.Rows(0).Item("Agent").ToString()
    '            txtReceiveFrom.Text = MyDatable.Rows(0).Item("Receive_From").ToString()
    '            cboBenefit.SelectedValue = MyDatable.Rows(0).Item("Benefit").ToString()
    '            txtpopulation.Text = MyDatable.Rows(0).Item("Population").ToString()
    '            txtpremium.Text = MyDatable.Rows(0).Item("Premium").ToString()
    '            txtcomment.Text = MyDatable.Rows(0).Item("Comment").ToString()

    '        End If

    '    End If
    'End Sub

    Protected Sub cboagent_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboagent.SelectedIndexChanged
        'txtagent.Text = cboagent.Text
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_4") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Member_No],Assigned_TO,Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE Closed=0 and Proposer_Name Like '%" & Trim(txtsearch.Text) & "%'"

            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Member_No],Assigned_TO,Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE Closed=0 and Member_No Like '%" & Trim(txtsearch.Text) & "%' "

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Member_No],Assigned_TO,Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE Closed=0 and File_No Like '%" & Trim(txtsearch.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "U" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Type],[Member_No],Assigned_TO ,Status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) WHERE Closed=0 and Assigned_To Like '%" & Trim(txtsearch.Text) & "%'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_4") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_NeedDataSource(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH.NeedDataSource

    End Sub

    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_4")
        GDSEARCH.DataBind()

    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim STATUS As String = ""

        lblerr.Text = ""
        lblfileno.Text = ""
        lblfileno.Text = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
        Dim SqlAction As String = ""

        Session("status_1") = Nothing
        SqlAction = "SELECT  is_aarcredit,File_No,Business_Type,Receive_Date,Proposer_Name,Type,Agent,Receive_From,Benefit,Population,Premium,Membership_Comments,status  FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] where File_No ='" & lblfileno.Text & "'"

        If SqlAction <> "" Then
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                'Session("Application") = MyDatable
                cborenewnew.SelectedValue = MyDatable.Rows(0).Item("Business_Type").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                dtreceivedate.DbSelectedDate = MyDatable.Rows(0).Item("Receive_Date").ToString()
                cbotype.SelectedValue = MyDatable.Rows(0).Item("Type").ToString()
                cboagent.SelectedValue = MyDatable.Rows(0).Item("Agent").ToString()
                txtagent.Text = cboagent.Text
                txtReceiveFrom.Text = MyDatable.Rows(0).Item("Receive_From").ToString()
                cboBenefit.SelectedValue = MyDatable.Rows(0).Item("Benefit").ToString()
                txtpopulation.Text = MyDatable.Rows(0).Item("Population").ToString()
                txtpremium.Text = MyDatable.Rows(0).Item("Premium").ToString()
                txtcomment.Text = MyDatable.Rows(0).Item("Membership_Comments").ToString()
                lblfileno.Text = MyDatable.Rows(0).Item("File_No").ToString()
                Session("status_1") = MyDatable.Rows(0).Item("status").ToString()
                chkaarcredit.Checked = MyDatable.Rows(0).Item("is_aarcredit").ToString()
            End If


            '
            cborenewnew.Enabled = False
            txtproposer.Enabled = False
            cbotype.Enabled = False
            cboagent.Enabled = False
            txtReceiveFrom.Enabled = False
            txtagent.Enabled = False
            cboBenefit.Enabled = False
            txtpopulation.Enabled = False
            txtpremium.Enabled = False
            txtcomment.Enabled = False
            cmdsave.Enabled = False

            dtreceivedate.Enabled = False
            cmdedit.Enabled = True
            chkaarcredit.Enabled = False




        End If


    End Sub


    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDSEARCH.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("File_No").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""

            Try

                Dim MyDatable As New Data.DataTable
                MySqlAction = "SELECT  [File_No],[Proposer_Name] FROM [MISREPORTS].[dbo].[TBL_MIS_CORPORATE_TRACKING] WITH (NOLOCK) where File_No ='" & HiddenField1.Value & "'"

                MyDataTable = TryCast(MyDBAction.DBAction(MySqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

                If MyDataTable.Rows.Count > 0 Then
                    File_No = MyDataTable.Rows(0).Item("File_No")
                    Proposer_Name = MyDataTable.Rows(0).Item("Proposer_Name")
                End If
            Catch ex As Exception

            End Try

            'AUDIT TRAIL-------
            Dim audit As New DataManagement
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Delete File", "Successfully Deleted File :- File deleted is: FleNO - " & File_No & ", proposer - " & Proposer_Name & ".", _
            Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            '----END AUDIT TRAIL-----

            DeleteRecord("Delete from MISREPORTS.dbo.TBL_MIS_CORPORATE_TRACKING where File_No= '" & HiddenField1.Value.ToString & "'")

            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            LoadGrid()

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub

    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadButton1.Click

        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String = "Tracked Business As At-& " & dtDateTo.DbSelectedDate & ""

        Session("EXCEL") = "TO EXCEL"
        Str = "SELECT  T.File_No,T.Receive_Date, T.Mem_Receive_date Membership_Rec_date,T.Proposer_Name,T.Business_Type, T.Premium, T.Type,  T.Receive_From,dbo.TBL_MIS_SALES_AGENTS.AGENT_NAME, T.Population, T.Benefit, T.Returned,T.Return_Received, T.Entered_by, T.Returned_To, T.Assigned_To,T.Ack,T.Ack_Date, T.Card_activated,T.Members_updated,Members_update_date, T.Card_requested, T.Card_Req_Date,T.Card_Dis, T.Card_Dis_Date, T.Card_Dis_To, T.Policy_Doc_Gen,T.Policy_Date_Gen,T.Policy_Dispatched,T.Policy_Date_Disp, T.Policy_Disp_To,T.Closed,T.Date_terminated AS Date_Closed, T.Filed,T.Consent_Received,T.Code_Receive_Date, T.Status FROM MISREPORTS.dbo.TBL_MIS_CORPORATE_TRACKING T WITH (NOLOCK) left JOIN COMMISSION.dbo.TBL_MIS_SALES_AGENTS  WITH (NOLOCK) ON T.Agent = dbo.TBL_MIS_SALES_AGENTS.USER_ID   WHERE T.Entered_by ='" & Session("username") & "'  AND T.EntryDate BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY T.Status"

      

        'Mytable = Session("DAD_4") '' TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        Session("Mytable") = (Mytable)
        Session("Reportname") = Reportname
        ResponseHelper.Redirect("Reports.aspx", "_blank", "")
        Mytable = Nothing

        System.Threading.Thread.Sleep(5000)

    End Sub
End Class
