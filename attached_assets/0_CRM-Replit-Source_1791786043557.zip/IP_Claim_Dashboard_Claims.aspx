﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="IP_Claim_Dashboard_Claims.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="IP DISCHARGE" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td style="width: 1639px" align="right">
                                                    &nbsp;</td>
                                                <td style="width: 125px">
                                                    &nbsp;</td>
                                                <td style="width: 91px">
                                                    <asp:CheckBox ID="chkdate" runat="server" Text="By date" />
                                                    &nbsp;</td>
                                                <td style="width: 264px">
                                                    <asp:CheckBox ID="chkname" runat="server" Text="By Name" />
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="right" style="width: 1639px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    <asp:Label ID="Label158" runat="server" Text="Name"></asp:Label>
                                                </td>
                                                <td colspan="2" style="width: 264px">
                                                    <telerik:RadComboBox ID="cboNAME" Runat="server" AllowCustomText="True" 
                                                        AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" Width="250px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboNAME" Text="RM Name" 
                                                                Value="R" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboNAME" Text="Date Range" 
                                                                Value="D" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1639px">
                                                    &nbsp;</td>
                                                <td style="width: 125px">
                                                    <asp:Label ID="Label156" runat="server" Text="Date From"></asp:Label>
                                                </td>
                                                <td style="width: 264px" colspan="2">
                                                    <telerik:RadDatePicker ID="dtfrom" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1639px">
                                                    <asp:Label ID="FILE_NO" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    <asp:Label ID="Label157" runat="server" Text="Date To"></asp:Label>
                                                </td>
                                                <td colspan="2" style="width: 264px">
                                                    <telerik:RadDatePicker ID="dtto" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel32" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTracking_1" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Sunset" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                 
                                                                    <telerik:GridBoundColumn DataField="NOT_DISCHARGED" 
                                                                        FilterControlAltText="Filter NOT_DISCHARGED column" HeaderText="NOT_DISCHARGED" 
                                                                        SortExpression="NOT_DISCHARGED" UniqueName="NOT_DISCHARGED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_ALLOCATED" 
                                                                        FilterControlAltText="Filter NOT_ALLOCATED column" HeaderText="NOT_ALLOCATED" 
                                                                        SortExpression="NOT_ALLOCATED" UniqueName="NOT_ALLOCATED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="ALLOCATED" 
                                                                        FilterControlAltText="Filter ALLOCATED column" HeaderText="ALLOCATED" 
                                                                        SortExpression="ALLOCATED" UniqueName="ALLOCATED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="PROCESSED" 
                                                                        FilterControlAltText="Filter PROCESSED column" HeaderText="PROCESSED" 
                                                                        SortExpression="PROCESSED" UniqueName="PROCESSED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="AUDITED" 
                                                                        FilterControlAltText="Filter AUDITED column" HeaderText="AUDITED" 
                                                                        SortExpression="AUDITED" UniqueName="AUDITED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_PROCESSED" 
                                                                        FilterControlAltText="Filter NOT_PROCESSED column" HeaderText="ALLOCATED" 
                                                                        SortExpression="NOT_PROCESSED" UniqueName="NOT_PROCESSED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="POSTED" 
                                                                        FilterControlAltText="Filter POSTED column" HeaderText="POSTED" 
                                                                        SortExpression="POSTED" UniqueName="POSTED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="[IT-ISSUE]" 
                                                                        FilterControlAltText="Filter [IT-ISSUE] column" HeaderText="IT-ISSUE" 
                                                                        SortExpression="[IT-ISSUE]" UniqueName="[IT-ISSUE]">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="[MSHIP-ISSUE]" 
                                                                        FilterControlAltText="Filter [MSHIP-ISSUE] column" HeaderText="MSHIP-ISSUE" 
                                                                        SortExpression="[MSHIP-ISSUE]" UniqueName="[MSHIP-ISSUE]">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="[RETENTION-ISSUE]" 
                                                                        FilterControlAltText="Filter [RETENTION-ISSUE] column" 
                                                                        HeaderText="RETENTION-ISSUE" SortExpression="[RETENTION-ISSUE]" 
                                                                        UniqueName="[RETENTION-ISSUE]">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="TOTAL_INVOICES" 
                                                                        FilterControlAltText="Filter TOTAL_INVOICES column" 
                                                                        HeaderText="TOTAL_INVOICES" SortExpression="TOTAL_INVOICES" 
                                                                        UniqueName="TOTAL_INVOICES">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel31" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTracking_0" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="30" Skin="Sunset" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                   
                                                                    <telerik:GridBoundColumn DataField="allocate_to" 
                                                                        FilterControlAltText="Filter allocate_to column" HeaderText="ALLOCATED_TO" 
                                                                        SortExpression="allocate_to" UniqueName="allocate_to">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_DISCHARGED" 
                                                                        FilterControlAltText="Filter NOT_DISCHARGED column" HeaderText="NOT_DISCHARGED" 
                                                                        SortExpression="NOT_DISCHARGED" UniqueName="NOT_DISCHARGED">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="NOT_ALLOCATED" 
                                                                        FilterControlAltText="Filter NOT_ALLOCATED column" HeaderText="NOT_ALLOCATED" 
                                                                        SortExpression="NOT_ALLOCATED" UniqueName="NOT_ALLOCATED">
                                                                    </telerik:GridBoundColumn>     
    
 
<telerik:GridBoundColumn DataField="ALLOCATED" 
FilterControlAltText="Filter ALLOCATED column" HeaderText="ALLOCATED" 
SortExpression="ALLOCATED" UniqueName="ALLOCATED">
</telerik:GridBoundColumn>  
  
<telerik:GridBoundColumn DataField="PROCESSED" 
FilterControlAltText="Filter PROCESSED column" HeaderText="PROCESSED" 
SortExpression="PROCESSED" UniqueName="PROCESSED">
</telerik:GridBoundColumn>    

<telerik:GridBoundColumn DataField="AUDITED" 
FilterControlAltText="Filter AUDITED column" HeaderText="AUDITED" 
SortExpression="AUDITED" UniqueName="AUDITED">
</telerik:GridBoundColumn>    

<telerik:GridBoundColumn DataField="NOT_PROCESSED" 
FilterControlAltText="Filter NOT_PROCESSED column" HeaderText="ALLOCATED" 
SortExpression="NOT_PROCESSED" UniqueName="NOT_PROCESSED">
</telerik:GridBoundColumn>    

<telerik:GridBoundColumn DataField="POSTED" 
FilterControlAltText="Filter POSTED column" HeaderText="POSTED" 
SortExpression="POSTED" UniqueName="POSTED">
</telerik:GridBoundColumn>    

<telerik:GridBoundColumn DataField="[IT-ISSUE]" 
FilterControlAltText="Filter [IT-ISSUE] column" HeaderText="IT-ISSUE" 
SortExpression="[IT-ISSUE]" UniqueName="[IT-ISSUE]">
</telerik:GridBoundColumn>    

<telerik:GridBoundColumn DataField="[MSHIP-ISSUE]" 
FilterControlAltText="Filter [MSHIP-ISSUE] column" HeaderText="MSHIP-ISSUE" 
SortExpression="[MSHIP-ISSUE]" UniqueName="[MSHIP-ISSUE]">
</telerik:GridBoundColumn>  

<telerik:GridBoundColumn DataField="[RETENTION-ISSUE]" 
FilterControlAltText="Filter [RETENTION-ISSUE] column" HeaderText="RETENTION-ISSUE" 
SortExpression="[RETENTION-ISSUE]" UniqueName="[RETENTION-ISSUE]">
</telerik:GridBoundColumn>  


<telerik:GridBoundColumn DataField="TOTAL_INVOICES" 
FilterControlAltText="Filter TOTAL_INVOICES column" HeaderText="TOTAL_INVOICES" 
SortExpression="TOTAL_INVOICES" UniqueName="TOTAL_INVOICES">
</telerik:GridBoundColumn>            
                                                
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 193px">
                                                    &nbsp;</td>
                                                <td style="width: 246px">
                                                    <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" 
                                                        Text="Export to Excel">
                                                    </telerik:RadButton>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
       
            </asp:UpdatePanel>
</asp:Content>


