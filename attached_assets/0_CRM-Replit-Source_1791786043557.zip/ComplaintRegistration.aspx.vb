﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                HiddenField1.Value = 0
                dtreceive.DbSelectedDate = Date.Now()
                
             

                Str = "SELECT [Depart_Code],[Department] FROM [AAR_RISK_DB].[dbo].[TBL_MIS_RISK_DEPART]" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbodepart
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("Department").ToString
                    .DataValueField = MyDatatable.Columns("Depart_Code").ToString
                    .DataBind()
                End With
                'Str = "SELECT CODE,SUB_AREA FROM [dbo].[TBL_MIS_CRM_COMPLAINT_AREA]" '"
                'MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                'With cbosubarea
                '    .Items.Clear()
                '    .DataSource = MyDatatable
                '    .DataTextField = MyDatatable.Columns("SUB_AREA").ToString
                '    .DataValueField = MyDatatable.Columns("CODE").ToString
                '    .DataBind()
                'End With

                Session("empcode") = Nothing
                Session("agentemail") = Nothing

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub


    Public Sub Notes(ByVal STR As String)

        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        GD_DOCS.DataSource = Nothing
        GD_DOCS.DataBind()
        
        MyDatable = Nothing
        SqlAction = "SELECT [DOC_ID],[Ref_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_COMPLAIN_DOCS] WHERE  [Ref_No] ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
            MyDatable = Nothing
        Else
            GD_DOCS.DataSource = MyDatable
            GD_DOCS.DataBind()
        End If

        SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINTS_NOTES] WHERE  case_No ='" & STR & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        End If

        SqlAction = " SELECT  t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To,t.Due_Dt  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where t.[Case_no]='" & STR & "'"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCOMPL.DataSource = MyDatable
            GDCOMPL.DataBind()
            MyDatable = Nothing
        Else
            GDCOMPL.DataSource = Nothing
            GDCOMPL.DataBind()
        End If
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            GDMEMBER.DataSource = Nothing
            GDMEMBER.DataBind()
            GDCOMPL.DataSource = Nothing
            GDCOMPL.DataBind()

            SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],FAMILY_NO,PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO,DATA_DATE,POLICY_STATUS FROM DATA_REPOSITORY_DB.dbo.MASTER_MEMBER_LIST  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO like '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("FAMILY_NO") = MyDatable.Rows(0).Item("FAMILY_NO").ToString()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing


            Else

                GDMEMBER.DataSource = Nothing
                GDMEMBER.DataBind()


            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            Session("FAMILY_NO") = Nothing
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            GDCOMPL.DataSource = Nothing
            GDCOMPL.DataBind()
            number = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            SqlAction = "SELECT PROPOSER_ID, [DISPLAY_MEMBERSHIP_NO],FAMILY_NO,PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],GRP_INDV FROM DATA_REPOSITORY_DB.dbo.MASTER_MEMBER_LIST   with(nolock) WHERE DISPLAY_MEMBERSHIP_NO ='" & number & "' order by DISPLAY_MEMBERSHIP_NO"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtmobile.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()
                txtemail.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_EMAIL").ToString()
                'txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()
                'ID.Text = MyDatatable.Rows(0).Item("PROPOSER_ID").ToString()
                'Session("FAMILY_NO") = MyDatable.Rows(0).Item("FAMILY_NO").ToString()
                'Notes(txtmemno.t)

                SqlAction = " SELECT  t.[Case_no] ,t.[Date_Received],t.[Mode_of_Receipt],t.[Membership_No],t.[Customer_Name],t.[Contacts], t.[Complain_Type],s.Issue_Name,t.[Action_Taken],t.Entered_By,e.employeename Escalated_To,t.Due_Dt   FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] t Left join employees e on e.Emp_Code=t.Escalated_To left join  [dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] s on s.Issue_Code=t.Summary_of_issue where [Membership_No]='" & txtmemno.Text & "'"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDCOMPL.DataSource = MyDatable
                    GDCOMPL.DataBind()
                    MyDatable = Nothing
                Else
                    GDCOMPL.DataSource = Nothing
                    GDCOMPL.DataBind()
                End If
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Public Sub Generate_Task()
        SqlAction = "SELECT ISNULL((MAX(Id)+1),1) NUMBER FROM CRM.[dbo].[TBL_MIS_COMPLAINT_TRACKING]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblcode.Text = cbotype.SelectedValue & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
        End If
    End Sub

 

    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "CLIENT COMPLAINT/ENQUIRY ESCALATION" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "CLIENT COMPLAINT/ENQUIRY ESCALATIONest:-" & txtname.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear:, " & lblesc.Text & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Case No:" & lblcode.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Client Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Description--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtdescr.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function



    Protected Sub GDCOMPL_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCOMPL.SelectedIndexChanged
        Try
            Dim number As String = ""
            lblerr.Text = ""
            lblcode.Text = ""
            Session("FAMILY_NO") = Nothing
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()

            number = (DirectCast(GDCOMPL.SelectedItems(0), GridDataItem)).GetDataKeyValue("Case_no").ToString()
            SqlAction = "SELECT  [Case_no] ,[Date_Received],[Mode_of_Receipt],[Membership_No],[Customer_Name],[Contacts],[Email],[Complain_Type],[Summary_of_issue],[Action_Taken]  FROM [CRM].[dbo].[TBL_MIS_COMPLAINT_TRACKING] where [Case_no]='" & number & "'"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                Notes(number)
                'txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                'txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                'txtmobile.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()
                'txtemail.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_EMAIL").ToString()
                ''txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                'cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()
                'lblcode.Text = MyDatatable.Rows(0).Item("Case_no").ToString()

                ''ID.Text = MyDatatable.Rows(0).Item("PROPOSER_ID").ToString()
                'Session("FAMILY_NO") = MyDatable.Rows(0).Item("FAMILY_NO").ToString()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub cbodepart_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbodepart.SelectedIndexChanged
        cbissue.Text = ""

        Str = "SELECT [Issue_Code],[Issue_Name]  FROM  [CRM].[dbo].[TBL_MIS_CRM_COMPLAINT_SUMMARY] WHERE ACTIVE=1 AND [Depart_Code]='" & cbodepart.SelectedValue & "'" '"
        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
        With cbissue
            .Items.Clear()
            .DataSource = MyDatatable
            .DataTextField = MyDatatable.Columns("Issue_Name").ToString
            .DataValueField = MyDatatable.Columns("Issue_Code").ToString
            .DataBind()
        End With
    End Sub

    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Try
            Try
                Dim adm_status As String = ""
                Dim case_status As String = ""
                HiddenField1.Value = 0




                If HiddenField1.Value = 0 Then
                    Generate_Task()
                    If FL1.PostedFile.FileName <> "" Then
                        Dim filePath As String = FL1.PostedFile.FileName
                        Dim filename As String = Path.GetFileName(filePath)
                        Dim ext As String = Path.GetExtension(filename)
                        Dim contenttype As String = String.Empty
                        Dim fs As Stream = FL1.PostedFile.InputStream
                        Dim br As New BinaryReader(fs)
                        Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

                        Dim app As Integer = 0

                        Select Case ext
                            Case ".doc"
                                contenttype = "application/vnd.ms-word"
                                Exit Select
                            Case ".docx"
                                contenttype = "application/vnd.ms-word"
                                Exit Select
                            Case ".xls"
                                contenttype = "application/vnd.ms-excel"
                                Exit Select
                            Case ".xlsx"
                                contenttype = "application/vnd.ms-excel"
                                Exit Select
                            Case ".jpg"
                                contenttype = "image/jpg"
                                Exit Select
                            Case ".png"
                                contenttype = "image/png"
                                Exit Select
                            Case ".gif"
                                contenttype = "image/gif"
                                Exit Select
                            Case ".jpeg"
                                contenttype = "image/jpeg"
                                Exit Select
                            Case ".pdf"
                                contenttype = "application/pdf"
                                Exit Select
                            Case ".rar"
                                contenttype = "application/zip"
                                Exit Select
                            Case ".zip"
                                contenttype = "application/zip"
                                Exit Select
                        End Select

                        If contenttype <> String.Empty Then
                            Dim fileLocation As String = ""
                            MyDBAction.UPLOAD_File_Complain_Docs(bytes, filename, contenttype, lblcode.Text, Trim("Complain"), CDate(Date.Now()).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "COMP_R01")


                            MyDBAction.Complaint_tracking(lblcode.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd hh:mm"), CDate(dtreceive.DbSelectedDate).ToString("hh:mm"), cbomode.SelectedValue, Session("username"), txtmemno.Text, txtname.Text, cboclient.SelectedValue, txtmobile.Text, txtemail.Text, cbotype.SelectedValue, cbissue.SelectedValue, cboaction.SelectedValue, "", txtdescr.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd hh:mm"), Session("username"), cbodepart.selectedvalue)
                            lblerr.ForeColor = System.Drawing.Color.Green
                            lblerr.Text = "File Uploaded and Saved Successfully"

                        Else
                            lblerr.Text = "File format not recognised." _
                        & " Upload Image/Word/PDF/Excel formats"
                        End If
                        'load_Grid(lblfile.Text)

                    Else

                        MyDBAction.Complaint_tracking(lblcode.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd hh:mm"), CDate(dtreceive.DbSelectedDate).ToString("hh:mm"), cbomode.SelectedValue, Session("username"), txtmemno.Text, txtname.Text, cboclient.SelectedValue, txtmobile.Text, txtemail.Text, cbotype.SelectedValue, cbissue.SelectedValue, cboaction.SelectedValue, "", txtdescr.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd hh:mm"), Session("username"), cbodepart.selectedvalue)
                        lblerr.Text = "File Uploaded Successfully"
                    End If

                End If
                If txtcomment.Text <> "" Then
                    MyDBAction.TASK_MESSAGES_COMPLAIN(lblcode.Text, txtcomment.Text, Session("username"), Date.Now(), "COMPLAINTS/QUERY", Session("FAMILY_NO"))
                End If

                If cboaction.SelectedValue = "Escalated" Then
                    Session("cc_email") = Nothing
                    Session("email") = Nothing
                    Str = "SELECT NAME,EMAIL FROM [COM_ACTIVITIES_DB].[dbo].[TBL_MIS_CRM_EMAIL_NOTIFICATION] WHERE Case_No='" & lblcode.Text & "'" '"
                    MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                    If MyDatatable.Rows.Count > 0 Then
                        Session("EMAIL") = MyDatatable.Rows(0).Item("EMAIL").ToString()
                        lblesc.Text = MyDatatable.Rows(0).Item("NAME").ToString()
                    End If
                    Session("msg") = "Kindly note the below concern that has been escalated to you for action."
                    'Session("email") = Trim(txtescaemail.Text)

                    'Session("cc_email") = "jmwaniki@aar.co.ke"
                    Session("Header") = "CLIENT COMPLAINT/ENQUIRY ESCALATION"
                    MailSent = SendLoginDetails(lblesc.Text, Session("email"), "")
                End If

                Notes(lblcode.Text)
                lblerr.Text = "Saved Successfully.."

                HiddenField1.Value = 0
                lblcode.Text = ""
                txtdescr.Text = ""
                dtreceive.DbSelectedDate = Date.Now()

                txtname.Text = ""
                txtmemno.Text = ""
                txtmemno.Text = ""
                txtname.Text = ""
                txtmobile.Text = ""
                txtemail.Text = ""
                txtcomment.Text = ""

                lblcode.Enabled = True
                txtdescr.Enabled = True
                dtreceive.Enabled = True

                txtname.Enabled = True
                txtmemno.Enabled = True




            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
End Class
