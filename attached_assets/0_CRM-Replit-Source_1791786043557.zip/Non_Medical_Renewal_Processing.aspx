﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Non_Medical_Renewal_Processing.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1221px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1212px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC" colspan="4">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="NON-MEDICAL LOADING" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" colspan="4">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 1025px">
                                                    &nbsp;</td>
                                                <td style="width: 261px">
                                                    <telerik:RadDatePicker ID="dtfrom" Runat="server" Culture="en-US" 
                                                        SelectedDate="2022-11-10">
                                                        <Calendar UseColumnHeadersAsSelectors="False" UseRowHeadersAsSelectors="False" 
                                                            ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                            SelectedDate="2022-11-10">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadDatePicker ID="dtto" Runat="server" Culture="en-US" 
                                                        SelectedDate="2022-11-10">
                                                        <Calendar UseColumnHeadersAsSelectors="False" UseRowHeadersAsSelectors="False" 
                                                            ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                            SelectedDate="2022-11-10">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 261px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Insured" Value="I" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Policy No" Value="P" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" Width="200px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" Width="1200px">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Policy_Number">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Policy_Number" FilterControlAltText="Filter Policy_Number column" HeaderText="Policy_Number" SortExpression="Policy_Number" UniqueName="Policy_Number">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Insured" FilterControlAltText="Filter Insured column" HeaderText="Insured" SortExpression="Insured" UniqueName="Insured">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Renewal_start_date" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Renewal_start_date column" HeaderText="Start_date" SortExpression="Renewal_start_date" UniqueName="Renewal_start_date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Renewal_end_date" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Renewal_end_date column" HeaderText="End_date" SortExpression="Renewal_end_date" UniqueName="Renewal_end_date">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Basic_Premium" FilterControlAltText="Filter Basic_Premium column" HeaderText="Basic_Premium" SortExpression="Basic_Premium" UniqueName="Basic_Premium">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Policy_Fund" FilterControlAltText="Filter Policy_Fund column" HeaderText="Policy_Fund" SortExpression="Policy_Fund" UniqueName="Policy_Fund">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Training_Levy" FilterControlAltText="Filter Training_Levy column" HeaderText="Training_Levy" SortExpression="Training_Levy" UniqueName="Training_Levy">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Claim_Amount" FilterControlAltText="Filter Claim_Amount column" HeaderText="Claim_Amount" SortExpression="Claim_Amount" UniqueName="Claim_Amount">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_Premium" FilterControlAltText="Filter Total_Premium column" HeaderText="Total_Premium" SortExpression="Total_Premium" UniqueName="Total_Premium">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Label ID="Label191" runat="server" Text="Period From"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadDatePicker ID="dtPeriodFrom" Runat="server" Culture="en-US" SelectedDate="2022-11-10">
                                            <Calendar UseColumnHeadersAsSelectors="False" UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" SelectedDate="2022-11-10">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        <asp:Label ID="Label193" runat="server" Text="Policy No"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtpolicy" Runat="server" Skin="Outlook" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Label ID="Label192" runat="server" Text="Period To"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadDatePicker ID="dtPeriodTo" Runat="server" Culture="en-US" SelectedDate="2022-11-10">
                                            <Calendar UseColumnHeadersAsSelectors="False" UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" SelectedDate="2022-11-10">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>&nbsp;</td>
                                    <td>
                                        <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                            </table>
                                          <table style="width: 100%">
                                              <tr>
                                                  <td>
                                                      <telerik:RadTabStrip ID="RadTabStrip1" runat="server" MultiPageID="RadMultiPage1" SelectedIndex="0" Skin="Web20" Width="100%">
                                                          <Tabs>
                                                              <telerik:RadTab runat="server" Text="Loading" PageViewID="V2" PerTabScrolling="True" Selected="True">
                                                              </telerik:RadTab>
                                                              <telerik:RadTab runat="server" SelectedIndex="0" Text="On-Hold" PageViewID="V1">
                                                              </telerik:RadTab>
                                                              <telerik:RadTab runat="server" PageViewID="V3" Text="SignOff">
                                                              </telerik:RadTab>
                                                          </Tabs>
                                                      </telerik:RadTabStrip>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td>
                                                      <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="1100px">
                                                          <telerik:RadPageView ID="V1" runat="server" Selected="True">
                                                              <asp:Panel ID="P1" runat="server" Width="1200px">
                                                                  <table style="width: 100%">
                                                                      <tr>
                                                                          <td colspan="4">
                                                                              <asp:Label ID="Label186" runat="server" Font-Bold="True" Font-Size="Medium" style="font-weight: 700" Text="Policies On Hold"></asp:Label>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td colspan="4">
                                                                              <asp:Panel ID="Panel32" runat="server" Height="100%" ScrollBars="Both" Width="1200px">
                                                                                  <telerik:RadGrid ID="GD_HOLD" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                      <MasterTableView AutoGenerateColumns="False" DataKeyNames="Policy_Number">
                                                                                          <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                          <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                              <HeaderStyle Width="20px" />
                                                                                          </RowIndicatorColumn>
                                                                                          <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                              <HeaderStyle Width="20px" />
                                                                                          </ExpandCollapseColumn>
                                                                                          <Columns>
                                                                                                  <telerik:GridButtonColumn CommandName="Select" FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" UniqueName="Select">
        <HeaderStyle ForeColor="Blue" Width="50px" />
        <ItemStyle Width="50px" />
    </telerik:GridButtonColumn>
                                                                                              <telerik:GridBoundColumn DataField="Policy_Number" FilterControlAltText="Filter Policy_Number column" HeaderText="Policy_Number" SortExpression="Policy_Number" UniqueName="Policy_Number">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Insured" FilterControlAltText="Filter Insured column" HeaderText="Insured" SortExpression="Insured" UniqueName="Insured">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Renewal_start_date" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Renewal_start_date column" HeaderText="Start_date" SortExpression="Renewal_start_date" UniqueName="Renewal_start_date">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Renewal_end_date" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Renewal_end_date column" HeaderText="End_date" SortExpression="Renewal_end_date" UniqueName="Renewal_end_date">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Basic_Premium" FilterControlAltText="Filter Basic_Premium column" HeaderText="Basic_Premium" SortExpression="Basic_Premium" UniqueName="Basic_Premium">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Policy_Fund" FilterControlAltText="Filter Policy_Fund column" HeaderText="Policy_Fund" SortExpression="Policy_Fund" UniqueName="Policy_Fund">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Training_Levy" FilterControlAltText="Filter Training_Levy column" HeaderText="Training_Levy" SortExpression="Training_Levy" UniqueName="Training_Levy">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Claim_Amount" FilterControlAltText="Filter Claim_Amount column" HeaderText="Claim_Amount" SortExpression="Claim_Amount" UniqueName="Claim_Amount">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Total_Premium" FilterControlAltText="Filter Total_Premium column" HeaderText="Total_Premium" SortExpression="Total_Premium" UniqueName="Total_Premium">
                                                                                              </telerik:GridBoundColumn>
                                                                                          </Columns>
                                                                                          <EditFormSettings>
                                                                                              <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                              </EditColumn>
                                                                                          </EditFormSettings>
                                                                                      </MasterTableView>
                                                                                      <ItemStyle Wrap="False" />
                                                                                      <FilterMenu EnableImageSprites="False">
                                                                                      </FilterMenu>
                                                                                      <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                      </HeaderContextMenu>
                                                                                  </telerik:RadGrid>
                                                                              </asp:Panel>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 69px">&nbsp;</td>
                                                                          <td style="width: 147px">
                                                                              <asp:CheckBox ID="chkhold" runat="server" Text="Hold" />
                                                                          </td>
                                                                          <td class="style18" style="width: 105px">&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 69px">&nbsp;</td>
                                                                          <td rowspan="2" style="width: 147px">
                                                                              <telerik:RadTextBox ID="txtHold_notes" Runat="server" Font-Size="Large" Height="50px" Rows="3" Skin="Sunset" style="font-size: medium" TextMode="MultiLine" Width="400px">
                                                                              </telerik:RadTextBox>
                                                                          </td>
                                                                          <td class="style18" style="width: 105px">&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 69px">&nbsp;</td>
                                                                          <td class="style18" style="width: 105px">&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 69px">&nbsp;</td>
                                                                          <td style="width: 147px">
                                                                              <telerik:RadButton ID="RadButton5" runat="server" Skin="Simple" Text="Save" Width="100px">
                                                                              </telerik:RadButton>
                                                                              <asp:Label ID="lblerr_1" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                          </td>
                                                                          <td class="style18" style="width: 105px">&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                  </table>
                                                              </asp:Panel>
                                                          </telerik:RadPageView>
                                                          <telerik:RadPageView ID="V2" runat="server" Width="1144px" Selected="True">
                                                              <asp:Panel ID="Panel2" runat="server">
                                                                  <table style="width: 100%">
                                                                      <tr>
                                                                          <td bgcolor="#999999" colspan="4">
                                                                              <asp:Label ID="Label147" runat="server" style="font-weight: 700" Text="Member Info"></asp:Label>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px; height: 23px;">
                                                                              <asp:Label ID="Label188" runat="server" Text="Loading Type"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px; height: 23px;">
                                                                              <telerik:RadComboBox ID="cboType" Runat="server" AccessibilityMode="True" AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                                                  <Items>
                                                                                      <telerik:RadComboBoxItem runat="server" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Policy" Value="P" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Class" Value="C" />
                                                                                  </Items>
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                          <td style="width: 116px; height: 23px;">
                                                                              <asp:Label ID="Label189" runat="server" Text="GI Class"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 23px">
                                                                              <telerik:RadComboBox ID="cboclass" Runat="server" AccessibilityMode="True" AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">
                                                                              <asp:Label ID="Label174" runat="server" Text="Loading By"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px">
                                                                              <telerik:RadComboBox ID="cboload" Runat="server" AccessibilityMode="True" AllowCustomText="True" MarkFirstMatch="True" Skin="Outlook" Width="250px">
                                                                                  <Items>
                                                                                      <telerik:RadComboBoxItem runat="server" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Basic Premium" Value="P" />
                                                                                      <telerik:RadComboBoxItem runat="server" Text="Sum Insured" Value="S" />
                                                                                  </Items>
                                                                              </telerik:RadComboBox>
                                                                          </td>
                                                                          <td style="width: 116px">&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 112px; height: 23px;">
                                                                              <asp:Label ID="Label178" runat="server" Text="Period From"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px; height: 23px;">
                                                                              <telerik:RadDatePicker ID="dtStart" Runat="server" Culture="en-US" SelectedDate="2022-11-10">
                                                                                  <Calendar UseColumnHeadersAsSelectors="False" UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                  </Calendar>
                                                                                  <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" SelectedDate="2022-11-10">
                                                                                  </DateInput>
                                                                                  <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                              </telerik:RadDatePicker>
                                                                          </td>
                                                                          <td style="height: 23px">
                                                                              <asp:Label ID="Label179" runat="server" Text="Period To"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 23px">
                                                                              <telerik:RadDatePicker ID="dtend" Runat="server" Culture="en-US" SelectedDate="2022-11-10">
                                                                                  <Calendar UseColumnHeadersAsSelectors="False" UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                  </Calendar>
                                                                                  <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" SelectedDate="2022-11-10">
                                                                                  </DateInput>
                                                                                  <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                              </telerik:RadDatePicker>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 112px; height: 26px;">
                                                                              <asp:Label ID="Label175" runat="server" Text="Sum Insured"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px; height: 26px;">
                                                                              <telerik:RadNumericTextBox ID="txtsumIns" Runat="server" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td style="height: 26px">
                                                                              <asp:Label ID="Label185" runat="server" Text="Claim Amount"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 26px">
                                                                              <telerik:RadNumericTextBox ID="txtClaim" Runat="server" AutoPostBack="True" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 112px; height: 26px;">
                                                                              <asp:Label ID="Label183" runat="server" Text="Basic Premium"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px; height: 26px;">
                                                                              <telerik:RadNumericTextBox ID="txtBasicPrem" Runat="server" AutoPostBack="True" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td style="height: 26px">
                                                                              <asp:Label ID="Label184" runat="server" Text="Basic Premium(L)"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 26px">
                                                                              <telerik:RadNumericTextBox ID="txtBasicPrem_L" Runat="server" AutoPostBack="True" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 112px; height: 26px;">
                                                                              <asp:Label ID="Label176" runat="server" Text="Policy Fund"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px; height: 26px;">
                                                                              <telerik:RadNumericTextBox ID="txtfund" Runat="server" AutoPostBack="True" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td style="height: 26px">
                                                                              <asp:Label ID="Label180" runat="server" Text="Policy Fund(L)"></asp:Label>
                                                                          </td>
                                                                          <td style="height: 26px">
                                                                              <telerik:RadNumericTextBox ID="txtfund_L" Runat="server" AutoPostBack="True" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">
                                                                              <asp:Label ID="Label177" runat="server" Text="Training Levy"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px">
                                                                              <telerik:RadNumericTextBox ID="txtlevy" Runat="server" AutoPostBack="True" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td>
                                                                              <asp:Label ID="Label181" runat="server" Text="Training Levy(L)"></asp:Label>
                                                                          </td>
                                                                          <td>
                                                                              <telerik:RadNumericTextBox ID="txtlevy_L" Runat="server" AutoPostBack="True" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">
                                                                              <asp:Label ID="Label170" runat="server" Text="Total Premium"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px">
                                                                              <telerik:RadNumericTextBox ID="txttot" Runat="server" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td>
                                                                              <asp:Label ID="Label182" runat="server" Text="Total Premium(L)"></asp:Label>
                                                                          </td>
                                                                          <td>
                                                                              <telerik:RadNumericTextBox ID="txttot_L" Runat="server" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">
                                                                              <asp:Label ID="Label165" runat="server" Text="Renewal Premium"></asp:Label>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px">
                                                                              <telerik:RadNumericTextBox ID="txtprem" Runat="server" Culture="en-US" Skin="Simple" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td>&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" colspan="4" style="height: 11px;">&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td style="width: 112px; height: 26px;">
                                                                              <asp:Label ID="Label166" runat="server" Text="Loading Rate"></asp:Label>
                                                                          </td>
                                                                          <td style="width: 255px; height: 26px;">
                                                                              <telerik:RadNumericTextBox ID="txtrate" Runat="server" Culture="en-US" DataType="System.Int16" Skin="Simple" Type="Percent" Value="0" Width="125px">
                                                                              </telerik:RadNumericTextBox>
                                                                          </td>
                                                                          <td style="height: 26px">&nbsp;</td>
                                                                          <td style="height: 26px">&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">
                                                                              <asp:Label ID="Label156" runat="server" Text="Notes"></asp:Label>
                                                                          </td>
                                                                          <td colspan="2" rowspan="2">
                                                                              <telerik:RadTextBox ID="txtnotes" Runat="server" Font-Size="Large" Height="50px" Rows="3" Skin="Sunset" style="font-size: medium" TextMode="MultiLine" Width="400px">
                                                                              </telerik:RadTextBox>
                                                                          </td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">&nbsp;</td>
                                                                          <td>
                                                                              <asp:HiddenField ID="HiddenField1" runat="server" />
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">&nbsp;</td>
                                                                          <td style="width: 255px">
                                                                              <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Update ">
                                                                              </telerik:RadButton>
                                                                              <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                          </td>
                                                                          <td>&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" colspan="4">
                                                                              <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" Width="1200px">
                                                                                  <telerik:RadGrid ID="GD_Loading" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                      <MasterTableView AutoGenerateColumns="False" DataKeyNames="Policy_Number">
                                                                                          <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                          <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                              <HeaderStyle Width="20px" />
                                                                                          </RowIndicatorColumn>
                                                                                          <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                              <HeaderStyle Width="20px" />
                                                                                          </ExpandCollapseColumn>
                                                                                          <Columns>
                                                                                              <telerik:GridButtonColumn CommandName="Select" FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" UniqueName="Select">
                                                                                                  <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                                  <ItemStyle Width="50px" />
                                                                                              </telerik:GridButtonColumn>
                                                                                              <telerik:GridBoundColumn DataField="Policy_Number" FilterControlAltText="Filter Policy_Number column" HeaderText="Policy_Number" SortExpression="Policy_Number" UniqueName="Policy_Number">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Insured" FilterControlAltText="Filter Insured column" HeaderText="Insured" SortExpression="Insured" UniqueName="Insured">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Period_From" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Period_From column" HeaderText="Start_date" SortExpression="Period_From" UniqueName="Period_From">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Period_To" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Period_To column" HeaderText="End_date" SortExpression="Period_To" UniqueName="Period_To">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Sum_Insured" FilterControlAltText="Filter Sum_Insured column" HeaderText="Sum_Insured" SortExpression="Sum_Insured" UniqueName="Sum_Insured">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Basic_Premium" FilterControlAltText="Filter Basic_Premium column" HeaderText="Basic_Premium" SortExpression="Basic_Premium" UniqueName="Basic_Premium">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Policy_Fund" FilterControlAltText="Filter Policy_Fund column" HeaderText="Policy_Fund" SortExpression="Policy_Fund" UniqueName="Policy_Fund">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Training_Levy" FilterControlAltText="Filter Training_Levy column" HeaderText="Training_Levy" SortExpression="Training_Levy" UniqueName="Training_Levy">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Loading_AMT" FilterControlAltText="Filter Loading_AMT column" HeaderText="Loading_AMT" SortExpression="Loading_AMT" UniqueName="Loading_AMT">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Total_Premium" FilterControlAltText="Filter Total_Premium column" HeaderText="Total_Premium" SortExpression="Total_Premium" UniqueName="Total_Premium">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Loading_Rate" FilterControlAltText="Filter Loading_Rate column" HeaderText="Loading_Rate" SortExpression="Loading_Rate" UniqueName="Loading_Rate">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridBoundColumn DataField="Loading_Item" FilterControlAltText="Filter Loading_Item column" HeaderText="Loading_Item" SortExpression="Loading_Item" UniqueName="Loading_Item">
                                                                                              </telerik:GridBoundColumn>
                                                                                              <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                                                  <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                                                  <ItemStyle CssClass="ButtonColumn" />
                                                                                              </telerik:GridButtonColumn>
                                                                                          </Columns>
                                                                                          <EditFormSettings>
                                                                                              <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                              </EditColumn>
                                                                                          </EditFormSettings>
                                                                                      </MasterTableView>
                                                                                      <ItemStyle Wrap="False" />
                                                                                      <FilterMenu EnableImageSprites="False">
                                                                                      </FilterMenu>
                                                                                      <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                      </HeaderContextMenu>
                                                                                  </telerik:RadGrid>
                                                                              </asp:Panel>
                                                                          </td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px; height: 31px;">
                                                                              <telerik:RadButton ID="RadButton4" runat="server" Skin="Simple" Text="Post" Width="100px">
                                                                              </telerik:RadButton>
                                                                          </td>
                                                                          <td class="style17" style="width: 255px; height: 31px;"></td>
                                                                          <td style="height: 31px"></td>
                                                                          <td style="height: 31px"></td>
                                                                      </tr>
                                                                      <tr>
                                                                          <td class="style18" style="width: 112px">&nbsp;</td>
                                                                          <td class="style17" style="width: 255px">&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                          <td>&nbsp;</td>
                                                                      </tr>
                                                                  </table>
                                                              </asp:Panel>
                                                          </telerik:RadPageView>
                                                          <telerik:RadPageView ID="V3" runat="server" Width="1144px">
    <asp:Panel ID="Panel3" runat="server">
        <table style="width: 100%">
            <tr>
                <td colspan="4">
                    <asp:Label ID="Label187" runat="server" Font-Bold="True" Font-Size="Medium" Text="Policy SignOff"></asp:Label>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" Width="1200px">
                        <telerik:RadGrid ID="GD_Signoff" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                            <MasterTableView AutoGenerateColumns="False">
                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                    <HeaderStyle Width="20px" />
                                </RowIndicatorColumn>
                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                    <HeaderStyle Width="20px" />
                                </ExpandCollapseColumn>
                                <Columns>
                                    <telerik:GridBoundColumn DataField="Policy_Number" FilterControlAltText="Filter Policy_Number column" HeaderText="Policy_Number" SortExpression="Policy_Number" UniqueName="Policy_Number">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Insured" FilterControlAltText="Filter Insured column" HeaderText="Insured" SortExpression="Insured" UniqueName="Insured">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Renewal_start_date" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Renewal_start_date column" HeaderText="Start_date" SortExpression="Renewal_start_date" UniqueName="Renewal_start_date">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Renewal_end_date" DataFormatString="{0:dd-MM-yyyy}" FilterControlAltText="Filter Renewal_end_date column" HeaderText="End_date" SortExpression="Renewal_end_date" UniqueName="Renewal_end_date">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Basic_Premium" FilterControlAltText="Filter Basic_Premium column" HeaderText="Basic_Premium" SortExpression="Basic_Premium" UniqueName="Basic_Premium">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Policy_Fund" FilterControlAltText="Filter Policy_Fund column" HeaderText="Policy_Fund" SortExpression="Policy_Fund" UniqueName="Policy_Fund">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Training_Levy" FilterControlAltText="Filter Training_Levy column" HeaderText="Training_Levy" SortExpression="Training_Levy" UniqueName="Training_Levy">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Claim_Amount" FilterControlAltText="Filter Claim_Amount column" HeaderText="Claim_Amount" SortExpression="Claim_Amount" UniqueName="Claim_Amount">
                                    </telerik:GridBoundColumn>
                                    <telerik:GridBoundColumn DataField="Total_Premium" FilterControlAltText="Filter Total_Premium column" HeaderText="Total_Premium" SortExpression="Total_Premium" UniqueName="Total_Premium">
                                    </telerik:GridBoundColumn>
                                </Columns>
                                <EditFormSettings>
                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                    </EditColumn>
                                </EditFormSettings>
                            </MasterTableView>
                            <ItemStyle Wrap="False" />
                            <FilterMenu EnableImageSprites="False">
                            </FilterMenu>
                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                            </HeaderContextMenu>
                        </telerik:RadGrid>
                    </asp:Panel>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>
                    <telerik:RadButton ID="RadButton3" runat="server" Skin="Simple" Text="Export To Excel">
                    </telerik:RadButton>
                </td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <asp:CheckBox ID="chksign" runat="server" Text="Sign Off" />
                </td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <telerik:RadButton ID="btnsign" runat="server" Skin="Simple" Text="Sign Off" Width="100px">
                    </telerik:RadButton>
                    <asp:Label ID="lblerr_2" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                </td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            </tr>
        </table>
    </asp:Panel>
</telerik:RadPageView>
                                                      </telerik:RadMultiPage>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Policy_Number" 
                                                            FilterControlAltText="Filter Policy_Number column" HeaderText="Policy_Number" 
                                                            ItemStyle-Width="50" SortExpression="Policy_Number" UniqueName="Policy_Number">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
           
            </asp:UpdatePanel>
</asp:Content>


