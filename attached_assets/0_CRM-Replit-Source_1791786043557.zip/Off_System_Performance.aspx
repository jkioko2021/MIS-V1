﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Off_System_Performance.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="OFF-SYSTEM PERFORMANCE"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1121px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 737px">
                                                    &nbsp;</td>
                                                <td style="width: 92px">
                                                    <asp:Label ID="Label156" runat="server" Text="Date From"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadDatePicker ID="dtfrom" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                            </tr>
                                        </table>
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 736px">
                                                    &nbsp;</td>
                                                <td style="width: 93px">
                                                    <asp:Label ID="Label157" runat="server" Text="Date To"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadDatePicker ID="dtto" Runat="server" Skin="Sunset">
                                                        <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                        </Calendar>
                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                        </DateInput>
                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                    </telerik:RadDatePicker>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4">
                                                    <asp:Panel ID="Panel25" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="99%">
                                                        <telerik:RadGrid ID="GD_M" runat="server" AllowPaging="True" CellSpacing="0" 
                                                            GridLines="None" Height="100%" PageSize="50" Skin="Web20" Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                     
                                                                    <telerik:GridBoundColumn DataField="Total_Tracked" 
                                                                        FilterControlAltText="Filter Total_Tracked column" HeaderText="Total_Tracked" 
                                                                        SortExpression="Total_Tracked" UniqueName="Total_Tracked">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Invoice_Attached" 
                                                                        FilterControlAltText="Filter Invoice_Attached column" 
                                                                        HeaderText="Invoice_Attached" SortExpression="Invoice_Attached" 
                                                                        UniqueName="Invoice_Attached">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Perc_Attached" 
                                                                        FilterControlAltText="Filter Perc_Attached column" HeaderText="Perc_Attached" 
                                                                        SortExpression="Perc_Attached" UniqueName="Perc_Attached">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Billed" 
                                                                        FilterControlAltText="Filter Billed column" HeaderText="Billed" 
                                                                        SortExpression="Billed" UniqueName="Billed">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Perc_Billed" 
                                                                        FilterControlAltText="Filter Perc_Billed column" HeaderText="Perc_Billed" 
                                                                        SortExpression="Perc_Billed" UniqueName="Perc_Billed">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="With_Issues" 
                                                                        FilterControlAltText="Filter With_Issues column" HeaderText="With_Issues" 
                                                                        SortExpression="With_Issues" UniqueName="With_Issues">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Perc_Issues" 
                                                                        FilterControlAltText="Filter Perc_Issues column" HeaderText="Perc_Issues" 
                                                                        SortExpression="Perc_Issues" UniqueName="Perc_Issues">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel23" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="99%">
                                            <telerik:RadGrid ID="GDSUM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="50" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Entered_by">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="Entered_by" 
                                                            FilterControlAltText="Filter Entered_by column" HeaderText="Name" 
                                                            SortExpression="Entered_by" UniqueName="Entered_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_Tracked" 
                                                            FilterControlAltText="Filter Total_Tracked column" HeaderText="Total_Tracked" 
                                                            SortExpression="Total_Tracked" UniqueName="Total_Tracked">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_Attached" 
                                                            FilterControlAltText="Filter Invoice_Attached column" 
                                                            HeaderText="Invoice_Attached" SortExpression="Invoice_Attached" 
                                                            UniqueName="Invoice_Attached">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Perc_Attached" 
                                                            FilterControlAltText="Filter Perc_Attached column" HeaderText="Perc_Attached" 
                                                            SortExpression="Perc_Attached" UniqueName="Perc_Attached">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Billed" 
                                                            FilterControlAltText="Filter Billed column" HeaderText="Billed" 
                                                            SortExpression="Billed" UniqueName="Billed">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Perc_Billed" 
                                                            FilterControlAltText="Filter Perc_Billed column" HeaderText="Perc_Billed" 
                                                            SortExpression="Perc_Billed" UniqueName="Perc_Billed">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="With_Issues" 
                                                            FilterControlAltText="Filter With_Issues column" HeaderText="With_Issues" 
                                                            SortExpression="With_Issues" UniqueName="With_Issues">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Perc_Issues" 
                                                            FilterControlAltText="Filter Perc_Issues column" HeaderText="Perc_Issues" 
                                                            SortExpression="Perc_Issues" UniqueName="Perc_Issues">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="Label1" runat="server" style="font-weight: 700" Text="MONTH"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel24" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="99%">
                                            <telerik:RadGrid ID="GDRM_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="50" Skin="Web20" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" >
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Entry_Yr" FilterControlAltText="Filter Entry_Yr column" 
                                                            HeaderText="Entry_Yr" SortExpression="Entry_Yr" UniqueName="Entry_Yr">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Entry_Mon" 
                                                            FilterControlAltText="Filter Entry_Mon column" HeaderText="Entry_Mon" 
                                                            SortExpression="Entry_Mon" UniqueName="Entry_Mon">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="Total_Tracked" 
                                                            FilterControlAltText="Filter Total_Tracked column" HeaderText="Total_Tracked" 
                                                            SortExpression="Total_Tracked" UniqueName="Total_Tracked">
                                                        </telerik:GridBoundColumn>
                                                              <telerik:GridBoundColumn DataField="Invoice_Attached" 
                                                            FilterControlAltText="Filter Invoice_Attached column" HeaderText="Invoice_Attached" 
                                                            SortExpression="Invoice_Attached" UniqueName="Invoice_Attached">
                                                        </telerik:GridBoundColumn>
                                                           <telerik:GridBoundColumn DataField="Billed" 
                                                            FilterControlAltText="Filter Billed column" HeaderText="Billed" 
                                                            SortExpression="Billed" UniqueName="Billed">
                                                        </telerik:GridBoundColumn>
                                                                <telerik:GridBoundColumn DataField="Issues" 
                                                            FilterControlAltText="Filter Issues column" HeaderText="Issues" 
                                                            SortExpression="Issues" UniqueName="Issues">
                                                        </telerik:GridBoundColumn>
                                                       
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <telerik:RadButton ID="export" runat="server" Skin="Web20" Text="Export" 
                                            Width="149px">
                                        </telerik:RadButton>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                        <asp:HiddenField ID="HiddenField2" runat="server" />
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                    </td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
   
    </asp:UpdatePanel>
</asp:Content>

