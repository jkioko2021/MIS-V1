﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Post_Statement_Approval.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1170px">
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="APPROVE TRANSACTION" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <asp:Panel ID="Panel36" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1129px">
                                            <telerik:RadGrid ID="GD_STATE_1" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="REFERENCE_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                         <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                                        Text="Select" UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                            FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                            SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="INVOICE_DATE" 
                                                            FilterControlAltText="Filter INVOICE_DATE column" HeaderText="INVOICE_DATE" 
                                                            SortExpression="INVOICE_DATE" UniqueName="TRANSACTION_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PREMIUM" 
                                                            FilterControlAltText="Filter PREMIUM column" HeaderText="PREMIUM" 
                                                            SortExpression="PREMIUM" UniqueName="PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="REC_AMOUNT" 
                                                            FilterControlAltText="Filter REC_AMOUNT column" HeaderText="RECEIPT" 
                                                            SortExpression="REC_AMOUNT" UniqueName="REC_AMOUNT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TRANS_TYPE" 
                                                            FilterControlAltText="Filter TRANS_TYPE column" HeaderText="TRANS_TYPE" 
                                                            SortExpression="TRANS_TYPE" UniqueName="TRANS_TYPE">
                                                        </telerik:GridBoundColumn>
                                                 
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 148px; height: 34px;">
                                                    <asp:Label ID="LBLTYPE" runat="server" Visible="False"></asp:Label>
                                                </td>
                                                <td colspan="2" style="height: 34px">
                                                    <asp:Label ID="LBLPROP" runat="server" Visible="False"></asp:Label>
                                                </td>
                                                <td style="width: 149px; height: 34px;">
                                                    &nbsp;</td>
                                                <td style="height: 34px">
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px; height: 35px;">
                                                </td>
                                                <td style="width: 169px; height: 35px;">
                                                </td>
                                                <td style="width: 123px; height: 35px;">
                                                </td>
                                                <td style="width: 149px; height: 35px;">
                                                    <asp:Label ID="Label165" runat="server" Text="Action"></asp:Label>
                                                </td>
                                                <td style="height: 35px">
                                                    <telerik:RadComboBox ID="cboAction" Runat="server" AllowCustomText="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboAction" Text="Post Trans" 
                                                                Value="P" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 148px">
                                                    &nbsp;</td>
                                                <td colspan="3">
                                                    <asp:Label ID="RefNo" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsave" runat="server" Skin="Simple" Text="Save" 
                                                        Width="150px">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="height: 46px; width: 148px">
                                                </td>
                                                <td style="height: 46px; width: 169px">
                                                    &nbsp;</td>
                                                <td colspan="2" style="height: 46px">
                                                    &nbsp;</td>
                                                <td style="height: 46px">
                                                    &nbsp;:<asp:Label ID="lblsave" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        ForeColor="Red"></asp:Label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1142px">
                                                        <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="200" Skin="Simple" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                        FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                        SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                        DataFormatString="{0:yyyy-MM-dd}" 
                                                                        FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                        SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                        DataFormatString="{0:yyyy-MM-dd}" 
                                                                        FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                        SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="ACTION_TYPE" 
                                                                        FilterControlAltText="Filter ACTION_TYPE column" HeaderText="ACTION_TYPE" 
                                                                        SortExpression="ACTION_TYPE" UniqueName="ACTION_TYPE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="TOTAL_MEMBERS" 
                                                                        FilterControlAltText="Filter TOTAL_MEMBERS column" HeaderText="MEMBERS" 
                                                                        SortExpression="TOTAL_MEMBERS" UniqueName="TOTAL_MEMBERS">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                                        FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                                        SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="TRANSACTION_DATE" 
                                                                        FilterControlAltText="Filter TRANSACTION_DATE column" 
                                                                        HeaderText="TRANSACTION_DATE" SortExpression="TRANSACTION_DATE" 
                                                                        UniqueName="TRANSACTION_DATE">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="DR" FilterControlAltText="Filter DR column" 
                                                                        HeaderText="DR" SortExpression="DR" UniqueName="DR">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="CR" FilterControlAltText="Filter CR column" 
                                                                        HeaderText="CR" SortExpression="CR" UniqueName="CR">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <PagerStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 34px">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 144px; height: 43px;">
                                                </td>
                                                <td style="height: 43px">
                                                    </td>
                                                <td style="height: 43px">
                                                    </td>
                                                <td style="width: 193px; height: 43px;">
                                                    <telerik:RadButton ID="btnstatement" runat="server" Skin="Simple" 
                                                        Text="Print Statement" Width="276px">
                                                    </telerik:RadButton>
                                                </td>
                                                <td style="height: 43px">
                                                    </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1133px">
                                                        <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                            GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridBoundColumn DataField="Note_date" 
                                                                        FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                                        ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                                        <ItemStyle Width="100px" />
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Notes_by" 
                                                                        FilterControlAltText="Filter Notes_by column" HeaderText="From" 
                                                                        ItemStyle-Width="100" SortExpression="Notes_by" UniqueName="Notes_by">
                                                                        <ItemStyle Width="100px" />
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Notes" 
                                                                        FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                        SortExpression="Notes" UniqueName="Notes">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height: 41px">
                                        &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" ForeColor="Red" 
                                            Font-Size="Medium"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
   
            </asp:UpdatePanel>
</asp:Content>
