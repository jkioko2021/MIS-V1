﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("PRINT") = Nothing
            Session("Report_") = Nothing
            Session("EXCEL") = Nothing
            dtto.DbSelectedDate = Date.Now
            dtfrom.DbSelectedDate = Date.Now
        End If

    End Sub
    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try
            GDPROP.DataSource = Nothing
            GDPROP.DataBind()

            Dim MyDatable As New Data.DataTable
            ' SqlAction = "SELECT[PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"

            SqlAction = "SELECT USER_ID,AGENT_NAME,AGENT_TYPE,UNIT_NAME FROM [COMMISSION].[dbo].[VW_MIS_AGENTS_LISTING] WITH (NOLOCK)  WHERE AGENT_NAME LIKE '%" & Trim(TXTSEARCH.Text.ToUpper) & "%' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                Session("TAT_5") = MyDatable
                'RMNAME.Text = MyDatable.Rows(0).Item("RM_NAME").ToString
            
                MyDatable = Nothing
            Else
             
 

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try


            Session("FAMILY_NO") = Nothing
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0

            Session("AGENT_ID") = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("USER_ID").ToString()
            SqlAction = "SELECT DISTINCT  PROPOSER_DISPLAY_NAME, SUM(DR)DR,SUM(CR)CR   FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE AGENT_ID='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "'GROUP BY PROPOSER_DISPLAY_NAME  ORDER BY PROPOSER_DISPLAY_NAME DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_STATE.DataSource = MyDatable
                GD_STATE.DataBind()
                Session("STATE_01") = MyDatable
                DR = Convert.ToInt32(MyDatable.Compute("SUM(DR)", String.Empty))
                CR = Convert.ToInt32(MyDatable.Compute("sum(CR)", String.Empty))
                txtbal.Text = DR - CR
                MyDatable = Nothing
            Else
                GD_STATE.DataSource = Nothing
                GD_STATE.DataBind()
            End If
            'Session("PROPOSER_ID") = Nothing
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_STATE.PageIndexChanged
        GD_STATE.CurrentPageIndex = e.NewPageIndex
        GD_STATE.DataSource = Session("STATE_01")
        GD_STATE.DataBind()
    End Sub


    Protected Sub btnstatement_Click(sender As Object, e As System.EventArgs) Handles btnstatement.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable


            'If chkex.Checked = True Then
            '    Session("EXCEL") = "TO EXCEL"
            '    Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],  [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing]  WITH(NOLOCK) WHERE AGENT_ID ='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(PERIOD_FROM AS DATETIME),126) >= '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and Convert(VarChar(10),CAST(PERIOD_TO AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
            'Else
            '    Session("PRINT") = "PDF"
            '    Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],  [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing]  WITH(NOLOCK) WHERE AGENT_ID ='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(PERIOD_FROM AS DATETIME),126) >= '" & CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and Convert(VarChar(10),CAST(PERIOD_TO AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
            'End If




                If chkcurrent.Checked = True Then
                    If chkex.Checked = True Then
                        Session("EXCEL") = "TO EXCEL"
                    Str = "SELECT  DISTINCT  PROPOSER_DISPLAY_NAME, SUM(DR)DR,SUM(CR)CR ,[USER_DISPLAY_NAME],BUSINESS,PLAN_CODE FROM [DATA_REPOSITORY_DB].[dbo].[vw_statement_ageing_Agent]  WITH(NOLOCK) WHERE AGENT_ID ='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)>=GETDATE() GROUP BY PROPOSER_DISPLAY_NAME,USER_DISPLAY_NAME,BUSINESS,PLAN_CODE  ORDER BY PROPOSER_DISPLAY_NAME DESC"
                    Else
                        Session("PRINT") = "PDF"
                    Str = "SELECT DISTINCT  PROPOSER_DISPLAY_NAME, SUM(DR)DR,SUM(CR)CR ,[USER_DISPLAY_NAME],BUSINESS,PLAN_CODE  FROM [DATA_REPOSITORY_DB].[dbo].[vw_statement_ageing_Agent] WITH(NOLOCK) WHERE AGENT_ID ='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)>=GETDATE() GROUP BY PROPOSER_DISPLAY_NAME,USER_DISPLAY_NAME,BUSINESS,PLAN_CODE  ORDER BY PROPOSER_DISPLAY_NAME DESC"
                    End If
                Else
                    If chkex.Checked = True Then
                        Session("EXCEL") = "TO EXCEL"
                    Str = "SELECT  DISTINCT  PROPOSER_DISPLAY_NAME, SUM(DR)DR,SUM(CR)CR ,[USER_DISPLAY_NAME],BUSINESS,PLAN_CODE  FROM [DATA_REPOSITORY_DB].[dbo].[vw_statement_ageing_Agent]  WITH(NOLOCK) WHERE AGENT_ID ='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY PROPOSER_DISPLAY_NAME,USER_DISPLAY_NAME,BUSINESS,PLAN_CODE  ORDER BY PROPOSER_DISPLAY_NAME DESC"
                    Else
                        Session("PRINT") = "PDF"
                    Str = "SELECT DISTINCT  PROPOSER_DISPLAY_NAME, SUM(DR)DR,SUM(CR)CR ,[USER_DISPLAY_NAME],BUSINESS,PLAN_CODE   FROM [DATA_REPOSITORY_DB].[dbo].[vw_statement_ageing_Agent] WITH(NOLOCK) WHERE AGENT_ID ='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY PROPOSER_DISPLAY_NAME,USER_DISPLAY_NAME,BUSINESS,PLAN_CODE  ORDER BY PROPOSER_DISPLAY_NAME DESC"
                    End If
                End If
 


            Session("Report_") = "Customer Statement_Agent"

            'Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR],BALANCE, [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],['0-30 Days'],['31-60 Days'],['61-90 Days'],['91-120 Days'],['121-180 Days'],['181-240 Days'],['241-300 Days'],['301-365 Days'],['Over 365 Days'] FROM [MISREPORTS].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & Session("PROPOSER_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE,REFERENCE_NO"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable

            Session("EXCEL") = "TO EXCEL"
            Session("Report_") = "OS_AS_AT" & CDate(Date.Now()).ToString("yyyy-MM-dd")
            Str = "SELECT DISTINCT  PROPOSER_DISPLAY_NAME, SUM(DR)DR,SUM(CR)CR ,[USER_DISPLAY_NAME],BUSINESS,PLAN_CODE  FROM [DATA_REPOSITORY_DB].[dbo].[vw_statement_ageing_Agent] WITH(NOLOCK) WHERE AGENT_ID ='" & Session("AGENT_ID") & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(dtto.DbSelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY PROPOSER_DISPLAY_NAME,USER_DISPLAY_NAME,BUSINESS,PLAN_CODE ORDER BY PROPOSER_DISPLAY_NAME DESC"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    
End Class
