﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtemail.DbSelectedDate = Date.Now()
            dtindex.DbSelectedDate = Date.Now()
            dtscanned.DbSelectedDate = Date.Now()
            HiddenField1.Value = ""
            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST    ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboprovider
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With
          
            Str = ""
            MyDatatable = Nothing

            loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT id, File_no, [Provider_name],[Invoice_no],[Invoice_Amt],Entry_date, [Email_Date],[Receive_Date],[Scan_date],[Index_Date],[Bar_Code]   FROM [CRM].[dbo].[TBL_MIS_OP_CLAIM_TRACKING] where Closed=0 ORDER BY Entry_date DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    
    Function ContainsSpecialChars(s As String) As Boolean
        Return s.IndexOfAny("[~`!@#$%^&*()-+=|{}':;.,<>/?]".ToCharArray) <> -1
    End Function
    Public Sub Generate_Task()
        Dim AB As Integer
        SqlAction = "SELECT ISNULL((MAX(Id)+1),1) NUMBER FROM [dbo].[TBL_MIS_OP_CLAIM_TRACKING]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            lblfile.Text = "OP" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""

        End If
    End Sub
    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        'Dim PROCESSED As Integer = 0
        'Dim TO_FINANCE As Integer = 0
        Dim FILENO As String
        Dim app As Integer = 0
        Dim Member_no As String


        Dim receivedate As String
        Try
            If txtprovname.Text = "" Then
                lblerr.Text = "You have not captured the provider Name!"
                Exit Sub
            End If

            If txtinv_no.Text = "" Then
                lblerr.Text = "You have not captured the Invoice No!"
                Exit Sub
            End If
            If txtinv_amt.Text = 0 Then
                lblerr.Text = "You have not captured the Invoice Amount!"
                Exit Sub
            End If
          
            If chkclose.Checked = True Then
                app = 1
            Else
                app = 0
            End If

            If HiddenField1.Value = "" Then
                Dim searchStr As String = ""
                Dim MyDBAction As New DataManagement
                Dim DEPART As String = ""

              
                Generate_Task()


               
                STS = 0
                MyDBAction.Register_OP(lblfile.Text, cboprovider.SelectedValue, txtprovname.Text, txtinv_no.Text, txtinv_amt.Text, CDate(dtemail.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtscanned.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtindex.DbSelectedDate).ToString("yyyy-MM-dd"), txtbarcode.Text, Session("username"), CDate(Date.Now()).ToString("yyyy-MM-dd"), STS, app)

           
                lblerr.Text = "Saved Successfully!"
                HiddenField1.Value = ""
            Else
                STS = 1
                MyDBAction.Register_OP(lblfile.Text, cboprovider.SelectedValue, txtprovname.Text, txtinv_no.Text, txtinv_amt.Text, CDate(dtemail.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtscanned.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtindex.DbSelectedDate).ToString("yyyy-MM-dd"), txtbarcode.Text, Session("username"), CDate(Date.Now()).ToString("yyyy-MM-dd"), STS, app)

                lblerr.Text = "Updated Successfully!"
                FILENO = ""
            End If
            loadGrid()

            'loadGrid_OTH(txtinv_no.Text)
            HiddenField1.Value = ""

            dtreceive.DbSelectedDate = Date.Now()
            dtemail.DbSelectedDate = Date.Now()
            dtindex.DbSelectedDate = Date.Now()
            dtscanned.DbSelectedDate = Date.Now()
            dtemail.Enabled = True
            dtreceive.Enabled = True
            dtindex.Enabled = True
            dtscanned.Enabled = True
            lblfile.Text = ""
            cboprovider.SelectedValue = ""
            txtprovname.Text = ""
            txtinv_no.Text = ""
            txtinv_amt.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        'cboprovider.Text = ""
        lblerr.Text = ""
        Session("Audited") = 0
        Session("Posting") = 0
        lblfile.Text = ""
        Try


            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT File_no,  [Provider_name],[Invoice_no],[Invoice_Amt],Entry_date, [Email_Date],[Receive_Date],[Scan_date],[Index_Date],[Bar_Code]   FROM [CRM].[dbo].[TBL_MIS_OP_CLAIM_TRACKING]  WHERE File_No ='" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("Receive_Date").ToString()
                    dtemail.DbSelectedDate = MyDatable.Rows(0).Item("Email_Date").ToString()

                    dtscanned.DbSelectedDate = MyDatable.Rows(0).Item("Scan_date").ToString()
                    dtindex.DbSelectedDate = MyDatable.Rows(0).Item("Index_Date").ToString()
                    txtprovname.Text = MyDatable.Rows(0).Item("Provider_Name").ToString()
                    

                    txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                    txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                    txtbarcode.Text = MyDatable.Rows(0).Item("Bar_Code").ToString()
            
                    dtemail.Enabled = False
                    dtreceive.Enabled = False
                    dtindex.Enabled = False
                        dtscanned.Enabled = False

                    '  txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False


                    'txtbarcode.Enabled = False
                    '  cbotype.Enabled = False


                    txtinv_no.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False

                    ' txtname.Enabled = False
                    txtinv_no.Enabled = False

                    txtinv_amt.Enabled = False
                    'txtcomment.Enabled = False


                    txtinv_amt.Enabled = False



                End If
                HiddenField1.Value = 1
                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "I" Then
                'SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT], INV_STATUS,P.ORG_NAME FROM  [dbo].[TBL_MIS_IP_CLAIM_TRACKING] T WITH (NOLOCK)   INNER JOIN [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST p WITH (NOLOCK)  ON T.Provider_Code COLLATE DATABASE_DEFAULT =P.ORG_ID  WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%'"
                SqlAction = "SELECT Id, [Provider_name],[Invoice_no],[Invoice_Amt],Entry_date, [Email_Date],[Receive_Date],[Scan_date],[Index_Date],[Bar_Code]   FROM [CRM].[dbo].[TBL_MIS_OP_CLAIM_TRACKING] where INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%'"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT Id, [Provider_name],[Invoice_no],[Invoice_Amt],Entry_date, [Email_Date],[Receive_Date],[Scan_date],[Index_Date],[Bar_Code]   FROM [CRM].[dbo].[TBL_MIS_OP_CLAIM_TRACKING] where File_no Like '%" & Trim(txtsearch.Text) & "%'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub

    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        cmdsave.Enabled = True
        lblfile.Enabled = True
        dtreceive.Enabled = True
        
        dtemail.Enabled = True
        dtreceive.Enabled = True
        dtindex.Enabled = True
        dtscanned.Enabled = True
        txtinv_no.Enabled = True

        txtinv_amt.Enabled = True
        'cboreason.Enabled = True
        'txtname.Enabled = True
        txtinv_no.Enabled = True
        txtinv_amt.Enabled = True

        'txtproposer.Enabled = True

        txtinv_amt.Enabled = True


    End Sub


    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDSEARCH.DeleteCommand
        Try
            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("File_No").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            DeleteRecord("DELETE FROM  CRM.[dbo].[TBL_MIS_OP_CLAIM_TRACKING] WHERE  File_No='" & HiddenField1.Value.ToString & "'")

            HiddenField1.Value = ""
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid()


        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub

    Protected Sub cboprovider_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboprovider.SelectedIndexChanged
        txtprovname.Text = cboprovider.Text
    End Sub
End Class
