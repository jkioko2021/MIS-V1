﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Renewal_View_Print.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%;">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Larger" 
                            ForeColor="#CCCCCC" style="font-weight: 700" 
                            Text="VIEW"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td align="center" style="text-align: left">
                        <asp:Label ID="Label131" runat="server" style="font-weight: 700" Text="From"></asp:Label>
                        &nbsp;&nbsp;
                        <telerik:RadDatePicker ID="dtmonthfr" Runat="server" MinDate="" Skin="Forest">
                            <Calendar Skin="Forest" UseColumnHeadersAsSelectors="False" 
                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                            </Calendar>
                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                            </DateInput>
                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                        </telerik:RadDatePicker>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                    <td align="center">
                        &nbsp;</td>
                </tr>
                <tr>
                    <td align="center" colspan="4" style="text-align: left">
                        <asp:Label ID="Label130" runat="server" style="font-weight: 700" 
                            Text="To"></asp:Label>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <telerik:RadDatePicker ID="dtmonthto" Runat="server" MinDate="" Skin="Forest">
                            <Calendar Skin="Forest" UseColumnHeadersAsSelectors="False" 
                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                            </Calendar>
                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                            </DateInput>
                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                        </telerik:RadDatePicker>
                        &nbsp;&nbsp;&nbsp;
                        </td>
                </tr>
                <tr>
                    <td align="center" colspan="4" style="text-align: left">
                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                            <table style="width: 100%">
                                <tr>
                                    <td>
                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" Text="Select"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" AutoPostBack="True">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Family Code" Value="F" />
                                                <telerik:RadComboBoxItem runat="server" Text="Proposer" Value="P" />
                                                <telerik:RadComboBoxItem runat="server" Text="Agent" Value="A" />
                                                <telerik:RadComboBoxItem runat="server" Text="RM" Value="RM" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadComboBox ID="cbotext" Runat="server" AllowCustomText="True" 
                                            MarkFirstMatch="True" Width="300px">
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                            Width="157px">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1162px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1142px">
                                            <telerik:RadGrid ID="GDSEARCH" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>                                                       
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                    
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="FAMILY_NO" 
                                                            FilterControlAltText="Filter FAMILY_NO column" HeaderText="FAMILY_NO" 
                                                            SortExpression="FAMILY_NO" UniqueName="FAMILY_NO">
                                                        </telerik:GridBoundColumn>
                                                            <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                            FilterControlAltText="Filter POLICY_VALID_FROM column" 
                                                            HeaderText="POLICY_VALID_FROM" SortExpression="POLICY_VALID_FROM" 
                                                            UniqueName="POLICY_VALID_FROM" DataFormatString="{0:yyyy-MM-dd}">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                            FilterControlAltText="Filter POLICY_VALID_UPTO column" 
                                                            HeaderText="POLICY_VALID_UPTO" SortExpression="POLICY_VALID_UPTO" 
                                                            UniqueName="POLICY_VALID_UPTO" DataFormatString="{0:yyyy-MM-dd}">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="DISPLAY_MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>                                                      
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" 
                                                            HeaderText="MEMBER_BIRTH_DATE" SortExpression="MEMBER_BIRTH_DATE" 
                                                            UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" 
                                                            HeaderText="MEMBER_ADMINISTRATIVE_SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGENT" 
                                                            FilterControlAltText="Filter AGENT column" HeaderText="AGENT" 
                                                            SortExpression="AGENT" UniqueName="AGENT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="AGE_AT_RENEWAL" 
                                                            FilterControlAltText="Filter AGE_AT_RENEWAL column" HeaderText="AGE_AT_RENEWAL" 
                                                            SortExpression="AGE_AT_RENEWAL" UniqueName="AGE_AT_RENEWAL">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CATEGORY" 
                                                            FilterControlAltText="Filter CATEGORY column" HeaderText="CATEGORY" 
                                                            SortExpression="CATEGORY" UniqueName="CATEGORY">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OP_LIMIT" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter OP_LIMIT column" 
                                                            HeaderText="OP_LIMIT" SortExpression="OP_LIMIT" UniqueName="OP_LIMIT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OP_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter OP_PREMIUM column" 
                                                            HeaderText="OP_PREMIUM" SortExpression="OP_PREMIUM" UniqueName="OP_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_LIMIT" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter IP_LIMIT column" 
                                                            HeaderText="IP_LIMIT" SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter IP_PREMIUM column" 
                                                            HeaderText="IP_PREMIUM" SortExpression="IP_PREMIUM" UniqueName="IP_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PA" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter PA column" 
                                                            HeaderText="PA" SortExpression="PA" UniqueName="PA">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="NCD" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter NCD column" 
                                                            HeaderText="NCD" SortExpression="NCD" UniqueName="NCD">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="LEVIES" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter LEVIES column" 
                                                            HeaderText="LEVIES" SortExpression="LEVIES" UniqueName="LEVIES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL_PREMIUM" DataFormatString="{0:n}" 
                                                            DataType="System.Decimal" FilterControlAltText="Filter TOTAL_PREMIUM column" 
                                                            HeaderText="TOTAL_PREMIUM" SortExpression="TOTAL_PREMIUM" 
                                                            UniqueName="TOTAL_PREMIUM">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        <asp:Label ID="Label104" runat="server" Text="Total Premiums"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadNumericTextBox ID="txttotal" Runat="server" Width="155px">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#333333" colspan="4">
                                        <asp:Label ID="Label135" runat="server" 
                                            style="font-weight: 700; color: #FFFFFF;" Text="Print"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        <asp:Label ID="Label136" runat="server" style="font-weight: 700" Text="Product"></asp:Label>
                                    </td>
                                    <td style="width: 151px; height: 11px;">
                                        <telerik:RadComboBox ID="cboTYPE" Runat="server" Skin="Simple">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Owner="cboTYPE" Text="Schedule" 
                                                    Value="S" />
                                                <telerik:RadComboBoxItem runat="server" Text="Letter" Value="L" />
                                                <telerik:RadComboBoxItem runat="server" Text="Claim Statement" Value="C" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        <telerik:RadButton ID="BTNprint" runat="server" Skin="Simple" 
                                            Text="Print Renewal Notices">
                                        </telerik:RadButton>
                                    </td>
                                    <td rowspan="2" style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px; height: 11px;">
                                        &nbsp;</td>
                                    <td style="width: 151px; height: 11px;">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px; height: 11px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>
