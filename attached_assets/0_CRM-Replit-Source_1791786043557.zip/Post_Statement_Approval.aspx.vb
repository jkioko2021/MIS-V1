﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""

                ' dtupload.DbSelectedDate = Date.Now
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing
                Session("med") = 0
                Session("Allocate") = 0
                Session("INVOICED") = 0
                '

                GD_STATE.DataSource = Nothing
                GD_STATE.DataBind()
                'ltEmbed.Text = ""
                LOADGRID()
            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
  

    Public Sub LOADGRID()
        SqlAction = "SELECT PROPOSER_DISPLAY_NAME, REFERENCE_NO,INVOICE_DATE,PERIOD_FROM,PERIOD_TO,PREMIUM,REC_AMOUNT,TRANS_TYPE FROM [CRM].[dbo].[MASTER_STATEMENT_ADJUSTMENT] WHERE [POSTED]=0  AND IS_ACTIVE=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_STATE_1.DataSource = MyDatable
            GD_STATE_1.DataBind()
        Else
            GD_STATE_1.DataSource = Nothing
            GD_STATE_1.DataBind()
        End If
    End Sub

    Protected Sub btnsave_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0
            If RefNo.Text = "" Then
                lblerr.Text = "Select the Transaction"
                Exit Sub
            End If

            If cboAction.SelectedValue = "P" Then
                MyDBAction.POST_STATEMENT_ADJ_AMT(RefNo.Text, LBLPROP.Text, Session("username"))
                LOADGRID()
                LoadNotes(LBLPROP.Text)
                lblsave.Text = "Transaction Saved Successfull!"
            End If



            RefNo.Text = ""

        Catch ex As Exception
            lblsave.Text = ex.Message
        End Try
    End Sub
    Public Sub LoadNotes(ByVal id As String)
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        SqlAction = "SELECT DISTINCT  [POLICY_CODE], Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & LBLPROP.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_STATE.DataSource = MyDatable
            GD_STATE.DataBind()
            Session("STATE_01") = MyDatable
        Else
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()
        End If

        SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_CORPORATE_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If

        End If



    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
  

    
    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_STATE.PageIndexChanged
        GD_STATE.CurrentPageIndex = e.NewPageIndex
        GD_STATE.DataSource = Session("STATE_01")
        GD_STATE.DataBind()
    End Sub

    Protected Sub btnstatement_Click(sender As Object, e As System.EventArgs) Handles btnstatement.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable

            If LBLPROP.Text = "" Then
                lblsave.Text = "Select Proposer Name"
                Exit Sub
            End If


            Session("PRINT") = "PDF"
            Session("Report_") = "Customer Statement"

            Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR], [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & LBLPROP.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC,REFERENCE_NO"

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GD_STATE_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_STATE_1.SelectedIndexChanged
        Try
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()




            Session("PROPOSER_ID") = Nothing
            Session("CLIENT_TYPE") = Nothing
            Dim dr As Decimal = 0
            Dim cr As Decimal = 0



            RefNo.Text = (DirectCast(GD_STATE_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("REFERENCE_NO").ToString()

            SqlAction = "SELECT PROPOSER_DISPLAY_NAME,PROPOSER_ID, REFERENCE_NO,INVOICE_DATE,PERIOD_FROM,PERIOD_TO,PREMIUM,REC_AMOUNT,TRANS_TYPE FROM [CRM].[dbo].[MASTER_STATEMENT_ADJUSTMENT] WHERE  REFERENCE_NO= '" & RefNo.Text & "' AND IS_ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                LBLPROP.Text = MyDatable.Rows(0).Item("PROPOSER_ID").ToString()
                'txtmobile.Text = MyDatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()

                LoadNotes(LBLPROP.Text)

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
End Class
