﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="AAR_Protect.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                                      <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" Width="1151px">
                            <table style="width: 100%">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="HPC REGISTRATION"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 100%">
                                            <tr>
                                                <td style="width: 1025px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td style="width: 261px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 250px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Outlook" 
                                                        Width="200px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <asp:Panel ID="Panel29" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1140px">
                                            <telerik:RadGrid ID="GDMEMBER" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                           <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                            FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                            HeaderText="MEMBERSHIP NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                            UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                            FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                            SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="RELATION" 
                                                            FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                            SortExpression="RELATION" UniqueName="RELATION">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                            FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                            SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                            UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                            DataFormatString="{0:dd-MM-yyyy}" 
                                                            FilterControlAltText="Filter MEMBER_BIRTH_DATE column" 
                                                            HeaderText="MEMBER_BIRTH_DATE" SortExpression="MEMBER_BIRTH_DATE" 
                                                            UniqueName="MEMBER_BIRTH_DATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                            FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                            SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                            FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                            SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                            FilterControlAltText="Filter POLICY_STATUS column" HeaderText="STATUS" 
                                                            SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                                          <table style="width: 100%">
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label147" runat="server" style="font-weight: 700" 
                                                          Text="Member Info"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      <asp:CheckBox ID="chkupdate" runat="server" Text=" Member Not updated" />
                                                  </td>
                                                  <td style="width: 131px">
                                                      <asp:Label ID="Label171" runat="server" style="font-weight: 700" Text="STATUS"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <asp:Label ID="lblstatus" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label143" runat="server" Text="Member No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px">
                                                      &nbsp;<asp:Label ID="Label144" runat="server" Text="Member Name"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadTextBox ID="txtname" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label146" runat="server" Text="Proposer Name"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px">
                                                      <asp:Label ID="Label145" runat="server" Text="Client Type"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Outlook">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Text="Corporate" Value="C" />
                                                              <telerik:RadComboBoxItem runat="server" Text="Individual" Value="I" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label167" runat="server" Text="Mobile No"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadTextBox ID="txtmobile" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                                  <td style="width: 131px">
                                                      <asp:Label ID="Label168" runat="server" Text="Email"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#999999" colspan="4">
                                                      <asp:Label ID="Label148" runat="server" style="font-weight: 700" 
                                                          Text="Case Info"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label149" runat="server" Text="Diagnosis date"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadDatePicker ID="dtdx" Runat="server" Skin="Outlook">
                                                          <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                              UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                          </Calendar>
                                                          <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                          </DateInput>
                                                          <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                      </telerik:RadDatePicker>
                                                  </td>
                                                  <td style="width: 131px">
                                                      <asp:Label ID="Label150" runat="server" Text="Doctor"></asp:Label>
                                                  </td>
                                                  <td>
                                                      <telerik:RadTextBox ID="txtother" Runat="server" Skin="Outlook" Width="250px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px; height: 17px;">
                                                      <asp:Label ID="Label158" runat="server" Text="Diagnosis"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px; height: 17px;">
                                                      <telerik:RadComboBox ID="cbocomor" Runat="server" Skin="Outlook" Width="250px" 
                                                          AllowCustomText="True" MarkFirstMatch="True" DropDownWidth="250px" 
                                                          MaxHeight="400px">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbocomor" Text="Open" 
                                                                  Value="Open" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbocomor" Text="Closed" 
                                                                  Value="Closed" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                                  <td style="width: 131px; height: 17px;">
                                                      <asp:Label ID="Label172" runat="server" Text="Source"></asp:Label>
                                                  </td>
                                                  <td style="height: 17px">
                                                      <telerik:RadComboBox ID="cbosrc" Runat="server" AllowCustomText="True" 
                                                          DropDownWidth="250px" MarkFirstMatch="True" MaxHeight="400px" Skin="Outlook" 
                                                          Width="250px">
                                                          <Items>
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbosrc" Text="Open" 
                                                                  Value="Open" />
                                                              <telerik:RadComboBoxItem runat="server" Owner="cbosrc" Text="Closed" 
                                                                  Value="Closed" />
                                                          </Items>
                                                      </telerik:RadComboBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      <asp:Label ID="Label160" runat="server" Text="Followup date"></asp:Label>
                                                  </td>
                                                  <td style="width: 272px">
                                                      <telerik:RadDatePicker ID="dtafollow" Runat="server" Skin="Outlook">
                                                          <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                              UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                          </Calendar>
                                                          <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                          </DateInput>
                                                          <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                      </telerik:RadDatePicker>
                                                  </td>
                                                  <td style="width: 131px">
                                                      <asp:Label ID="Label156" runat="server" Text="Notes"></asp:Label>
                                                  </td>
                                                  <td rowspan="4">
                                                      <telerik:RadTextBox ID="txtnotes" Runat="server" Font-Size="Large" 
                                                          Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                          TextMode="MultiLine" Width="500px">
                                                      </telerik:RadTextBox>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      &nbsp;</td>
                                                  <td style="width: 131px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      &nbsp;</td>
                                                  <td style="width: 131px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      &nbsp;</td>
                                                  <td style="width: 131px">
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                  </td>
                                                  <td style="width: 131px">
                                                      &nbsp;</td>
                                                  <td>
                                                      <telerik:RadButton ID="cmdsave" runat="server" Height="38px" Skin="Sunset" 
                                                          Text="Save" Width="113px">
                                                      </telerik:RadButton>
                                                      &nbsp;&nbsp;<asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td style="width: 146px">
                                                      &nbsp;</td>
                                                  <td style="width: 272px">
                                                      &nbsp;</td>
                                                  <td style="width: 131px">
                                                      &nbsp;</td>
                                                  <td>
                                                      &nbsp;</td>
                                              </tr>
                                              <tr>
                                                  <td bgcolor="#666666" colspan="4">
                                                      <asp:Label ID="Label166" runat="server" Text="Search Provider"></asp:Label>
                                                  </td>
                                              </tr>
                                          </table>
                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8" align="left">
                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" 
                                            Text="Registry"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="left" class="style8">
                                        <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1140px">
                                            <telerik:RadGrid ID="GDCASE" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                       
                                                           <telerik:GridBoundColumn DataField="Code_Id" 
                                                            FilterControlAltText="Filter Code_Id column" 
                                                            HeaderText="Code_Id" SortExpression="Code_Id" 
                                                            UniqueName="Code_Id">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" 
                                                            HeaderText="Member_No" SortExpression="Member_No" 
                                                            UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                     <telerik:GridBoundColumn DataField="Member_Name" 
                                                            FilterControlAltText="Filter Member_Name column" 
                                                            HeaderText="Member_Name" SortExpression="Member_Name" 
                                                            UniqueName="Member_Name">
                                                        </telerik:GridBoundColumn>
                                                      <telerik:GridBoundColumn DataField="Followup_Dt" 
                                                      FilterControlAltText="Filter Followup_Dt column" HeaderText="Followup_Dt" 
                                                      SortExpression="Followup_Dt" UniqueName="Followup_Dt">
                                                     </telerik:GridBoundColumn>                                                     
                                                        <telerik:GridBoundColumn DataField="Entered_by" 
                                                            FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                            SortExpression="Entered_by" UniqueName="Entered_by">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Entry_Dt" 
                                                            FilterControlAltText="Filter Entry_Dt column" HeaderText="Entry_Dt" 
                                                            SortExpression="Entry_Dt" UniqueName="Entry_Dt">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>

