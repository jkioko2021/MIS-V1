﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="HPC_Update.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#CC0000" 
                Text="Please Wait...." Font-Size="Large"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                    
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1158px" Height="100%">
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8" style="height: 523px">
                                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                            Height="100%" Width="1151px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#CCCCCC">
                                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                                            Text="HPC update"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="center">
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                                </td>
                                                                <td style="width: 261px">
                                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" MarkFirstMatch="True" 
                                                                        Skin="Sunset" Width="190px" AutoPostBack="True">
                                                                        <Items>
                                                                            <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" 
                                                                                Owner="cbosearch" />
                                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch" Text="Member Name" 
                                                                                Value="N" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Followup date" Value="D" />
                                                                            <telerik:RadComboBoxItem runat="server" Text="Registration Date" Value="R" />
                                                                            <telerik:RadComboBoxItem runat="server" Owner="cbosearch" Text="Source" 
                                                                                Value="S" />
                                                                        </Items>
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td style="width: 250px">
                                                                    <telerik:RadComboBox ID="txtsearch" Runat="server" AllowCustomText="True" 
                                                                        MarkFirstMatch="True" Skin="Sunset" Width="223px">
                                                                    </telerik:RadComboBox>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    &nbsp;</td>
                                                                <td style="width: 261px">
                                                                    <asp:Label ID="Label180" runat="server" Text="From"></asp:Label>
                                                                </td>
                                                                <td style="width: 250px">
                                                                    <telerik:RadDatePicker ID="DtFollFrom" Runat="server" Skin="Outlook">
                                                                        <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                        </Calendar>
                                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                        </DateInput>
                                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                    </telerik:RadDatePicker>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    &nbsp;</td>
                                                                <td style="width: 261px">
                                                                    <asp:Label ID="Label181" runat="server" Text="To"></asp:Label>
                                                                </td>
                                                                <td style="width: 250px">
                                                                    <telerik:RadDatePicker ID="dtFolloto" Runat="server" Skin="Outlook">
                                                                        <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                            UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                        </Calendar>
                                                                        <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                        </DateInput>
                                                                        <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                    </telerik:RadDatePicker>
                                                                </td>
                                                                <td>
                                                                    <telerik:RadButton ID="btnsearch" runat="server" Text="Search">
                                                                    </telerik:RadButton>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 1025px">
                                                                    <asp:Label ID="lblcode" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td style="width: 261px">
                                                                    <asp:Label ID="lblno" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td style="width: 250px">
                                                                    <asp:Label ID="lbldp" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    &nbsp;</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel30" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1140px">
                                                            <telerik:RadGrid ID="GDCASE" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Member_No">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                        <HeaderStyle Width="20px" />
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                       <telerik:GridButtonColumn CommandName="Select" 
                                                                                      FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                                      UniqueName="Select">
                                                                                      <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                      <ItemStyle Width="50px" />
                                                                                  </telerik:GridButtonColumn>
                                                                        <telerik:GridBoundColumn DataField="Code_Id" 
                                                                            FilterControlAltText="Filter Code_Id column" HeaderText="Code_Id" 
                                                                            SortExpression="Code_Id" UniqueName="Code_Id">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                                            SortExpression="Member_Name" UniqueName="Member_Name">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Followup_Dt" 
                                                                            FilterControlAltText="Filter Followup_Dt column" HeaderText="Followup_Dt" 
                                                                            SortExpression="Followup_Dt" UniqueName="Followup_Dt">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Entered_by" 
                                                                            FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                            SortExpression="Entered_by" UniqueName="Entered_by">
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Entry_Dt" 
                                                                            FilterControlAltText="Filter Entry_Dt column" HeaderText="Entry_Dt" 
                                                                            SortExpression="Entry_Dt" UniqueName="Entry_Dt">
                                                                        </telerik:GridBoundColumn>
                                                                           <telerik:GridBoundColumn DataField="HPC_Src" 
                                                                            FilterControlAltText="Filter HPC_Src column" HeaderText="Source" 
                                                                            SortExpression="HPC_Src" UniqueName="HPC_Src">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="lblprov" runat="server" Font-Size="Large" ForeColor="Red" 
                                                            Visible="False"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <table style="width: 100%">
                                                            <tr>
                                                                <td align="left">
                                                                    <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                                                        MultiPageID="RadMultiPage1" SelectedIndex="7" Skin="Outlook" Width="100%">
                                                                        <Tabs>
                                                                            <telerik:RadTab runat="server" PageViewID="V2" Text="Data Fulfilment">
                                                                            </telerik:RadTab>
                                                                            <telerik:RadTab runat="server" PageViewID="V1" Text="Diagnosis">
                                                                            </telerik:RadTab>
                                                                            <telerik:RadTab runat="server" PageViewID="V4" Text="Notes">
                                                                            </telerik:RadTab>
                                                                            <telerik:RadTab runat="server" PageViewID="V3" Text="Followup">
                                                                            </telerik:RadTab>
                                                                            <telerik:RadTab runat="server" PageViewID="V5" Text="Reports">
                                                                            </telerik:RadTab>
                                                                        </Tabs>
                                                                    </telerik:RadTabStrip>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <telerik:RadMultiPage ID="RadMultiPage1" Runat="server" Width="100%">
                                                                        <telerik:RadPageView ID="V1" runat="server">
                                                                            <asp:Panel ID="Panel32" runat="server">
                                                                                <table style="width: 100%">
                                                                                    <tr>
                                                                                        <td bgcolor="#999999" colspan="4">
                                                                                            <asp:Label ID="Label159" runat="server" style="font-weight: 700" 
                                                                                                Text="DIAGNOSIS UPDATE"></asp:Label>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 94px">
                                                                                            <asp:Label ID="Label158" runat="server" Text="Diagnosis"></asp:Label>
                                                                                        </td>
                                                                                        <td style="width: 194px">
                                                                                            <telerik:RadComboBox ID="cbocomor" Runat="server" Skin="Outlook" Width="250px">
                                                                                                <Items>
                                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbocomor" Text="Open" 
                                                                                                        Value="Open" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbocomor" Text="Closed" 
                                                                                                        Value="Closed" />
                                                                                                </Items>
                                                                                            </telerik:RadComboBox>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 94px">
                                                                                            <asp:Label ID="Label161" runat="server" Text="Dx date"></asp:Label>
                                                                                        </td>
                                                                                        <td style="width: 194px">
                                                                                            <telerik:RadDatePicker ID="dtdxdate" Runat="server" Skin="Outlook">
                                                                                                <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                                </Calendar>
                                                                                                <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                                </DateInput>
                                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                            </telerik:RadDatePicker>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 94px">
                                                                                            <asp:Label ID="Label178" runat="server" Text="Provider"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadTextBox ID="txtotherdoc" Runat="server" Skin="Outlook" 
                                                                                                Width="250px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 13px; width: 94px">
                                                                                            <asp:Label ID="Label160" runat="server" Text="Notes"></asp:Label>
                                                                                        </td>
                                                                                        <td colspan="2" rowspan="2">
                                                                                            <telerik:RadTextBox ID="txtnotesCorm" Runat="server" Font-Size="Large" 
                                                                                                Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                                TextMode="MultiLine" Width="500px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                        <td style="height: 13px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 94px">
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 42px; width: 94px">
                                                                                            &nbsp;</td>
                                                                                        <td colspan="2" style="height: 42px">
                                                                                            <telerik:RadButton ID="cmdsavecom" runat="server" Height="38px" Skin="Sunset" 
                                                                                                Text="Save" Width="113px">
                                                                                            </telerik:RadButton>
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 42px; width: 94px">
                                                                                        </td>
                                                                                        <td colspan="2" style="height: 42px">
                                                                                            &nbsp;<asp:Label ID="lblCOMM" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                                                                Width="1140px">
                                                                                                <telerik:RadGrid ID="GDCOMORM" runat="server" AllowPaging="True" 
                                                                                                    CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="Id">
                                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </RowIndicatorColumn>
                                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </ExpandCollapseColumn>
                                                                                                        <Columns>
                                                                                                            <telerik:GridBoundColumn DataField="Id" FilterControlAltText="Filter Id column" 
                                                                                                                HeaderText="Id" SortExpression="Id" UniqueName="Id">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Dx_Date" DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                                FilterControlAltText="Filter Dx_Date column" HeaderText="Dx_Date" 
                                                                                                                SortExpression="Dx_Date" UniqueName="Dx_Date">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Name" 
                                                                                                                FilterControlAltText="Filter Name column" HeaderText="Name" 
                                                                                                                SortExpression="Name" UniqueName="Name">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Other_Doctor" 
                                                                                                                FilterControlAltText="Filter Other_Doctor column" HeaderText="Provider" 
                                                                                                                SortExpression="Other_Doctor" UniqueName="Other_Doctor">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                                FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                                SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                                                                                ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                                                                                Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                                                                <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                                                                <ItemStyle CssClass="ButtonColumn" />
                                                                                                            </telerik:GridButtonColumn>
                                                                                                        </Columns>
                                                                                                        <EditFormSettings>
                                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                            </EditColumn>
                                                                                                        </EditFormSettings>
                                                                                                    </MasterTableView>
                                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                                    </FilterMenu>
                                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                                    </HeaderContextMenu>
                                                                                                </telerik:RadGrid>
                                                                                            </asp:Panel>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </asp:Panel>
                                                                        </telerik:RadPageView>
                                                                        <telerik:RadPageView ID="V2" runat="server" Selected="True">
                                                                            <asp:Panel ID="Panel2" runat="server" Height="100%">
                                                                                <table style="width: 100%">
                                                                                    <tr>
                                                                                        <td bgcolor="#999999" colspan="4">
                                                                                            <asp:Label ID="Label147" runat="server" style="font-weight: 700" 
                                                                                                Text="Member Info"></asp:Label>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Panel ID="Panel39" runat="server">
                                                                                                <table style="width: 100%">
                                                                                                    <tr>
                                                                                                        <td style="width: 707px">
                                                                                                            &nbsp;</td>
                                                                                                        <td style="width: 195px">
                                                                                                            <telerik:RadComboBox ID="cbosearch_1" Runat="server" AutoPostBack="True" 
                                                                                                                MarkFirstMatch="True" Skin="Sunset" Width="190px">
                                                                                                                <Items>
                                                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Member No" 
                                                                                                                        Value="M" />
                                                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cbosearch_1" Text="Member Name" 
                                                                                                                        Value="N" />
                                                                                                                </Items>
                                                                                                            </telerik:RadComboBox>
                                                                                                        </td>
                                                                                                        <td>
                                                                                                            <telerik:RadTextBox ID="txtsearch_1" Runat="server" Skin="Sunset">
                                                                                                            </telerik:RadTextBox>
                                                                                                            <telerik:RadButton ID="search" runat="server" Text="Search">
                                                                                                            </telerik:RadButton>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                </table>
                                                                                            </asp:Panel>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                                                                                Width="1140px">
                                                                                                <telerik:RadGrid ID="GD_1" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                                    GridLines="None" Height="100%" PageSize="20" Skin="Outlook" Width="100%">
                                                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="Member_No">
                                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </RowIndicatorColumn>
                                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </ExpandCollapseColumn>
                                                                                                        <Columns>
                                                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                                                FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                                                                UniqueName="Select">
                                                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                                                <ItemStyle Width="50px" />
                                                                                                            </telerik:GridButtonColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Code_Id" 
                                                                                                                FilterControlAltText="Filter Code_Id column" HeaderText="Code_Id" 
                                                                                                                SortExpression="Code_Id" UniqueName="Code_Id">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Member_No" 
                                                                                                                FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                                                                SortExpression="Member_No" UniqueName="Member_No">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Member_Name" 
                                                                                                                FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                                                                                SortExpression="Member_Name" UniqueName="Member_Name">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Followup_Dt" 
                                                                                                                FilterControlAltText="Filter Followup_Dt column" HeaderText="Followup_Dt" 
                                                                                                                SortExpression="Followup_Dt" UniqueName="Followup_Dt">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                                FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                                SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entry_Dt" 
                                                                                                                FilterControlAltText="Filter Entry_Dt column" HeaderText="Entry_Dt" 
                                                                                                                SortExpression="Entry_Dt" UniqueName="Entry_Dt">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="HPC_Src" 
                                                                                                                FilterControlAltText="Filter HPC_Src column" HeaderText="Source" 
                                                                                                                SortExpression="HPC_Src" UniqueName="HPC_Src">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                        </Columns>
                                                                                                        <EditFormSettings>
                                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                            </EditColumn>
                                                                                                        </EditFormSettings>
                                                                                                    </MasterTableView>
                                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                                    </FilterMenu>
                                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                                    </HeaderContextMenu>
                                                                                                </telerik:RadGrid>
                                                                                            </asp:Panel>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 146px">
                                                                                            <asp:Label ID="Label143" runat="server" Text="Member No"></asp:Label>
                                                                                        </td>
                                                                                        <td style="width: 272px">
                                                                                            <telerik:RadTextBox ID="txtmemno" Runat="server" Skin="Outlook" Width="250px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                        <td style="width: 131px">
                                                                                            &nbsp;<asp:Label ID="Label144" runat="server" Text="Member Name"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadTextBox ID="txtname" Runat="server" Skin="Outlook" Width="250px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 146px">
                                                                                            <asp:Label ID="Label146" runat="server" Text="Proposer Name"></asp:Label>
                                                                                        </td>
                                                                                        <td style="width: 272px">
                                                                                            <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Outlook" Width="250px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                        <td style="width: 131px">
                                                                                            <asp:Label ID="Label145" runat="server" Text="Client Type"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadComboBox ID="cboclient" Runat="server" Skin="Outlook">
                                                                                                <Items>
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Corporate" Value="C" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Individual" Value="I" />
                                                                                                </Items>
                                                                                            </telerik:RadComboBox>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 146px; height: 29px;">
                                                                                            <asp:Label ID="Label173" runat="server" Text="Mobile No"></asp:Label>
                                                                                        </td>
                                                                                        <td style="width: 272px; height: 29px;">
                                                                                            <telerik:RadTextBox ID="txtmobile" Runat="server" Skin="Outlook" Width="250px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                        <td style="width: 131px; height: 29px;">
                                                                                            <asp:Label ID="Label174" runat="server" Text="Email"></asp:Label>
                                                                                        </td>
                                                                                        <td style="height: 29px">
                                                                                            <telerik:RadTextBox ID="txtemail" Runat="server" Skin="Outlook" Width="250px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 146px">
                                                                                            &nbsp;</td>
                                                                                        <td style="width: 272px">
                                                                                            <asp:Label ID="lblcodeU" runat="server" Font-Size="Large" ForeColor="Red"></asp:Label>
                                                                                        </td>
                                                                                        <td style="width: 131px">
                                                                                            <telerik:RadButton ID="cmdedit" runat="server" Height="38px" Skin="Sunset" 
                                                                                                Text="Edit" Width="113px">
                                                                                            </telerik:RadButton>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadButton ID="cmdsave" runat="server" Height="38px" Skin="Sunset" 
                                                                                                Text="Save" Width="113px">
                                                                                            </telerik:RadButton>
                                                                                            &nbsp;&nbsp;<asp:Label ID="lblerr_f" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </asp:Panel>
                                                                        </telerik:RadPageView>
                                                                        <telerik:RadPageView ID="V4" runat="server">
                                                                            <asp:Panel ID="Panel6" runat="server">
                                                                                <table style="width: 100%">
                                                                                    <tr>
                                                                                        <td bgcolor="#999999" colspan="4">
                                                                                            <asp:Label ID="Label5" runat="server" style="font-weight: 700" 
                                                                                                Text="NOTES UPDATE"></asp:Label>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 139px">
                                                                                            <asp:Label ID="Label12" runat="server" Text="Notes  Date"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadDatePicker ID="DtNotes" Runat="server" Skin="Outlook">
                                                                                                <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                                </Calendar>
                                                                                                <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                                </DateInput>
                                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                            </telerik:RadDatePicker>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 13px; width: 139px">
                                                                                            <asp:Label ID="Label15" runat="server" Text="Notes"></asp:Label>
                                                                                        </td>
                                                                                        <td colspan="2" rowspan="2">
                                                                                            <telerik:RadTextBox ID="txtadmnotes" Runat="server" Font-Size="Large" 
                                                                                                Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                                TextMode="MultiLine" Width="500px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                        <td style="height: 13px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 139px">
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 42px; width: 139px">
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                            <telerik:RadButton ID="btnnotes" runat="server" Height="38px" Skin="Sunset" 
                                                                                                Text="Save" Width="113px">
                                                                                            </telerik:RadButton>
                                                                                            &nbsp;<asp:Label ID="lblnotes" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                </table>
                                                                            </asp:Panel>
                                                                        </telerik:RadPageView>
                                                                        <telerik:RadPageView ID="V3" runat="server">
                                                                            <asp:Panel ID="Panel3" runat="server">
                                                                                <table style="width: 100%">
                                                                                    <tr>
                                                                                        <td bgcolor="#999999" colspan="4">
                                                                                            <asp:Label ID="Label1" runat="server" style="font-weight: 700" 
                                                                                                Text="FOLLOWUP UPDATE"></asp:Label>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 139px">
                                                                                            <asp:Label ID="Label175" runat="server" Text="Scheduled date"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadDatePicker ID="dtsched" Runat="server" Skin="Outlook">
                                                                                                <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                                </Calendar>
                                                                                                <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                                </DateInput>
                                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                            </telerik:RadDatePicker>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 139px">
                                                                                            <asp:Label ID="Label2" runat="server" Text="Next FollowUp"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadDatePicker ID="dtfollow" Runat="server" Skin="Outlook">
                                                                                                <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                                </Calendar>
                                                                                                <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                                </DateInput>
                                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                            </telerik:RadDatePicker>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 139px">
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            <asp:CheckBox ID="chkcall" runat="server" Text="Member Engagement" />
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 13px; width: 139px">
                                                                                            <asp:Label ID="Label3" runat="server" Text="Notes"></asp:Label>
                                                                                        </td>
                                                                                        <td colspan="2" rowspan="2">
                                                                                            <telerik:RadTextBox ID="txtfoll" Runat="server" Font-Size="Large" 
                                                                                                Height="100px" Rows="3" Skin="Sunset" style="font-size: medium" 
                                                                                                TextMode="MultiLine" Width="500px">
                                                                                            </telerik:RadTextBox>
                                                                                        </td>
                                                                                        <td style="height: 13px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 139px">
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 42px; width: 139px">
                                                                                            &nbsp;</td>
                                                                                        <td style="height: 42px">
                                                                                            <telerik:RadButton ID="RadButton1" runat="server" Height="38px" Skin="Sunset" 
                                                                                                Text="Save" Width="113px">
                                                                                            </telerik:RadButton>
                                                                                            &nbsp;<asp:Label ID="lblfoll" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                                                                                Width="1140px">
                                                                                                <telerik:RadGrid ID="GDFOLLOW" runat="server" AllowPaging="True" 
                                                                                                    CellSpacing="0" GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="Follow_Id">
                                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </RowIndicatorColumn>
                                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </ExpandCollapseColumn>
                                                                                                        <Columns>
                                                                                                            <telerik:GridBoundColumn DataField="Follow_Id" 
                                                                                                                FilterControlAltText="Filter Follow_Id column" HeaderText="Follow_Id" 
                                                                                                                SortExpression="Follow_Id" UniqueName="Follow_Id">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Member_No" 
                                                                                                                FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                                                                SortExpression="Member_No" UniqueName="Member_No">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Scheduled_date" 
                                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                                FilterControlAltText="Filter Scheduled_date column" HeaderText="Scheduled_date" 
                                                                                                                SortExpression="Scheduled_date" UniqueName="Scheduled_date">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entered_By" 
                                                                                                                FilterControlAltText="Filter Entered_By column" HeaderText="Entered_by" 
                                                                                                                SortExpression="Entered_By" UniqueName="Entered_By">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entry_Date" 
                                                                                                                FilterControlAltText="Filter Entry_Date column" HeaderText="Entry_Date" 
                                                                                                                SortExpression="Entry_Date" UniqueName="Entry_Date">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Member_Call" 
                                                                                                                FilterControlAltText="Filter Member_Call column" HeaderText="Member_Call" 
                                                                                                                SortExpression="Member_Call" UniqueName="Member_Call">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Call_Date" 
                                                                                                                DataFormatString="{0:yyyy-MM-dd}" 
                                                                                                                FilterControlAltText="Filter Call_Date column" HeaderText="Call_Date" 
                                                                                                                SortExpression="Call_Date" UniqueName="Call_Date">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Call_By" 
                                                                                                                FilterControlAltText="Filter Call_By column" HeaderText="Call_By" 
                                                                                                                SortExpression="Call_By" UniqueName="Call_By">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                        </Columns>
                                                                                                        <EditFormSettings>
                                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                            </EditColumn>
                                                                                                        </EditFormSettings>
                                                                                                    </MasterTableView>
                                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                                    </FilterMenu>
                                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                                    </HeaderContextMenu>
                                                                                                </telerik:RadGrid>
                                                                                            </asp:Panel>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </asp:Panel>
                                                                        </telerik:RadPageView>
                                                                        <telerik:RadPageView ID="V5" runat="server">
                                                                            <asp:Panel ID="Panel4" runat="server">
                                                                                <table style="width: 100%">
                                                                                    <tr>
                                                                                        <td bgcolor="#999999" colspan="4">
                                                                                            <asp:Label ID="Label4" runat="server" style="font-weight: 700" 
                                                                                                Text="REPORTS-DASHBOARD"></asp:Label>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Panel ID="Panel36" runat="server" Height="100%" ScrollBars="Both" 
                                                                                                Width="1140px">
                                                                                                <telerik:RadGrid ID="GD_2" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                                    GridLines="None" Height="100%" Skin="Outlook" Width="100%" PageSize="20">
                                                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="Entered_by">
                                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </RowIndicatorColumn>
                                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </ExpandCollapseColumn>
                                                                                                        <Columns>
                                                                                                            <telerik:GridButtonColumn CommandName="Select" 
                                                                                                                FilterControlAltText="Filter Id column" HeaderText="Select" Text="Select" 
                                                                                                                UniqueName="Select">
                                                                                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                                                                                <ItemStyle Width="50px" />
                                                                                                            </telerik:GridButtonColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entry_Yr" 
                                                                                                                FilterControlAltText="Filter Entry_Yr column" HeaderText="Entry_Yr" 
                                                                                                                SortExpression="Entry_Yr" UniqueName="Entry_Yr">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                                FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                                SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Jan" 
                                                                                                                FilterControlAltText="Filter Jan column" HeaderText="Jan" SortExpression="Jan" 
                                                                                                                UniqueName="Jan">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Feb" 
                                                                                                                FilterControlAltText="Filter Feb column" HeaderText="Feb" SortExpression="Feb" 
                                                                                                                UniqueName="Feb">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Mar" 
                                                                                                                FilterControlAltText="Filter Mar column" HeaderText="Mar" SortExpression="Mar" 
                                                                                                                UniqueName="Mar">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Apr" 
                                                                                                                FilterControlAltText="Filter Apr column" HeaderText="Apr" SortExpression="Apr" 
                                                                                                                UniqueName="Apr">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="May" 
                                                                                                                FilterControlAltText="Filter May column" HeaderText="May" SortExpression="May" 
                                                                                                                UniqueName="May">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Jun" 
                                                                                                                FilterControlAltText="Filter Jun column" HeaderText="Jun" SortExpression="Jun" 
                                                                                                                UniqueName="Jun">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Jul" 
                                                                                                                FilterControlAltText="Filter Jul column" HeaderText="Jul" SortExpression="Jul" 
                                                                                                                UniqueName="Jul">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Aug" 
                                                                                                                FilterControlAltText="Filter Aug column" HeaderText="Aug" SortExpression="Aug" 
                                                                                                                UniqueName="Aug">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Sep" 
                                                                                                                FilterControlAltText="Filter Sep column" HeaderText="Sep" SortExpression="Sep" 
                                                                                                                UniqueName="Sep">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Oct" 
                                                                                                                FilterControlAltText="Filter Oct column" HeaderText="Oct" SortExpression="Oct" 
                                                                                                                UniqueName="Oct">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Nov" 
                                                                                                                FilterControlAltText="Filter Nov column" HeaderText="Nov" SortExpression="Nov" 
                                                                                                                UniqueName="Nov">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Dec" 
                                                                                                                FilterControlAltText="Filter Dec column" HeaderText="Dec" SortExpression="Dec" 
                                                                                                                UniqueName="Dec">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Total" 
                                                                                                                FilterControlAltText="Filter Total column" HeaderText="Total" 
                                                                                                                SortExpression="Total" UniqueName="Total">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                        </Columns>
                                                                                                        <EditFormSettings>
                                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                            </EditColumn>
                                                                                                        </EditFormSettings>
                                                                                                    </MasterTableView>
                                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                                    </FilterMenu>
                                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                                    </HeaderContextMenu>
                                                                                                </telerik:RadGrid>
                                                                                            </asp:Panel>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Panel ID="Panel37" runat="server" Height="100%" ScrollBars="Both" 
                                                                                                Width="1140px">
                                                                                                <telerik:RadGrid ID="GD_3" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                                    GridLines="None" Height="100%" Skin="Outlook" Width="100%">
                                                                                                    <MasterTableView AutoGenerateColumns="False" DataKeyNames="Member_No">
                                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </RowIndicatorColumn>
                                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </ExpandCollapseColumn>
                                                                                                        <Columns>
                                                                                                            <telerik:GridBoundColumn DataField="Code_Id" 
                                                                                                                FilterControlAltText="Filter Code_Id column" HeaderText="Code_Id" 
                                                                                                                SortExpression="Code_Id" UniqueName="Code_Id">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Member_No" 
                                                                                                                FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                                                                                SortExpression="Member_No" UniqueName="Member_No">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Member_Name" 
                                                                                                                FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                                                                                SortExpression="Member_Name" UniqueName="Member_Name">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Followup_Dt" 
                                                                                                                FilterControlAltText="Filter Followup_Dt column" HeaderText="Followup_Dt" 
                                                                                                                SortExpression="Followup_Dt" UniqueName="Followup_Dt">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entered_by" 
                                                                                                                FilterControlAltText="Filter Entered_by column" HeaderText="Entered_by" 
                                                                                                                SortExpression="Entered_by" UniqueName="Entered_by">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entry_Dt" 
                                                                                                                FilterControlAltText="Filter Entry_Dt column" HeaderText="Entry_Dt" 
                                                                                                                SortExpression="Entry_Dt" UniqueName="Entry_Dt">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                        </Columns>
                                                                                                        <EditFormSettings>
                                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                            </EditColumn>
                                                                                                        </EditFormSettings>
                                                                                                    </MasterTableView>
                                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                                    </FilterMenu>
                                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                                    </HeaderContextMenu>
                                                                                                </telerik:RadGrid>
                                                                                            </asp:Panel>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Label ID="Label179" runat="server" style="font-weight: 700" 
                                                                                                Text="Call Dashboard"></asp:Label>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            <asp:Panel ID="Panel38" runat="server" Height="100%" ScrollBars="Both" 
                                                                                                Width="1140px">
                                                                                                <telerik:RadGrid ID="GD_4" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                                    GridLines="None" Height="100%" Skin="Outlook" Width="100%" PageSize="20">
                                                                                                    <MasterTableView AutoGenerateColumns="False">
                                                                                                        <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                                        <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </RowIndicatorColumn>
                                                                                                        <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                                            <HeaderStyle Width="20px" />
                                                                                                        </ExpandCollapseColumn>
                                                                                                        <Columns>
                                                                                                            <telerik:GridBoundColumn DataField="Entry_Yr" 
                                                                                                                FilterControlAltText="Filter Entry_Yr column" HeaderText="Entry_Yr" 
                                                                                                                SortExpression="Entry_Yr" UniqueName="Entry_Yr">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Scheduled_Mon" 
                                                                                                                FilterControlAltText="Filter Scheduled_Mon column" HeaderText="Scheduled_Mon" 
                                                                                                                SortExpression="Scheduled_Mon" UniqueName="Scheduled_Mon">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="CNT_Members" 
                                                                                                                FilterControlAltText="Filter CNT_Members column" HeaderText="CNT_Members" 
                                                                                                                SortExpression="CNT_Members" UniqueName="CNT_Members">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Members_Engaged" 
                                                                                                                FilterControlAltText="Filter Members_Engaged column" 
                                                                                                                HeaderText="Members_Engaged" SortExpression="Members_Engaged" 
                                                                                                                UniqueName="Members_Engaged">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Members_NOT_Engaged" 
                                                                                                                FilterControlAltText="Filter Members_NOT_Engaged column" 
                                                                                                                HeaderText="Members_NOT_Engaged" SortExpression="Members_NOT_Engaged" 
                                                                                                                UniqueName="Members_NOT_Engaged">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                            <telerik:GridBoundColumn DataField="Entry_Dt" 
                                                                                                                FilterControlAltText="Filter Entry_Dt column" HeaderText="Entry_Dt" 
                                                                                                                SortExpression="Entry_Dt" UniqueName="Entry_Dt">
                                                                                                            </telerik:GridBoundColumn>
                                                                                                        </Columns>
                                                                                                        <EditFormSettings>
                                                                                                            <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                                            </EditColumn>
                                                                                                        </EditFormSettings>
                                                                                                    </MasterTableView>
                                                                                                    <FilterMenu EnableImageSprites="False">
                                                                                                    </FilterMenu>
                                                                                                    <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                                    </HeaderContextMenu>
                                                                                                </telerik:RadGrid>
                                                                                            </asp:Panel>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 124px">
                                                                                            <asp:Label ID="Label176" runat="server" Text="Search By"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadComboBox ID="cboreportsearc" Runat="server" Skin="Simple" 
                                                                                                Width="250px">
                                                                                                <Items>
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Member List" Value="M" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Owner="cboreportsearc" Text="Diagnosis" 
                                                                                                        Value="D" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Notes Listing" Value="N" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Entry date" Value="E" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Followup Date" Value="F" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Not Engaged" Value="NE" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Engaged" Value="EN" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="Dx Date" Value="DX" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="All" Value="A" />
                                                                                                </Items>
                                                                                            </telerik:RadComboBox>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 124px">
                                                                                            <asp:Label ID="Label6" runat="server" Text="Date From"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadDatePicker ID="RadDatePicker1" Runat="server" Skin="Outlook">
                                                                                                <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                                </Calendar>
                                                                                                <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                                </DateInput>
                                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                            </telerik:RadDatePicker>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 124px">
                                                                                            <asp:Label ID="Label177" runat="server" Text="Date To"></asp:Label>
                                                                                        </td>
                                                                                        <td>
                                                                                            <telerik:RadDatePicker ID="RadDatePicker2" Runat="server" Skin="Outlook">
                                                                                                <Calendar Skin="Outlook" UseColumnHeadersAsSelectors="False" 
                                                                                                    UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                                </Calendar>
                                                                                                <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy">
                                                                                                </DateInput>
                                                                                                <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                            </telerik:RadDatePicker>
                                                                                        </td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                        <td>
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="height: 13px; width: 124px">
                                                                                            &nbsp;</td>
                                                                                        <td colspan="2">
                                                                                            <telerik:RadComboBox ID="cboreport" Runat="server" Skin="Outlook" Width="250px">
                                                                                                <Items>
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="HPC Active List" Value="A" />
                                                                                                    <telerik:RadComboBoxItem runat="server" Text="HPC Lapsed List" Value="L" />
                                                                                                </Items>
                                                                                            </telerik:RadComboBox>
                                                                                        </td>
                                                                                        <td style="height: 13px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 124px; height: 42px;">
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                            <telerik:RadButton ID="RadButton2" runat="server" Height="38px" Skin="Sunset" 
                                                                                                Text="Export data" Width="113px">
                                                                                            </telerik:RadButton>
                                                                                            &nbsp;<asp:Label ID="Label8" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                        </td>
                                                                                        <td style="height: 42px">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td colspan="4">
                                                                                            &nbsp;</td>
                                                                                    </tr>
                                                                                </table>
                                                                            </asp:Panel>
                                                                        </telerik:RadPageView>
                                                                    </telerik:RadMultiPage>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Label ID="Label157" runat="server" style="font-weight: 700" 
                                                            Text="Member Notes"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                                            Width="1140px">
                                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                GridLines="None" Height="100%" PageSize="20" Skin="Sunset" Width="100%">
                                                                <MasterTableView AutoGenerateColumns="False">
                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    </RowIndicatorColumn>
                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    </ExpandCollapseColumn>
                                                                    <Columns>
                                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Note_Type" 
                                                                            FilterControlAltText="Filter Note_Type column" HeaderText="Note_Type " 
                                                                            SortExpression="Note_Type" UniqueName="Note_Type">
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridBoundColumn>
                                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                            SortExpression="Notes" UniqueName="Notes">
                                                                        </telerik:GridBoundColumn>
                                                                    </Columns>
                                                                    <EditFormSettings>
                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                        </EditColumn>
                                                                    </EditFormSettings>
                                                                </MasterTableView>
                                                                <ItemStyle Wrap="True" />
                                                                <FilterMenu EnableImageSprites="False">
                                                                </FilterMenu>
                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                </HeaderContextMenu>
                                                            </telerik:RadGrid>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                        </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="lblErr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                            </table>
   </asp:Panel>
   </div>
            </ContentTemplate>
            </asp:UpdatePanel>
</asp:Content>

