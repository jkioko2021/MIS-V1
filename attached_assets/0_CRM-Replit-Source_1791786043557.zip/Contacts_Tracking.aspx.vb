﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False


    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try


            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
            dtdob.DbSelectedDate = Date.Now()

        End If
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            If cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM [CRM].[dbo].[TBL_VALID_LIST]  with(nolock) WHERE MEMBER_NAME  LIKE '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME,[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[POLICY_VALID_FROM],POLICY_VALID_UPTO FROM [CRM].[dbo].[TBL_VALID_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO like '%" & txtsearch.Text & "%' order by DISPLAY_MEMBERSHIP_NO"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEMBER.DataSource = MyDatable
                GDMEMBER.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDMEMBER.DataSource = Nothing
                GDMEMBER.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDMEMBER_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEMBER.SelectedIndexChanged
        Try

            Dim number As String = ""
            lblerr.Text = ""
            number = (DirectCast(GDMEMBER.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()
            SqlAction = "SELECT [DISPLAY_MEMBERSHIP_NO],PROPOSER_DISPLAY_NAME,MEMBER_PRI_ADD_LINE1, [MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],GRP_INDV FROM [CRM].[dbo].[TBL_VALID_LIST]  with(nolock) WHERE DISPLAY_MEMBERSHIP_NO ='" & number & "' order by DISPLAY_MEMBERSHIP_NO"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                txtmemno.Text = MyDatatable.Rows(0).Item("DISPLAY_MEMBERSHIP_NO").ToString()
                txtname.Text = MyDatatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtprop.Text = MyDatatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                cboclient.SelectedValue = MyDatatable.Rows(0).Item("GRP_INDV").ToString()
                dtdob.DbSelectedDate = MyDatatable.Rows(0).Item("MEMBER_BIRTH_DATE").ToString()
                cbogender.SelectedValue = MyDatatable.Rows(0).Item("MEMBER_ADMINISTRATIVE_SEX").ToString()
                txtprimobile.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()
                txtemail.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_EMAIL").ToString()
                txtaddress.Text = MyDatatable.Rows(0).Item("MEMBER_PRI_ADD_LINE1").ToString()
                txtname.Enabled = False
                txtmemno.Enabled = False
                txtprop.Enabled = False
                cboclient.Enabled = False

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            If Len(txtprimobile.Text) < 12 Or Len(txtprimobile.Text) > 12 Then
                lblerr.Text = "Enter The correct Mobile No"
                Exit Sub
            End If
            If txtemail.Text = "" Then
                lblerr.Text = "Enter The correct email"
                Exit Sub
            End If
            If txtid.Text = "" Then
                lblerr.Text = "Enter The correct ID Or Passport No."
                Exit Sub
            End If
            If txtmemno.Text = "" Then
                lblerr.Text = "Select the Mmeber Number"
                Exit Sub
            End If

            MyDBAction.Contact_Member(txtmemno.Text, txtname.Text, txtprimobile.Text, txtsecmobile.Text, txtpin.Text, txtemail.Text, txtid.Text, cbogender.SelectedValue, txtaddress.Text, cbomarital.SelectedValue, Session("UserName").ToString, CDate(Date.Now).ToString("yyyy-MM-dd"), CDate(dtdob.DbSelectedDate).ToString("yyyy-MM-dd"))
            lblerr.Text = "Saved Successfull!"
            txtprop.Text = "" : txtmemno.Text = "" : txtname.Text = "" : txtprimobile.Text = "" : txtsecmobile.Text = "" : txtpin.Text = "" : txtemail.Text = "" : txtid.Text = "" : cbogender.SelectedValue = "" : txtaddress.Text = "" : cbomarital.SelectedValue = "" : dtdob.DbSelectedDate = Date.Now()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub txtname_TextChanged(sender As Object, e As System.EventArgs) Handles txtname.TextChanged

    End Sub
End Class
