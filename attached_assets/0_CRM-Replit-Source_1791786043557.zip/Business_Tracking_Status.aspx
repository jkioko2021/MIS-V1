﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Business_Tracking_Status.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Medium"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
                <ContentTemplate>
                    <div align="center">
                  
                    <asp:Panel ID="Panel1" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                        Width="1176px">
                      
                 
                 <table style="width: 96%; margin-left: 0px;" align="center">
                                <tr>
                                    <td class="style8">
                            
                            <table style="1100: ;">
                                <tr>
                                    <td align="center" bgcolor="#CCCCCC">
                                        <asp:Label ID="Label135" runat="server" Font-Bold="True" 
                                            Text="BUSINESS UPDATE STATUS VIEW" Font-Size="Medium"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center">
                                        <table style="width: 1132px">
                                            <tr>
                                                <td style="width: 3282px" align="right">
                                                    &nbsp;</td>
                                                <td align="right" style="width: 1025px">
                                                    <asp:Label ID="Label175" runat="server" Text=" Business Type"></asp:Label>
                                                </td>
                                                <td style="width: 125px">
                                                    <asp:CheckBox ID="chkall" runat="server" Text="All Records" />
                                                </td>
                                                <td style="width: 264px">
                                                    <asp:CheckBox ID="chkpolicy" runat="server" Text="Policy Docs" />
                                                </td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="right" style="width: 3282px">
                                                    <asp:Label ID="Label141" runat="server" Text="Search by"></asp:Label>
                                                </td>
                                                <td align="right" style="width: 1025px">
                                                    <telerik:RadComboBox ID="cboBusiness" Runat="server" MarkFirstMatch="True" 
                                                        Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" Text="New" 
                                                                Value="N" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" Text="Renewal" 
                                                                Value="R" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Addon" Value="A" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" Text="Termination" 
                                                                Value="T" />
                                                            <telerik:RadComboBoxItem runat="server" Owner="cboBusiness" 
                                                                Text="Reinstatement" Value="RT" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Category Change" Value="CC" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Premium Recon" Value="PR" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Nill_Endr" Value="NE" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Fund_Topup" Value="FT" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Suspension" Value="SU" />
                                                            <telerik:RadComboBoxItem runat="server" Text="Lift Suspension" Value="LS" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 125px">
                                                    <telerik:RadComboBox ID="cbosearch" Runat="server" Skin="Sunset" Width="190px">
                                                        <Items>
                                                            <telerik:RadComboBoxItem runat="server" Text="Proposer Name" Value="P" />
                                                            <telerik:RadComboBoxItem runat="server" Text="File No." Value="F" />
                                                        </Items>
                                                    </telerik:RadComboBox>
                                                </td>
                                                <td style="width: 264px">
                                                    <telerik:RadTextBox ID="txtsearch" Runat="server" Skin="Sunset" Width="250px">
                                                    </telerik:RadTextBox>
                                                </td>
                                                <td>
                                                    <telerik:RadButton ID="btnsearch" runat="server" Skin="Simple" Text="Search">
                                                    </telerik:RadButton>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="width: 3282px">
                                                    <asp:Label ID="FILE_NO" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                        style="font-weight: 700; color: #CC0000; background-color: #FFFFFF"></asp:Label>
                                                </td>
                                                <td style="width: 1025px">
                                                    &nbsp;</td>
                                                <td style="width: 125px">
                                                    &nbsp;</td>
                                                <td style="width: 264px">
                                                    &nbsp;</td>
                                                <td>
                                                    &nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel11" runat="server" Height="100%" ScrollBars="Both" 
                                                        Width="1128px">
                                                        <telerik:RadGrid ID="GDTracking" runat="server" AllowPaging="True" 
                                                            CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="WebBlue" 
                                                            Width="100%">
                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                    <HeaderStyle Width="20px" />
                                                                </RowIndicatorColumn>
                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                    <HeaderStyle Width="20px" />
                                                                </ExpandCollapseColumn>
                                                                <Columns>
                                                                    <telerik:GridButtonColumn CommandName="Select" 
                                                                        FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                        UniqueName="Select">
                                                                        <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                        <ItemStyle Width="50px" />
                                                                    </telerik:GridButtonColumn>
                                                                    <telerik:GridBoundColumn DataField="Receive_dt" 
                                                                        FilterControlAltText="Filter Receive_dt column" HeaderText="Receive_dt" 
                                                                        SortExpression="Receive_dt" UniqueName="Receive_dt">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="File_No" 
                                                                        FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                                        SortExpression="File_No" UniqueName="File_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Premium" 
                                                                        FilterControlAltText="Filter Premium column" HeaderText="Premium" 
                                                                        SortExpression="Premium" UniqueName="Premium">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="eOx_Invoice_No" 
                                                                        FilterControlAltText="Filter eOx_Invoice_No column" HeaderText="Invoice_No" 
                                                                        SortExpression="eOx_Invoice_No" UniqueName="eOx_Invoice_No">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                        FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                        SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Client_Type" 
                                                                        FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                        SortExpression="Client_Type" UniqueName="Client_Type">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Business_Type" 
                                                                        FilterControlAltText="Filter Business_Type column" HeaderText="Type" 
                                                                        SortExpression="Business_Type" UniqueName="Business_Type">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="File_Status" 
                                                                        FilterControlAltText="Filter File_Status column" HeaderText="Status" 
                                                                        SortExpression="File_Status" UniqueName="File_Status">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Allocated_to" 
                                                                        FilterControlAltText="Filter Allocated_to column" HeaderText="Allocated_to" 
                                                                        SortExpression="Allocated_to" UniqueName="Allocated_to">
                                                                    </telerik:GridBoundColumn>
                                                                    <telerik:GridBoundColumn DataField="Product" 
                                                                        FilterControlAltText="Filter Product column" HeaderText="Product" 
                                                                        SortExpression="Product" UniqueName="Product">
                                                                    </telerik:GridBoundColumn>
                                                                           <telerik:GridBoundColumn DataField="Syst" 
                                                                        FilterControlAltText="Filter Syst column" HeaderText="System" 
                                                                        SortExpression="Syst" UniqueName="Syst">
                                                                    </telerik:GridBoundColumn>
                                                                </Columns>
                                                                <EditFormSettings>
                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                    </EditColumn>
                                                                </EditFormSettings>
                                                            </MasterTableView>
                                                            <ItemStyle Wrap="False" />
                                                            <FilterMenu EnableImageSprites="False">
                                                            </FilterMenu>
                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                            </HeaderContextMenu>
                                                        </telerik:RadGrid>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                               
                                                <td colspan="5">
                                                    <asp:Panel ID="Panel33" runat="server">
                                                        <table style="width: 99%">
                                                            <tr>
                                                                <td>
                                                                    <asp:Label ID="Label176" runat="server" Font-Bold="True" Text="Payment Info"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1128px">
                                                                        <telerik:RadGrid ID="GD_Pay" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                            GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="File_No">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                    <HeaderStyle Width="20px" />
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                    <HeaderStyle Width="20px" />
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridBoundColumn DataField="File_No" 
                                                                                        FilterControlAltText="Filter File_No column" HeaderText="File_No" 
                                                                                        SortExpression="File_No" UniqueName="File_No">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Proposer_Name" 
                                                                                        FilterControlAltText="Filter Proposer_Name column" HeaderText="Proposer_Name" 
                                                                                        SortExpression="Proposer_Name" UniqueName="Proposer_Name">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Client_Type" 
                                                                                        FilterControlAltText="Filter Client_Type column" HeaderText="Client_Type" 
                                                                                        SortExpression="Client_Type" UniqueName="Client_Type">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Premium" DataFormatString="{0:### ##0.0}" 
                                                                                        FilterControlAltText="Filter Premium column" HeaderText="Premium" 
                                                                                        SortExpression="Premium" UniqueName="Premium">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Paid_Amt" DataFormatString="{0:### ##0.0}" 
                                                                                        FilterControlAltText="Filter Paid_Amt column" HeaderText="Paid_Amt" 
                                                                                        SortExpression="Paid_Amt" UniqueName="Paid_Amt">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Pay_Ref_No" 
                                                                                        FilterControlAltText="Filter Pay_Ref_No column" HeaderText="Pay_Ref_No" 
                                                                                        SortExpression="Pay_Ref_No" UniqueName="Pay_Ref_No">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="File_Status" 
                                                                                        FilterControlAltText="Filter File_Status column" HeaderText="File_Status" 
                                                                                        SortExpression="File_Status" UniqueName="File_Status">
                                                                                    </telerik:GridBoundColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <ItemStyle Wrap="False" />
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Label ID="Label177" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                                                        Width="1100px">
                                                                        <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                            GridLines="None" Height="100%" Skin="Web20" Width="100%">
                                                                            <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                                <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                    <HeaderStyle Width="20px" />
                                                                                </RowIndicatorColumn>
                                                                                <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                    <HeaderStyle Width="20px" />
                                                                                </ExpandCollapseColumn>
                                                                                <Columns>
                                                                                    <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                                        FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                                        SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="File_No" 
                                                                                        FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                                        SortExpression="File_No" UniqueName="File_No">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                                        FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                                        SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                                        FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                                        SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="File_Name" 
                                                                                        FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                                        SortExpression="File_Name" UniqueName="File_Name">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Doc_Ref" 
                                                                                        FilterControlAltText="Filter Doc_Ref column" HeaderText="Doc_Ref" 
                                                                                        SortExpression="Doc_Ref" UniqueName="Doc_Ref">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="Upload_By" 
                                                                                        FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                                        SortExpression="Upload_By" UniqueName="Upload_By">
                                                                                    </telerik:GridBoundColumn>
                                                                                    <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                                        SortExpression="DOC_ID">
                                                                                        <ItemTemplate>
                                                                                            <asp:LinkButton ID="lnkDownload0" runat="server" 
                                                                                                CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                                        </ItemTemplate>
                                                                                    </telerik:GridTemplateColumn>
                                                                                </Columns>
                                                                                <EditFormSettings>
                                                                                    <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                    </EditColumn>
                                                                                </EditFormSettings>
                                                                            </MasterTableView>
                                                                            <FilterMenu EnableImageSprites="False">
                                                                            </FilterMenu>
                                                                            <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                            </HeaderContextMenu>
                                                                        </telerik:RadGrid>
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <asp:Panel ID="Panel36" runat="server" BorderStyle="Solid" Height="100%" 
                                                                        ScrollBars="Horizontal" Width="1071px">
                                                                        <asp:Literal ID="ltEmbed" runat="server" />
                                                                    </asp:Panel>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </asp:Panel>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="5">
                                                    &nbsp;</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                                          </td>
                                          </tr>
                                          <tr>
                                              <td>
                                                  <asp:Label ID="Label178" runat="server" Font-Bold="True" Text="AML Risk Details"></asp:Label>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td>
                                                  <asp:Panel ID="Panel37" runat="server" Height="100%" ScrollBars="Both" Width="1128px">
                                                      <telerik:RadGrid ID="GD_AML" runat="server" AllowPaging="True" CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Web20" Width="100%">
                                                          <MasterTableView AutoGenerateColumns="False" >
                                                              <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                              <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                  <HeaderStyle Width="20px" />
                                                              </RowIndicatorColumn>
                                                              <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                  <HeaderStyle Width="20px" />
                                                              </ExpandCollapseColumn>
                                                              <Columns>
                                                               
                                                                  <telerik:GridBoundColumn DataField="Risk_Rating" FilterControlAltText="Filter Risk_Rating column" HeaderText="Risk_Rating" SortExpression="Risk_Rating" UniqueName="Risk_Rating">
                                                                  </telerik:GridBoundColumn>
                                                              
                                                                  <telerik:GridBoundColumn DataField="Description" FilterControlAltText="Filter Description column" HeaderText="Description" SortExpression="Description" UniqueName="Reason">
                                                                  </telerik:GridBoundColumn>
                                                                 
                                                              </Columns>
                                                              <EditFormSettings>
                                                                  <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                  </EditColumn>
                                                              </EditFormSettings>
                                                          </MasterTableView>
                                                          <ItemStyle Wrap="False" />
                                                          <FilterMenu EnableImageSprites="False">
                                                          </FilterMenu>
                                                          <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                          </HeaderContextMenu>
                                                      </telerik:RadGrid>
                                                  </asp:Panel>
                                              </td>
                                </tr>
                                          <tr>
                                              <td bgcolor="#666666">
                                                  &nbsp;</td>
                                          </tr>
                                          <tr>
                                              <td style="height: 34px">
                                                  <table style="width: 100%">
                                                      <tr>
                                                          <td style="width: 193px">
                                                              <asp:Label ID="Label154" runat="server" Text="Entered By"></asp:Label>
                                                          </td>
                                                          <td style="width: 246px">
                                                              <asp:Label ID="lblenteredby" runat="server"></asp:Label>
                                                          </td>
                                                          <td>
                                                              <asp:Label ID="Label155" runat="server" Text="updated by"></asp:Label>
                                                          </td>
                                                          <td>
                                                              <asp:Label ID="lblupdateby" runat="server"></asp:Label>
                                                          </td>
                                                      </tr>
                                                      <tr>
                                                          <td style="width: 193px">
                                                              &nbsp;</td>
                                                          <td style="width: 246px">
                                                              &nbsp;</td>
                                                          <td>
                                                              &nbsp;</td>
                                                          <td>
                                                              &nbsp;</td>
                                                      </tr>
                                                  </table>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td style="height: 41px">
                                                  &nbsp;<asp:Label ID="lblerr" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                      ForeColor="Red"></asp:Label>
                                                  <asp:HiddenField ID="HiddenField1" runat="server" />
                                              </td>
                                          </tr>
                                          <tr>
                                              <td>
                                                  <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                                      Width="100%">
                                                      <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                          GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                          <MasterTableView AutoGenerateColumns="False">
                                                              <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                              <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                              </RowIndicatorColumn>
                                                              <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                              </ExpandCollapseColumn>
                                                              <Columns>
                                                                  <telerik:GridBoundColumn DataField="Note_date" 
                                                                      FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                                      ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                                      <ItemStyle Width="100px" />
                                                                  </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="File_No" 
                                                                      FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                      ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                                      <ItemStyle Width="50px" />
                                                                  </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="Note_From" 
                                                                      FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                                      ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                                      <ItemStyle Width="100px" />
                                                                  </telerik:GridBoundColumn>
                                                                  <telerik:GridBoundColumn DataField="Notes" 
                                                                      FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                                      SortExpression="Notes" UniqueName="Notes">
                                                                  </telerik:GridBoundColumn>
                                                              </Columns>
                                                              <EditFormSettings>
                                                                  <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                  </EditColumn>
                                                              </EditFormSettings>
                                                          </MasterTableView>
                                                          <ItemStyle Wrap="False" />
                                                          <FilterMenu EnableImageSprites="False">
                                                          </FilterMenu>
                                                          <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                          </HeaderContextMenu>
                                                      </telerik:RadGrid>
                                                  </asp:Panel>
                                              </td>
                                          </tr>
                                          </table>
                     
            </asp:Panel>                    
  
   </div>
            </ContentTemplate>
       
            </asp:UpdatePanel>
</asp:Content>

