﻿Imports System.Data
Imports System.IO
Imports DocManage
Imports Mymail
Imports Telerik.Web.UI
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Dim email As New Mail

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""

                dtupload.DbSelectedDate = Date.Now
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing
                Session("med") = 0
                Session("Allocate") = 0
                Session("INVOICED") = 0
                GD_DOCS.DataSource = Nothing
                GD_DOCS.DataBind()
                GDTrackingRef.DataSource = Nothing
                GDTrackingRef.DataBind()
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()
                GD_STATE.DataSource = Nothing
                GD_STATE.DataBind()
                'ltEmbed.Text = ""


                Me.Str = "SELECT  [DOC_CODE],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] WHERE ACTIVE=1  AND CODE=5"
                Me.MyDatatable = TryCast(Me.MyDBAction.DBAction(Me.Str, DataManagement.DBActionType.DataTable, "", Nothing), DataTable)
                Dim cbodocs As RadComboBox = Me.cbodocs
                cbodocs.Items.Clear()
                cbodocs.DataSource = Me.MyDatatable
                cbodocs.DataTextField = Me.MyDatatable.Columns("DOC_NAME").ToString()
                cbodocs.DataValueField = Me.MyDatatable.Columns("DOC_CODE").ToString()
                cbodocs.DataBind()
                Loadgrid()

            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If
    End Sub
    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            If cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT DISTINCT [PROPOSER_ID], PROPOSER_DISPLAY_NAME,CLIENT_TYPE   FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROPOSER_LIST] WITH (NOLOCK)  WHERE POLICY_CODE LIKE '%" & Trim(txtsearch.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT DISTINCT [PROPOSER_ID], PROPOSER_DISPLAY_NAME,CLIENT_TYPE  FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROPOSER_LIST]  WHERE PROPOSER_DISPLAY_NAME  LIKE '%" & Trim(txtsearch.Text) & "%' "
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()
            End If
        Catch ex As Exception
            lblupload.Text = ex.Message
        End Try
    End Sub
    Private Sub Loadgrid()
        ' SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE    Is_Active=1 and Requested=0"

        SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE Entered_By = '" & Session("username") & "' AND Is_Active=1 and Requested=0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTrackingRef.DataSource = MyDatable
            GDTrackingRef.DataBind()
            MyDatable = Nothing
        Else
            GDTrackingRef.DataSource = Nothing
            GDTrackingRef.DataBind()
        End If
    End Sub

    Public Sub loadGrid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            GDTrackingRef.DataSource = Nothing
            GDTrackingRef.DataBind()

            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = Nothing
                GD_DOCS.DataBind()
            End If

            SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE File_No = '" & FILE_NO.Text & "' AND Is_Active=1 and Requested=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTrackingRef.DataSource = MyDatable
                GDTrackingRef.DataBind()
                MyDatable = Nothing
            Else
                GDTrackingRef.DataSource = Nothing
                GDTrackingRef.DataBind()
            End If

            If lbltype.Text = "RET" Then
                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & FILE_NO.Text & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            ElseIf cbotype.Text = "CORP" Then
                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_CORPORATE_NOTES] WHERE  proposer_id ='" & FILE_NO.Text & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If

            End If


            'Notes


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Public Sub Generate_Task()

        SqlAction = "SELECT ISNULL((MAX(Refund_id)+1),1) NUMBER FROM [dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            RefNo.Text = "AARKE/REF" & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""
            FILE_NO.Text = RefNo.Text
        End If
    End Sub
    Protected Sub btnsave_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try
            If cbotype.SelectedValue = "" Then
                lblsave.Text = "Select the Refund Type"
                txtname.Focus()
                txtname.BackColor = Drawing.Color.Red
                Exit Sub
            End If
            If txtname.Text = "" Then
                lblsave.Text = "Enter the Payee Name"
                txtname.Focus()
                txtname.BackColor = Drawing.Color.Red
                Exit Sub

            End If
            If txtemail.Text = "" Then
                lblsave.Text = "Enter the email address"
                txtemail.Focus()
                txtemail.BackColor = Drawing.Color.Red
                Exit Sub

            End If
            If txtmobile.Text = "" Then
                lblsave.Text = "Enter the Mobile Number"
                txtmobile.Focus()
                txtmobile.BackColor = Drawing.Color.Red
                Exit Sub
            End If


            'If txtrefund.Text > 0 Then
            '    lblsave.Text = "Invalid Amount to refund"
            '    txtrefund.Focus()
            '    txtrefund.BackColor = Drawing.Color.Red
            '    Exit Sub
            'End If

            If HiddenField1.Value = 0 Then
                Generate_Task()
            End If

            MyDBAction.Save_Refund(RefNo.Text, RefNo.Text, txtpaid.Text, txtrefund.Text, txtname.Text, txtemail.Text, txtmobile.Text, "REF-REGISTERED", cbotype.SelectedValue, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"), lbltype.Text, LBLPROP.Text, txtproposer.Text)
            'For Each MyItem In chklist.Items
            '    If MyItem.Selected = True Then
            '        MyDBAction.UPLOAD_ITEMS(FILE_NO.Text, MyItem.value, MyItem.TEXT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"))
            '    End If
            'Next
            loadGrid(FILE_NO.Text)
            lblsave.Text = "Saved Successfull!"



        Catch ex As Exception
            lblsave.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String

        lblupload.Text = ""
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If cbodocs.SelectedValue = "" Then
                lblerr.Text = "You must enter Document Name!"
                Exit Sub
            End If

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                ' MyDBAction.UPLOAD_File_DOCS(bytes, filename, contenttype, FILE_NO.Text, Trim(txttitle.Text.ToUpper), CDate(dtupload.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), DOC_ID.Text)
                Me.MyDBAction.UPLOAD_ITEMS_1(Me.FILE_NO.Text, Me.cbodocs.SelectedValue, Me.cbodocs.Text, DateTime.Now.ToString("yyyy-MM-dd"), Me.Session("username"), bytes, filename, contenttype)

                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green

                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            loadGrid(FILE_NO.Text)

            DOC_ID.Text = ""
            'lbltaskno.Text = ""

            dtupload.DbSelectedDate = Date.Now

        Catch ex As Exception
            lblupload.Text = ex.Message
        End Try

    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub btnforward_Click(sender As Object, e As System.EventArgs) Handles btnforward.Click
        Try
            If LBLPROP.Text = "" Then
                lblerr.Text = "Select the Proposer Name"
                Exit Sub
            End If

            SqlAction = "SELECT  File_Name FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE File_No='" & FILE_NO.Text & "' AND ACTIVE=1 AND Upload_Done=0"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                btnsave.Enabled = True
                lblerr.Text = "You must upload the Missing Documents!"
                Exit Sub
            Else
                UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] SET Request_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',[Request_By]= '" & Session("username") & "',Requested=1,[Refund_Status]='SUBMITTED'  WHERE [Refund_No]='" & RefNo.Text & "'")

                'UpdateRecord("UPDATE  [DATA_REPOSITORY_DB].[dbo].[MASTER_DEBITS_REGISTER]  SET REFUND_REQUESTED=1   WHERE [INVOICE_NO]='" & FILE_NO.Text & "'")

                If txtcomment.Text <> "" Then
                    If Session("CLIENT_TYPE") = "RET" Then
                        MyDBAction.TASK_MESSAGES(RefNo.Text, txtcomment.Text, Session("username"), Date.Now(), "PREM-REFUND", "RETAIL")

                    Else
                        MyDBAction.TASK_MESSAGES_CORP(RefNo.Text, txtcomment.Text, Session("username"), Date.Now(), "PREM-REFUND", "CORPORATE")

                    End If

                End If
            End If
            lblerr.Text = "Submitted successfull! REFUND NO." & RefNo.Text
            loadGrid(FILE_NO.Text)
            GDPROP.DataSource = Nothing
            GDPROP.DataBind()
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            RefNo.Text = ""
            FILE_NO.Text = ""
            txtname.Text = ""
            lbltype.Text = ""
            txtemail.Text = ""
            txtmobile.Text = ""
            txtproposer.Text = ""
            txtrefund.Text = 0
            txtpaid.Text = 0
            txtDR.Text = 0
            txtCR.Text = 0
            txtcomment.Text = ""


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GDTrackingRef_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTrackingRef.SelectedIndexChanged
        Try
            Dim stst As String = ""
            FILE_NO.Text = ""
            txtname.Text = ""
            lbltype.Text = ""
            txtemail.Text = ""
            txtmobile.Text = ""
            txtproposer.Text = ""
            txtrefund.Text = 0
            txtpaid.Text = 0
            txtDR.Text = 0
            txtCR.Text = 0
            txtcomment.Text = ""

            HiddenField1.Value = 1
            'ltEmbed.Text = ""

            stst = (DirectCast(GDTrackingRef.SelectedItems(0), GridDataItem)).GetDataKeyValue("Refund_No").ToString()
            SqlAction = "SELECT Refund_No,[File_No],payee_email,Payee_Mobile,Payee_Name,[Amount_Paid],[Refund_Amt],Proposer_id,CLIENT_TYPE ,Proposer FROM  TBL_MIS_BUSINESS_TRACKING_REFUNDS WHERE  Refund_No ='" & stst & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RefNo.Text = MyDatable.Rows(0).Item("Refund_No").ToString()
                FILE_NO.Text = MyDatable.Rows(0).Item("File_No").ToString()
                txtemail.Text = MyDatable.Rows(0).Item("payee_email").ToString()
                txtmobile.Text = MyDatable.Rows(0).Item("Payee_Mobile").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Payee_Name").ToString()
                txtpaid.Text = MyDatable.Rows(0).Item("Amount_Paid").ToString()
                txtrefund.Text = MyDatable.Rows(0).Item("Refund_Amt").ToString()
                LBLPROP.Text = MyDatable.Rows(0).Item("Proposer_id").ToString()
                lbltype.Text = MyDatable.Rows(0).Item("CLIENT_TYPE").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("Proposer").ToString()

            End If

            txtsearch.Enabled = False
            loadGrid(RefNo.Text)
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try
            GD_STATE.DataSource = Nothing
            GD_STATE.DataBind()
            GDTrackingRef.DataSource = Nothing
            GDTrackingRef.DataBind()
            FILE_NO.Text = ""
            txtname.Text = ""
            lbltype.Text = ""
            txtemail.Text = ""
            txtmobile.Text = ""
            txtrefund.Text = 0
            txtpaid.Text = 0
            txtDR.Text = 0
            txtCR.Text = 0
            txtcomment.Text = ""

            Session("PROPOSER_ID") = Nothing
            Session("CLIENT_TYPE") = Nothing
            Dim dr As Decimal = 0
            Dim cr As Decimal = 0



            LBLPROP.Text = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("PROPOSER_ID").ToString()

            SqlAction = "SELECT  [PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,PERIOD_FROM,PERIOD_TO,CLIENT_TYPE FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_PROPOSER_LIST]  WHERE PROPOSER_ID  = '" & LBLPROP.Text & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then

                txtname.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER_DISPLAY_NAME").ToString()
                lbltype.Text = MyDatable.Rows(0).Item("CLIENT_TYPE").ToString()
                'txtmobile.Text = MyDatable.Rows(0).Item("MEMBER_PRI_MOBILE").ToString()

                SqlAction = "SELECT DISTINCT  [POLICY_CODE], Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & LBLPROP.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_STATE.DataSource = MyDatable
                    GD_STATE.DataBind()
                    Session("STATE_01") = MyDatable
                    dr = Convert.ToInt32(MyDatable.Compute("SUM(DR)", String.Empty))
                    cr = Convert.ToInt32(MyDatable.Compute("sum(CR)", String.Empty))
                    txtDR.Text = dr
                    txtCR.Text = cr

                    txtpaid.Text = dr - cr
                    txtrefund.Text = txtpaid.Text


                    If txtpaid.Text > 0 Then
                        txtname.Enabled = False
                        txtemail.Enabled = False
                        txtname.Text = "AAR INSURANCE LTD"
                        txtemail.Text = "info@aar.co.ke"
                        txtmobile.Text = "020"
                    Else
                        txtname.Enabled = True
                        txtemail.Enabled = True
                    End If
                Else
                    GD_STATE.DataSource = Nothing
                    GD_STATE.DataBind()
                End If

                SqlAction = "SELECT  [Refund_No],[File_No],[Amount_Paid],[Refund_Amt] ,[Payee_Name],[Payee_eMail],[Payee_Mobile],[Refund_Status],[Refund_Type],[Request_Dt],Entered_By FROM [CRM].[dbo].[TBL_MIS_BUSINESS_TRACKING_REFUNDS] WITH (NOLOCK) WHERE Proposer_ID = '" & LBLPROP.Text & "' AND Is_Active=1 and requested=0"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDTrackingRef.DataSource = MyDatable
                    GDTrackingRef.DataBind()
                    Session("DAD_T") = MyDatable
                    MyDatable = Nothing
                    MyDatable = Nothing
                Else
                    GDTrackingRef.DataSource = Nothing
                    GDTrackingRef.DataBind()
                End If

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try


    End Sub
    Protected Sub GD_STATE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_STATE.PageIndexChanged
        GD_STATE.CurrentPageIndex = e.NewPageIndex
        GD_STATE.DataSource = Session("STATE_01")
        GD_STATE.DataBind()
    End Sub

    Protected Sub btnstatement_Click(sender As Object, e As System.EventArgs) Handles btnstatement.Click
        Try
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement
            Dim StrQuery As String = ""
            Dim Str_1 As String = ""
            Dim Str_E As String = ""
            Dim Reportname As String = ""
            Dim SelectionFormula As String = ""
            Dim MyDatable As New Data.DataTable
            Dim MyDatable_E As New Data.DataTable
            Dim MyDatable_1 As New Data.DataTable

            If LBLPROP.Text = "" Then
                lblsave.Text = "Select Proposer Name"
                Exit Sub
            End If


            Session("PRINT") = "PDF"
            Session("Report_") = "Customer Statement"

            Str = "SELECT DISTINCT  [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[ACTION_TYPE],[TOTAL_MEMBERS],[REFERENCE_NO],Convert(VarChar(10),CAST([TRANSACTION_DATE] AS DATETIME),126)[TRANSACTION_DATE],[DR],[CR], [USER_DISPLAY_NAME],Convert(VarChar(10),CAST([PERIOD_FROM] AS DATETIME),126) [PERIOD_FROM],Convert(VarChar(10),CAST([PERIOD_TO] AS DATETIME),126)[PERIOD_TO] FROM [DATA_REPOSITORY_DB].[dbo].[TBL_MIS_statement_ageing] WHERE PROPOSER_ID ='" & LBLPROP.Text & "' AND Convert(VarChar(10),CAST(TRANSACTION_DATE AS DATETIME),126) <='" & CDate(Date.Now()).ToString("yyyy-MM-dd") & "' ORDER BY TRANSACTION_DATE DESC,REFERENCE_NO"

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)

            If Str <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = MyDatable
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Session("DA_G") = Nothing

                'Session("PRINT") = Nothing
                'Session("Report_") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub



    Protected Sub GD_DOCS_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GD_DOCS.NeedDataSource

    End Sub

    Protected Sub GDTrackingRef_NeedDataSource(sender As Object, e As GridNeedDataSourceEventArgs) Handles GDTrackingRef.NeedDataSource

    End Sub

    Private Sub GD_DOCS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GD_DOCS.SelectedIndexChanged

    End Sub
End Class
