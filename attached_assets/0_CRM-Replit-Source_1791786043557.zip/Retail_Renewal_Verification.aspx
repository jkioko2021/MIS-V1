﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Retail_Renewal_Verification.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    N<asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%" align="center">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="2">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="RETAIL DATA VERIFICATION"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1196px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 869px">
                                        &nbsp;</td>
                                    <td style="width: 154px">
                                        <asp:Label ID="Label2" runat="server" Text="Period From"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadDatePicker ID="DTEXTRFROM" Runat="server" Enabled="False" 
                                            Skin="Sunset">
                                            <calendar skin="Sunset" usecolumnheadersasselectors="False" 
                                                userowheadersasselectors="False" viewselectortext="x">
                                            </calendar>
                                            <dateinput dateformat="dd/MM/yyyy" displaydateformat="dd/MM/yyyy">
                                            </dateinput>
                                            <datepopupbutton hoverimageurl="" imageurl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 869px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 154px">
                                        <asp:Label ID="Label198" runat="server" Text="Period To"></asp:Label>
                                    </td>
                                    <td>
                                        <telerik:RadDatePicker ID="DTEXTRACTTO" Runat="server" Enabled="False" 
                                            Skin="Sunset">
                                            <calendar skin="Sunset" usecolumnheadersasselectors="False" 
                                                userowheadersasselectors="False" viewselectortext="x">
                                            </calendar>
                                            <dateinput dateformat="dd/MM/yyyy" displaydateformat="dd/MM/yyyy">
                                            </dateinput>
                                            <datepopupbutton hoverimageurl="" imageurl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td>
                        <asp:Panel ID="Panel4" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1200px">
                            <table style="width: 100%">
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel38" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH_4" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PERIOD">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>

                                                         <telerik:GridButtonColumn CommandName="Select" 
                                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                                            UniqueName="Select">
                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                            <ItemStyle Width="100px" />
                                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD" 
                                                            FilterControlAltText="Filter PERIOD column" HeaderText="PERIOD" 
                                                            SortExpression="PERIOD" UniqueName="PERIOD">
                                                        </telerik:GridBoundColumn>
                                                          
                                                        <telerik:GridBoundColumn DataField="CNT_POLICY" 
                                                            FilterControlAltText="Filter CNT_POLICY column" HeaderText="CNT_POLICY" 
                                                            SortExpression="CNT_POLICY" UniqueName="CNT_POLICY">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CNT_LIVES" 
                                                            FilterControlAltText="Filter CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                            SortExpression="CNT_LIVES" UniqueName="CNT_LIVES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_RATE" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter IP_RATE column" HeaderText="IP PREMIUM" 
                                                            ItemStyle-Wrap="False" SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OP_RATE" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter OP_RATE column" HeaderText="OP PREMIUM" 
                                                            SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="DEN_RATE" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter DEN_RATE column" HeaderText="DEN PREMIUM" 
                                                            SortExpression="DEN_RATE" UniqueName="DEN_RATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OPT_RATE" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter OPT_RATE column" HeaderText="OPT PREMIUM" 
                                                            SortExpression="OPT_RATE" UniqueName="OPT_RATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="LEVIES" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter LEVIES column" HeaderText="LEVIES" 
                                                            SortExpression="LEVIES" UniqueName="LEVIES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="TOTAL" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter TOTAL column" HeaderText="TOTAL" 
                                                            SortExpression="TOTAL" UniqueName="TOTAL">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Label ID="Label202" runat="server" style="font-weight: 700" 
                                            Text="Summary Plan"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH_2" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%" 
                                                PageSize="20">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="PLAN_NAME" 
                                                            FilterControlAltText="Filter PLAN_NAME column" HeaderText="PLAN_NAME" 
                                                            SortExpression="PLAN_NAME" UniqueName="PLAN_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CNT_POLICY" 
                                                            FilterControlAltText="Filter CNT_POLICY column" HeaderText="CNT_POLICY" 
                                                            SortExpression="CNT_POLICY" UniqueName="CNT_POLICY">
                                                        </telerik:GridBoundColumn>
                                                              <telerik:GridBoundColumn DataField="CNT_LIVES" 
                                                            FilterControlAltText="Filter CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                            SortExpression="CNT_LIVES" UniqueName="CNT_LIVES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_RATE" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter IP_RATE column" HeaderText="IP PREMIUM" 
                                                            ItemStyle-Wrap="False" SortExpression="IP_RATE" UniqueName="IP_RATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OP_RATE" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter OP_RATE column" HeaderText="OP PREMIUM" 
                                                            SortExpression="OP_RATE" UniqueName="OP_RATE">
                                                        </telerik:GridBoundColumn>
                                                         <telerik:GridBoundColumn DataField="DEN_RATE" 
                                                            DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter DEN_RATE column" HeaderText="DEN PREMIUM" 
                                                            SortExpression="DEN_RATE" UniqueName="DEN_RATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="OPT_RATE" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter OPT_RATE column" HeaderText="OPT PREMIUM" 
                                                            SortExpression="OPT_RATE" UniqueName="OPT_RATE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="LEVIES" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter LEVIES column" HeaderText="LEVIES" 
                                                            SortExpression="LEVIES" UniqueName="LEVIES">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="TOTAL" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter TOTAL column" HeaderText="TOTAL" 
                                                            SortExpression="TOTAL" UniqueName="TOTAL">
                                                        </telerik:GridBoundColumn>
                                                      
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel36" runat="server">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td style="width: 135px">
                                                        <asp:Label ID="Label201" runat="server" Text="Reports"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadComboBox ID="cborpt" Runat="server" AutoPostBack="True" 
                                                            Skin="Simple" Width="210px">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" Text="0" Value="0" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" Text="Renewal List" 
                                                                    Value="RL" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" 
                                                                    Text="Summary Missing Rates" Value="SSR" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" Text="Loading Per Policy" 
                                                                    Value="LPP" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" 
                                                                    Text="Loading Per Ind" Value="LPI" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cborpt" 
                                                                    Text="Summary Per SCheme" Value="SPC" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 135px">
                                                        &nbsp;</td>
                                                    <td>
                                                        <telerik:RadButton ID="btnsubmit1" runat="server" Skin="Simple" 
                                                            Text="Export Data">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td bgcolor="#666666" colspan="4">
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 135px">
                                                        <asp:Label ID="Label203" runat="server" Text="Verification"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadComboBox ID="cboverify" Runat="server" AutoPostBack="True" 
                                                            Skin="Simple" Width="210px">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboverify" Text="0" Value="0" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboverify" Text="Validate" 
                                                                    Value="1" />
                                                                <telerik:RadComboBoxItem runat="server" Owner="cboverify" Text="Reverse" 
                                                                    Value="0" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 135px">
                                                        &nbsp;</td>
                                                    <td>
                                                        <telerik:RadButton ID="btnsubmit2" runat="server" Skin="Simple" Text="Submit">
                                                        </telerik:RadButton>
                                                        <asp:Label ID="lblerror" runat="server" ForeColor="Red"></asp:Label>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                        &nbsp;<asp:Label ID="Label204" runat="server" style="font-weight: 700" 
                                            Text="MISSING RATES"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8">
                                        <asp:Panel ID="Panel37" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDSEARCH_3" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="PLAN_NAME" 
                                                            FilterControlAltText="Filter PLAN_NAME column" HeaderText="PLAN_NAME" 
                                                            SortExpression="PLAN_NAME" UniqueName="PLAN_NAME">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                            FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                            SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CNT_POLICY" 
                                                            FilterControlAltText="Filter CNT_POLICY column" HeaderText="CNT_POLICY" 
                                                            SortExpression="CNT_POLICY" UniqueName="CNT_POLICY">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="CNT_LIVES" 
                                                            FilterControlAltText="Filter CNT_LIVES column" HeaderText="CNT_LIVES" 
                                                            SortExpression="CNT_LIVES" UniqueName="CNT_LIVES">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="IP_LIMIT" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter IP_LIMIT column" HeaderText="IP LIMIT" 
                                                            ItemStyle-Wrap="False" SortExpression="IP_LIMIT" UniqueName="IP_LIMIT">
                                                        </telerik:GridBoundColumn>

                                                        <telerik:GridBoundColumn DataField="IP_RATE" DataFormatString="{0:#,#.##}" 
                                                            FilterControlAltText="Filter IP_RATE column" HeaderText="IP PREMIUM" 
                                                            SortExpression="OP_RATE" UniqueName="IP_RATE">
                                                        </telerik:GridBoundColumn>
                                                     
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
      
    </asp:UpdatePanel>
</asp:Content>


