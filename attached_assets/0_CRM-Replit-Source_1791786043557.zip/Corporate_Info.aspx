﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Corporate_Info.aspx.vb" Inherits="_Default" %>
<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="Red" 
                Text="Please Wait...." Font-Size="Larger"></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="height: 100%; width: 100%;">
                <tr>
                    <td>
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1213px">
                            <table style="width: 99%">
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel13" runat="server" Height="100%">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td>
                                                        &nbsp;</td>
                                                    <td>
                                                        <asp:Label ID="Label139" runat="server" style="font-weight: 700" 
                                                            Text="Corporate  name"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <telerik:RadTextBox ID="TXTSEARCH" Runat="server" 
                                                            Skin="Outlook" Width="250px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td>
                                                        <telerik:RadButton ID="cmdview" runat="server" Skin="Simple" Text="View" 
                                                            Width="157px">
                                                        </telerik:RadButton>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel12" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="1200px">
                                            <telerik:RadGrid ID="GDPROP" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="PROPOSER_ID">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="Select" 
                                                            Text="Select" UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="PROPOSER_DISPLAY_NAME" 
                                                            FilterControlAltText="Filter PROPOSER_DISPLAY_NAME column" 
                                                            HeaderText="PROPOSER_DISPLAY_NAME" SortExpression="PROPOSER_DISPLAY_NAME" 
                                                            UniqueName="PROPOSER_DISPLAY_NAME">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                            FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                            SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                            SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                            DataFormatString="{0:yyyy-MM-dd}" 
                                                            FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                            SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                        </telerik:GridBoundColumn>
                                                     
                                                          <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                            FilterControlAltText="Filter POLICY_STATUS column" HeaderText="POLICY_STATUS" 
                                                            SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <PagerStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="LBLFAMNO" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Label ID="Label146" runat="server" style="font-weight: 700" Text="RM"></asp:Label>
                                        :<asp:Label ID="RMNAME" runat="server" style="font-weight: 700"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadTabStrip ID="RadTabStrip1" runat="server" 
                                            MultiPageID="RadMultiPage1" SelectedIndex="3" Skin="Office2007">
                                            <Tabs>
                                                <telerik:RadTab runat="server" PageViewID="V5" Text="Benefit Listing">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" PageViewID="V2" Text="Premium Statement">
                                                </telerik:RadTab>
                                                <telerik:RadTab runat="server" Owner="RadTabStrip1" PageViewID="V7" 
                                                    Text="Non-Medical Policies">
                                                </telerik:RadTab>
                                            </Tabs>
                                        </telerik:RadTabStrip>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <telerik:RadMultiPage ID="RadMultiPage1" Runat="server">
                                            <telerik:RadPageView ID="V2" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel1" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="3">
                                                                <asp:Label ID="Label144" runat="server" Text="Premium Statement"></asp:Label>
                                                            </td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel17" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_STATE" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>                                                                           
                                                                                <telerik:GridBoundColumn DataField="POLICY_CODE" 
                                                                                    FilterControlAltText="Filter POLICY_CODE column" HeaderText="POLICY_CODE" 
                                                                                    SortExpression="POLICY_CODE" UniqueName="POLICY_CODE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_FROM" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_FROM column" HeaderText="PERIOD_FROM" 
                                                                                    SortExpression="PERIOD_FROM" UniqueName="PERIOD_FROM">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="PERIOD_TO" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter PERIOD_TO column" HeaderText="PERIOD_TO" 
                                                                                    SortExpression="PERIOD_TO" UniqueName="PERIOD_TO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ACTION_TYPE" 
                                                                                    FilterControlAltText="Filter ACTION_TYPE column" HeaderText="ACTION_TYPE" 
                                                                                    SortExpression="ACTION_TYPE" UniqueName="ACTION_TYPE">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="TOTAL_MEMBERS" 
                                                                                    FilterControlAltText="Filter TOTAL_MEMBERS column" HeaderText="MEMBERS" 
                                                                                    SortExpression="TOTAL_MEMBERS" UniqueName="TOTAL_MEMBERS">
                                                                                </telerik:GridBoundColumn>
                                                                                 <telerik:GridBoundColumn DataField="REFERENCE_NO" 
                                                                                    FilterControlAltText="Filter REFERENCE_NO column" HeaderText="REFERENCE_NO" 
                                                                                    SortExpression="REFERENCE_NO" UniqueName="REFERENCE_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="TRANSACTION_DATE" 
                                                                                    FilterControlAltText="Filter TRANSACTION_DATE column" HeaderText="TRANSACTION_DATE" 
                                                                                    SortExpression="TRANSACTION_DATE" UniqueName="TRANSACTION_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                                      <telerik:GridBoundColumn DataField="DR" 
                                                                                    FilterControlAltText="Filter DR column" HeaderText="DR" 
                                                                                    SortExpression="DR" UniqueName="DR">
                                                                                </telerik:GridBoundColumn>
                                                                                   <telerik:GridBoundColumn DataField="CR" 
                                                                                    FilterControlAltText="Filter CR column" HeaderText="CR" 
                                                                                    SortExpression="CR" UniqueName="CR">
                                                                                </telerik:GridBoundColumn>
                                                                             
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:CheckBox ID="chkcurrent" runat="server" Text="Active Policy" />
                                                            </td>
                                                            <td style="width: 85px" align="right">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:CheckBox ID="chkex" runat="server" Text="Excel Version" />
                                                            </td>
                                                            <td align="right" style="width: 85px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel24" runat="server">
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="width: 86px; height: 25px;">
                                                                                <asp:CheckBox ID="chkdate" runat="server" Text="Policy Period" />
                                                                            </td>
                                                                            <td style="height: 25px">
                                                                                &nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 86px; height: 25px;">
                                                                                <asp:Label ID="Label154" runat="server" Text="Period From"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 25px">
                                                                                <telerik:RadDatePicker ID="dtfrom" Runat="server" Culture="en-US" 
                                                                                    SelectedDate="2022-10-31" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                                        SelectedDate="2022-10-31">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 86px; height: 23px;">
                                                                                <asp:Label ID="Label155" runat="server" Text="Period To"></asp:Label>
                                                                            </td>
                                                                            <td style="height: 23px">
                                                                                <telerik:RadDatePicker ID="dtto" Runat="server" Culture="en-US" 
                                                                                    SelectedDate="2022-10-31" Skin="Simple">
                                                                                    <Calendar Skin="Simple" UseColumnHeadersAsSelectors="False" 
                                                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                                                    </Calendar>
                                                                                    <DateInput DateFormat="dd-MMM-yyyy" DisplayDateFormat="dd-MMM-yyyy" 
                                                                                        SelectedDate="2022-10-31">
                                                                                    </DateInput>
                                                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                                                </telerik:RadDatePicker>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px; height: 24px;">
                                                                <telerik:RadButton ID="btnstatement" runat="server" Skin="Simple" 
                                                                    Text="Print Statement" Width="149px">
                                                                </telerik:RadButton>
                                                                &nbsp;
                                                            </td>
                                                            <td align="right" style="width: 85px; height: 24px;">
                                                                <asp:Label ID="Label145" runat="server" Font-Bold="True" Text="O/S balance"></asp:Label>
                                                            </td>
                                                            <td style="width: 223px; height: 24px;">
                                                                <telerik:RadNumericTextBox ID="txtbal" Runat="server" Enabled="False" 
                                                                    Skin="Simple">
                                                                </telerik:RadNumericTextBox>
                                                            </td>
                                                            <td style="height: 24px">
                                                                &nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="lblid" runat="server" ForeColor="Red" Visible="False"></asp:Label>
                                                            </td>
                                                            <td style="width: 85px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V3" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel2" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label153" runat="server" Text="Valis Listing"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel21" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GDMEM" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                        GridLines="None" Height="100%" PageSize="20" Skin="Simple" Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" 
                                                                            DataKeyNames="DISPLAY_MEMBERSHIP_NO">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                         
                                                                                <telerik:GridBoundColumn DataField="MEMBER_NAME" 
                                                                                    FilterControlAltText="Filter MEMBER_NAME column" HeaderText="MEMBER_NAME" 
                                                                                    SortExpression="MEMBER_NAME" UniqueName="MEMBER_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="DISPLAY_MEMBERSHIP_NO" 
                                                                                    FilterControlAltText="Filter DISPLAY_MEMBERSHIP_NO column" 
                                                                                    HeaderText="MEMBERSHIP_NO" SortExpression="DISPLAY_MEMBERSHIP_NO" 
                                                                                    UniqueName="DISPLAY_MEMBERSHIP_NO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MEMBER_BIRTH_DATE" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter MEMBER_BIRTH_DATE column" HeaderText="DOB" 
                                                                                    SortExpression="MEMBER_BIRTH_DATE" UniqueName="MEMBER_BIRTH_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="FIRST_ENROLLMENT_DATE" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter FIRST_ENROLLMENT_DATE column" HeaderText="JOIN DT" 
                                                                                    SortExpression="FIRST_ENROLLMENT_DATE" UniqueName="FIRST_ENROLLMENT_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="POLICY_VALID_FROM" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter POLICY_VALID_FROM column" HeaderText="PERIOD_FROM" 
                                                                                    SortExpression="POLICY_VALID_FROM" UniqueName="POLICY_VALID_FROM">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="POLICY_VALID_UPTO" 
                                                                                    DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter POLICY_VALID_UPTO column" HeaderText="PERIOD_TO" 
                                                                                    SortExpression="POLICY_VALID_UPTO" UniqueName="POLICY_VALID_UPTO">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MEMBER_ADMINISTRATIVE_SEX" 
                                                                                    FilterControlAltText="Filter MEMBER_ADMINISTRATIVE_SEX column" HeaderText="SEX" 
                                                                                    SortExpression="MEMBER_ADMINISTRATIVE_SEX" 
                                                                                    UniqueName="MEMBER_ADMINISTRATIVE_SEX">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="RELATION" 
                                                                                    FilterControlAltText="Filter RELATION column" HeaderText="RELATION" 
                                                                                    SortExpression="RELATION" UniqueName="RELATION">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                                    FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                                                    SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="POLICY_STATUS" 
                                                                                    FilterControlAltText="Filter POLICY_STATUS column" HeaderText="POLICY_STATUS" 
                                                                                    SortExpression="POLICY_STATUS" UniqueName="POLICY_STATUS">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MEMBER_PRI_MOBILE" 
                                                                                    FilterControlAltText="Filter MEMBER_PRI_MOBILE column" HeaderText="MOBILE" 
                                                                                    SortExpression="MEMBER_PRI_MOBILE" UniqueName="MEMBER_PRI_MOBILE">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MEMBER_PRI_EMAIL" 
                                                                                    FilterControlAltText="Filter MEMBER_PRI_EMAIL column" HeaderText="EMAIL" 
                                                                                    SortExpression="MEMBER_PRI_EMAIL" UniqueName="MEMBER_PRI_EMAIL">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                                                    FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA_DATE" 
                                                                                    SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V5" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel5" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel6" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_SCHEME" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False" DataKeyNames="SCHEME_ID">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                     <telerik:GridButtonColumn CommandName="Select" 
                                                FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                UniqueName="Select">
                                                <HeaderStyle ForeColor="Blue" Width="50px" />
                                                <ItemStyle Width="50px" />
                                            </telerik:GridButtonColumn>  
                                                                          
                                                                                <telerik:GridBoundColumn DataField="PLAN_NAME" 
                                                                                    FilterControlAltText="Filter PLAN_NAME column" HeaderText="PLAN_NAME" 
                                                                                    SortExpression="PLAN_NAME" UniqueName="PLAN_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="SCHEME_NAME"                                                                                    
                                                                                    FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME_NAME" 
                                                                                    SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                                </telerik:GridBoundColumn>                                                                                 
                                                                              <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                                                    FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA DATE" 
                                                                                    SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel22" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_BENEFIT" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                                <telerik:GridBoundColumn DataField="CLAUSE_DESCRIPTION" 
                                                                                    FilterControlAltText="Filter CLAUSE_DESCRIPTION column" HeaderText="CLAUSE" 
                                                                                    SortExpression="CLAUSE_DESCRIPTION" UniqueName="CLAUSE_DESCRIPTION">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="MAXIMUM_LIMIT" 
                                                                                    FilterControlAltText="Filter MAXIMUM_LIMIT column" HeaderText="MAXIMUM_LIMIT" 
                                                                                    SortExpression="MAXIMUM_LIMIT" UniqueName="MAXIMUM_LIMIT">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="FUND_MANAGE" 
                                                                                    FilterControlAltText="Filter FUND_MANAGE column" HeaderText="FUND_MANAGE" 
                                                                                    SortExpression="FUND_MANAGE" UniqueName="FUND_MANAGE">
                                                                                </telerik:GridBoundColumn>
                                                                                    <telerik:GridBoundColumn DataField="DATA_DATE" 
                                                                                    FilterControlAltText="Filter DATA_DATE column" HeaderText="DATA_DATE" 
                                                                                    SortExpression="DATA_DATE" UniqueName="DATA_DATE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                <asp:Label ID="Label147" runat="server" Font-Bold="True" Text="Data As at"></asp:Label>
                                                            </td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                            <telerik:RadPageView ID="V6" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel4" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label148" runat="server" Font-Bold="True" 
                                                                    Text="PREVIOUS POLICY HISTRY"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel7" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="GD_POLICY" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="FromDt"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter FromDt column" HeaderText="PERIOD FROM" 
                                                                                    SortExpression="FromDt" UniqueName="FromDt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ToDt"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter ToDt column" HeaderText="PERIOD TO" 
                                                                                    SortExpression="ToDt" UniqueName="ToDt">
                                                                                </telerik:GridBoundColumn>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                                    FilterControlAltText="Filter SCHEME_NAME column" HeaderText="SCHEME NAME" 
                                                                                    SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="SOURCE" 
                                                                                    FilterControlAltText="Filter SOURCE column" HeaderText="SOURCE" 
                                                                                    SortExpression="SOURCE" UniqueName="SOURCE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                              <telerik:RadPageView ID="V7" runat="server" Width="1151px">
                                                <asp:Panel ID="Panel8" runat="server">
                                                    <table style="width: 100%">
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Label ID="Label1" runat="server" Font-Bold="True" 
                                                                    Text="NON-MEDICAL POLICY HISTRY"></asp:Label>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4">
                                                                <asp:Panel ID="Panel10" runat="server" Height="100%" ScrollBars="Both" 
                                                                    Width="1142px">
                                                                    <telerik:RadGrid ID="RD_NONMED" runat="server" AllowPaging="True" 
                                                                        CellSpacing="0" GridLines="None" Height="100%" PageSize="20" Skin="Simple" 
                                                                        Width="100%">
                                                                        <MasterTableView AutoGenerateColumns="False">
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                            <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </RowIndicatorColumn>
                                                                            <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                <HeaderStyle Width="20px" />
                                                                            </ExpandCollapseColumn>
                                                                            <Columns>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="FromDt"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter FromDt column" HeaderText="PERIOD FROM" 
                                                                                    SortExpression="FromDt" UniqueName="FromDt">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="ToDt"  DataFormatString="{0:yyyy-MM-dd}" 
                                                                                    FilterControlAltText="Filter ToDt column" HeaderText="PERIOD TO" 
                                                                                    SortExpression="ToDt" UniqueName="ToDt">
                                                                                </telerik:GridBoundColumn>
                                                                              
                                                                                <telerik:GridBoundColumn DataField="SCHEME_NAME" 
                                                                                    FilterControlAltText="Filter SCHEME_NAME column" HeaderText="CLASS" 
                                                                                    SortExpression="SCHEME_NAME" UniqueName="SCHEME_NAME">
                                                                                </telerik:GridBoundColumn>
                                                                                <telerik:GridBoundColumn DataField="SOURCE" 
                                                                                    FilterControlAltText="Filter SOURCE column" HeaderText="SOURCE" 
                                                                                    SortExpression="SOURCE" UniqueName="SOURCE">
                                                                                </telerik:GridBoundColumn>
                                                                            </Columns>
                                                                            <EditFormSettings>
                                                                                <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                </EditColumn>
                                                                            </EditFormSettings>
                                                                        </MasterTableView>
                                                                        <ItemStyle Wrap="False" />
                                                                        <PagerStyle Wrap="False" />
                                                                        <FilterMenu EnableImageSprites="False">
                                                                        </FilterMenu>
                                                                        <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                        </HeaderContextMenu>
                                                                    </telerik:RadGrid>
                                                                </asp:Panel>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="width: 143px">
                                                                &nbsp;</td>
                                                            <td style="width: 215px">
                                                                &nbsp;</td>
                                                            <td style="width: 223px">
                                                                &nbsp;</td>
                                                            <td>
                                                                &nbsp;</td>
                                                        </tr>
                                                    </table>
                                                </asp:Panel>
                                            </telerik:RadPageView>
                                        </telerik:RadMultiPage>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        <asp:Panel ID="Panel20" runat="server" BorderStyle="Solid" BorderWidth="1px">
                                            <table style="width: 100%">
                                                <tr>
                                                    <td align="center" bgcolor="#999999" colspan="4">
                                                        <asp:Label ID="Label150" runat="server" Font-Bold="True" Text="Report Extract"></asp:Label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px; height: 37px;">
                                                        <asp:Label ID="Label152" runat="server" Font-Bold="True" Text="Report name"></asp:Label>
                                                    </td>
                                                    <td style="width: 168px; height: 37px;">
                                                        <telerik:RadComboBox ID="cboreport" Runat="server" AutoPostBack="True">
                                                            <Items>
                                                                <telerik:RadComboBoxItem runat="server" Text="Valid List" 
                                                                    Value="V" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Lapsed List" 
                                                                    Value="L" />
                                                                <telerik:RadComboBoxItem runat="server" Text="Terminations" Value="T" />
                                                            </Items>
                                                        </telerik:RadComboBox>
                                                    </td>
                                                    <td style="height: 37px">
                                                        </td>
                                                    <td style="height: 37px">
                                                        </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 181px">
                                                        &nbsp;</td>
                                                    <td colspan="2">
                                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" 
                                                            Text="export" Width="200px">
                                                        </telerik:RadButton>
                                                    </td>
                                                    <td>
                                                        &nbsp;</td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="4">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="width: 174px">
                                        &nbsp;</td>
                                    <td style="width: 151px">
                                        &nbsp;</td>
                                    <td class="style8" style="width: 300px">
                                        <asp:Label ID="lblfile" runat="server" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="2">
                                        <asp:Label ID="lblerr" runat="server" ForeColor="Red"></asp:Label>
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                    <td class="style8" style="width: 300px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;&nbsp;&nbsp;</td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
     
    </asp:UpdatePanel>
</asp:Content>

