﻿
Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim empcode As String
    Dim MyDatatable As DataTable : Dim Str As String

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                dtDateFrom.DbSelectedDate = Date.Now
                dtDateTo.DbSelectedDate = Date.Now
                empcode = ""
                Session("EXCEL") = Nothing

                Load_Grid()

            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Load_Grid()
        Try

            GDRM.DataSource = Nothing
            GDRM.DataBind()
            GDRM_1.DataSource = Nothing
            GDRM_1.DataBind()


            SqlAction = " SELECT  Entered_by,YR,count(REF_NO)as Total_cnt,avg(TAT)avg_TaT FROM [VW_MIS_CRM_OFF_SYSTEM_TAT]   with(nolock)  where [Entry_Date]  Between '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'  group by Yr,Entered_by"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDRM.DataSource = MyDatable
                GDRM.DataBind()
            Else
                GDRM.DataSource = Nothing
                GDRM.DataBind()
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub GDRM_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDRM.SelectedIndexChanged
        Try
            GDRM_1.DataSource = Nothing
            GDRM_1.DataBind()
            HiddenField1.Value = ""

            HiddenField1.Value = (DirectCast(GDRM.SelectedItems(0), GridDataItem)).GetDataKeyValue("Entered_by").ToString()
            SqlAction = "SELECT  Entered_by,YR,Mn,count(REF_NO)as Total_cnt,avg(TAT)avg_TaT FROM [VW_MIS_CRM_OFF_SYSTEM_TAT]  with(nolock)   WHERE Entered_by ='" & HiddenField1.Value & "' and [Entry_Date]  Between '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'   group by Entered_by,YR,Mn order by Mn asc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDRM_1.DataSource = MyDatable
                GDRM_1.DataBind()
            Else
                GDRM_1.DataSource = Nothing
                GDRM_1.DataBind()
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub export_Click(sender As Object, e As System.EventArgs) Handles view.Click
        Try

            SqlAction = " SELECT  Entered_by,YR,count(REF_NO)as Total_cnt,avg(TAT)avg_TaT FROM [VW_MIS_CRM_OFF_SYSTEM_TAT]   with(nolock) where [Entry_Date]  Between '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "'  group by Yr,Entered_by"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDRM.DataSource = MyDatable
                GDRM.DataBind()
            Else
                GDRM.DataSource = Nothing
                GDRM.DataBind()
            End If


           
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub export_Click1(sender As Object, e As System.EventArgs) Handles export.Click
        Try
            Dim Str As String = ""
            Session("EXCEL") = "TO EXCEL"

            Dim Reportname As String = "Off_System_TAT"
            SqlAction = "SELECT [Id],[Entry_Date],[Ref_No],[Member_No],[Member_Name],[Proposer_Name],[Provider_name],[Service_Dt],[Reason_name],[Off_Type],[Entered_By],[Inv_Status], Time_In,Time_Out  FROM [CRM].[dbo].[Vw_Mis_CRM_Off_System]  with(nolock) WHERE   Entry_Date Between '" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Time_In IS NOT NULL"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (MyDatable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            MyDatable = Nothing
            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
        
    End Sub
End Class
