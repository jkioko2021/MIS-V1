﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()

            Str = "SELECT DISTINCT [Code],[Descr] FROM [dbo].[TBL_MIS_REIMB_REASONS] WHERE ACTIVE=1" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboreason
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Descr").ToString
                .DataValueField = MyDatatable.Columns("Code").ToString
                .DataBind()
            End With
            Str = "SELECT  [Doc_Code],[Doc_Name] FROM [CRM].[dbo].[TBL_MIS_REIMB_REQUIREMENTS]"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With chklist
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Doc_Name").ToString
                .DataValueField = MyDatatable.Columns("Doc_Code").ToString
                .DataBind()
            End With
            '
            loadGrid()
            Str = ""
            MyDatatable = Nothing
            dtupload.DbSelectedDate = Date.Now
        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WHERE ACTIVE=1 and Approved=0 and submitted=0 and Ready_To_Process=0 and Inv_Status='DECLINED' AND Is_Special=0"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

        If MyDatable.Rows.Count > 0 Then
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH.DataSource = MyDatable
            GDSEARCH.DataBind()
        End If
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If

            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_CLAIM_TRACKING_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0

        Dim FILENO As String
        Dim appeal As Integer = 0
        Dim special As Integer = 0
        Dim Member_no As String


        Dim receivedate As String
        Try
            If lblfile.Text = "" Then
                lblerr.Text = "You have not selected the File!"
                Exit Sub
            End If
            If cboreqtype.SelectedValue = 0 Then
                lblerr.Text = "You must select Appeal Request Type!"
                Exit Sub
            End If

            If lblcnt.Text = 1 Then
                lblerr.Text = "You have reached Maximum Appeal Limit.!"
                Exit Sub
            End If

           

            UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET   [Is_Special]='" & cboreqtype.SelectedValue & "',[Special_Req_Dt]='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "' where [File_No]= '" & lblfile.Text & "'")
            ' MyDBAction.Register_REIMB(lblfile.Text, CDate(dtreceive.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtservice.DbSelectedDate).ToString("yyyy-MM-dd"), cbotype.SelectedValue, Trim(txtmemno.Text), Trim(txtname.Text), Trim(txtinv_no.Text), txtinv_amt.Text, Session("username"), STS, cboreason.SelectedValue, Trim(txtproposer.Text), Trim(txtmobile.Text), Trim(txtemail.Text))
            For Each MyItem In chklist.Items
                If MyItem.Selected = True Then
                    MyDBAction.UPLOAD_CLAIMS(lblfile.Text, MyItem.value, MyItem.TEXT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"))
                End If
            Next

            lblerr.Text = "Updated Successfully!"
            FILENO = ""

            'loadGrid()
            load_Grid(lblfile.Text)
            cmdsave.Enabled = False
            ' 'loadGrid_OTH(txtinv_no.Text)
            HiddenField1.Value = ""



        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Dim ID As String = ""
        'cboprovider.SelectedValue = ""
        Dim Is_Appeal As Integer = 0
        Dim Is_SPECIAL As Integer = 0
        'cboprovider.Text = ""
        lblerr.Text = ""
        lblfile.Text = ""
        Try


            cboreason.SelectedValue = ""
            cboreason.Text = ""
            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            Dim SqlAction As String = ""

            Session("status_1") = Nothing
            SqlAction = "SELECT  [ID],[FILE_NO],[RECEIVE_DT],[SERVICE_DT],[CLAIM_TYPE],[MEMBER_NO],MEMBER_NAME,[INVOICE_NO],[INVOICE_AMT],REASON,PROPOSER,email,Mobile_no,is_appeal,Is_Special  FROM  [dbo].[TBL_MIS_REIMB_TRACKING] WITH (NOLOCK) WHERE File_No ='" & ID & "'"

            If SqlAction <> "" Then
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If SqlAction <> "" Then

                    'lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                    lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                    dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("RECEIVE_DT").ToString()
                    dtservice.DbSelectedDate = MyDatable.Rows(0).Item("SERVICE_DT").ToString()
                    txtmobile.Text = MyDatable.Rows(0).Item("Mobile_no").ToString()
                    cbotype.SelectedValue = MyDatable.Rows(0).Item("CLAIM_TYPE").ToString()
                    txtmemno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                    txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                    txtinv_no.Text = MyDatable.Rows(0).Item("INVOICE_NO").ToString()
                    txtinv_amt.Text = MyDatable.Rows(0).Item("INVOICE_AMT").ToString()
                    txtemail.Text = MyDatable.Rows(0).Item("email").ToString()
                    cboreason.SelectedValue = MyDatable.Rows(0).Item("REASON").ToString()
                    txtproposer.Text = MyDatable.Rows(0).Item("PROPOSER").ToString()
                    lblcnt.Text = MyDatable.Rows(0).Item("Is_Special").ToString()
                    cboreqtype.SelectedValue = MyDatable.Rows(0).Item("Is_Special").ToString()

                    If lblcnt.Text = 1 Then
                        lblerr.Text = "You have reached Maximum Request Limit!."
                        cmdsave.Enabled = False
                        cmdedit.Enabled = False
                        btnupload.Enabled = False
                        FL1.Enabled = False
                        cboreqtype.Enabled = False
                    Else
                        cmdsave.Enabled = True
                        cmdedit.Enabled = True
                        btnupload.Enabled = True
                        FL1.Enabled = True
                        cboreqtype.Enabled = True
                    End If



                    load_Grid(lblfile.Text)
                    SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE  File_No ='" & lblfile.Text & "' and Active=1"
                    MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                    chklist.ClearSelection()
                    For Each dt2_row As System.Data.DataRow In MyDatable.Rows
                        Dim IT As String = dt2_row("Doc_code").ToString()
                        For i As Integer = 0 To chklist.Items.Count - 1
                            If chklist.Items(i).Value = IT Then
                                chklist.Items(i).Selected = True
                            End If
                        Next

                    Next

                    txtproposer.Enabled = False
                    lblfile.Enabled = False
                    dtreceive.Enabled = False
                    dtservice.Enabled = False

                    'txtbarcode.Enabled = False
                    cbotype.Enabled = False
                    txtmemno.Enabled = False

                    txtinv_no.Enabled = False
                    'txtcomment.Enabled = False
                    txtinv_amt.Enabled = False

                    txtname.Enabled = False
                    txtinv_no.Enabled = False

                    txtinv_amt.Enabled = False
                    'txtcomment.Enabled = False
                    cboreqtype.Enabled = False

                    txtinv_amt.Enabled = False

                    cboreason.Enabled = False

                End If
                HiddenField1.Value = 1
                Session("DAD_5") = Nothing

            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If

            If cbosearch.SelectedValue = "I" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM [dbo].[TBL_MIS_REIMB_TRACKING] WHERE ACTIVE=1 AND INVOICE_NO Like '%" & Trim(txtsearch.Text) & "%'  and Approved=0 and submitted=0 and Ready_To_Process=0 and Inv_Status='DECLINED' AND Is_Special=0"
            ElseIf cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%' and Approved=0 and submitted=0 and Ready_To_Process=0 and Inv_Status='DECLINED' AND Is_Special=0"
            ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%' and Approved=0 and submitted=0 and Ready_To_Process=0 and Inv_Status='DECLINED' AND Is_Special=0"

            ElseIf cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT  [ID],[FILE_NO],[MEMBER_NO],[INVOICE_NO],[INVOICE_AMT],MEMBER_NAME,INV_STATUS,is_appeal,Is_Special FROM  [dbo].[TBL_MIS_REIMB_TRACKING]   WITH (NOLOCK) WHERE ACTIVE=1 AND   FILE_NO Like '%" & Trim(txtsearch.Text) & "%' and Approved=0 and submitted=0 and Ready_To_Process=0 and Inv_Status='DECLINED' AND Is_Special=0"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GDSEARCH1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5")
        GDSEARCH.DataBind()
    End Sub

    Protected Sub cmdedit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdedit.Click
        HiddenField1.Value = 1
        cmdsave.Enabled = True
        lblfile.Enabled = True
        dtreceive.Enabled = True
        dtservice.Enabled = True
        'txtbarcode.Enabled = True
        cbotype.Enabled = True
        txtmemno.Enabled = True
        cboreqtype.Enabled = True
        txtinv_no.Enabled = True
        txtcomment.Enabled = True
        txtinv_amt.Enabled = True
        cboreason.Enabled = True
        txtname.Enabled = True
        txtinv_no.Enabled = True
        txtinv_amt.Enabled = True
        txtcomment.Enabled = True
        txtproposer.Enabled = True

        txtinv_amt.Enabled = True


    End Sub


    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If txttitle.Text = "" Then
                lblerr.Text = "You must enter Document title!"
                Exit Sub
            End If

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".jpeg"
                    contenttype = "image/jpeg"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_File_CLAIMS(bytes, filename, contenttype, lblfile.Text, Trim(txttitle.Text.ToUpper), CDate(dtupload.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), DOC_ID.Text)
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green

                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            load_Grid(lblfile.Text)

            DOC_ID.Text = ""
            'lbltaskno.Text = ""
            txttitle.Text = ""
            dtupload.DbSelectedDate = Date.Now

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub


    Protected Sub GD_DOCS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_DOCS.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""
            'ltEmbed.Text = ""
            stst = (DirectCast(GD_DOCS.SelectedItems(0), GridDataItem)).GetDataKeyValue("DOC_ID").ToString()
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM  [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE  DOC_ID ='" & stst & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txttitle.Text = MyDatable.Rows(0).Item("Doc_Title").ToString()
                DOC_ID.Text = MyDatable.Rows(0).Item("DOC_ID").ToString()
            End If
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = "REIMBURSEMENT PROCESSING" ' System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            'LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            LoginSubject = "SPECIAL CLAIM:-" & txtname.Text
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b><u>Dear, " & Session("to") & " </u></b> </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = Session("Header")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>" & Session("msg") & " </b></span>")

            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>File No:" & lblfile.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Member Name: " & txtname.Text & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date : " & Date.Now() & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Forwaded By : " & Session("FullNames") & " </b></span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------Notes--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End--------------------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", LoginSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            lblerr.Text = ""
            lblerr_1.Text = ""
            If lblfile.Text = "" Then
                lblerr_1.Text = "Select the File to Submit!"
                Exit Sub
            End If
            If txtcomment.Text = "" Then
                lblerr_1.Text = "You must enter short notes!"
                Exit Sub
            End If

            SqlAction = "SELECT  File_Name FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CLAIM_DOCS] WHERE File_No='" & lblfile.Text & "' AND ACTIVE=1 AND Upload_Done=0"
            MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatatable.Rows.Count > 0 Then
                lblerr_1.Text = "You must upload the Missing Documents!"
                Exit Sub
            Else
               
                UpdateRecord("UPDATE [dbo].[TBL_MIS_REIMB_TRACKING] SET Ready_To_Process=1,[Approved]=0, Submitted=1,Submitted_By='" & Session("username") & "',Submit_dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Inv_Status='SUBMITTED'  where [File_No]= '" & lblfile.Text & "'")
                MyDBAction.TRACKING_CLAIM_MESSAGES(lblfile.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)

                lblerr_1.Text = "Submit successfull!"

                Session("to") = "Claims Team"
                Session("email") = "aar-claims@aar.co.ke"
                Session("cc_email") = ""

                'Session("Header") = "Submitted-" & txtproposer.Text
                Session("msg") = "Kindly note that the above Reimbursement 'SPECIAL' claim has been Tracked and submitted for Document verification and approval."
                MailSent = SendLoginDetails("Team", Session("email"), Session("cc_email"))

                dtreceive.DbSelectedDate = Date.Now()
                dtservice.DbSelectedDate = Date.Now()
                HiddenField1.Value = ""
                lblfile.Enabled = False
                dtreceive.Enabled = False
                dtservice.Enabled = False
                cboreason.SelectedValue = ""
                cboreason.Text = ""
                txtproposer.Text = ""
                lblfile.Text = ""
                cbotype.Text = ""
                txtmemno.Text = ""
                txtinv_no.Text = ""
                txtcomment.Text = ""
                txtinv_amt.Text = ""
                txtname.Text = ""
                txtinv_no.Text = ""
                txtinv_amt.Text = ""
                txtcomment.Text = ""
                txtinv_amt.Text = ""
                txtemail.Text = ""
                txtmobile.Text = ""
                load_Grid(lblfile.Text)
                loadGrid()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

End Class
