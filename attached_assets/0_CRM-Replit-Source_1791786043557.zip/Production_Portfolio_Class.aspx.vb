﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            empcode = ""
            cboclass.SelectedValue = ""
            cboyear.SelectedValue = Year(Date.Now)
            Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            If MyDatatable.Rows.Count > 0 Then
                empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                'empcode = "0101"
            Else
                lbltext.Text = "You are not authorized to view this page"
                Exit Sub
            End If
            Str = "SELECT [MGR_CODE],[MGR_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_CLASS_MGR] where IS_ACTIVE=1 AND YEAR='" & cboyear.SelectedValue & "' AND EMP_CODE='" & empcode & "' ORDER BY MGR_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboRM
                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("MGR_NAME").ToString
                .DataValueField = MyDatatable.Columns("MGR_CODE").ToString
                .DataBind()

            End With

            Str = "select CLASS_CODE,CLASS_NAME from [dbo].[TBL_MIS_CRM_CLASS] where CLASS_MGR='" & cboRM.SelectedValue & "'" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboclass
                .Items.Clear()

                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("CLASS_NAME").ToString
                .DataValueField = MyDatatable.Columns("CLASS_CODE").ToString
                .DataBind()

            End With

            Session("EXCEL") = Nothing

            SqlAction = "SELECT  MIN([DATE_FROM])DATE_FROM,MIN([DATE_TO])DATE_TO FROM [SALES].[dbo].[TBL_MIS_PROD_MONTHS] WHERE [MONTH_CLOSED] =0"
            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                dtDateFrom.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_FROM")).ToString("yyyy-MM-dd")
                dtDateTo.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()
                dtDateFrom_1.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_FROM").ToString()).ToString("yyyy-MM-dd")
                dtDateTo_1.DbSelectedDate = CDate(MyDatable.Rows(0).Item("DATE_TO").ToString()).ToString("yyyy-MM-dd")

            End If

            LOADGRID()
        End If
    End Sub
    Public Sub LOADGRID()
     
        GD_PORT_NON_1.DataSource = Nothing
        GD_PORT_NON_1.DataBind()
        GD_CORP.DataSource = Nothing
        GD_CORP.DataBind()
        GD_RETAIL.DataSource = Nothing
        GD_RETAIL.DataBind()

        SqlAction = "SELECT  [MGR_CODE],[MGR_NAME],[CLASS_CODE] ,SUM([M_CNT_POLICY])[M_CNT_POLICY],SUM([M_PREM])[M_PREM],SUM([M_CNT_LIVES])[M_CNT_LIVES],SUM([M_EARNED_PREMIUM])[M_EARNED_PREMIUM],SUM([M_CLAIM_RATIO])[M_CLAIM_RATIO],SUM([MED_CLAIMS])[MED_CLAIMS],SUM([NON_PREM])[NON_PREM] FROM [dbo].[TBL_MIS_CRM_PORTFOLIO_CLASS]   WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'  AND  [CLASS_CODE]='" & cboclass.SelectedValue & "'  GROUP BY [MGR_CODE],[MGR_NAME],[CLASS_CODE] "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_CLASS.DataSource = MyDatable
            GD_CLASS.DataBind()
            MyDatable = Nothing
        Else
            GD_CLASS.DataSource = Nothing
            GD_CLASS.DataBind()
        End If
        SqlAction = "SELECT  [MGR_CODE],[MGR_NAME],[CLASS_CODE] ,SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES],SUM([NON_PREM])[NON_PREM] FROM [dbo].[TBL_MIS_CRM_PORTFOLIO_CLASS]   WHERE    MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND [CLASS_CODE]='" & cboclass.SelectedValue & "'  GROUP BY [MGR_CODE],[MGR_NAME],[CLASS_CODE] "
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_PORT_NON.DataSource = MyDatable
            GD_PORT_NON.DataBind()
            Session("DAD_5_2") = MyDatable
            MyDatable = Nothing
        Else
            GD_PORT_NON.DataSource = Nothing
            GD_PORT_NON.DataBind()
        End If


        SqlAction = "SELECT  [RM_CODE],[RM_NAME], SUM([M_CNT_POLICY])[M_CNT_POLICY],SUM([M_PREM])[M_PREM],SUM([M_CNT_LIVES])[M_CNT_LIVES],SUM([M_EARNED_PREMIUM])[M_EARNED_PREMIUM],SUM([M_CLAIM_RATIO])[M_CLAIM_RATIO],SUM([MED_CLAIMS])[MED_CLAIMS],SUM([NON_PREM])[NON_PREM],SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE]  WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND  [CLASS_CODE]='" & cboclass.SelectedValue & "' GROUP BY [RM_CODE],[RM_NAME]"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_RM_PORT.DataSource = MyDatable
            GD_RM_PORT.DataBind()
            'Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GD_RM_PORT.DataSource = Nothing
            GD_RM_PORT.DataBind()
        End If

      

      
    End Sub
    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click

        GD_PORT_NON_1.DataSource = Nothing
        GD_PORT_NON_1.DataBind()
        GD_CORP.DataSource = Nothing
        GD_CORP.DataBind()
      

        Try


            SqlAction = "SELECT  [MGR_CODE],[MGR_NAME],[CLASS_CODE] ,SUM([M_CNT_POLICY])[M_CNT_POLICY],SUM([M_PREM])[M_PREM],SUM([M_CNT_LIVES])[M_CNT_LIVES],SUM([M_EARNED_PREMIUM])[M_EARNED_PREMIUM],SUM([M_CLAIM_RATIO])[M_CLAIM_RATIO],SUM([MED_CLAIMS])[MED_CLAIMS],SUM([NON_PREM])[NON_PREM] FROM [dbo].[TBL_MIS_CRM_PORTFOLIO_CLASS]   WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'  AND  [CLASS_CODE]='" & cboclass.SelectedValue & "'  GROUP BY [MGR_CODE],[MGR_NAME],[CLASS_CODE] "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_CLASS.DataSource = MyDatable
                GD_CLASS.DataBind()
                MyDatable = Nothing
            Else
                GD_CLASS.DataSource = Nothing
                GD_CLASS.DataBind()
            End If
            SqlAction = "SELECT  [MGR_CODE],[MGR_NAME],[CLASS_CODE] ,SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES],SUM([NON_PREM])[NON_PREM] FROM [dbo].[TBL_MIS_CRM_PORTFOLIO_CLASS]   WHERE    MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND [CLASS_CODE]='" & cboclass.SelectedValue & "'  GROUP BY [MGR_CODE],[MGR_NAME],[CLASS_CODE] "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_PORT_NON.DataSource = MyDatable
                GD_PORT_NON.DataBind()
                Session("DAD_5_2") = MyDatable
                MyDatable = Nothing
            Else
                GD_PORT_NON.DataSource = Nothing
                GD_PORT_NON.DataBind()
            End If


            SqlAction = "SELECT  [RM_CODE],[RM_NAME], SUM([M_CNT_POLICY])[M_CNT_POLICY],SUM([M_PREM])[M_PREM],SUM([M_CNT_LIVES])[M_CNT_LIVES],SUM([M_EARNED_PREMIUM])[M_EARNED_PREMIUM],SUM([M_CLAIM_RATIO])[M_CLAIM_RATIO],SUM([MED_CLAIMS])[MED_CLAIMS],SUM([NON_PREM])[NON_PREM],SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE]  WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND  [CLASS_CODE]='" & cboclass.SelectedValue & "' GROUP BY [RM_CODE],[RM_NAME]"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_RM_PORT.DataSource = MyDatable
                GD_RM_PORT.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GD_RM_PORT.DataSource = Nothing
                GD_RM_PORT.DataBind()
            End If
        Catch ex As Exception
        End Try
    End Sub



    Protected Sub GD_MED_POLICY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_CORP.PageIndexChanged
        GD_CORP.CurrentPageIndex = e.NewPageIndex
        GD_CORP.DataSource = Session("DAD_5_4")
        GD_CORP.DataBind()
    End Sub
    Protected Sub GD_NON_POLICY_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_RETAIL.PageIndexChanged
        GD_RETAIL.CurrentPageIndex = e.NewPageIndex
        GD_RETAIL.DataSource = Session("DAD_5_5")
        GD_RETAIL.DataBind()
    End Sub
    Protected Sub GD_RM_PORT_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_RM_PORT.PageIndexChanged
        GD_RM_PORT.CurrentPageIndex = e.NewPageIndex
        GD_RM_PORT.DataSource = Session("GD_RM_PORT")
        GD_RM_PORT.DataBind()
    End Sub

    Protected Sub GD_CLASS_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GD_CLASS.SelectedIndexChanged
        Dim USER_ID As String = ""

        GD_CLASS_1.DataSource = Nothing
        GD_CLASS_1.DataBind()
        Try
            Session("CLASS_CODE") = Nothing

            USER_ID = (DirectCast(GD_CLASS.SelectedItems(0), GridDataItem)).GetDataKeyValue("CLASS_CODE").ToString()
            Session("CLASS_CODE") = USER_ID
            SqlAction = "SELECT [MONTH_FROM],[MONTH_TO],[M_CNT_POLICY],[M_PREM],[M_CNT_LIVES],[M_EARNED_PREMIUM],[M_CLAIM_RATIO],[MED_CLAIMS] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_CLASS] WHERE  CLASS_CODE='" & USER_ID & "' AND   MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_CLASS_1.DataSource = MyDatable
                GD_CLASS_1.DataBind()
                MyDatable = Nothing
            Else
                GD_CLASS_1.DataSource = Nothing
                GD_CLASS_1.DataBind()
            End If

            SqlAction = "SELECT  [RM_CODE],[RM_NAME], SUM([M_CNT_POLICY])[M_CNT_POLICY],SUM([M_PREM])[M_PREM],SUM([M_CNT_LIVES])[M_CNT_LIVES],SUM([M_EARNED_PREMIUM])[M_EARNED_PREMIUM],SUM([M_CLAIM_RATIO])[M_CLAIM_RATIO],SUM([MED_CLAIMS])[MED_CLAIMS],SUM([NON_PREM])[NON_PREM],SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE]  WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND [CLASS_CODE]='" & USER_ID & "' GROUP BY [RM_CODE],[RM_NAME] ORDER BY SUM([M_PREM]) DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_RM_PORT.DataSource = MyDatable
                GD_RM_PORT.DataBind()
                Session("GD_RM_PORT") = MyDatable
                MyDatable = Nothing
            Else
                GD_RM_PORT.DataSource = Nothing
                GD_RM_PORT.DataBind()
            End If

            SqlAction = "SELECT  [MGR_CODE],[MGR_NAME],[CLASS_CODE] ,SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES],SUM([NON_PREM])[NON_PREM] FROM [dbo].[TBL_MIS_CRM_PORTFOLIO_CLASS]   WHERE    MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND [CLASS_CODE]='" & cboclass.SelectedValue & "'  GROUP BY [MGR_CODE],[MGR_NAME],[CLASS_CODE] "
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_PORT_NON.DataSource = MyDatable
                GD_PORT_NON.DataBind()
                Session("DAD_5_2") = MyDatable
                MyDatable = Nothing
            Else
                GD_PORT_NON.DataSource = Nothing
                GD_PORT_NON.DataBind()
            End If

        Catch ex As Exception

        End Try

    End Sub


    
    Protected Sub GD_RM_PORT_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GD_RM_PORT.SelectedIndexChanged
        Dim USER_ID As String = ""

        GD_RM_PORT_1.DataSource = Nothing
        GD_RM_PORT_1.DataBind()
        Try
            USER_ID = (DirectCast(GD_RM_PORT.SelectedItems(0), GridDataItem)).GetDataKeyValue("RM_CODE").ToString()
            SqlAction = "SELECT [MONTH_FROM],[MONTH_TO],[M_CNT_POLICY],[M_PREM],[M_CNT_LIVES],[M_EARNED_PREMIUM],[M_CLAIM_RATIO],[MED_CLAIMS] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE] WHERE  [RM_CODE]='" & USER_ID & "'  AND  MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' and CLASS_CODE='" & Session("class_code") & "' ORDER BY MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_RM_PORT_1.DataSource = MyDatable
                GD_RM_PORT_1.DataBind()
                MyDatable = Nothing
            Else
                GD_RM_PORT_1.DataSource = Nothing
                GD_RM_PORT_1.DataBind()
            End If



        Catch ex As Exception

        End Try

    End Sub
    Protected Sub GD_PORT_NON_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GD_PORT_NON.SelectedIndexChanged
        Dim USER_ID As String = ""

        GD_PORT_NON_1.DataSource = Nothing
        GD_PORT_NON_1.DataBind()
        GD_CLASS.DataSource = Nothing
        GD_CLASS.DataBind()
        Try
            'USER_ID = (DirectCast(GD_PORT_MED.SelectedItems(0), GridDataItem)).GetDataKeyValue("CLASS_CODE").ToString()
            SqlAction = "SELECT [MONTH_FROM],[MONTH_TO],[NON_PREM],[NON_CNT_POLICY],[NON_CNT_LIVES] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_NSM] WHERE   MONTH_FROM >='" & CDate(dtDateFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY MONTH_FROM"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_PORT_NON_1.DataSource = MyDatable
                GD_PORT_NON_1.DataBind()
                MyDatable = Nothing
            Else
                GD_PORT_NON_1.DataSource = Nothing
                GD_PORT_NON_1.DataBind()
            End If

            'SqlAction = "SELECT  [MGR_CODE],[MGR_NAME],[CLASS_CODE] ,SUM([NON_CNT_POLICY])[NON_CNT_POLICY],SUM([NON_CNT_LIVES])[NON_CNT_LIVES],SUM([NON_PREM])[NON_PREM] FROM [dbo].[TBL_MIS_CRM_PORTFOLIO_CLASS]   WHERE   MONTH_FROM >= '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "'  GROUP BY [MGR_CODE],[MGR_NAME],[CLASS_CODE] "
            'MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatable.Rows.Count > 0 Then
            '    GD_CLASS.DataSource = MyDatable
            '    GD_CLASS.DataBind()
            '    MyDatable = Nothing
            'Else
            '    GD_CLASS.DataSource = Nothing
            '    GD_CLASS.DataBind()
            'End If

        Catch ex As Exception

        End Try

    End Sub
    Protected Sub RadButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGenerate.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Reportname As String
        Session("Mytable") = Nothing
        Session("Reportname") = Nothing

        Session("EXCEL") = "TO EXCEL"
        If cbotype.SelectedValue = "DR" Then
            Reportname = "Debits As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "SELECT  PROPOSER_DISPLAY_NAME,INVOICE_NO,CONVERT(date,INVOICE_DATE)INVOICE_DATE ,SUM(PREMIUM)PREMIUM,USER_DISPLAY_NAME,BUSINESS,AGENT_TYPE,PLAN_CODE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE INVOICE_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND RM_RET_CODE IN( SELECT [RE_CODE]   FROM [CRM].[dbo].[TBL_MIS_CRM_RMS] WHERE NSM_CODE='" & cboclass.SelectedValue & "') AND PLAN_CODE='I' AND BUSINESS_TYPE='RENEWAL'  GROUP BY PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,AGENT_TYPE,PLAN_CODE"
        ElseIf cbotype.SelectedValue = "DC" Then
            Reportname = "Debits As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "SELECT  PROPOSER_DISPLAY_NAME,INVOICE_NO,CONVERT(date,INVOICE_DATE)INVOICE_DATE ,SUM(PREMIUM)PREMIUM,USER_DISPLAY_NAME,BUSINESS,AGENT_TYPE,PLAN_CODE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE INVOICE_DATE BETWEEN '" & CDate(dtDateFrom.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & "' AND RM_CORP_CODE IN( SELECT [RE_CODE]   FROM [CRM].[dbo].[TBL_MIS_CRM_RMS] WHERE NSM_CODE='" & cboclass.SelectedValue & "') AND PLAN_CODE <>'I' AND BUSINESS_TYPE='RENEWAL'  GROUP BY PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,AGENT_TYPE,PLAN_CODE"

            'ElseIf cbotype.SelectedValue = "P" Then
            '    Reportname = "Production As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            '    SqlAction = "SELECT  PROPOSER_DISPLAY_NAME,INVOICE_NO,CONVERT(date,INVOICE_DATE)INVOICE_DATE ,SUM(PREMIUM)PREMIUM,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,PERIOD_FROM,PERIOD_TO,AGENT_TYPE,PLAN_CODE  FROM [SALES].[dbo].[TBL_MIS_SALES_PRODUCTION] WHERE INVOICE_DATE BETWEEN '" & CDate(dtDateFrom_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtDateTo_1.SelectedDate).ToString("yyyy-MM-dd") & "' AND RM_CORP_CODE ='" & cboRE.SelectedValue & "' AND PLAN_CODE='I' AND BUSINESS_TYPE='RENEWAL' GROUP BY PROPOSER_DISPLAY_NAME,INVOICE_NO,INVOICE_DATE,BUSINESS_TYPE,USER_DISPLAY_NAME,BUSINESS,AGENT_TYPE,PLAN_CODE"
        ElseIf cbotype.SelectedValue = "PLR" Then
            Reportname = "PolicyListing As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "select PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,PREMIUMS,LIVES,CONTACT_PERSON,MOBILE_NO,PROPOSER_ID,AGENCY_CODE from [dbo].[TBL_MIS_RET_CORP] WHERE   [RM_CODE] IN ( SELECT [RE_CODE]   FROM [CRM].[dbo].[TBL_MIS_CRM_RMS] WHERE NSM_CODE='" & cboclass.SelectedValue & "')"
        ElseIf cbotype.SelectedValue = "PLC" Then
            Reportname = "PolicyListing As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "select PROPOSER_DISPLAY_NAME,PERIOD_FROM,PERIOD_TO,PREMIUMS,LIVES,CONTACT_PERSON,MOBILE_NO,PROPOSER_ID,AGENCY_CODE from [dbo].[TBL_MIS_RET_CORP] WHERE   [RM_CODE] IN ( SELECT [RE_CODE]   FROM [CRM].[dbo].[TBL_MIS_CRM_RMS] WHERE NSM_CODE='" & cboclass.SelectedValue & "') "

        ElseIf cbotype.SelectedValue = "PO" Then
            Reportname = "Portfolio As At-& " & CDate(dtDateTo.SelectedDate).ToString("yyyy-MM-dd") & ""
            SqlAction = "SELECT [MONTH_FROM],[MONTH_TO],[M_CNT_POLICY],[M_PREM],[M_CNT_LIVES],[M_EARNED_PREMIUM],[M_CLAIM_RATIO],[MED_CLAIMS] FROM [CRM].[dbo].[TBL_MIS_CRM_PORTFOLIO_RE] WHERE  [NSM_CODE]='" & cboclass.SelectedValue & "'  AND  MONTH_FROM >='" & CDate(dtDateFrom_1.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND MONTH_TO <='" & CDate(dtDateTo_1.DbSelectedDate).ToString("yyyy-MM-dd") & "' ORDER BY MONTH_FROM"
        End If
        Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If Mytable.Rows.Count > 0 Then
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
        End If
    End Sub



End Class
