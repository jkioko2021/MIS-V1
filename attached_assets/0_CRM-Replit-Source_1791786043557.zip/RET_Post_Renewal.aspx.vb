﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Imports Microsoft.VisualBasic
Imports System
'Imports Microsoft.Office.Interop.Excel
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports Microsoft.Office.Interop
Imports System.Windows.Forms
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                empcode = ""
                Session("EXCEL") = Nothing
                Str = "SELECT Emp_Code FROM	employees  WHERE username ='" & Session("username") & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                If MyDatatable.Rows.Count > 0 Then
                    empcode = MyDatatable.Rows(0).Item("Emp_Code").ToString()
                    'empcode = "0111"
                Else
                    lblerr.Text = "You are not authorized to view this page"
                    Exit Sub
                End If
                Str = ""
                Str = "SELECT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1 AND C_CODE='R' AND RE_CODE ='" & empcode & "' " '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cborm
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                    .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                    .DataBind()
                End With
                cborm.SelectedValue = empcode

                loadgrid()
                Session("Month") = Nothing
                Session("EXCEL") = Nothing
            Catch ex As Exception

            End Try
        End If
    End Sub

    Protected Sub GD_PROP_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_PROP.PageIndexChanged
        GD_PROP.CurrentPageIndex = e.NewPageIndex
        GD_PROP.DataSource = Session("DAD_5")
        GD_PROP.DataBind()
    End Sub

    Public Sub loadgrid()
        GD_PROP.DataSource = Nothing
        GD_PROP.DataBind()


        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing

        'Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)DAYS_DUE, TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)>=1 AND DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)<=30  and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS   in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I'  AND POLICY_STATUS='LAPSED') AND RMS_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
        Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,RENEWAL_DATE,GETDATE()) DAYS_DUE,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,RENEWAL_DATE,GETDATE())>=0 AND DATEDIFF(DAY,RENEWAL_DATE,GETDATE())<=60 and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS   in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I'  AND POLICY_STATUS NOT IN ('ACTIVE','TERMINATED')) AND RMS_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE DESC"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_PROP.DataSource = MyDatable
            GD_PROP.DataBind()
            Session("DAD_5") = MyDatable
            'txttotal.Text = Convert.ToInt32(MyDatable.Compute("SUM(TOTAL_PREMIUM)", String.Empty))
            'txttotalplus.Text = Convert.ToInt32(MyDatable.Compute("sum(SILVERPLUS_PREMIUM)", String.Empty))
            MyDatable = Nothing
        Else
            GD_PROP.DataSource = Nothing
            GD_PROP.DataBind()
        End If


    End Sub
    Protected Sub GD_PROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_PROP.SelectedIndexChanged
        Try
            GDSEARCH.DataSource = Nothing
            GDSEARCH.DataBind()
            lblproposer.Text = ""
            Session("FAMILY_NO") = Nothing
            lblPolicy.Text = (DirectCast(GD_PROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("POLICY_CODE").ToString()
            SqlAction = "SELECT PLAN_NAME,PROPOSER_ID, [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[FAMILY_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[FAMILY_SHARED],[OP_BENEFIT],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGENT],[PROPOSER_PRI_ADD_LINE1],[AGE_AT_RENEWAL],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOTAL_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM] FROM CRM.[dbo].[TBL_MIS_RENEWAL_UPLOAD] WHERE POLICY_CODE = '" & Trim(lblPolicy.Text) & "' AND APPROVED=1  ORDER BY  DISPLAY_MEMBERSHIP_NO  ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("FAMILY_NO") = MyDatable.Rows(0).Item("FAMILY_NO").ToString()
                lblproposer.Text = MyDatable.Rows(0).Item("PROPOSER_ID").ToString()
                'Session("DAD_5") = MyDatable
                txttotal.Text = Convert.ToInt32(MyDatable.Compute("SUM(TOTAL_PREMIUM)", String.Empty))
                'txttotalplus.Text = Convert.ToInt32(MyDatable.Compute("sum(SILVERPLUS_PREMIUM)", String.Empty))
                MyDatable = Nothing
                SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & lblproposer.Text & "'  ORDER BY Note_id DESC"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                    MyDatable = Nothing
                Else
                    GDNOTES.DataSource = MyDatable
                    GDNOTES.DataBind()
                End If
            Else
                GDSEARCH.DataSource = Nothing
                GDSEARCH.DataBind()
            End If

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub cmdview_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdview.Click
        Try
            GD_PROP.DataSource = Nothing
            GD_PROP.DataBind()
            GDSEARCH.DataSource = Nothing
            GDSEARCH.DataBind()

            Dim MyDatable As New Data.DataTable
            Session("DAD_5") = Nothing


            If cbosearch.SelectedValue = "RM" Then
                'Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)DAYS_DUE, TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)>=1 AND DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)<=30  and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS NOT in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I') AND RMS_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
                Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,RENEWAL_DATE,GETDATE()) DAYS_DUE,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,RENEWAL_DATE,GETDATE())>=0 AND DATEDIFF(DAY,RENEWAL_DATE,GETDATE())<=60 and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS   in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I' AND POLICY_STATUS='LAPSED') AND RMS_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
            ElseIf cbosearch.SelectedValue = "A" Then
                'Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)DAYS_DUE, TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)>=1 AND DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)<=30  and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS NOT in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I') AND AGENT_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
                Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,RENEWAL_DATE,GETDATE()) DAYS_DUE,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,RENEWAL_DATE,GETDATE())>=0 AND DATEDIFF(DAY,RENEWAL_DATE,GETDATE())<=60 and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS   in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I' AND POLICY_STATUS='LAPSED') AND AGENT_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
            ElseIf cbosearch.SelectedValue = "F" Then
                cborm.Items.Clear()
                'Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)DAYS_DUE, TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)>=1 AND DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)<=30  and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS NOT in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I') AND AGENT_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
                Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,RENEWAL_DATE,GETDATE()) DAYS_DUE,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,RENEWAL_DATE,GETDATE())>=0 AND DATEDIFF(DAY,RENEWAL_DATE,GETDATE())<=60 and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS   in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I' AND POLICY_STATUS='LAPSED') AND FAMILY_NO='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"

            Else
                lblerr.Text = "Enter search creteria"
                Exit Sub
            End If

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_PROP.DataSource = MyDatable
                GD_PROP.DataBind()
                Session("DAD_5") = MyDatable
                txttotal.Text = Convert.ToInt32(MyDatable.Compute("SUM(TOTAL_PREMIUM)", String.Empty))
                'txttotalplus.Text = Convert.ToInt32(MyDatable.Compute("sum(SILVERPLUS_PREMIUM)", String.Empty))
                MyDatable = Nothing
            Else
                GD_PROP.DataSource = Nothing
                GD_PROP.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub



    'Private Function SendLoginDetails(ByVal POLICY_CODE As String, ByVal PROPOSER_DISPLAY_NAME As String, ByVal PERIOD_FROM As String, ByVal PERIOD_TO As String, ByVal PROPOSER_PRI_EMAIL As String, ByVal FAMILY_CODE As String) As Boolean
    Protected Sub BTNprint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BTNprint.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Str_1 As String = ""
        Dim Str_2 As String = ""
        Dim CAT As String = ""
        Dim CAT_SCHEME As String = ""
        Dim Str_3 As String = ""
        Dim approve As Integer = 0
        Dim MailSent As Boolean = False
        Dim body As String = ""
        Dim MyDatable_1 As DataTable = Nothing
        Dim MyDatable_2 As DataTable = Nothing
        Dim MyDatable_3 As DataTable = Nothing
        Dim Str_Live As String = ""
        Dim theMonth As String = "" ' DateTime.Now.ToString("MMMM")
        Dim policy As String = ""


        Session("EMPNAME") = Nothing
        Session("FrmDT") = Nothing
        Session("ToDt") = Nothing
        Session("agentEmail") = Nothing
        Session("RecepientEmail") = ""
        Session("MailSent") = False
        Session("EXPORT_TYPE") = "PDF"


        Str = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],S_PLUS_PREM,INV_NO,PLAN_NAME,SCHEME_NAME  FROM CRM.[dbo].[VW_RENEWAL_ADVICE] WHERE   POLICY_CODE='" & lblPolicy.Text.ToUpper & "'  ORDER BY FAMILY_NO"
        MyDatable_1 = Nothing
        MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable_1.Rows.Count > 0 Then

            CAT = MyDatable_1.Rows(0).Item("RENEWAL_DATE").ToString()
            CAT_SCHEME = MyDatable_1.Rows(0).Item("CATEGORY").ToString()


            'GENERATE_RPT(MyDatable_1)
            Session("Report_") = "Renewal Schedule"
            Session("PRINT") = "PDF"
            'MyDatable_1 = Nothing
            Session("Mytable") = Nothing
            Session("Reportname") = Nothing
            Session("Mytable") = (MyDatable_1)
            Session("Reportname") = Session("Report_")
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing
            System.Threading.Thread.Sleep(5000)
        Else
            lblerr.Text = "No Data Found"
            Exit Sub
        End If


    End Sub



    Protected Sub cbosearch_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbosearch.SelectedIndexChanged
        If cbosearch.SelectedValue = "A" Then
            Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1 AND [RMS_CODE_RET]='" & cborm.SelectedValue & "' ORDER BY AGENT_NAME"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbotext

                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()
            End With


        End If
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            If lblproposer.Text = "" Then
                lblerr.Text = "Select Proposer!"
            End If

            If txtcomments.Text <> "" Then
                MyDBAction.TASK_MESSAGES(lblproposer.Text, txtcomments.Text, Session("username"), Date.Now(), "PRE-RENEWAL CALL", Session("FAMILY_NO"))
                lblerr.Text = "Updated successfully!"
                Session("FAMILY_NO") = Nothing
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub BTNprint0_Click(sender As Object, e As System.EventArgs) Handles BTNprint0.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String = "PRE-RENEWAL As -& " & cborm.Text & ""

            Session("EXCEL") = "TO EXCEL"

            If cbosearch.SelectedValue = "RM" Then
                'Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)DAYS_DUE, TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)>=1 AND DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)<=30  and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS NOT in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I') AND RMS_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
                Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,RENEWAL_DATE,GETDATE()) DAYS_DUE,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,RENEWAL_DATE,GETDATE())>=0 AND DATEDIFF(DAY,RENEWAL_DATE,GETDATE())<=60 and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS   in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I' AND POLICY_STATUS='LAPSED') AND RMS_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
            ElseIf cbosearch.SelectedValue = "A" Then
                'Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)DAYS_DUE, TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)>=1 AND DATEDIFF(DAY,GETDATE(),RENEWAL_DATE)<=30  and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS NOT in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I') AND AGENT_CODE='" & cborm.SelectedValue & "' ORDER BY DAYS_DUE ASC"
                Str = "SELECT POLICY_CODE, PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,DATEDIFF(DAY,RENEWAL_DATE,GETDATE()) DAYS_DUE,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE DATEDIFF(DAY,RENEWAL_DATE,GETDATE())>=0 AND DATEDIFF(DAY,RENEWAL_DATE,GETDATE())<=60 and PROPOSER_ID COLLATE SQL_Latin1_General_CP1_CS_AS   in (SELECT PROPOSER_ID FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE GRP_INDV='I' AND POLICY_STATUS='LAPSED') AND AGENT_CODE='" & cbotext.SelectedValue & "' ORDER BY DAYS_DUE ASC"
            Else
                lblerr.Text = "Enter search creteria"
                Exit Sub
            End If
            Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'Mytable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            Session("Mytable") = (Mytable)
            Session("Reportname") = Reportname
            ResponseHelper.Redirect("Reports.aspx", "_blank", "")
            Mytable = Nothing

            System.Threading.Thread.Sleep(5000)
        Catch ex As Exception

        End Try
    End Sub
End Class
