﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="Tracking_reports.aspx.vb" Inherits="Default2" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
 
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">

            <ContentTemplate>
                <asp:UpdateProgress runat="server" id="PageUpdateProgress">
            <ProgressTemplate>
                Loading...
            </ProgressTemplate>
        </asp:UpdateProgress>
                
                             &nbsp;<br />
                             <asp:Label ID="Lblguide" runat="server" ForeColor="Red"></asp:Label>
                      
                
                 <br />
                <asp:Panel ID="Panel1" runat="server" Height="485px" Width="1016px" 
                    BorderStyle="Groove" BorderWidth="1px" style="margin-left: 70px">
                    <table style="width: 1002px; height: 474px; margin-left: 0px; left: 50px;">
                        <tr>
                            <td rowspan="6" valign="top" style="width: 146px">
                            
                                <asp:Panel ID="Panel2" runat="server" BorderStyle="Dotted" Height="369px" 
                                    Width="620px">
                                    <table style="width: 100%; height: 100%;">
                                        <tr>
                                            <td style="width: 307px">
                                                <fieldset style="background-color:#DDDDDD; width: 289px;">
                                                    <legend>Main Reports</legend>
                                                    <asp:Panel ID="Panel3" runat="server" Height="335px" ScrollBars="Horizontal" 
                                                        Width="282px">
                                                        <telerik:RadListBox ID="MainRptRad" runat="server" AutoPostBack="True" 
                                                            Height="100%" Skin="Sunset" Width="100%">
                                                        </telerik:RadListBox>
                                                    </asp:Panel>
                                                </fieldset> &nbsp;</td>
                                            <td style="width: 297px">
                                                <fieldset style="background-color:#DDDDDD; width: 264px;">
                                                    <legend>Sub Reports</legend>
                                                    <asp:Panel ID="Panel4" runat="server" Height="334px" ScrollBars="Horizontal" 
                                                        style="margin-left: 0px" Width="244px">
                                                        <telerik:RadListBox ID="SubRadRpt" runat="server" Height="100%" Skin="Sunset" 
                                                            Width="100%" AutoPostBack="True">
                                                        </telerik:RadListBox>
                                                    </asp:Panel>
                                                </fieldset> &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </td>
                            <td style="width: 149px; background-color: #C0C0C0; height: 19px;">
                                <asp:Panel ID="Panel5" runat="server" Height="319px" Width="344px">
                                    <table style="width: 100%">
                                        <tr>
                                            <td bgcolor="#999999" style="width: 135px">
                                                <asp:Label ID="Label8" runat="server" style="font-weight: 700" 
                                                    Text="Date From"></asp:Label>
                                            </td>
                                            <td bgcolor="#999999">
                                                <telerik:RadDatePicker ID="dtDateFrom" Runat="server" Skin="Sunset" 
                                                    Culture="en-US">
                                                    <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                    </Calendar>
                                                    <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                    </DateInput>
                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                </telerik:RadDatePicker>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#999999" style="width: 135px">
                                                <asp:Label ID="Label9" runat="server" style="font-weight: 700" 
                                                    Text="Date To"></asp:Label>
                                            </td>
                                            <td bgcolor="#999999">
                                                <telerik:RadDatePicker ID="dtDateTo" Runat="server" Skin="Sunset" 
                                                    Culture="en-US">
                                                    <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                        UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                    </Calendar>
                                                    <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                    </DateInput>
                                                    <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                </telerik:RadDatePicker>
                                            </td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 149px; height: 28px;">
                                <asp:CheckBox ID="chkexcel" runat="server" style="font-weight: 700" 
                                    Text="Excel" />
                                <asp:Label ID="LblErr" runat="server" ForeColor="Red"></asp:Label>
                                <telerik:RadButton ID="RadButton1" runat="server" Skin="Sunset" Text="Generate" 
                                    Width="80%">
                                </telerik:RadButton>
                            </td>
                            <td style="height: 28px">
                                &nbsp;</td>
                        </tr>
                    </table>
                </asp:Panel>                
            </ContentTemplate>
        </asp:UpdatePanel>
</asp:Content>


