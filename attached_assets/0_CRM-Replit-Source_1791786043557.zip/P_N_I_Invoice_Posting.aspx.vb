﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim MailSent As Boolean = False

    Protected Sub Page_LoadComplete(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LoadComplete
        If Not IsPostBack Then
            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()
            dtdoa.DbSelectedDate = Date.Now()

            'dtInv.DbSelectedDate = Date.Now()

            Str = "SELECT DISTINCT [ORG_ID],[ORG_NAME] FROM [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST    ORDER BY ORG_NAME" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cboprovider
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("ORG_NAME").ToString
                .DataValueField = MyDatatable.Columns("ORG_ID").ToString
                .DataBind()
            End With

            Str = "SELECT  [Doc_Code],[Doc_Name] FROM CRM.[dbo].[TBL_MIS_IP_CLAIM_REQUIREMENTS] where doc_code='IP010'"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbodoc
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Doc_Name").ToString
                .DataValueField = MyDatatable.Columns("Doc_Code").ToString
                .DataBind()
            End With
            Str = ""
            MyDatatable = Nothing
            cmdsave.Enabled = True
            loadGrid()
            Str = ""
            MyDatatable = Nothing

        End If
    End Sub
    Public Sub loadGrid()
        Dim MyDatable As New Data.DataTable
        Session("DAD_5") = Nothing
        SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name], [Inv_Status],L.ORG_NAME Provider_Name FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] I INNER JOIN  [DATA_REPOSITORY_DB].dbo.MASTER_PROVIDER_LIST L  ON L.ORG_ID=I.PROVIDER_ID  WHERE Submitted=1 and Discharged=1 and Posted=0  AND [Is_Active]=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
            Session("DAD_5") = MyDatable
            MyDatable = Nothing
        Else
            GDSEARCH_1.DataSource = MyDatable
            GDSEARCH_1.DataBind()
        End If
    End Sub
    Public Sub load_Grid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            SqlAction = " SELECT [Ref_No] ,[Invoice_No],Invoice_Dt, [Invoice_Amt],[DoA],[DoD],[Total_Bill],[Cover_Limit],[Overshot],[Admin_Fee],[Pay_N_Invoice],Sage_INv_No,Posting_Dt from  [CRM].[dbo].[TBL_MIS_CRM_PAY_N_I_BILLING] WHERE  Ref_No ='" & STR & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
                'Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_2.DataSource = MyDatable
                GDSEARCH_2.DataBind()
            End If
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If


            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INV_NOTES] WHERE  File_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Protected Sub cmdsave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim sign As String = 0
            lblerr.Text = ""
            If cbopost.SelectedValue = "" Then
                lblerr.Text = "You must Select Status!"
                Exit Sub
            End If

            If txtcomment.Text = "" Then
                lblerr.Text = "You must enter short notes!"
                Exit Sub
            End If

            If txtinvno.Text = "" Then
                lblerr.Text = "You must enter Sage Invoice NO!"
                Exit Sub
            End If

            If cbopost.SelectedValue = "P" Then
                UpdateRecord("UPDATE CRM.[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] SET  [Posted]=1,  Posted_By='" & Session("username") & "',Inv_Status='POSTED'  where [Ref_No]= '" & lblfile.Text & "'")
                UpdateRecord("UPDATE [CRM].[dbo].[TBL_MIS_CRM_PAY_N_I_BILLING] SET Sage_Inv_No='" & Trim(txtinvno.Text.ToUpper) & "',Posting_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "', [Posted]=1,  Posted_By='" & Session("username") & "'   where [Ref_No]= '" & lblfile.Text & "'")

            ElseIf cbopost.SelectedValue = "R" Then
                UpdateRecord("UPDATE CRM.[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] SET [Discharged]=0 ,Inv_Status='RETURN_INCOMPLETE'  where [Ref_No]= '" & lblfile.Text & "'")
            End If

            'UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_PAY_N_INVOICE] SET [Dicharged]=1, Dicharged_By='" & Session("username") & "',Submit_dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Inv_Status='SUBMITTED' where [Ref_No]= '" & lblfile.Text & "'")

            MyDBAction.TRACKING_PNI_CLAIM_MESSAGES(lblfile.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
            lblerr.Text = "Submit successfull!"

            dtreceive.DbSelectedDate = Date.Now()
            dtservice.DbSelectedDate = Date.Now()
            HiddenField1.Value = ""
            lblfile.Enabled = False
            dtreceive.Enabled = False
            dtservice.Enabled = False

            lblfile.Text = ""
            'ltEmbed.Text = ""
            ltEmbed.Text = ""
            cboprovider.Text = ""
            cboprovider.SelectedValue = ""
            txtmemno.Text = ""

            txtcomment.Text = ""

            ' txtname.Text = ""

            txtcomment.Text = ""

            txtname.Text = ""


            load_Grid(lblfile.Text)
            loadGrid()

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

         

 
    End Sub



    Protected Sub SEARCH_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SEARCH.Click
        Str = ""
        Try

            Session("DAD_5") = Nothing
            Dim SqlAction As String = ""
            Dim searchStr As String = ""
            Dim MyDBAction As New DataManagement

            If txtsearch.Text = "" Then
                lblerr.Text = "You cannot search empty string!"
                Exit Sub
            End If
            'SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]

            If cbosearch.SelectedValue = "M" Then
                SqlAction = "SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE DISPLAY_MEMBERSHIP_NO Like '%" & Trim(txtsearch.Text) & "%'"
            ElseIf cbosearch.SelectedValue = "N" Then
                SqlAction = "SELECT PROPOSER_DISPLAY_NAME,MEMBER_NAME,AGENT,DISPLAY_MEMBERSHIP_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE MEMBER_NAME Like '%" & Trim(txtsearch.Text) & "%'"

            End If

            Dim MyDatable As New Data.DataTable
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)

            If MyDatable.Rows.Count > 0 Then
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
                Session("DAD_5") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH_1.DataSource = MyDatable
                GDSEARCH_1.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub



    


    Protected Sub GD_DOCS_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_DOCS.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""
            'ltEmbed.Text = ""
            stst = (DirectCast(GD_DOCS.SelectedItems(0), GridDataItem)).GetDataKeyValue("DOC_ID").ToString()
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM  [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE  DOC_ID ='" & stst & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                'txttitle.Text = MyDatable.Rows(0).Item("Doc_Title").ToString()
                'DOC_ID.Text = MyDatable.Rows(0).Item("DOC_ID").ToString()
            End If
            'ltEmbed.Text = ""
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


   
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

    Protected Sub GD_DOCS_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GD_DOCS.DeleteCommand
        Try
            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("DOC_ID").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            DeleteRecord("DELETE FROM [Doc_Arc_DB].[dbo].[TBL_MIS_PAY_N_INVOICE_DOCS] WHERE  DOC_ID='" & HiddenField1.Value.ToString & "' AND [Upload_By]='" & Session("username") & "'")

            audit.AddAdminAuditTrail(Session("UserName").ToString, "PNI Claim Doc Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid()


        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub

    Protected Sub GDSEARCH_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH_1.SelectedIndexChanged
        Try
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            MyDatable = Nothing
            ID = ""
            ltEmbed.Text = ""
            lblfile.Text = (DirectCast(GDSEARCH_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("Ref_No").ToString()

            SqlAction = "SELECT [Id],[Ref_No],[New_Member],[Member_No],[Member_Name],[Proposer_Name],Service_Dt, [Inv_Status],PROVIDER_ID,Submit_Dt FROM [CRM].[dbo].[TBL_MIS_CRM_PAY_N_INVOICE] WHERE Submitted=1 and ref_no='" & lblfile.Text & "'  AND [Is_Active]=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If SqlAction <> "" Then
                txtmemno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                cboprovider.SelectedValue = MyDatable.Rows(0).Item("PROVIDER_ID").ToString()
                dtreceive.DbSelectedDate = MyDatable.Rows(0).Item("Submit_Dt").ToString()
                dtservice.DbSelectedDate = MyDatable.Rows(0).Item("Service_Dt").ToString()
            End If

            load_Grid(lblfile.Text)
            SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_IP_CLAIM_DOCS] WHERE  File_No ='" & lblfile.Text & "' and Active=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            

            'load_Grid(lblfile.Text)


        Catch ex As Exception

        End Try
    End Sub
 

    Protected Sub GDSEARCH_1_NeedDataSource(sender As Object, e As Telerik.Web.UI.GridNeedDataSourceEventArgs) Handles GDSEARCH_1.NeedDataSource

    End Sub

   
    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FilePNI.ashx?Id="), id)
    End Sub

    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If cbodoc.SelectedValue = "" Then
                lblerr.Text = "You must enter Document title!"
                Exit Sub
            End If

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".jpeg"
                    contenttype = "image/jpeg"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
                Case ".eml"
                    contenttype = "application/zip"
                    Exit Select
                Case ".msg"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_File_DOC_PNI_SAGE(bytes, filename, contenttype, lblfile.Text, Trim(cbodoc.Text.ToUpper), CDate(Date.Now()).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), cbodoc.SelectedValue, "")
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green
                UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_CRM_PAY_N_I_BILLING] SET [Sage_Inv_No]='" & Trim(txtinvno.Text.ToUpper) & "'   where [Ref_No]= '" & lblfile.Text & "'")

                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            load_Grid(lblfile.Text)
 
            'lbltaskno.Text = ""
          

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
End Class
