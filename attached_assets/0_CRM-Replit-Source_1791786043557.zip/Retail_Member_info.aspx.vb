﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Session("PRINT") = Nothing
            Session("Report_") = Nothing
        End If

    End Sub
    Protected Sub cmdview_Click(sender As Object, e As System.EventArgs) Handles cmdview.Click
        Try
            GDPROP.DataSource = Nothing
            GDPROP.DataBind()
            GDMEM.DataSource = Nothing
            GDMEM.DataBind()
            Dim MyDatable As New Data.DataTable
            ' SqlAction = "SELECT[PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],[USER_ID] FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_ID ='" & PRD.Text & "' order by DISPLAY_MEMBERSHIP_NO"
            If cbotype.SelectedValue = "C" Then
                If cbosearch.SelectedValue = "F" Then
                    SqlAction = "SELECT FAMILY_NO, [PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,AGENT,POLICY_VALID_FROM [PERIOD_FROM],POLICY_VALID_UPTO PERIOD_TO,POLICY_STATUS,RM_NAME FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK)  WHERE FAMILY_NO LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND RELATION='MAIN MEMBER'"
                ElseIf cbosearch.SelectedValue = "M" Then
                    SqlAction = "SELECT FAMILY_NO,[PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,AGENT,POLICY_VALID_FROM [PERIOD_FROM],POLICY_VALID_UPTO PERIOD_TO,POLICY_STATUS,RM_NAME FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE MEMBER_NAME  LIKE '%" & Trim(TXTSEARCH.Text) & "%'"
                Else
                    lblerr.Text = "Invalid Search type!"
                End If
            Else
                If cbosearch.SelectedValue = "F" Then
                    SqlAction = "SELECT FAMILY_NO, [PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,AGENT,POLICY_VALID_FROM [PERIOD_FROM],POLICY_VALID_UPTO PERIOD_TO,POLICY_STATUS,RM_NAME FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WITH (NOLOCK)  WHERE FAMILY_NO LIKE '%" & Trim(TXTSEARCH.Text) & "%' AND RELATION='MAIN MEMBER'"
                ElseIf cbosearch.SelectedValue = "P" Then
                    SqlAction = "SELECT FAMILY_NO,[PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,AGENT,POLICY_VALID_FROM [PERIOD_FROM],POLICY_VALID_UPTO PERIOD_TO,POLICY_STATUS,RM_NAME FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE PROPOSER_DISPLAY_NAME  LIKE '%" & Trim(TXTSEARCH.Text) & "%'  AND RELATION='MAIN MEMBER'"
                ElseIf cbosearch.SelectedValue = "M" Then
                    SqlAction = "SELECT FAMILY_NO,[PROPOSER_ID],POLICY_CODE,PROPOSER_DISPLAY_NAME ,AGENT,POLICY_VALID_FROM [PERIOD_FROM],POLICY_VALID_UPTO PERIOD_TO,POLICY_STATUS,RM_NAME FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  WHERE MEMBER_NAME  LIKE '%" & Trim(TXTSEARCH.Text) & "%'"
                End If

            End If
          
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDPROP.DataSource = MyDatable
                GDPROP.DataBind()
                Session("TAT_5") = MyDatable
                RMNAME.Text = MyDatable.Rows(0).Item("RM_NAME").ToString
                MyDatable = Nothing
            Else
                GDPROP.DataSource = Nothing
                GDPROP.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDPROP_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDPROP.SelectedIndexChanged
        Try
            GDMEM.DataSource = Nothing
            GDMEM.DataBind()
            GD_BENEFIT.DataSource = Nothing
            GD_BENEFIT.DataBind()
            GD_POLICY.DataSource = Nothing
            GD_POLICY.DataBind()
            GD_CLAIMS.DataSource = Nothing
            GD_CLAIMS.DataBind()
            RD_CLAIMS.DataSource = Nothing
            RD_CLAIMS.DataBind()
            RD_NONMED.DataSource = Nothing
            RD_NONMED.DataBind()
            Session("FAMILY_NO") = Nothing
            Session("PERIOD_FROM") = Nothing
            Session("PERIOD_TO") = Nothing
            Dim DR As Decimal = 0
            Dim CR As Decimal = 0

            Session("FAMILY_NO") = (DirectCast(GDPROP.SelectedItems(0), GridDataItem)).GetDataKeyValue("FAMILY_NO").ToString()

            SqlAction = "SELECT [PROPOSER_ID],[DISPLAY_MEMBERSHIP_NO],FAMILY_NO,[MEMBER_NAME],FIRST_ENROLLMENT_DATE,[RELATION],[SCHEME_NAME],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[MEMBER_PRI_MOBILE],[MEMBER_PRI_EMAIL],POLICY_VALID_FROM ,POLICY_VALID_UPTO ,POLICY_STATUS,DATA_DATE,PERIOD_FROM,PERIOD_TO,ID_DOC_NO,INTG_CODE,CARD_TYPE FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST]  with(nolock) WHERE FAMILY_NO ='" & Session("FAMILY_NO") & "'   order by DISPLAY_MEMBERSHIP_NO"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDMEM.DataSource = MyDatable
                GDMEM.DataBind()
                Session("TAT_5") = MyDatable
                Session("FAMILY_NO") = MyDatable.Rows(0).Item("FAMILY_NO").ToString()
                LBLID.Text = MyDatable.Rows(0).Item("PROPOSER_ID").ToString

                Session("PERIOD_FROM") = MyDatable.Rows(0).Item("PERIOD_FROM").ToString
                Session("PERIOD_TO") = MyDatable.Rows(0).Item("PERIOD_TO").ToString
                MyDatable = Nothing
            Else
                GDMEM.DataSource = Nothing
                GDMEM.DataBind()
            End If

            Str = "SELECT File_No, Member_No,Invoice_No,Invoice_Amt,Claim_Type,Inv_Status,Service_dt FROM DATA_REPOSITORY_DB.dbo.MASTER_CLAIM_REIMBURSMENTS WHERE ltrim(rtrim(Family_No))='" & Session("FAMILY_NO") & "' ORDER BY Service_dt DESC"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_CLAIMS.DataSource = MyDatable
                GD_CLAIMS.DataBind()
                Session("DAD_Claims") = MyDatable

                MyDatable = Nothing
            Else
                GD_CLAIMS.DataSource = Nothing
                GD_CLAIMS.DataBind()
            End If

            'Str = "select  Family_no,  m_ClaimNo,m_MemberNo,m_RefNo,m_FromDt,m_ToDt, Claim_Amt,m_ProviderNo,P_FromDt,P_ToDt, [Source]  FROM  DATA_REPOSITORY_DB.[dbo].[MASTER_CLAIMS_HISTRY_CCA_SUMMARY]   with(nolock) WHERE ltrim(rtrim(Family_No))='" & Session("FAMILY_NO") & "' ORDER BY m_FromDt DESC"
            'MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatable.Rows.Count > 0 Then
            '    RD_CCA_CLAIMS.DataSource = MyDatable
            '    RD_CCA_CLAIMS.DataBind()
            '    Session("DAD_Claims") = MyDatable

            '    MyDatable = Nothing
            'Else
            '    RD_CCA_CLAIMS.DataSource = Nothing
            '    RD_CCA_CLAIMS.DataBind()
            'End If





            LoadNotes(lblid.Text)


            'Policy_No	Client_Type	Insured	Agency	NAME	Commence	Expiring	Class_Name	Sum_Insured	Family_No


            Str = "SELECT Commence,Expiring, Class_Name,Insured,Sum_Insured,Agency, Policy_No FROM   DATA_REPOSITORY_DB.[dbo].[MASTER_NONMED_POLICY] WHERE Family_No='" & Session("FAMILY_NO") & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_NONMED.DataSource = MyDatable
                RD_NONMED.DataBind()
                Session("RD_NONMED") = MyDatable

                MyDatable = Nothing
            Else
                RD_NONMED.DataSource = Nothing
                RD_NONMED.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub LoadNotes(ByVal id As String)
        SqlAction = "SELECT [Note_id],[Notes],[Notes_by],[Note_Date],[Note_Type] FROM  [DATA_REPOSITORY_DB].[dbo].[MASTER_RET_MEMBER_NOTES] WHERE  proposer_id ='" & id & "'  ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
        End If
    End Sub

    Protected Sub GD_CLAIMS_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_CLAIMS.PageIndexChanged
        GD_CLAIMS.CurrentPageIndex = e.NewPageIndex
        GD_CLAIMS.DataSource = Session("DAD_Claims")
        GD_CLAIMS.DataBind()
    End Sub
    Protected Sub RD_CLAIMS_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_CLAIMS.PageIndexChanged
        RD_CLAIMS.CurrentPageIndex = e.NewPageIndex
        RD_CLAIMS.DataSource = Session("RD_Claims")
        RD_CLAIMS.DataBind()
    End Sub
    'Protected Sub RD_CCA_CLAIMS_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles RD_CCA_CLAIMS.PageIndexChanged
    '    RD_CCA_CLAIMS.CurrentPageIndex = e.NewPageIndex
    '    RD_CCA_CLAIMS.DataSource = Session("RD_CCA_CLAIMS")
    '    RD_CCA_CLAIMS.DataBind()
    'End Sub

    Protected Sub GDMEM_PageIndexChanged(sender As Object, e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDMEM.PageIndexChanged

    End Sub


    Protected Sub GDMEM_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDMEM.SelectedIndexChanged
        Try
            Dim number As String = ""
            GD_BENEFIT.DataSource = Nothing
            GD_BENEFIT.DataBind()
            GD_POLICY.DataSource = Nothing
            GD_POLICY.DataBind()
            GD_CLAIMS.DataSource = Nothing
            GD_CLAIMS.DataBind()
            RD_CLAIMS.DataSource = Nothing
            RD_CLAIMS.DataBind()
            'RD_CCA_CLAIMS.DataSource = Nothing
            'RD_CCA_CLAIMS.DataBind()
            GD_BENEFIT_Clap.DataSource = Nothing
            GD_BENEFIT_Clap.DataBind()

            number = (DirectCast(GDMEM.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()

            Str = "SELECT  Benefit,Sub_Benefit,Shared_Unshared,Limit,Fund_Type  FROM  [DATA_REPOSITORY_DB_CLAPI].[dbo].[MASTER_CLAPI_RET_MEMBER_BENEFITS_LIST] WITH (NOLOCK) where Member_number='" & number & "' AND Membership_Status='Active'"
            'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_BENEFIT_Clap.DataSource = MyDatable
                GD_BENEFIT_Clap.DataBind()
                MyDatable = Nothing
            Else
                Str = "SELECT  Benefit,Sub_Benefit,Shared_Unshared,Limit,Fund_Type  FROM  [DATA_REPOSITORY_DB_CLAPI].[dbo].[MASTER_CLAPI_CORP_MEMBER_BENEFITS_LIST] WITH (NOLOCK) where Member_number='" & number & "' AND Membership_Status='Active'"
                'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_BENEFIT_Clap.DataSource = MyDatable
                    GD_BENEFIT_Clap.DataBind()
                    MyDatable = Nothing
                Else

                    GD_BENEFIT_Clap.DataSource = Nothing
                    GD_BENEFIT_Clap.DataBind()
                End If
            End If

            Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM DATA_REPOSITORY_DB.[dbo].[TBL_MEMBER_BAL] WITH (NOLOCK) WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_BENEFIT.DataSource = MyDatable
                GD_BENEFIT.DataBind()
                MyDatable = Nothing
            Else
                GD_BENEFIT.DataSource = Nothing
                GD_BENEFIT.DataBind()
            End If

            Str = "SELECT [FromDt],[ToDt],SCHEME_NAME,SOURCE,JOINDT FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_POLICY_HISTRY] WITH (NOLOCK) WHERE  ltrim(rtrim(MemberNo))='" & number & "' ORDER BY ToDt DESC"
            'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_POLICY.DataSource = MyDatable
                GD_POLICY.DataBind()
                MyDatable = Nothing
            Else
                GD_POLICY.DataSource = Nothing
                GD_POLICY.DataBind()
            End If
            'Claims

            'Str = "SELECT [DISPLAY_MEMBERSHIP_NO],[INVOICE_NO],ADMISSION_DATE,INVOICE_AMT,CLAIM_SUB_TYPE CLAIM_TYPE, PROVIDER_NAME,BILL_STATUS FROM [DATA_REPOSITORY_DB].[dbo].[VW_MASTER_CLAIMS] WITH (NOLOCK) WHERE  ltrim(rtrim(DISPLAY_MEMBERSHIP_NO))='" & number & "' and ADMISSION_DATE between '" & Session("PERIOD_FROM") & "' and '" & Session("PERIOD_TO") & "' ORDER BY ADMISSION_DATE DESC"
            ''Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            'MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatable.Rows.Count > 0 Then
            '    RD_CLAIMS.DataSource = MyDatable
            '    RD_CLAIMS.DataBind()
            '    Session("RD_Claims") = MyDatable
            '    MyDatable = Nothing
            'Else
            '    RD_CLAIMS.DataSource = Nothing
            '    RD_CLAIMS.DataBind()
            'End If

            'Str = "select  Family_no,  m_ClaimNo,m_MemberNo,m_RefNo,m_FromDt,m_ToDt, Claim_Amt,m_ProviderNo,P_FromDt,P_ToDt, [Source]  FROM  DATA_REPOSITORY_DB.[dbo].[MASTER_CLAIMS_HISTRY_CCA_SUMMARY]   with(nolock) WHERE  ltrim(rtrim(m_MemberNo))='" & number & "'  ORDER BY m_FromDt DESC"
            ''Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            'MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatable.Rows.Count > 0 Then
            '    RD_CCA_CLAIMS.DataSource = MyDatable
            '    RD_CCA_CLAIMS.DataBind()
            '    Session("RD_CCA_CLAIMS") = MyDatable
            '    MyDatable = Nothing
            'Else
            '    RD_CCA_CLAIMS.DataSource = Nothing
            '    RD_CCA_CLAIMS.DataBind()
            'End If
          
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            If cbonote.SelectedValue = "" Then
                lblerr.Text = "Select the Note Type"
                Exit Sub
            End If
            If lblid.Text = "" Then
                lblerr.Text = "Select the Proposer Name"
                Exit Sub
            End If
            If txtnote.Text <> "" Then
                MyDBAction.TASK_MESSAGES(LBLID.Text, txtnote.Text, Session("username"), Date.Now(), cbonote.SelectedValue, Session("FAMILY_NO"))
                LoadNotes(lblid.Text)

                lblerr.Text = "Note Saved Successful!"
                txtnote.Text = ""
            End If


        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

 

    Protected Sub GD_POLICY_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_POLICY.SelectedIndexChanged
        Try
            Dim number_1 As String = ""
         
            RD_CLAIMS.DataSource = Nothing
            RD_CLAIMS.DataBind()
            'RD_CCA_CLAIMS.DataSource = Nothing
            'RD_CCA_CLAIMS.DataBind()
            number_1 = (DirectCast(GD_POLICY.SelectedItems(0), GridDataItem)).GetDataKeyValue("DISPLAY_MEMBERSHIP_NO").ToString()

            Str = "SELECT [DISPLAY_MEMBERSHIP_NO],[INVOICE_NO],ADMISSION_DATE,INVOICE_AMT,CLAIM_SUB_TYPE CLAIM_TYPE, PROVIDER_NAME,BILL_STATUS FROM [DATA_REPOSITORY_DB].[dbo].[VW_MASTER_CLAIMS] WHERE  ltrim(rtrim(DISPLAY_MEMBERSHIP_NO))='" & number_1 & "' and ADMISSION_DATE between '" & Session("PERIOD_FROM") & "' and '" & Session("PERIOD_TO") & "' ORDER BY ADMISSION_DATE DESC"
            'Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                RD_CLAIMS.DataSource = MyDatable
                RD_CLAIMS.DataBind()
                Session("RD_Claims") = MyDatable
                MyDatable = Nothing
            Else
                RD_CLAIMS.DataSource = Nothing
                RD_CLAIMS.DataBind()
            End If

            'Str = "select  Family_no,  m_ClaimNo,m_MemberNo,m_RefNo,m_FromDt,m_ToDt, Claim_Amt,m_ProviderNo,P_FromDt,P_ToDt, [Source]  FROM  [dbo].[MASTER_CLAIMS_HISTRY_CCA_SUMMARY]   with(nolock) WHERE  ltrim(rtrim(m_MemberNo))='" & number_1 & "'  and m_FromDt between '" & Session("PERIOD_FROM") & "' and '" & Session("PERIOD_TO") & "'  ORDER BY m_FromDt DESC"
            ''Str = "SELECT BENEFIT,LIMIT_AMT,CONSUMED,BALANCE,WAITING_PERIOD,FUND_MANAGE,DATA_DATE FROM [C_REGISTRY].[DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_BAL] WHERE  DISPLAY_MEMBERSHIP_NO='" & number & "'"
            'MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatable.Rows.Count > 0 Then
            '    RD_CCA_CLAIMS.DataSource = MyDatable
            '    RD_CCA_CLAIMS.DataBind()
            '    Session("RD_CCA_CLAIMS") = MyDatable
            '    MyDatable = Nothing
            'Else
            '    RD_CCA_CLAIMS.DataSource = Nothing
            '    RD_CCA_CLAIMS.DataBind()
            'End If

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
      
    End Sub
End Class
