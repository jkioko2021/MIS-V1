﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Try
                Dim unit_code As String = ""
                Dim region_code As String = ""
                dtreceivedate.DbSelectedDate = Date.Now
                dtreceivedate.Enabled = False
                dtupload.DbSelectedDate = Date.Now
                HiddenField1.Value = 0
                Session("empcode") = Nothing
                Session("agentemail") = Nothing
                Session("med") = 0
                Session("Allocate") = 0
                'ltEmbed.Text = ""
                FL1.Enabled = False
                btnupload.Enabled = False

                Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1  ORDER BY AGENT_NAME" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboagent
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                    .DataValueField = MyDatatable.Columns("USER_ID").ToString
                    .DataBind()
                End With
                Str = "SELECT  [DOC_ID],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] where CODE=3"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cbodoc
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("DOC_NAME").ToString
                    .DataValueField = MyDatatable.Columns("DOC_ID").ToString
                    .DataBind()
                End With

                SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE entered_by='" & Session("username") & "' and Forwarded=0  AND Is_Declined=0  AND Is_Active=1"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GDTracking_0.DataSource = MyDatable
                    GDTracking_0.DataBind()
                    Session("DAD_T") = MyDatable
                    MyDatable = Nothing
                Else
                    GDTracking_0.DataSource = Nothing
                    GDTracking_0.DataBind()
                End If

                cboAllocateto.Enabled = True
                Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 AND username='" & Session("username") & "'" '"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With cboAllocateto
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("EmployeeName").ToString
                    .DataValueField = MyDatatable.Columns("username").ToString
                    .DataBind()
                End With

                Str = "SELECT  [DOC_ID],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] WHERE ACTIVE=1"
                MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                With chklist
                    .Items.Clear()
                    .DataSource = MyDatatable
                    .DataTextField = MyDatatable.Columns("DOC_NAME").ToString
                    .DataValueField = MyDatatable.Columns("DOC_ID").ToString
                    .DataBind()
                End With
                loadGrid_N()


            Catch ex As Exception
                lblerr.Text = ex.Message
            End Try
        End If

    End Sub
    Protected Sub GDSEARCH_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDTracking.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("File_No").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""
            Dim audit As New DataManagement
            UpdateRecord("UPDATE  [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] SET Is_Active=0  WHERE File_No='" & HiddenField1.Value.ToString & "'")
            'DeleteRecord("DELETE FROM TBL_MIS_CRM_DOCS WHERE  File_No='" & HiddenField1.Value.ToString & "'")

            audit.AddAdminAuditTrail(Session("UserName").ToString, "Business Tracking Delete", "Deleted Record :-   :" & HiddenField1.Value & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblerr.Text = "Record Deleted!"
            'CmdSave.Enabled = False

            loadGrid_N()

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub
    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub



    Protected Sub btnsave_Click(sender As Object, e As System.EventArgs) Handles btnsave.Click
        Try
            Dim mtiba As Integer = 0
            Dim Is_IPF As Integer = 0
            If chkmtiba.Checked = True Then
                mtiba = 1
            End If
            If chkipf.Checked = True Then
                Is_IPF = 1
            End If
            Dim complete As Integer = 0
            If chkassembly.Checked = True Then
                complete = 1
            End If
            If cboBusiness.SelectedValue = "" Then
                lblsave.Text = "Select The Business Type"
                Exit Sub
            End If
            If cboclient.SelectedValue = "" Then
                lblsave.Text = "Select The Client Type"
                Exit Sub
            End If
            If cboagent.SelectedValue = "" Then
                lblsave.Text = "Select The Agent"
                Exit Sub
            End If
            If cborateType.SelectedValue = "" Then
                lblsave.Text = "Select The Rate Type.i.e Normal standard or negotiated rates!"
                cborateType.Focus()
                Exit Sub
            End If
            If txtProposer.Text = "" Then
                lblsave.Text = "Enter the Proposer Name"
                Exit Sub
            End If
            If cboclient.SelectedValue = "C" Then
                cborateType.SelectedValue = "C"
            End If
            If cboclient.SelectedValue = "R" Then
                cborateType.SelectedValue = "S"
            End If
         

            If HiddenField1.Value = 0 Then
                Generate_Task()
                If txtrefno.Text = "" Then
                    txtrefno.Text = FILE_NO.Text
                End If
                MyDBAction.Business_Tracking(FILE_NO.Text, cboBusiness.SelectedValue, cboclient.SelectedValue, txtProposer.Text, txtFamily.Text, cboagent.SelectedValue, txtpremium.Text, mtiba, CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), complete, HiddenField1.Value, Session("UserName").ToString, cboBUS.SelectedValue, HiddenField1.Value, cbobenefit.SelectedValue, 1, "N", "", cborateType.SelectedValue, Is_IPF, Trim(txtrefno.Text).ToUpper, txtreceiptamt.Text)
            Else
                If txtrefno.Text = "" Then
                    txtrefno.Text = FILE_NO.Text
                End If
                MyDBAction.Business_Tracking(FILE_NO.Text, cboBusiness.SelectedValue, cboclient.SelectedValue, txtProposer.Text, txtFamily.Text, cboagent.SelectedValue, txtpremium.Text, mtiba, CDate(dtreceivedate.DbSelectedDate).ToString("yyyy-MM-dd"), complete, HiddenField1.Value, Session("UserName").ToString, cboBUS.SelectedValue, HiddenField1.Value, cbobenefit.SelectedValue, 1, "N", "", cborateType.SelectedValue, Is_IPF, Trim(txtrefno.Text).ToUpper, txtreceiptamt.Text)
            End If


            For Each MyItem In chklist.Items
                If MyItem.Selected = True Then
                    MyDBAction.UPLOAD_ITEMS(FILE_NO.Text, MyItem.value, MyItem.TEXT, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"))
                End If
            Next


            loadGrid_N()
            loadGrid(FILE_NO.Text)
            txtcomment.Text = ""
            HiddenField1.Value = 0
            lblsave.Text = "Saved Successfully!"
            txtProposer.Text = ""
            txtFamily.Text = ""
            dtreceivedate.DbSelectedDate = Date.Now
            txtpremium.Text = 0
            cboBusiness.Text = ""
            cboclient.Text = ""
            txtrefno.Text = ""
            txtreceiptamt.Text = 0
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub loadGrid_N()
        SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE entered_by='" & Session("username") & "' and updated=0 AND Is_Declined=0 AND Is_Branch=1  AND Is_Active=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_0.DataSource = MyDatable
            GDTracking_0.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
        End If
        SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE entered_by='" & Session("username") & "' and Is_complete=0 and Forwarded=0 and  Is_Declined=0 AND Is_Branch=1 AND Is_Active=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking.DataSource = MyDatable
            GDTracking.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking.DataSource = Nothing
            GDTracking.DataBind()
        End If

        SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type,Allocated_to  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE Forwarded=1 AND Medical_UW=1 AND Ready_For_update=0 AND Is_Declined=0 and entered_by='" & Session("username") & "' AND Is_Branch=1 AND Is_Active=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDTracking_med.DataSource = MyDatable
            GDTracking_med.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDTracking_med.DataSource = Nothing
            GDTracking_med.DataBind()
        End If

        SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type,Allocated_to  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE Forwarded=1 AND Ready_For_Update=1  AND Allocated_to='" & Session("username") & "' AND ALLOCATED=1 AND updated=0 AND  Is_Declined=0 And [Client_Type]='R'  AND Business='M' AND Is_Branch=1 AND Is_Active=1"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDAllocated.DataSource = MyDatable
            GDAllocated.DataBind()
            Session("DAD_T") = MyDatable
            MyDatable = Nothing
        Else
            GDAllocated.DataSource = Nothing
            GDAllocated.DataBind()
        End If
    End Sub

    Public Sub loadGrid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        Try

            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By],Doc_Ref FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS_1.DataSource = MyDatable
                GD_DOCS_1.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS_1.DataSource = MyDatable
                GD_DOCS_1.DataBind()
            End If

            MyDatable = Nothing
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By],Doc_Ref FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  File_No ='" & STR & "' AND ACTIVE=1 AND UPLOAD_DONE=1 ORDER BY DOC_ID ASC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
                MyDatable = Nothing
            Else
                GD_DOCS.DataSource = MyDatable
                GD_DOCS.DataBind()
            End If
            'Notes
            SqlAction = "SELECT [Note_id],[File_No],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_BUS_TRACKING_NOTES] WHERE  File_No ='" & STR & "'  AND ACTIVE=1 ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
            End If
            SqlAction = "SELECT [File_No],[Proposer_Name], Premium, Client_Type,Pay_Ref_No,Paid_Amt,File_Status  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE Pay_Ref_No='" & Trim(txtrefno.Text) & "'  AND Is_Active=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_Pay.DataSource = MyDatable
                GD_Pay.DataBind()
                txtpaid.Text = Convert.ToInt32(MyDatable.Compute("sum(Paid_Amt)", String.Empty))
                MyDatable = Nothing
            Else
                GD_Pay.DataSource = Nothing
                GD_Pay.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub


    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub
    Protected Sub btnupload_Click(sender As Object, e As System.EventArgs) Handles btnupload.Click
        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        lblupload_1.Text = ""
        lblupload.Text = ""
        'ltEmbed.Text = ""
        Try

            If FL1.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If txttitle.Text = "" Then
                lblerr.Text = "You must enter Document title!"
                Exit Sub
            End If

            Dim filePath As String = FL1.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_File_DOCS(bytes, filename, contenttype, FILE_NO.Text, Trim(txttitle.Text.ToUpper), CDate(dtupload.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), DOC_ID.Text)
                'Response.Redirect(Request.Url.AbsoluteUri)
                lblupload.ForeColor = System.Drawing.Color.Green

                lblupload.Text = "File Uploaded Successfully"

            Else
                lblupload.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            loadGrid(FILE_NO.Text)

            DOC_ID.Text = ""
            'lbltaskno.Text = ""
            txttitle.Text = ""
            dtupload.DbSelectedDate = Date.Now

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    'Protected Sub DownloadFile(sender As Object, e As EventArgs)
    '    ltEmbed.Text = ""
    '    Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
    '    Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
    '    embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
    '    embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
    '    embed += "</object>"
    '    ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileDoc.ashx?Id="), id)
    'End Sub


    Protected Sub GDTracking_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDTracking.SelectedIndexChanged
        Try
            'ltEmbed.Text = ""
            lblupload_1.Text = ""
            lblupload.Text = ""
            lblerr.Text = ""

            HiddenField1.Value = 1
            ID = (DirectCast(GDTracking.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            SqlAction = "SELECT [File_No],[Proposer_Name],Pay_Ref_No,Paid_Amt,[Family_code],Premium,File_Status,Business_Type,Business, Receive_dt,Client_Type,Is_Mtiba,Is_Complete,Agent_id,Medical_UW,Allocated,Is_IPF,Rate_Type,Benefit_Verified,Invoiced  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE File_No='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                FILE_NO.Text = MyDatable.Rows(0).Item("File_No").ToString()
                txtProposer.Text = MyDatable.Rows(0).Item("Proposer_Name").ToString()
                txtFamily.Text = MyDatable.Rows(0).Item("Family_code").ToString()
                dtreceivedate.DbSelectedDate = MyDatable.Rows(0).Item("Receive_dt").ToString()
                txtpremium.Text = MyDatable.Rows(0).Item("Premium").ToString()
                cboBusiness.SelectedValue = MyDatable.Rows(0).Item("Business_Type").ToString()
                cboclient.SelectedValue = MyDatable.Rows(0).Item("Client_Type").ToString()
                chkmtiba.Checked = MyDatable.Rows(0).Item("Is_Mtiba").ToString()
                chkassembly.Checked = MyDatable.Rows(0).Item("Is_Complete").ToString()
                cboagent.SelectedValue = MyDatable.Rows(0).Item("Agent_id").ToString()
                cboBUS.SelectedValue = MyDatable.Rows(0).Item("Business").ToString()
                Session("med") = MyDatable.Rows(0).Item("Medical_UW").ToString()
                chkmedical.Checked = MyDatable.Rows(0).Item("Medical_UW").ToString()
                Session("Allocate") = MyDatable.Rows(0).Item("Allocated").ToString()
                Session("Invoiced") = MyDatable.Rows(0).Item("Invoiced").ToString()
                lblbene.Text = MyDatable.Rows(0).Item("Benefit_Verified").ToString()
                cborateType.SelectedValue = MyDatable.Rows(0).Item("Rate_Type").ToString()
                chkipf.Checked = MyDatable.Rows(0).Item("Is_IPF").ToString()
                txtrefno.Text = MyDatable.Rows(0).Item("Pay_Ref_No").ToString()
                txtreceiptamt.Text = MyDatable.Rows(0).Item("Paid_Amt").ToString()
                loadGrid(FILE_NO.Text)

                'If cboclient.SelectedValue = "R" Then
                '    chklist.Items.Clear()
                '    If cboBusiness.SelectedValue = "N" Then
                '        Str = "SELECT  [DOC_ID],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] where  [BUSINESS_TYPE] <>'R' AND CLIENT='R'"
                '        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                '        With chklist
                '            .Items.Clear()
                '            .DataSource = MyDatatable
                '            .DataTextField = MyDatatable.Columns("DOC_NAME").ToString
                '            .DataValueField = MyDatatable.Columns("DOC_ID").ToString
                '            .DataBind()
                '        End With
                '    ElseIf cboBusiness.SelectedValue = "R" Then
                '        Str = "SELECT  [DOC_ID],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] where  [BUSINESS_TYPE] <>'N' AND CLIENT='R'"
                '        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                '        With chklist
                '            .Items.Clear()
                '            .DataSource = MyDatatable
                '            .DataTextField = MyDatatable.Columns("DOC_NAME").ToString
                '            .DataValueField = MyDatatable.Columns("DOC_ID").ToString
                '            .DataBind()
                '        End With
                '    End If
                'Else
                '    chklist.Items.Clear()
                '    If cboBusiness.SelectedValue = "N" Then
                '        Str = "SELECT  [DOC_ID],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] where  [BUSINESS_TYPE] <>'R' AND CLIENT='C'"
                '        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                '        With chklist
                '            .Items.Clear()
                '            .DataSource = MyDatatable
                '            .DataTextField = MyDatatable.Columns("DOC_NAME").ToString
                '            .DataValueField = MyDatatable.Columns("DOC_ID").ToString
                '            .DataBind()
                '        End With
                '    ElseIf cboBusiness.SelectedValue = "R" Then
                '        Str = "SELECT  [DOC_ID],[DOC_NAME] FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_REQ] where  [BUSINESS_TYPE] <>'N' AND CLIENT='C'"
                '        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
                '        With chklist
                '            .Items.Clear()
                '            .DataSource = MyDatatable
                '            .DataTextField = MyDatatable.Columns("DOC_NAME").ToString
                '            .DataValueField = MyDatatable.Columns("DOC_ID").ToString
                '            .DataBind()
                '        End With
                '    End If
                'End If


                SqlAction = "SELECT Doc_code FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  File_No ='" & FILE_NO.Text & "' and Active=1"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                chklist.ClearSelection()
                For Each dt2_row As System.Data.DataRow In MyDatable.Rows
                    Dim IT As String = dt2_row("Doc_code").ToString()
                    For i As Integer = 0 To chklist.Items.Count - 1
                        If chklist.Items(i).Value = IT Then
                            chklist.Items(i).Selected = True
                        End If
                    Next

                Next
            End If
            chklist.Enabled = False
            btnsave.Enabled = False
            txtProposer.Enabled = False
            txtFamily.Enabled = False
            dtreceivedate.Enabled = False
            txtpremium.Enabled = False
            cboBusiness.Enabled = False
            cboclient.Enabled = False
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Public Sub Generate_Task()

        SqlAction = "SELECT ISNULL((MAX(Id)+1),1) NUMBER FROM [dbo].[TBL_MIS_CRM_BUSINESS_TRACKING]"
        MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatatable.Rows.Count > 0 Then
            AB = MyDatatable.Rows(0).Item("NUMBER").ToString()
            Dim numStr4ch As String = Strings.Right("000" & AB.ToString(), 4)
            FILE_NO.Text = cboclient.SelectedValue & "-" & Month(Date.Now()) & "/" & Right(Year(Date.Now()), 2) & "/-" + numStr4ch + ""

        End If
    End Sub

    Protected Sub btnedit_Click(sender As Object, e As System.EventArgs) Handles btnedit.Click
        HiddenField1.Value = 1
        chklist.Enabled = True
        txtProposer.Enabled = True
        txtFamily.Enabled = True
        dtreceivedate.Enabled = True
        txtpremium.Enabled = True
        cboBusiness.Enabled = True
        cboclient.Enabled = True
        btnsave.Enabled = True
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            If cbosearch.SelectedValue = "F" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE File_No Like '%" & Trim(txtsearch.Text.ToUpper) & "%' AND Is_Declined=0  AND Is_Active=1"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE Proposer_Name Like '%" & Trim(txtsearch.Text.ToUpper) & "%' AND Is_Declined=0  AND Is_Active=1"
            End If
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDTracking_0.DataSource = MyDatable
                GDTracking_0.DataBind()
                Session("DAD_T") = MyDatable
                MyDatable = Nothing
            Else
                GDTracking_0.DataSource = Nothing
                GDTracking_0.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnnew_Click(sender As Object, e As System.EventArgs) Handles btnnew.Click
        HiddenField1.Value = 0
        txtProposer.Enabled = True
        chklist.Enabled = True
        txtFamily.Enabled = True
        dtreceivedate.Enabled = True
        txtpremium.Enabled = True
        cboBusiness.Enabled = True
        cboclient.Enabled = True
        btnsave.Enabled = True
        FILE_NO.Text = ""
        txtProposer.Text = ""
        txtFamily.Text = ""
        dtreceivedate.DbSelectedDate = Date.Now
        txtpremium.Text = ""
        cboBusiness.Text = ""
        cboclient.Text = ""
        chkassembly.Checked = False

        chkmedical.Checked = False
        chkmtiba.Checked = False


    End Sub

    'Protected Sub cboAction_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cboAction.SelectedIndexChanged
    '    cboAllocateto.SelectedValue = ""
    '    cboAction.Text = ""
    '    'ltEmbed.Text = ""

    '    If cboAction.SelectedValue = "MU" Then
    '        cboAllocateto.Enabled = True
    '        Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 AND Department='MEDICAL UNDERWRITING'" '"
    '        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
    '        With cboAllocateto
    '            .Items.Clear()
    '            .DataSource = MyDatatable
    '            .DataTextField = MyDatatable.Columns("EmployeeName").ToString
    '            .DataValueField = MyDatatable.Columns("username").ToString
    '            .DataBind()
    '        End With
    '    ElseIf cboAction.SelectedValue = "A" Then
    '        cboAllocateto.Enabled = True
    '        Str = "SELECT DISTINCT EmployeeName,username FROM dbo.Employees WHERE  Activated=1 AND approved=1 AND Deleted=0 AND Department='MEMBERSHIP'" '"
    '        MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
    '        With cboAllocateto
    '            .Items.Clear()
    '            .DataSource = MyDatatable
    '            .DataTextField = MyDatatable.Columns("EmployeeName").ToString
    '            .DataValueField = MyDatatable.Columns("username").ToString
    '            .DataBind()
    '        End With
    '    End If

    'End Sub

    Protected Sub btnforward_Click1(sender As Object, e As System.EventArgs) Handles btnforward.Click
        Dim a_to As String = ""
        lblsave.Text = ""
        lblerr.Text = ""
        Try
            If FILE_NO.Text = "" Then
                lblerr.Text = "Select the File!"
                Exit Sub
            End If

            If cboAction.SelectedValue = "" Then
                lblerr.Text = "Select the Action!"
                Exit Sub
            End If
            If cboAllocateto.SelectedValue = "" And cboAction.SelectedValue <> "RI" Then
                lblerr.Text = "Select the Forward To!"
                Exit Sub
            End If
            If txtcomment.Text = "" Then
                lblerr.Text = "Enter short notes!"
                Exit Sub
            End If
            If cboAction.SelectedValue = "MU" Then
                a_to = "medicalunderwriter"
            Else
                a_to = cboAllocateto.SelectedValue
            End If

            'SqlAction = "SELECT  File_Name FROM [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE File_No='" & FILE_NO.Text & "' AND ACTIVE=1 AND Upload_Done=0"
            'MyDatatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            'If MyDatatable.Rows.Count > 0 Then
            '    btnsave.Enabled = True
            '    lblerr.Text = "You must upload the Missing Documents!"
            'Else
            If cboBUS.SelectedValue = "M" And cboclient.SelectedValue = "R" And chkipf.Checked = False And (cboBusiness.SelectedValue = "N" Or cboBusiness.SelectedValue = "R") Then
                If Session("med") = 1 Then
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Forwarded=1,[Is_Complete]=1,[Ready_For_update]=1, File_Status='MEDICAL UW-REVIEW' where [File_No]= '" & FILE_NO.Text & "'")
                ElseIf Session("Allocate") = 1 Then
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Forwarded=1,Allocated_to='" & cboAllocateto.SelectedValue & "', [Is_Complete]=1,Allocated=1,[Ready_For_update]=1, File_Status='ALLOCATED' where [File_No]= '" & FILE_NO.Text & "'")
                Else
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Allocated=1,  Allocated_to='" & cboAllocateto.SelectedValue & "',Forwarded=1,[Is_Complete]=1 ,Forwarded_By='" & Session("username") & "' ,[Ready_For_update]=1, [Forward_Date]='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',File_Status='FORWARDED' where [File_No]= '" & FILE_NO.Text & "'")
                End If
                'SqlAction = "SELECT [File_No],[Proposer_Name],[Receive_dt],Premium,File_Status,Business_Type,Client_Type,Allocated_to  FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE Forwarded=1 AND Ready_For_Update=1  AND Allocated_to='" & Session("username") & "' AND ALLOCATED=1 AND INVOICED=0 AND  Is_Declined=0 And [Client_Type]='R'  AND Business='M'"
                UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Is_Branch=1,Forwarded=1,[Is_Complete]=1  where [File_No]= '" & FILE_NO.Text & "'")
                MyDBAction.TRACKING_ALLOCATION(FILE_NO.Text, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"), a_to, txtcomment.Text, cboAction.SelectedValue, "YES")
            Else
                If Session("med") = 1 And Session("Allocate") = 0 Then
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Forwarded=1,[Is_Complete]=1,[Ready_For_update]=0, File_Status='MEDICAL UW-REVIEW' where [File_No]= '" & FILE_NO.Text & "'")
                ElseIf Session("Allocate") = 1 And lblbene.Text = "NO" Then
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Forwarded=1,[Is_Complete]=1,Allocated=1,[Ready_For_update]=1, File_Status='BENEFIT VERIFICATION' where [File_No]= '" & FILE_NO.Text & "'")
                ElseIf Session("Allocate") = 1 And lblbene.Text = "YES" And Session("Invoiced") = 0 Then
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Forwarded=1,[Is_Complete]=1,Allocated=1,[Ready_For_update]=1, File_Status='ALLOCATED' where [File_No]= '" & FILE_NO.Text & "'")
                ElseIf Session("Allocate") = 1 And lblbene.Text = "YES" And Session("Invoiced") = 1 Then
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Forwarded=1,[Is_Complete]=1,Allocated=1,[Ready_For_update]=1, File_Status='INVOICED' where [File_No]= '" & FILE_NO.Text & "'")
                Else
                    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Forwarded=1,[Is_Complete]=1 ,Forwarded_By='" & Session("username") & "' ,[Ready_For_update]=1, [Forward_Date]='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',File_Status='FORWARDED' where [File_No]= '" & FILE_NO.Text & "'")
                End If
                If cboBUS.SelectedValue = "M" And Session("med") <> 1 Then
                    'Session("email") = "computer-operations@aar.co.ke"
                    'Session("msg") = "Kindly note that the above client has been Tracked and forwarded to Membership for update!"
                ElseIf cboBUS.SelectedValue = "N" Then
                    Session("email") = "nonmedical@aar.co.ke"
                    Session("msg") = "Kindly note that the above client has been Tracked and forwarded to Non-Medical Team for update!"
                    MailSent = SendLoginDetails("Team", Session("email"), Session("email"))
                End If

                'Session("email") = "jmwaniki@aar.co.ke"
                'Session("cc_email") = ""
                'End If
            End If
            If txtcomment.Text <> "" Then
                MyDBAction.TRACKING_MESSAGES(FILE_NO.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
            End If
            lblerr.Text = "Business updated successfully!"
            loadGrid_N()
            txtcomment.Text = ""
            FILE_NO.Text = ""
            chkmedical.Checked = False
            chkmtiba.Checked = False
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            GDTracking_0.DataSource = Nothing
            GDTracking_0.DataBind()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub GDAllocated_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDAllocated.SelectedIndexChanged
        Try
            ltEmbed.Text = ""
            HiddenField1.Value = 1
            ID = (DirectCast(GDAllocated.SelectedItems(0), GridDataItem)).GetDataKeyValue("File_No").ToString()
            SqlAction = "SELECT [File_No],Pay_Ref_No,Paid_Amt,[Proposer_Name],[Family_code],Premium,File_Status,Business_Type,Receive_dt,entered_By,Agent_id,  Client_Type,Is_Mtiba   FROM [CRM].[dbo].[TBL_MIS_CRM_BUSINESS_TRACKING] WITH (NOLOCK) WHERE File_No='" & ID & "'"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                FILE_NO.Text = MyDatable.Rows(0).Item("File_No").ToString()
                lblfile_1.Text = MyDatable.Rows(0).Item("File_No").ToString()
                lblenteredby.Text = MyDatable.Rows(0).Item("entered_By").ToString()
                txtrefno.Text = MyDatable.Rows(0).Item("Pay_Ref_No").ToString()
                txtreceiptamt.Text = MyDatable.Rows(0).Item("Paid_Amt").ToString()
                loadGrid(FILE_NO.Text)
            End If
        Catch ex As Exception

        End Try
    End Sub



    Protected Sub btnforward_1_Click(sender As Object, e As System.EventArgs) Handles btnforward_1.Click
        Dim a_to As String = ""
        lblupload_1.Text = ""
        Try
            If lblfile_1.Text = "" Then
                lblerr_1.Text = "Select the File!"
                Exit Sub
            End If

            If cboAction_1.SelectedValue = "" Then
                lblerr_1.Text = "Select the Action!"
                Exit Sub
            End If

            If txtcomment_1.Text = "" Then
                lblerr_1.Text = "Enter short notes!"
                Exit Sub
            End If


            MyDBAction.TRACKING_ALLOCATION_MSHIP(lblfile_1.Text, CDate(Date.Now).ToString("yyyy-MM-dd"), Session("username"), a_to, txtcomment_1.Text, cboAction_1.SelectedValue, txtinv.Text)

            If cboAction_1.SelectedValue = "M" Then
                UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET Allocated=0,Invoiced=1,File_Status='RECEIPTED',Cashier='" & Session("username") & "',To_Cashier_dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',Receipt_Dt='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',   Receipted=1,update_date='" & CDate(Date.Now).ToString("yyyy-MM-dd") & "',updated_by='" & Session("username") & "'  where [File_No]= '" & FILE_NO.Text & "'")
            End If


            If txtcomment_1.Text <> "" Then
                MyDBAction.TRACKING_MESSAGES(lblfile_1.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment_1.Text)
            End If
            Session("email") = ""
            If cboAction_1.SelectedValue = "M" Then
                'Session("email") = "computer-operations@aar.co.ke"
                'Session("msg") = "Kindly note that the above client has been Receipted from branch and forwarded to Membership for update!"
                'MailSent = SendLoginDetails("Team", Session("email"), Session("email"))
            ElseIf cboAction_1.SelectedValue = "IT" Then
                Session("email") = "itservicedesk@aar.co.ke"
                'Session("email") = "jmwaniki@aar.co.ke"
                Session("msg") = "Kindly note that the below business has been forwarded to IT for support assistance.!"
                MailSent = SendLoginDetails("Team", Session("email"), Session("email"))
            End If


            lblerr_1.Text = "Business updated successfully!"
            loadGrid_N()
            txtcomment_1.Text = ""
            GD_DOCS.DataSource = Nothing
            GD_DOCS.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub






    Protected Sub GD_DOCS_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_DOCS_1.SelectedIndexChanged
        Try
            Dim stst As String = ""
            HiddenField1.Value = ""
            stst = (DirectCast(GD_DOCS_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("DOC_ID").ToString()
            SqlAction = "SELECT [DOC_ID],[File_No],[Doc_Title],[Doc_Date],[File_Name],[Upload_By] FROM  [Doc_Arc_DB].[dbo].[TBL_MIS_CRM_DOCS] WHERE  DOC_ID ='" & stst & "' AND ACTIVE=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                txttitle.Text = MyDatable.Rows(0).Item("Doc_Title").ToString()
                DOC_ID.Text = MyDatable.Rows(0).Item("DOC_ID").ToString()

                FL1.Enabled = True
                btnupload.Enabled = True
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub

    Protected Sub DownloadFile(sender As Object, e As EventArgs)
        ltEmbed.Text = ""
        Dim id As Integer = Integer.Parse(TryCast(sender, LinkButton).CommandArgument)
        Dim embed As String = "<object data=""{0}{1}"" type=""application/pdf"" width=""1000px"" height=""600px"">"
        embed += "If you are unable to view file, you can download from <a href = ""{0}{1}&download=1"">here</a>"
        embed += " or download <a target = ""_blank"" href = ""{0}{1}&download=1"">Adobe PDF Reader</a> to view the file."
        embed += "</object>"
        ltEmbed.Text = String.Format(embed, ResolveUrl("~/FileDoc.ashx?Id="), id)
    End Sub

    Public Function SendLoginDetails(ByVal EmployeeName As String, ByVal RecepientEmail As String, ByVal ccemail As String) As Boolean

        Dim MailSent As Boolean = False
        Dim strMailFromEmail As String = ""
        Dim strMailFromName As String = ""
        Dim MessageSubject As String = ""
        Dim MySqlAction As String = ""
        Dim MyDBAction As New DataManagement
        Dim MyDataTable As New Data.DataTable
        Dim MyEncryption As New SysSettsEncryption
        Dim LoginFromEmail As String = ""
        Dim LoginDisplayName As String = ""
        Dim LoginSubject As String = ""
        Dim EmailServer As String = ""
        Dim EmailUserName As String = ""
        Dim EmailPassword As String = ""
        Dim action As String = ""

        Try ''--Retrieve settings from db n decrypt - Mercy - 12th Apr 2011
            LoginFromEmail = System.Configuration.ConfigurationManager.AppSettings("LoginFromEmail").Trim()
            LoginDisplayName = System.Configuration.ConfigurationManager.AppSettings("LoginDisplayName").Trim()
            LoginSubject = System.Configuration.ConfigurationManager.AppSettings("LoginSubject").Trim()
            'LoginSubject = "BUSINESS ALLOCATION"
            EmailServer = System.Configuration.ConfigurationManager.AppSettings("EmailServer").Trim()
            EmailUserName = System.Configuration.ConfigurationManager.AppSettings("EmailUsername").Trim()
            EmailPassword = System.Configuration.ConfigurationManager.AppSettings("EmailPassword").Trim()

            Dim strHTML As New StringBuilder
            strHTML = strHTML.Append("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>")
            strHTML = strHTML.Append("<html xmlns='http://www.w3.org/1999/xhtml' >")
            strHTML = strHTML.Append("<head>")
            strHTML = strHTML.Append("</head>")
            strHTML = strHTML.Append("<body>")
            strHTML = strHTML.Append("<table style='width: 668px'>")
            strHTML = strHTML.Append("<tr>")

            strHTML = strHTML.Append("<td colspan='3'>")
            'strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'> Attention:Relationship Managers")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Dear : Membership Team  </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            MessageSubject = "Branch Business Update:" & FILE_NO.Text & ""
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'>" & Session("msg") & " </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("--------------------------------------<b>Details</b>------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>File No    :</b>" & FILE_NO.Text & " </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Client Name:</b> " & txtProposer.Text & " </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Date       :</b> " & Date.Now() & " </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<span style='font-size: 11pt; font-family: Calibri'><b>Update By :</b> " & Session("FullNames") & " </span>")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------<b>Notes</b>--------------------------------------------------------")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment_1.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("" & txtcomment.Text & "")
            strHTML = strHTML.Append("<br />")
            strHTML = strHTML.Append("----------------------------------------End----------------------------------------------------------")
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("<span style='font-size: 11pt; font-color:RED; font-family: Calibri'><b><i>THIS IS A SYSTEM GENERATED EMAIL.DO NOT REPLY!.</i></b>")
            'Membership Enquiry (membershipenquiry@aar.co.ke)
            strHTML = strHTML.Append("<br />")

            strHTML = strHTML.Append("</table>")
            strHTML = strHTML.Append("</body>")
            strHTML = strHTML.Append("</html>")
            Dim mymail As New Emailing
            MailSent = mymail.SendNotification("", MessageSubject, strHTML.ToString, True, EmailServer, EmailUserName, EmailPassword, RecepientEmail, EmployeeName, LoginFromEmail, LoginDisplayName, ccemail)
            Session("MailSent") = MailSent
        Catch ex As Exception
            'MyDBAction.DoLogs("Class==AssignAdminAccessProfile.vb: Private Sub DisplayMenuItems()" & " : Error : " & ex.Message)
            MailSent = False
        End Try

        Return MailSent
    End Function



    Protected Sub btnupload_1_Click(sender As Object, e As System.EventArgs) Handles btnupload_1.Click

        Dim MyDatable As New Data.DataTable
        Dim STS As Integer
        Dim aar As Integer = 0
        Dim PROPOSER_ID As String
        Dim PERIOD As String
        Dim FILENO As String
        'ltEmbed.Text = ""
        Try
            If lblfile_1.Text = "" Then
                lblerr.Text = "You must Select The file!"
                Exit Sub
            End If
            If (Len(Trim(txtinv.Text)) > 25 Or Len(Trim(txtinv.Text)) < 20) Then
                lblerr.Text = "Enter a single Invoice No."
                txtinv.Focus()
                txtinv.BackColor = Drawing.Color.Red
                Exit Sub
            End If
            If FL2.PostedFile.FileName = "" Then
                lblerr.Text = "You must upload a reference pdf file!"
                Exit Sub
            End If
            If cbodoc.Text = "" Then
                lblerr.Text = "You must Select Document title!"
                Exit Sub
            End If

            Dim filePath As String = FL2.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            Dim fs As Stream = FL2.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(DirectCast(fs.Length, Long))

            Dim app As Integer = 0

            Select Case ext
                Case ".doc"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".docx"
                    contenttype = "application/vnd.ms-word"
                    Exit Select
                Case ".xls"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/vnd.ms-excel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".jpeg"
                    contenttype = "image/jpeg"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
                Case ".rar"
                    contenttype = "application/zip"
                    Exit Select
                Case ".zip"
                    contenttype = "application/zip"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fileLocation As String = ""
                MyDBAction.UPLOAD_File_DOC_INVOIC(bytes, filename, contenttype, lblfile_1.Text, Trim(cbodoc.Text.ToUpper), CDate(Date.Now()).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), cbodoc.SelectedValue, txtinv.Text)
                'Response.Redirect(Request.Url.AbsoluteUri)
                'If cbodoc.selectedvalue = "RET30" Then
                '    UpdateRecord("UPDATE [TBL_MIS_CRM_BUSINESS_TRACKING] SET eOx_Invoice_No='" & txtinv.Text & "' where [File_No]= '" & lblfile_1.Text & "'")
                'End If

                lblupload_1.ForeColor = System.Drawing.Color.Green

                lblupload_1.Text = "File Uploaded Successfully"

            Else
                lblupload_1.Text = "File format not recognised." _
            & " Upload Image/Word/PDF/Excel formats"
            End If
            loadGrid(FILE_NO.Text)



        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub

 

End Class
