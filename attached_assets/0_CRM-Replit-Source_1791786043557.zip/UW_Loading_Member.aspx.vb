﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_PROCESS] WHERE SIGNOFF_PERIOD=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                Session("PERIOD_FROM") = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                Session("PERIOD_TO") = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()
            End If
            Session("EXCEL") = Nothing

            SqlAction = "SELECT  [ID],[PROPOSER_ID],[MEMBER_NO],[MEMBER_NAME],[RELATION]  ,[PERIOD_FROM],[PERIOD_TO],[MEMBER_FLAG]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WHERE [MEMBER_FLAG]=1 AND IS_LOADING=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5_1") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
            Session("EXCEL") = Nothing
        End If
    End Sub
    Public Sub Load_Grid()
      

        SqlAction = "SELECT ID,[MEMBER_NO],[MEMBER_NAME],[AGE],PERIOD_FROM,PERIOD_TO,[OP_L_RATE],[IP_L_RATE],[IP_PREMIUM],[OP_PREMIUM],[LOADED_IP_PREM],[LOADED_OP_PREM],[CURRENT_IP_CLAIMS],[CURRENT_OP_CLAIMS],[DIAGNOSIS],[PERIOD_FROM],[PERIOD_TO],POLICY_CODE,ON_HOLD,S_PLUS_IP,LOADED_S_PLUS_IP  FROM [MISREPORTS].[dbo].[TBL_MIS_LOAD_MEM] WITH (NOLOCK) WHERE MEMBER_NO ='" & txtno.Text & "'"

        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            RD_LOAD.DataSource = MyDatable
            RD_LOAD.DataBind()
            Session("DAD_5_1") = MyDatable
            MyDatable = Nothing
        Else
            RD_LOAD.DataSource = MyDatable
            RD_LOAD.DataBind()
            'txtoprate.Text = MyDatable.Rows(0).Item("OP_L_RATE").ToString()
        End If

        SqlAction = "SELECT   [Note_id],[Member_No],[Notes],[Note_From],[Note_Date],[Note_Type],[Active]  FROM [CRM].[dbo].[TBL_MIS_CRM_LOADING_NOTES] WHERE  Member_No ='" & txtno.Text & "' ORDER BY Note_id DESC"
        MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
            MyDatable = Nothing
        Else
            GDNOTES.DataSource = MyDatable
            GDNOTES.DataBind()
        End If
    End Sub
    Protected Sub SEARCH_Click(sender As Object, e As System.EventArgs) Handles SEARCH.Click
        Try
            SqlAction = "SELECT  [ID],[PROPOSER_ID],[MEMBER_NO],[MEMBER_NAME],[RELATION]  ,[PERIOD_FROM],[PERIOD_TO],[SCHEME_NAME]  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WHERE MEMBER_NO Like '%" & Trim(txtsearch.Text) & "%' AND APPROVED=0"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5_1") = MyDatable
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub GDSEARCH_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDSEARCH.SelectedIndexChanged
        Try
            Dim SqlAction As String = ""
            Session("IP_RATE") = 0
            Session("OP_RATE") = 0
            ID = (DirectCast(GDSEARCH.SelectedItems(0), GridDataItem)).GetDataKeyValue("ID").ToString()

            SqlAction = "SELECT [ID],[MEMBER_NO],[MEMBER_NAME],[RELATION],PERIOD_FROM [POLICY_VALID_FROM], PERIOD_TO [POLICY_VALID_UPTO],[AGE],[FAMILY_NO],[OP_LIMIT],LOADING_RATE,[IP_LIMIT],[PRESENT_IP],[PRESENT_OP],[IP_RATE],[OP_RATE],POLICY_CODE,ON_HOLD,SILVER_PLUS_IP_PREMIUM,SCHEME_NAME  FROM [MISREPORTS].[dbo].[TBL_MIS_RENEWAL_LIST] WITH (NOLOCK) WHERE ID ='" & ID & "' AND  VERIFIED=1"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblID.Text = MyDatable.Rows(0).Item("ID").ToString()
                'lblfile.Text = MyDatable.Rows(0).Item("FILE_NO").ToString()
                txtno.Text = MyDatable.Rows(0).Item("MEMBER_NO").ToString()
                txtname.Text = MyDatable.Rows(0).Item("MEMBER_NAME").ToString()
                txtrela.Text = MyDatable.Rows(0).Item("RELATION").ToString()
                dtfrom.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_FROM").ToString()
                DTto.DbSelectedDate = MyDatable.Rows(0).Item("POLICY_VALID_UPTO").ToString()
                txtage.Text = MyDatable.Rows(0).Item("AGE").ToString()

                txtipprem.Text = MyDatable.Rows(0).Item("IP_RATE").ToString()
                txtopprem.Text = MyDatable.Rows(0).Item("OP_RATE").ToString()

                txtLIPPrem.Text = MyDatable.Rows(0).Item("IP_RATE").ToString()
                txtLopprem.Text = MyDatable.Rows(0).Item("OP_RATE").ToString()
                'txtiprate.Text = MyDatable.Rows(0).Item("LOADING_RATE").ToString()
                LBLPOLICY.Text = MyDatable.Rows(0).Item("POLICY_CODE").ToString()
                LBLSCHEME.Text = MyDatable.Rows(0).Item("SCHEME_NAME").ToString()

                Session("IP_RATE") = MyDatable.Rows(0).Item("IP_RATE").ToString()
                Session("OP_RATE") = MyDatable.Rows(0).Item("OP_RATE").ToString()
                Load_Grid()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
 

    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try

            MyDBAction.Save_Loading(txtno.Text, txtname.Text, txtage.Text, txtoprate.Text, txtiprate.Text, txtipprem.Text, txtopprem.Text, txtLIPPrem.Text, txtLopprem.Text, 0, 0, "", Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), CDate(dtfrom.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd"), cborevise.SelectedValue, LBLPOLICY.Text)
            'updateRecord("UPDATE [MISREPORTS].[dbo].[TBL_MIS_LOADING_FLAG] SET  LOADED=1,FLAGED_BY='" & Session("username") & "', FLAG_DATE= '" & CDate(Date.Now).ToString("yyyy-MM-dd") & "' where MEMBER_NO= '" & Trim(txtno.Text) & "'AND PERIOD_TO='" & CDate(DTto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and lOADED=0")
            If txtcomment.Text <> "" Then
                MyDBAction.TRACKING_UW_MESSAGES(txtno.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtcomment.Text)
            End If
            Load_Grid()
            lblID.Text = "" : txtno.Text = "" : txtname.Text = "" : txtage.Text = 0 : txtoprate.Text = 0 : txtiprate.Text = 0 : txtipprem.Text = 0 : txtopprem.Text = 0 : txtLIPPrem.Text = 0 : txtLopprem.Text = 0 : txtcomment.Text = ""

            lblerr.Text = "Saved successfully!"

        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try
    End Sub
    Protected Sub txtoprate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtoprate.TextChanged

        txtLopprem.Text = Session("OP_RATE") + (txtoprate.Text * Session("OP_RATE"))
    End Sub

    Protected Sub txtiprate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtiprate.TextChanged

        txtLIPPrem.Text = Session("IP_RATE") + (txtiprate.Text * Session("IP_RATE"))
        'txtLIPPrem.Text = Session("IP_RATE") + (txtiprate.Text * Session("IP_RATE"))
    End Sub

End Class
