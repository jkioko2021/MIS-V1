﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="P_N_I_Invoice_Billing.aspx.vb" Inherits="_Default" %>

<%@ OutputCache Location="None" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ Register assembly="Telerik.Web.UI" namespace="Telerik.Web.UI" tagprefix="telerik" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <asp:UpdateProgress ID="UpdateProgress1" runat="server">
        <ProgressTemplate>
         <asp:Label ID="lblProgress" runat="server" Font-Bold="True" ForeColor="#153E7E" Text="Please Wait...."></asp:Label>
        </ProgressTemplate>
    </asp:UpdateProgress>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <table style="width: 100%">
                <tr>
                    <td align="center" bgcolor="#333333" colspan="4">
                        <asp:Label ID="Label6" runat="server" Font-Bold="True" Font-Size="Medium" 
                            ForeColor="Silver" style="font-weight: 700" 
                            Text="P AND I REGISTRATION"></asp:Label>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">
                        <asp:Panel ID="Panel8" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Width="1096px">
                            <table style="width: 100%">
                                <tr>
                                    <td style="width: 2924px">
                                        <asp:Label ID="Label73" runat="server" style="font-weight: 700" 
                                            Text="Search By"></asp:Label>
                                    </td>
                                    <td style="width: 154px">
                                        <telerik:RadComboBox ID="cbosearch" Runat="server" style="margin-left: 0px">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="Member No" Value="M" />
                                                <telerik:RadComboBoxItem runat="server" Text="Name" Value="N" />
                                                <telerik:RadComboBoxItem runat="server" Text="File_No" Value="F" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                    <td>
                                        <telerik:RadTextBox ID="txtsearch" Runat="server" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td>
                                        <telerik:RadButton ID="SEARCH" runat="server" Text="Search">
                                        </telerik:RadButton>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                    <td>
                        &nbsp;</td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:Panel ID="Panel9" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                            Height="100%" style="font-weight: 700" Width="1121px">
                            <table style="width: 97%">
                                <tr>
                                    <td class="style8" colspan="5">
                                        <asp:Panel ID="Panel34" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDSEARCH_1" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%" 
                                                PageSize="15">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_No" 
                                                            FilterControlAltText="Filter Member_No column" HeaderText="Member_No" 
                                                            SortExpression="Member_No" UniqueName="Member_No">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Member_Name" 
                                                            FilterControlAltText="Filter Member_Name column" HeaderText="Member_Name" 
                                                            ItemStyle-Wrap="False" SortExpression="Member_Name" UniqueName="Member_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Provider_Name" 
                                                            FilterControlAltText="Filter Provider_Name column" HeaderText="Provider_Name" 
                                                            SortExpression="Provider_Name" UniqueName="Provider_Name">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Inv_Status" 
                                                            FilterControlAltText="Filter Inv_Status column" HeaderText="Inv_Status" 
                                                            SortExpression="Inv_Status" UniqueName="Inv_Status">
                                                        </telerik:GridBoundColumn>
                                                     
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label148" runat="server" Text="File Number"></asp:Label>
                                    </td>
                                    <td style="width: 831px">
                                        <asp:Label ID="lblfile" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label102" runat="server" Text="Receive Date"></asp:Label>
                                    </td>
                                    <td style="width: 831px">
                                        <telerik:RadDatePicker ID="dtreceive" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label128" runat="server" Text="Service Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtservice" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label126" runat="server" Text="Member No."></asp:Label>
                                    </td>
                                    <td style="width: 831px">
                                        <telerik:RadTextBox ID="txtmemno" Runat="server" EmptyMessage="KE123456700" 
                                            Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label132" runat="server" Text="Provider"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadComboBox ID="cboprovider" Runat="server" AccessibilityMode="True" 
                                            AllowCustomText="True" AutoPostBack="True" MarkFirstMatch="True" Skin="Sunset" 
                                            Width="250px" Enabled="False">
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label135" runat="server" Text="Member Name"></asp:Label>
                                    </td>
                                    <td style="width: 831px">
                                        <telerik:RadTextBox ID="txtname" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label154" runat="server" Text="Corporate"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadTextBox ID="txtprop" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#666666" colspan="5">
                                        <asp:Label ID="Label155" runat="server" Text="Billing"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label156" runat="server" Text="DOA"></asp:Label>
                                    </td>
                                    <td style="width: 831px">
                                        <telerik:RadDatePicker ID="dtdoa" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label157" runat="server" Text="DOD"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtdod" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label158" runat="server" Text="Invoice No."></asp:Label>
                                    </td>
                                    <td style="width: 831px">
                                        <telerik:RadTextBox ID="txtinvno" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        <asp:Label ID="Label159" runat="server" Text="Invoice Date"></asp:Label>
                                    </td>
                                    <td style="width: 287px">
                                        <telerik:RadDatePicker ID="dtInv" Runat="server" MinDate="" Skin="Sunset">
                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                            </Calendar>
                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                            </DateInput>
                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                        </telerik:RadDatePicker>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; height: 33px;">
                                        </td>
                                    <td style="width: 190px; height: 33px;">
                                        <asp:Label ID="Label162" runat="server" Text="Total Amt"></asp:Label>
                                    </td>
                                    <td style="width: 831px; height: 33px;">
                                        <telerik:RadNumericTextBox ID="txttotamt" Runat="server" Skin="Simple" 
                                            Width="150px" Culture="en-US" Value="0" AutoPostBack="True">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 33px;">
                                        <asp:Label ID="Label160" runat="server" Text="Cover Limit"></asp:Label>
                                    </td>
                                    <td style="width: 287px; height: 33px;">
                                        <telerik:RadNumericTextBox ID="txtcover" Runat="server" Skin="Simple" 
                                            Width="150px" Culture="en-US" Value="0" AutoPostBack="True">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; height: 31px;">
                                        </td>
                                    <td style="width: 190px; height: 31px;">
                                        <asp:Label ID="Label161" runat="server" Text="Overshot"></asp:Label>
                                    </td>
                                    <td style="width: 831px; height: 31px;">
                                        <telerik:RadNumericTextBox ID="txtover" Runat="server" Skin="Simple" 
                                            Width="150px" Culture="en-US" Value="0" AutoPostBack="True">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 31px;">
                                        <asp:Label ID="Label163" runat="server" Text="Admin Fee"></asp:Label>
                                    </td>
                                    <td style="width: 287px; height: 31px;">
                                        <telerik:RadComboBox ID="cboadmin" Runat="server" Skin="Simple" 
                                            AutoPostBack="True">
                                            <Items>
                                                <telerik:RadComboBoxItem runat="server" Text="0" Value="0" />
                                                <telerik:RadComboBoxItem runat="server" Text="15%" Value="0.15" />
                                            </Items>
                                        </telerik:RadComboBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; height: 34px;">
                                        </td>
                                    <td style="width: 190px; height: 34px;">
                                        <asp:Label ID="Label164" runat="server" Text="Pay N Invoice"></asp:Label>
                                    </td>
                                    <td style="width: 831px; height: 34px;">
                                        <telerik:RadNumericTextBox ID="txtPNI" Runat="server" Skin="Simple" 
                                            Width="150px" Culture="en-US" Value="0">
                                        </telerik:RadNumericTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 34px;">
                                        </td>
                                    <td style="width: 287px; height: 34px;">
                                        </td>
                                </tr>
                                <tr>
                                    <td style="width: 190px">
                                        &nbsp;</td>
                                    <td style="width: 190px">
                                        <asp:Label ID="Label165" runat="server" Text="Approved By"></asp:Label>
                                    </td>
                                    <td style="width: 831px">
                                        <telerik:RadTextBox ID="txtappr" Runat="server" Skin="Sunset" Width="250px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px">
                                        &nbsp;</td>
                                    <td style="width: 287px">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 190px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 831px; height: 41px;">
                                        <asp:Panel ID="Panel31" runat="server" BorderStyle="Dotted" BorderWidth="1px" 
                                            Height="100%" Width="100%">
                                            <asp:CheckBoxList ID="chklist" runat="server" Font-Bold="True" 
                                                Font-Size="Medium" ForeColor="#CC0000" Width="391px">
                                            </asp:CheckBoxList>
                                        </asp:Panel>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 41px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 41px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 190px; height: 41px;">
                                    </td>
                                    <td style="width: 190px; height: 41px;">
                                    </td>
                                    <td style="width: 831px; height: 41px;">
                                        <telerik:RadButton ID="cmdsave" runat="server" Height="35px" Skin="Simple" 
                                            Text="Save" Width="98px">
                                        </telerik:RadButton>
                                        &nbsp;<telerik:RadButton ID="cmdedit" runat="server" Height="35px" Skin="Simple" 
                                            Text="Edit" Width="98px">
                                        </telerik:RadButton>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 41px;">
                                    </td>
                                    <td style="width: 287px; height: 41px;">
                                        <asp:HiddenField ID="HiddenField1" runat="server" />
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        <asp:Label ID="lblerr" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        <asp:Panel ID="Panel35" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="100%">
                                            <telerik:RadGrid ID="GDSEARCH_2" runat="server" AllowPaging="True" 
                                                CellSpacing="0" GridLines="None" Height="100%" Skin="WebBlue" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="Ref_No">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                        <HeaderStyle Width="20px" />
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                        <HeaderStyle Width="20px" />
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                            FilterControlAltText="Filter ID column" HeaderText="Select" Text="Select" 
                                                            UniqueName="Select">
                                                            <HeaderStyle ForeColor="Blue" Width="50px" />
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridButtonColumn>
                                                        <telerik:GridBoundColumn DataField="ID" FilterControlAltText="Filter ID column" 
                                                            HeaderText="ID" SortExpression="ID" UniqueName="ID">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Ref_No" 
                                                            FilterControlAltText="Filter Ref_No column" HeaderText="Ref_No" 
                                                            SortExpression="Ref_No" UniqueName="Ref_No">
                                                        </telerik:GridBoundColumn>
                                                         
                                                        <telerik:GridBoundColumn DataField="Invoice_No" 
                                                            FilterControlAltText="Filter Invoice_No column" HeaderText="Invoice_No" 
                                                            ItemStyle-Wrap="False" SortExpression="Invoice_No" UniqueName="Invoice_No">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="Invoice_Dt" 
                                                            FilterControlAltText="Filter Invoice_Dt column" HeaderText="Invoice_Dt" 
                                                            ItemStyle-Wrap="False" SortExpression="Invoice_Dt" UniqueName="Invoice_Dt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Invoice_Amt"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Invoice_Amt column" HeaderText="Invoice_Amt" 
                                                            SortExpression="Invoice_Amt" UniqueName="Invoice_Amt">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Total_Bill"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Total_Bill column" HeaderText="Total_Bill" 
                                                            SortExpression="Inv_Status" UniqueName="Total_Bill">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Cover_Limit"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Cover_Limit column" HeaderText="Cover_Limit" 
                                                            SortExpression="Cover_Limit" UniqueName="Cover_Limit">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Overshot"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Overshot column" HeaderText="Overshot" 
                                                            SortExpression="Overshot" UniqueName="Overshot">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Admin_Fee" 
                                                            FilterControlAltText="Filter Admin_Fee column" HeaderText="Admin_Fee" 
                                                            SortExpression="Admin_Fee" UniqueName="Admin_Fee">
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Pay_N_Invoice"  DataFormatString="{0:### ##0.0}" 
                                                            FilterControlAltText="Filter Pay_N_Invoice column" HeaderText="Pay_N_Invoice" 
                                                            SortExpression="Pay_N_Invoice" UniqueName="Pay_N_Invoice">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="DoA" 
                                                            FilterControlAltText="Filter DoA column" HeaderText="DoA" 
                                                            SortExpression="DoA" UniqueName="DoA">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridBoundColumn DataField="DoD" 
                                                            FilterControlAltText="Filter DoD column" HeaderText="DoD" 
                                                            SortExpression="DoD" UniqueName="DoD">
                                                        </telerik:GridBoundColumn>
                                                          <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                            ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                            Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                            <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                            <ItemStyle CssClass="ButtonColumn" />
                                                        </telerik:GridButtonColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5">
                                        <asp:Panel ID="Panel2" runat="server" Width="1118px">
                                            <table style="width: 99%">
                                                <tr>
                                                    <td colspan="4">
                                                        <asp:Panel ID="Panel32" runat="server" BorderStyle="Solid" BorderWidth="1px" 
                                                            Height="100%" Width="1109px">
                                                            <table style="width: 99%">
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="Label151" runat="server" Font-Bold="True" Text="Documentation"></asp:Label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <asp:Panel ID="Panel33" runat="server" Height="100%" ScrollBars="Both" 
                                                                            Width="1100px">
                                                                            <telerik:RadGrid ID="GD_DOCS" runat="server" AllowPaging="True" CellSpacing="0" 
                                                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                                                <MasterTableView AutoGenerateColumns="False" DataKeyNames="DOC_ID">
                                                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </RowIndicatorColumn>
                                                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                                                        <HeaderStyle Width="20px" />
                                                                                    </ExpandCollapseColumn>
                                                                                    <Columns>
                                                                                        <telerik:GridButtonColumn CommandName="Select" 
                                                                                            FilterControlAltText="Filter Select column" HeaderText="Select" Text="Select" 
                                                                                            UniqueName="Select">
                                                                                            <HeaderStyle ForeColor="Blue" Width="100px" />
                                                                                            <ItemStyle Width="50px" />
                                                                                        </telerik:GridButtonColumn>
                                                                                        <telerik:GridBoundColumn DataField="DOC_ID" 
                                                                                            FilterControlAltText="Filter DOC_ID column" HeaderText="DOC_ID" 
                                                                                            SortExpression="DOC_ID" UniqueName="DOC_ID">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                                                            SortExpression="File_No" UniqueName="File_No">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Doc_Title" 
                                                                                            FilterControlAltText="Filter Doc_Title column" HeaderText="Doc_Title" 
                                                                                            SortExpression="Doc_Title" UniqueName="Doc_Title">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Doc_Date" 
                                                                                            FilterControlAltText="Filter Doc_Date column" HeaderText="Doc_Date" 
                                                                                            SortExpression="Doc_Date" UniqueName="Doc_Date">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="File_Name" 
                                                                                            FilterControlAltText="Filter File_Name column" HeaderText="File_Name" 
                                                                                            SortExpression="File_Name" UniqueName="File_Name">
                                                                                        </telerik:GridBoundColumn>
                                                                                        <telerik:GridBoundColumn DataField="Upload_By" 
                                                                                            FilterControlAltText="Filter Upload_By column" HeaderText="Upload_By" 
                                                                                            SortExpression="Upload_By" UniqueName="Upload_By">
                                                                                        </telerik:GridBoundColumn>
                                                                                      
                                                                                            <telerik:GridTemplateColumn AllowFiltering="false" HeaderText="View" 
                                                                                        SortExpression="DOC_ID">
                                                                                        <ItemTemplate>
                                                                                            <asp:LinkButton ID="lnkDownload" runat="server" 
                                                                                                CommandArgument='<%# Eval("DOC_ID") %>' OnClick="DownloadFile" Text="Download"></asp:LinkButton>
                                                                                        </ItemTemplate>
                                                                                    </telerik:GridTemplateColumn>
                                                                                      <telerik:GridButtonColumn ButtonType="ImageButton" CommandName="Delete" 
                                                                                            ConfirmText="Delete record?" FilterControlAltText="Filter DeleteColumn column" 
                                                                                            Resizable="false" Text="Delete" UniqueName="DeleteColumn">
                                                                                            <HeaderStyle CssClass="rgHeader ButtonColumnHeader" />
                                                                                            <ItemStyle CssClass="ButtonColumn" />
                                                                                        </telerik:GridButtonColumn>
                                                                                    </Columns>
                                                                                    <EditFormSettings>
                                                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                                                        </EditColumn>
                                                                                    </EditFormSettings>
                                                                                </MasterTableView>
                                                                                <FilterMenu EnableImageSprites="False">
                                                                                </FilterMenu>
                                                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                                                </HeaderContextMenu>
                                                                            </telerik:RadGrid>
                                                                        </asp:Panel>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <asp:Panel ID="Panel13" runat="server" BorderStyle="Solid" Height="100%" 
                                                                            ScrollBars="Horizontal" Width="1100px">
                                                                            <asp:Literal ID="ltEmbed" runat="server" />
                                                                        </asp:Panel>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 113px">
                                                        <asp:Label ID="Label145" runat="server" Text="Document Title"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                        <telerik:RadTextBox ID="txttitle" Runat="server" Enabled="False" Skin="Sunset" 
                                                            Width="300px">
                                                        </telerik:RadTextBox>
                                                    </td>
                                                    <td style="width: 143px; height: 35px;">
                                                        <asp:Label ID="DOC_ID" runat="server" 
                                                            style="font-weight: 700; color: #CC0000; background-color: #FFFFFF" 
                                                            Visible="False"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 113px">
                                                        <asp:Label ID="Label146" runat="server" Text="Document"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                        <asp:FileUpload ID="FL1" runat="server" Width="330px" />
                                                    </td>
                                                    <td style="width: 143px; height: 35px;">
                                                        <asp:Label ID="Label138" runat="server" Text="Upload Date"></asp:Label>
                                                    </td>
                                                    <td style="height: 35px">
                                                        &nbsp;<telerik:RadDatePicker ID="dtupload" Runat="server" Enabled="False" MinDate="" 
                                                            Skin="Sunset">
                                                            <Calendar Skin="Sunset" UseColumnHeadersAsSelectors="False" 
                                                                UseRowHeadersAsSelectors="False" ViewSelectorText="x">
                                                            </Calendar>
                                                            <DateInput DateFormat="dd/MM/yyyy" DisplayDateFormat="dd/MM/yyyy">
                                                            </DateInput>
                                                            <DatePopupButton HoverImageUrl="" ImageUrl="" />
                                                        </telerik:RadDatePicker>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 113px; height: 35px;">
                                                        &nbsp;</td>
                                                    <td style="height: 35px">
                                                        <telerik:RadButton ID="btnupload" runat="server" Skin="Simple" Text="Upload" 
                                                            Width="150px">
                                                        </telerik:RadButton>
                                                        &nbsp;
                                                    </td>
                                                    <td style="width: 143px; height: 35px;">
                                                        &nbsp;</td>
                                                    <td style="height: 35px">
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="4" style="height: 35px;">
                                                        <asp:Label ID="lblupload" runat="server" Font-Bold="True" Font-Size="Medium" 
                                                            ForeColor="Red"></asp:Label>
                                                    </td>
                                                </tr>
                                            </table>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                            <table style="width: 97%">
                                <tr>
                                    <td style="height: 13px">
                                        <asp:Label ID="Label121" runat="server" style="font-weight: 700" 
                                            Text="Comments"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 13px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 13px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 39px">
                                        <telerik:RadTextBox ID="txtcomment" Runat="server" Height="70px" Rows="1" 
                                            Skin="Sunset" TextMode="MultiLine" Width="450px">
                                        </telerik:RadTextBox>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 39px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 39px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 39px">
                                        <asp:CheckBox ID="chksign" runat="server" Text="Discharged" />
                                    </td>
                                    <td class="style8" style="width: 172px; height: 39px;">
                                        &nbsp;</td>
                                    <td style="width: 287px; height: 39px;">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td class="style8" style="height: 39px">
                                        <telerik:RadButton ID="RadButton1" runat="server" Skin="Simple" Text="Submit" 
                                            Width="150px">
                                        </telerik:RadButton>
                                        <asp:Label ID="lblerr_1" runat="server" Font-Size="Medium" ForeColor="Red"></asp:Label>
                                    </td>
                                    <td class="style8" style="width: 172px; height: 39px;">
                                    </td>
                                    <td style="width: 287px; height: 39px;">
                                    </td>
                                </tr>
                                <tr>
                                    <td class="style8" colspan="3">
                                        <asp:Panel ID="Panel15" runat="server" Height="100%" ScrollBars="Both" 
                                            Width="98%">
                                            <telerik:RadGrid ID="GDNOTES" runat="server" AllowPaging="True" CellSpacing="0" 
                                                GridLines="None" Height="100%" Skin="Sunset" Width="100%">
                                                <MasterTableView AutoGenerateColumns="False">
                                                    <CommandItemSettings ExportToPdfText="Export to PDF" />
                                                    <RowIndicatorColumn FilterControlAltText="Filter RowIndicator column">
                                                    </RowIndicatorColumn>
                                                    <ExpandCollapseColumn FilterControlAltText="Filter ExpandColumn column">
                                                    </ExpandCollapseColumn>
                                                    <Columns>
                                                        <telerik:GridBoundColumn DataField="Note_date" 
                                                            FilterControlAltText="Filter Note_date column" HeaderText="Note date" 
                                                            ItemStyle-Width="100" SortExpression="Note_date" UniqueName="Note_date">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="File_No" 
                                                            FilterControlAltText="Filter File_No column" HeaderText="File No" 
                                                            ItemStyle-Width="50" SortExpression="File_No" UniqueName="File_No">
                                                            <ItemStyle Width="50px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Note_From" 
                                                            FilterControlAltText="Filter Note_From column" HeaderText="From" 
                                                            ItemStyle-Width="100" SortExpression="Note_From" UniqueName="Note_From">
                                                            <ItemStyle Width="100px" />
                                                        </telerik:GridBoundColumn>
                                                        <telerik:GridBoundColumn DataField="Notes" 
                                                            FilterControlAltText="Filter Notes column" HeaderText="Notes" 
                                                            SortExpression="Notes" UniqueName="Notes">
                                                        </telerik:GridBoundColumn>
                                                    </Columns>
                                                    <EditFormSettings>
                                                        <EditColumn FilterControlAltText="Filter EditCommandColumn column">
                                                        </EditColumn>
                                                    </EditFormSettings>
                                                </MasterTableView>
                                                <ItemStyle Wrap="False" />
                                                <FilterMenu EnableImageSprites="False">
                                                </FilterMenu>
                                                <HeaderContextMenu CssClass="GridContextMenu GridContextMenu_Default">
                                                </HeaderContextMenu>
                                            </telerik:RadGrid>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </asp:Panel>
                    </td>
                </tr>
                <tr>
                    <td style="width: 105px">
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                    <td>
                        &nbsp;</td>
                </tr>
            </table>
        </ContentTemplate>
          <Triggers>
        <asp:PostBackTrigger ControlID = "btnupload" />
          </Triggers>
    </asp:UpdatePanel>
</asp:Content>


