﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient
Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim AB As Integer
    Dim MailSent As Boolean = False



    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            dtdxdate.DbSelectedDate = Date.Now()
            dtfollow.DbSelectedDate = DateAdd(DateInterval.Month, 1, Date.Now())

            DtFollFrom.DbSelectedDate = Date.Now
            dtFolloto.DbSelectedDate = Date.Now
            DtNotes.DbSelectedDate = Date.Now()
            Session("EXCEL") = Nothing


            Str = "SELECT DISTINCT [Code],[Name]  FROM [dbo].[TBL_MIS_CRM_HPC_DISEASES] ORDER BY CODE" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbocomor
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Name").ToString
                .DataValueField = MyDatatable.Columns("Code").ToString
                .DataBind()
            End With

          
            LoadGrid_M()

        End If
    End Sub

    Protected Sub btnsearch_Click(sender As Object, e As System.EventArgs) Handles btnsearch.Click
        Try
            lblno.Text = ""
            lblcode.Text = ""
            lblprov.Text = ""
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()

    

            If cbosearch.SelectedValue = "M" Then
                Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,HPC_Src  FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Member_No='" & txtsearch.Text & "'"
                      ElseIf cbosearch.SelectedValue = "N" Then
                Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Member_Name like '%" & txtsearch.Text & "%'"
            ElseIf cbosearch.SelectedValue = "D" Then
                ' Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Followup_Dt Between '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
                Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND Member_no in (select Member_no from [CRM].[dbo].[TBL_MIS_CRM_HPC_FOLLOWUP] where [Scheduled_date]  Between '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "' and [Member_Call]='NO') AND Policy_Status='ACTIVE'"
            ElseIf cbosearch.SelectedValue = "R" Then
                ' Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Followup_Dt Between '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
                Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND  CONVERT(DATE,R.Entry_dt)  Between '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Policy_Status='ACTIVE'"
            ElseIf cbosearch.SelectedValue = "S" Then
                ' Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Followup_Dt Between '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
                Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND  CONVERT(DATE,R.Entry_dt)  Between '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND Policy_Status='ACTIVE' AND HPC_Src='" & txtsearch.SelectedValue & "'"

            End If

            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCASE.DataSource = MyDatable
                GDCASE.DataBind()
                Session("GDCASE_T") = MyDatable
                MyDatable = Nothing
            Else
                GDCASE.DataSource = Nothing
                GDCASE.DataBind()

            End If
            loadGrid(txtsearch.Text)
        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdsavecom_Click(sender As Object, e As System.EventArgs) Handles cmdsavecom.Click
        Try
            If lblno.Text = "" Then
                lblCOMM.Text = "Select Member No."
                Exit Sub
            End If
             
            If txtnotesCorm.Text = "" Then
                lblCOMM.Text = "Enter Short Notes"
                Exit Sub
            End If

            If txtnotesCorm.Text <> "" Then
                MyDBAction.TRACKING_HPC_MESSAGES(lblno.Text, cbocomor.SelectedValue, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtnotesCorm.Text, "NOTES")
            End If
            If cbocomor.SelectedValue <> "" Then
                MyDBAction.TRACKING_HPC_COMORB(CDate(dtdxdate.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, lblno.Text, Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), "", Trim(txtotherdoc.Text))
            End If

            lblCOMM.Text = "Record updated successfull."
            txtnotesCorm.Text = ""
            dtdxdate.DbSelectedDate = Date.Now()
            cbocomor.SelectedValue = ""
            cbocomor.Text = ""
            loadGrid(lblno.Text)

        Catch ex As Exception
            lblCOMM.Text = ex.Message
        End Try
    End Sub
    Public Sub LoadGrid_M()
        GDCASE.DataSource = Nothing
        GDCASE.DataBind()
        GD_1.DataSource = Nothing
        GD_1.DataBind()
        Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt, R.HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND Member_no in (select Member_no from [CRM].[dbo].[TBL_MIS_CRM_HPC_FOLLOWUP] where month([Scheduled_date]) = month(getdate()) and [Member_Call]='NO') AND Policy_Status='ACTIVE' AND R.IS_ACTIVE=1"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GDCASE.DataSource = MyDatable
            GDCASE.DataBind()
            Session("GDCASE_T") = MyDatable
            MyDatable = Nothing
        Else
            GDCASE.DataSource = Nothing
            GDCASE.DataBind()
        End If

        Str = " SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,r.HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND     Policy_Status='ACTIVE' AND UPDATED=0"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_1.DataSource = MyDatable
            GD_1.DataBind()
            Session("GD_1_T") = MyDatable
            MyDatable = Nothing
        Else
            GD_1.DataSource = Nothing
            GD_1.DataBind()
        End If

        Str = " SELECT [Entry_Yr],[Entered_by], sum([Jan])[Jan],sum([Feb])[Feb],sum([Mar])[Mar],sum([Apr])[Apr],sum([May])[May],sum([Jun])[Jun],sum([Jul])[Jul],sum([Aug])[Aug],sum([Sep])[Sep],sum([Oct])[Oct],sum([Nov])[Nov],sum([Dec])[Dec],sum([Total])[Total]  FROM [CRM].[dbo].[vw_MIS_CRM_HPC_TRACKING_STATUS]group by [Entry_Yr],[Entered_by] "
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_2.DataSource = MyDatable
            GD_2.DataBind()
            Session("GD_2_T") = MyDatable
            MyDatable = Nothing
        Else
            GD_2.DataSource = Nothing
            GD_2.DataBind()
        End If

        Str = " SELECT  [Entry_Yr],[Scheduled_Mon],[CNT_Members],[Members_Engaged],[Members_NOT_Engaged]  FROM [CRM].[dbo].[vw_MIS_CRM_HPC_FOLLOWUP_STATUS]"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_4.DataSource = MyDatable
            GD_4.DataBind()
            Session("GD_4_T") = MyDatable
            MyDatable = Nothing
        Else
            GD_4.DataSource = Nothing
            GD_4.DataBind()
        End If

    End Sub
    Public Sub loadGrid(ByVal STR As String)
        Dim MyDatable As New Data.DataTable
        GDCOMORM.DataSource = Nothing
        GDCOMORM.DataBind()
        GDNOTES.DataSource = Nothing
        GDNOTES.DataBind()
        GDFOLLOW.DataSource = Nothing
        GDFOLLOW.DataBind()
      
      
        Try
           

            MyDatable = Nothing
            SqlAction = ""
            SqlAction = "SELECT  M.Id,M.DX_code, M.Member_No, C.Name,M.Dx_Date,M.Entered_By,M.Entry_date,M.Other_Doctor FROM   dbo.TBL_MIS_CRM_HPC_MEMBER_COMORB M INNER JOIN  dbo.TBL_MIS_CRM_HPC_DISEASES C ON M.DX_code = C.Code  WHERE  M.Member_No ='" & STR & "' AND M.Is_Active=1 order by M.Id desc"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDCOMORM.DataSource = MyDatable
                GDCOMORM.DataBind()
                MyDatable = Nothing
            Else
                GDCOMORM.DataSource = MyDatable
                GDCOMORM.DataBind()
            End If
            'Notes

            SqlAction = ""
            SqlAction = "SELECT [Note_id],[Note_Type],[Note_From] ,[Note_date],[Notes]  FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_NOTES] WHERE  Member_No ='" & STR & "' ORDER BY Note_id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDNOTES.DataSource = MyDatable
                GDNOTES.DataBind()
                MyDatable = Nothing
            Else
                GDNOTES.DataSource = Nothing
                GDNOTES.DataBind()
            End If

            '
            SqlAction = ""
            SqlAction = "SELECT  [Follow_Id],[Member_No],[Scheduled_date],[Entered_By],[Entry_Date],[Member_Call],Call_Date,Call_By  FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_FOLLOWUP] WHERE  Member_No ='" & STR & "' ORDER BY Follow_Id DESC"
            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDFOLLOW.DataSource = MyDatable
                GDFOLLOW.DataBind()
                MyDatable = Nothing
            Else
                GDFOLLOW.DataSource = Nothing
                GDFOLLOW.DataBind()
            End If
        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub

    Protected Sub GDCASE_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GDCASE.SelectedIndexChanged
        Try
            lblno.Text = ""
            lblcode.Text = ""
         

            GDCOMORM.DataSource = Nothing
            GDCOMORM.DataBind()
            GDNOTES.DataSource = Nothing
            GDNOTES.DataBind()
            lblcode.Text = (DirectCast(GDCASE.SelectedItems(0), GridDataItem)).GetDataKeyValue("Member_No").ToString()
            Str = "SELECT Code_Id, Member_No, Member_Name,email, Mobile_No,  Entered_by, Entry_dt,Followup_Dt,Proposer,Client_Type FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND Member_No='" & Trim(lblcode.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                txtmemno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatable.Rows(0).Item("Proposer").ToString()
                txtemail.Text = MyDatable.Rows(0).Item("email").ToString()
                txtmobile.Text = MyDatable.Rows(0).Item("Mobile_No").ToString()
                dtsched.DbSelectedDate = MyDatable.Rows(0).Item("Followup_Dt").ToString()
                cboclient.SelectedValue = MyDatable.Rows(0).Item("Client_Type").ToString()

            End If
            loadGrid(lblno.Text)
            lblcode.Enabled = False
            'cbocomor.Enabled = False
         
            'cboProvi.Enabled = False
            dtsched.Enabled = False

          
        Catch ex As Exception
            lblErr.Text = ex.Message
        End Try
    End Sub



    

    Protected Sub btnnotes_Click(sender As Object, e As System.EventArgs) Handles btnnotes.Click
        Try

            If lblno.Text = "" Then
                lblnotes.Text = "You Must Select Member no"
                Exit Sub
            End If
         
            If txtadmnotes.Text <> "" Then
                MyDBAction.TRACKING_HPC_MESSAGES(lblno.Text, "COM", Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtadmnotes.Text, "NOTES")
            End If

            lblnotes.Text = "Notes updated successfull."
            txtadmnotes.Text = ""
            DtNotes.DbSelectedDate = Date.Now()
            loadGrid(lblno.Text)
        Catch ex As Exception
            lblnotes.Text = ex.Message
        End Try
    End Sub


    
    Private Sub UpdateRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Update)

    End Sub

 

    Protected Sub GDCOMORM_DeleteCommand(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridCommandEventArgs) Handles GDCOMORM.DeleteCommand


        Try

            Dim item As GridDataItem = DirectCast(e.Item, GridDataItem)
            HiddenField1.Value = item.OwnerTableView.DataKeyValues(item.ItemIndex)("Id").ToString()

            Dim MySqlAction As String = ""
            Dim MyDBAction As New DataManagement
            Dim MyDataTable As New Data.DataTable
            Dim File_No As String = ""
            Dim Proposer_Name As String = ""

            DeleteRecord("UPDATE FROM [dbo].[TBL_MIS_CRM_HPC_MEMBER_COMORB] SET [Is_Active]=0 WHERE Id='" & HiddenField1.Value.ToString & "'")

            Dim audit As New DataManagement
            audit.AddAdminAuditTrail(Session("UserName").ToString, "Diagnosis Delete", "Deleted Record :-   :" & lblcode.Text & " date:" & Date.Now() & ", Name - " & Session("FullNames") & ".", _
           Request.Url.ToString, Session("ip").ToString, Session("sessionid").ToString)
            HiddenField1.Value = ""

            'ResetDisplayed("NewRecord")
            lblErr.Text = "Record Deleted!"
            'CmdSave.Enabled = False


            loadGrid(lblno.Text)

        Catch ex As Exception


            Dim ErrMsg As String = ex.Message
        End Try
    End Sub

    Private Sub DeleteRecord(ByVal sqlAction As String)
        Dim MySmsObject As New DataManagement
        MySmsObject.DBAction(sqlAction, DataManagement.DBActionType.Delete)

        'ShowGridDetails()
    End Sub




    

    Protected Sub cmdsave_Click(sender As Object, e As System.EventArgs) Handles cmdsave.Click
        Try
            Dim adm_status As String = ""
            Dim case_status As String = ""
            If lblno.Text = "" Then
                lblerr_f.Text = "Select The Number"
                Exit Sub
            End If
            'MyDBAction.Covid_reg(lblcode.Text, "", CDate(dtadmin.DbSelectedDate).ToString("yyyy-MM-dd"), cbocomor.SelectedValue, txtname.Text, txtmemno.Text, txtprop.Text, cboclient.SelectedValue, cboProvi.SelectedValue, cboProvi.SelectedValue, cboprovtype.SelectedValue, txtauth.Text, adm_status, cboclaimtype.SelectedValue, case_status, Session("UserName").ToString, Trim(txtclaimno.Text), 1)
            UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_HPC_TRACKING] SET updated=1, Member_No='" & Trim(txtmemno.Text) & "',Member_Name='" & Trim(txtname.Text.ToUpper) & "',Proposer='" & Trim(txtprop.Text.ToUpper) & "',Mobile_No='" & Trim(txtmobile.Text) & "',eMail='" & Trim(txtemail.Text) & "',[Update_Date]='" & CDate(Date.Now()) & "', Update_By='" & Session("username") & "' where [Member_No]='" & lblno.Text & "'")
            UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_HPC_NOTES] SET Member_No='" & Trim(txtmemno.Text) & "' where [Member_No]='" & lblno.Text & "'")
            UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_HPC_MEMBER_COMORB] SET Member_No='" & Trim(txtmemno.Text) & "' where [Member_No]='" & lblno.Text & "'")
            UpdateRecord("UPDATE [dbo].[TBL_MIS_CRM_HPC_FOLLOWUP] SET Member_No='" & Trim(txtmemno.Text) & "' where [Member_No]='" & lblno.Text & "'")

            lblerr_f.Text = "Record Updated Successful!"

            Str = " SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND     Policy_Status='ACTIVE' AND UPDATED=0"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GD_1.DataSource = MyDatable
                GD_1.DataBind()
                Session("GD_1_T") = MyDatable
                MyDatable = Nothing
            Else
                GD_1.DataSource = Nothing
                GD_1.DataBind()
            End If
            HiddenField1.Value = 0
            lblcode.Text = ""
            cbocomor.SelectedValue = ""
            txtname.Text = ""
            txtmemno.Text = ""
            txtprop.Text = ""
            txtmobile.Text = ""
            txtemail.Text = ""
            cboclient.SelectedValue = ""
          
            lblcode.Enabled = True
            cbocomor.Enabled = True
            txtname.Enabled = True
            txtmemno.Enabled = True
            txtprop.Enabled = True
            cboclient.Enabled = True
         
            cmdedit.Enabled = True
            txtmobile.Enabled = True
            txtemail.Enabled = True
            cmdsave.Enabled = True
        Catch ex As Exception
            lblerr_f.Text = ex.Message
        End Try
    End Sub

    Protected Sub cmdedit_Click(sender As Object, e As System.EventArgs) Handles cmdedit.Click
        lblcode.Enabled = True


        cbocomor.Enabled = True
        txtname.Enabled = True
        txtmemno.Enabled = True
        txtprop.Enabled = True
        cboclient.Enabled = True
      
      

        cmdedit.Enabled = True
        cmdsave.Enabled = True
    End Sub

    Protected Sub RadButton1_Click(sender As Object, e As System.EventArgs) Handles RadButton1.Click
        Try
            lblfoll.Text = ""
            Dim call_m As String = ""
            If chkcall.Checked = True Then
                call_m = "YES"
            Else
                call_m = "NO"
            End If

            If CDate(dtfollow.DbSelectedDate).ToString("yyyy-MM-dd") < CDate(Date.Now()).ToString("yyyy-MM-dd") Then
                lblfoll.Text = "Invalid Date selected"
                Exit Sub
            End If

            MyDBAction.TRACKING_HPC_FOLLOWUP(lblno.Text, CDate(dtsched.DbSelectedDate).ToString("yyyy-MM-dd"), CDate(dtfollow.DbSelectedDate).ToString("yyyy-MM-dd"), Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), call_m)
            If txtfoll.Text <> "" Then
                MyDBAction.TRACKING_HPC_MESSAGES(lblno.Text, "COM", Session("username"), CDate(Date.Now).ToString("yyyy-MM-dd"), txtfoll.Text, "NOTES")
            End If
            LoadGrid_M()
            loadGrid(lblno.Text)
            lblfoll.Text = "Saved!"
        Catch ex As Exception
            lblfoll.Text = ex.Message
        End Try
    End Sub

    Protected Sub RadButton2_Click(sender As Object, e As System.EventArgs) Handles RadButton2.Click
        Try
            Dim Str As String = "" : Dim Mytable As DataTable = Nothing
            Dim Reportname As String = ""

            If cboreportsearc.SelectedValue = "M" Then
                SqlAction = "SELECT [Member_No],[Member_Name],[Mobile_No],[eMail],[Proposer],[Client_Type],[Followup_Dt],[Entered_By],[Entry_Dt],[Is_Active],[Policy_Status],[Update_By],[Update_Date] ,HPC_Src FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_TRACKING] WHERE Policy_Status='ACTIVE' and Entry_Dt BETWEEN '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
                Reportname = "HPC_List"
            ElseIf cboreportsearc.SelectedValue = "D" Then
                SqlAction = "SELECT T.Member_No, T.Member_Name, T.Mobile_No, T.Client_Type,T.Followup_Dt,(SELECT Name FROM dbo.TBL_MIS_CRM_HPC_DISEASES WHERE Code=C.DX_code)Name,C.Entered_By, C.Entry_date, C.Doctor, C.Other_Doctor,C.Dx_Date FROM   dbo.TBL_MIS_CRM_HPC_TRACKING T LEFT JOIN dbo.TBL_MIS_CRM_HPC_MEMBER_COMORB C ON T.Member_No = C.Member_No where T.Policy_Status='ACTIVE'"
                Reportname = "HPC_dx"
            ElseIf cboreportsearc.SelectedValue = "E" Then
                SqlAction = "SELECT T.Member_No, T.Member_Name, T.Mobile_No, T.Client_Type,T.Followup_Dt,(SELECT Name FROM dbo.TBL_MIS_CRM_HPC_DISEASES WHERE Code=C.DX_code)Name,C.Entered_By, C.Entry_date, C.Doctor, C.Other_Doctor,C.Dx_Date FROM   dbo.TBL_MIS_CRM_HPC_TRACKING T LEFT JOIN dbo.TBL_MIS_CRM_HPC_MEMBER_COMORB C ON T.Member_No = C.Member_No where  CONVERT(DATE,C.Entry_dt)  Between '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND T.Policy_Status='ACTIVE'"
                Reportname = "HPC_ENTRY"

            ElseIf cboreportsearc.SelectedValue = "N" Then 'NOTES LISTING
                SqlAction = "SELECT  [Note_id]      ,[Member_No]      ,[Notes]      ,[Note_From]      ,[Note_Date]  FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_NOTES] WHERE ACTIVE=1 AND Note_Date BETWEEN '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
                Reportname = "NOTES_LISTING"
            ElseIf cboreportsearc.SelectedValue = "EN" Then
                SqlAction = "SELECT   [Follow_Id],[Member_No],[Scheduled_date],[Entered_By],[Entry_Date],[Member_Call],[Call_By],[Call_date]  FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_FOLLOWUP] WHERE MEMBER_NO IN (SELECT MEMBER_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE POLICY_STATUS='ACTIVE') AND Member_Call='YES'"
                Reportname = "ENGAGED"
            ElseIf cboreportsearc.SelectedValue = "NE" Then
                SqlAction = "SELECT   [Follow_Id],[Member_No],[Scheduled_date],[Entered_By],[Entry_Date],[Member_Call],[Call_By],[Call_date]  FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_FOLLOWUP] WHERE MEMBER_NO IN (SELECT MEMBER_NO FROM [DATA_REPOSITORY_DB].[dbo].[MASTER_MEMBER_LIST] WHERE POLICY_STATUS='ACTIVE') AND Member_Call='NO'"
                Reportname = "NOT_ENGAGED"
            ElseIf cboreportsearc.SelectedValue = "DX" Then

            ElseIf cboreportsearc.SelectedValue = "F" Then


            End If

                Session("EXCEL") = "TO EXCEL"
                Mytable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                Session("Mytable") = (Mytable)
                Session("Reportname") = Reportname
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Mytable = Nothing
                System.Threading.Thread.Sleep(5000)
                'Reportname = ""
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub GD_1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_1.SelectedIndexChanged
        Try
            lblno.Text = ""
            lblcode.Text = (DirectCast(GD_1.SelectedItems(0), GridDataItem)).GetDataKeyValue("Member_No").ToString()
            Str = "SELECT Code_Id, Member_No, Member_Name,email, Mobile_No,  Entered_by, Entry_dt,Followup_Dt,Proposer,Client_Type FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND Member_No='" & Trim(lblcode.Text) & "'"
            MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                lblno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                txtmemno.Text = MyDatable.Rows(0).Item("Member_No").ToString()
                txtname.Text = MyDatable.Rows(0).Item("Member_Name").ToString()
                txtprop.Text = MyDatable.Rows(0).Item("Proposer").ToString()
                txtemail.Text = MyDatable.Rows(0).Item("email").ToString()
                txtmobile.Text = MyDatable.Rows(0).Item("Mobile_No").ToString()
                dtsched.DbSelectedDate = MyDatable.Rows(0).Item("Followup_Dt").ToString()
                cboclient.SelectedValue = MyDatable.Rows(0).Item("Client_Type").ToString()
            End If
            txtname.Enabled = False
            txtmemno.Enabled = False
            txtprop.Enabled = False
            cboclient.Enabled = False
        Catch ex As Exception
            lblerr_f.Text = ex.Message
        End Try
    End Sub



    Protected Sub GD_2_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GD_2.SelectedIndexChanged
        lblno.Text = ""
        GD_3.DataSource = Nothing
        GD_3.DataBind()
        Dim ENTERED As String = ""
        ENTERED = (DirectCast(GD_2.SelectedItems(0), GridDataItem)).GetDataKeyValue("Entered_by").ToString()
        Str = "SELECT Code_Id, Member_No, Member_Name,email, Mobile_No,  Entered_by, Entry_dt,Followup_Dt,Proposer,Client_Type FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  WITH(NOLOCK) WHERE IS_ACTIVE=1 AND Entered_by='" & ENTERED & "' and convert(date,Entry_dt)  BETWEEN '" & CDate(DtFollFrom.DbSelectedDate).ToString("yyyy-MM-dd") & "' and '" & CDate(dtFolloto.DbSelectedDate).ToString("yyyy-MM-dd") & "'"
        MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
        If MyDatable.Rows.Count > 0 Then
            GD_3.DataSource = MyDatable
            GD_3.DataBind()
            Session("GD_3_T") = MyDatable
            MyDatable = Nothing
        Else
            GD_3.DataSource = Nothing
            GD_3.DataBind()
        End If

    End Sub

    Protected Sub cbosearch_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbosearch.SelectedIndexChanged
        txtsearch.SelectedValue = ""
        txtsearch.Text = ""
        If cbosearch.SelectedValue = "S" Then
            Str = " SELECT  [Src_Code],[Src_Name] FROM [CRM].[dbo].[TBL_MIS_CRM_HPC_SOURCE]" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With txtsearch
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("Src_Code").ToString
                .DataValueField = MyDatatable.Columns("Src_Name").ToString
                .DataBind()
            End With
        End If

    End Sub

    Protected Sub search_Click(sender As Object, e As System.EventArgs) Handles search.Click
        Try

            If cbosearch.SelectedValue = "M" Then
                Str = " SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK) WHERE   R.Member_No like '%" & txtsearch_1.Text & "%'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_1.DataSource = MyDatable
                    GD_1.DataBind()
                    Session("GD_1_T") = MyDatable
                    MyDatable = Nothing
                Else
                    GD_1.DataSource = Nothing
                    GD_1.DataBind()
                End If

            ElseIf cbosearch.SelectedValue = "N" Then
                Str = "SELECT R.Code_Id, R.Member_No, R.Member_Name,   R.Entered_by, R.Entry_dt,r.Followup_Dt,HPC_Src FROM    [dbo].[TBL_MIS_CRM_HPC_TRACKING]  R  WITH(NOLOCK)  WHERE R.Member_Name like '%" & txtsearch_1.Text & "%'"
                MyDatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    GD_1.DataSource = MyDatable
                    GD_1.DataBind()
                    Session("GD_1_T") = MyDatable
                    MyDatable = Nothing
                Else
                    GD_1.DataSource = Nothing
                    GD_1.DataBind()
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub
    Protected Sub GD_1_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_1.PageIndexChanged
        GD_1.CurrentPageIndex = e.NewPageIndex
        GD_1.DataSource = Session("GD_1_T")
        GD_1.DataBind()
    End Sub
    Protected Sub GD_2_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_2.PageIndexChanged
        GD_2.CurrentPageIndex = e.NewPageIndex
        GD_2.DataSource = Session("GD_2_T")
        GD_2.DataBind()
    End Sub
    Protected Sub GD_3_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_3.PageIndexChanged
        GD_3.CurrentPageIndex = e.NewPageIndex
        GD_3.DataSource = Session("GD_3_T")
        GD_3.DataBind()
    End Sub
    Protected Sub GD_4_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GD_4.PageIndexChanged
        GD_4.CurrentPageIndex = e.NewPageIndex
        GD_4.DataSource = Session("GD_4_T")
        GD_4.DataBind()
    End Sub
    '
    Protected Sub GDCASE_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDCASE.PageIndexChanged
        GDCASE.CurrentPageIndex = e.NewPageIndex
        GDCASE.DataSource = Session("GDCASE_T")
        GDCASE.DataBind()
    End Sub
End Class
