﻿Imports System.Data
Imports DocManage.DataManagement

Imports System.Data.SqlClient

Imports Telerik.Web.UI
Imports DocManage
Imports System.IO

Imports System.Data.OleDb
Imports System.Web.Configuration
Imports Mymail
Imports Microsoft.VisualBasic
Imports System
'Imports Microsoft.Office.Interop.Excel
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Imports Microsoft.Office.Interop
Imports System.Windows.Forms
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim MyDBAction As New DataManagement
    Dim MyDatable As New Data.DataTable
    Dim MyQuery As String = ""
    Dim SqlAction As String = ""
    Dim MyDatatable As DataTable : Dim Str As String
    Dim empcode As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Try
                empcode = ""

                SqlAction = "SELECT MIN(PERIOD_FROM)PERIOD_FROM,  MIN(PERIOD_TO)PERIOD_TO FROM [CRM].[dbo].[TBL_MIS_CRM_NON_MED_RENEWAL_PROCESS] WHERE [Signed_Off]=0"
                MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
                If MyDatable.Rows.Count > 0 Then
                    Session("PERIOD_FROM") = CDate(MyDatable.Rows(0).Item("PERIOD_FROM")).ToString("yyyy-MM-dd")
                    Session("PERIOD_TO") = CDate(MyDatable.Rows(0).Item("PERIOD_TO")).ToString("yyyy-MM-dd") ' MyDatable.Rows(0).Item("DATE_TO").ToString()

                    dtmonthfr.DbSelectedDate = Session("PERIOD_FROM")
                    dtmonthto.DbSelectedDate = Session("PERIOD_TO")

                End If
                Session("Month") = Nothing
                Session("EXCEL") = Nothing
            Catch ex As Exception

            End Try
        End If
    End Sub



    Protected Sub cmdview_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdview.Click
        Try

            Dim MyDatable As New Data.DataTable
            Session("DAD_5") = Nothing

            If cbosearch.SelectedValue = "PN" Then
                'Str = "SELECT PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE FAMILY_NO Like '%" & Trim(cbotext.Text) & "%' AND POLICY_VALID_FROM>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND POLICY_VALID_FROM<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVED=1"
                ' SqlAction = "SELECT PLAN_NAME, [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[FAMILY_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[FAMILY_SHARED],[OP_BENEFIT],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGENT],[PROPOSER_PRI_ADD_LINE1],[AGE_AT_RENEWAL],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOTAL_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM] FROM CRM.[dbo].[TBL_MIS_RENEWAL_UPLOAD] WHERE FAMILY_NO Like '%" & Trim(cbotext.Text) & "%' AND POLICY_VALID_FROM>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND POLICY_VALID_FROM<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVED=1 ORDER BY DISPLAY_MEMBERSHIP_NO ASC, POLICY_CODE"
                SqlAction = "SELECT [policy type], [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  Policy_Number = '" & Trim(cbotext.Text) & "' AND VERIFIED=1 AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "'"

            ElseIf cbosearch.SelectedValue = "P" Then
                'Str = "SELECT PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE PROPOSER_DISPLAY_NAME Like '%" & Trim(cbotext.Text) & "%' AND  POLICY_VALID_FROM>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND POLICY_VALID_FROM<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVED=1"
                ' SqlAction = "SELECT PLAN_NAME, [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[DISPLAY_MEMBERSHIP_NO],[FAMILY_NO],[MEMBER_NAME],[RELATION],[SCHEME_NAME],[FAMILY_SHARED],[OP_BENEFIT],[MEMBER_BIRTH_DATE],[MEMBER_ADMINISTRATIVE_SEX],[POLICY_VALID_FROM],[POLICY_VALID_UPTO],[AGENT],[PROPOSER_PRI_ADD_LINE1],[AGE_AT_RENEWAL],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOTAL_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM] FROM CRM.[dbo].[TBL_MIS_RENEWAL_UPLOAD] WHERE PROPOSER_DISPLAY_NAME Like '%" & Trim(cbotext.Text) & "%' AND  POLICY_VALID_FROM>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND POLICY_VALID_FROM<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVED=1  ORDER BY  DISPLAY_MEMBERSHIP_NO  ASC, POLICY_CODE"
                SqlAction = "SELECT [policy type], [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  Insured  LIKE  '%" & Trim(cbotext.Text) & "%' AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED=1"

            ElseIf cbosearch.SelectedValue = "A" Then
                ' Str = "SELECT PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE AGENT_ID = '" & Trim(cbotext.SelectedValue) & "' AND POLICY_VALID_FROM>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND POLICY_VALID_FROM<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVED=1"
                SqlAction = "SELECT [policy type], [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  AGENCY  LIKE  '%" & Trim(cbotext.Text) & "%' AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED=1"
            ElseIf cbosearch.SelectedValue = "RM" Then
                '  Str = "SELECT PROPOSER_ID,PROPOSER_DISPLAY_NAME,FAMILY_NO,RENEWAL_DATE, PERIOD_FROM,PERIOD_TO,TOTAL_PREMIUM,AGENT,MOBILE_NO FROM TBL_MIS_RENEWAL_PROPOSER_LIST  WHERE RMS_CODE = '" & Trim(cborm.SelectedValue) & "' AND POLICY_VALID_FROM>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND POLICY_VALID_FROM<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND APPROVED=1"
                SqlAction = "SELECT [policy type], [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  RM_NAME  LIKE  '%" & Trim(cbotext.Text) & "%' AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED=1"

            Else
                lblerr.Text = "Enter search creteria"
                Exit Sub
            End If

            MyDatable = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable.Rows.Count > 0 Then
                GDSEARCH.DataSource = MyDatable
                GDSEARCH.DataBind()
                Session("DAD_5_N") = MyDatable
                txttotal.Text = Convert.ToInt32(MyDatable.Compute("SUM(Total_Premium)", String.Empty))
                'txttotalplus.Text = Convert.ToInt32(MyDatable.Compute("sum(SILVERPLUS_PREMIUM)", String.Empty))
                MyDatable = Nothing
            Else
                GDSEARCH.DataSource = Nothing
                GDSEARCH.DataBind()
            End If
        Catch ex As Exception
            lblerr.Text = ex.Message
        End Try

    End Sub
    Protected Sub GDSEARCH_PageIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.GridPageChangedEventArgs) Handles GDSEARCH.PageIndexChanged
        GDSEARCH.CurrentPageIndex = e.NewPageIndex
        GDSEARCH.DataSource = Session("DAD_5_N")
        GDSEARCH.DataBind()
    End Sub


    'Private Function SendLoginDetails(ByVal POLICY_CODE As String, ByVal PROPOSER_DISPLAY_NAME As String, ByVal PERIOD_FROM As String, ByVal PERIOD_TO As String, ByVal PROPOSER_PRI_EMAIL As String, ByVal FAMILY_CODE As String) As Boolean
    Protected Sub BTNprint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BTNprint.Click
        Dim Str As String = "" : Dim Mytable As DataTable = Nothing
        Dim Str_1 As String = ""
        Dim Str_2 As String = ""
        Dim CAT As String = ""
        Dim CAT_SCHEME As String = ""
        Dim Str_3 As String = ""
        Dim approve As Integer = 0
        Dim MailSent As Boolean = False
        Dim body As String = ""
        Dim MyDatable_1 As DataTable = Nothing
        Dim MyDatable_2 As DataTable = Nothing
        Dim MyDatable_3 As DataTable = Nothing
        Dim Str_Live As String = ""
        Dim theMonth As String = "" ' DateTime.Now.ToString("MMMM")
        Dim policy As String = ""


        Session("EMPNAME") = Nothing
        Session("FrmDT") = Nothing
        Session("ToDt") = Nothing
        Session("agentEmail") = Nothing
        Session("RecepientEmail") = ""
        Session("MailSent") = False
        Session("EXPORT_TYPE") = "PDF"

        If cboTYPE.SelectedValue = "C" Then
        ElseIf cboTYPE.SelectedValue = "S" Then
            If cbosearch.SelectedValue = "PN" Then
                SqlAction = "SELECT [policy type],Expiry_Date, [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  Policy_Number = '" & cbotext.Text & "' AND VERIFIED=1  AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "'"
            ElseIf cbosearch.SelectedValue = "P" Then
                SqlAction = "SELECT [policy type],Expiry_Date, [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  Insured  =  '" & cbotext.Text & "' AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED=1"
            ElseIf cbosearch.SelectedValue = "A" Then
                SqlAction = "SELECT [policy type],Expiry_Date, [Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  AGENCY  =  '" & cbotext.Text & "' AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED=1"
            ElseIf cbosearch.SelectedValue = "RM" Then
                SqlAction = "SELECT  [policy type],Expiry_Date,[Insured], [Policy_Number],[Renewal_start_date],[Renewal_end_date] ,[Claim_Amount],[Sum_Insured],[Loading],[Hold],[Total_Premium],Basic_Premium,Policy_Fund,Training_Levy,AGENCY    FROM [AIMSOFT_DATADUMP].[dbo].[Renewal_Schedules_Non_Med] WHERE  RM_NAME  =  '" & cbotext.Text & "' AND  Renewal_start_date>= '" & CDate(dtmonthfr.SelectedDate).ToString("yyyy-MM-dd") & "' AND Renewal_start_date<= '" & CDate(dtmonthto.SelectedDate).ToString("yyyy-MM-dd") & "' AND VERIFIED=1"

            End If

            '--------------------------Renewal schedule
            'If cbocat.SelectedValue = "S" Then

            MyDatable_1 = Nothing
            MyDatable_1 = TryCast(MyDBAction.DBAction(SqlAction, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable_1.Rows.Count > 0 Then



                Session("Report_") = "Renewal Schedule-Gen"


                'GENERATE_RPT(MyDatable_1)

                Session("PRINT") = "PDF"
                'MyDatable_1 = Nothing
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = (MyDatable_1)
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Mytable = Nothing
                System.Threading.Thread.Sleep(5000)
            Else
                lblerr.Text = "No Data Found"
                Exit Sub
            End If
            'Renewal Schedule_N_S
            'Renewal Schedule_N

        ElseIf cboTYPE.SelectedValue = "L" Then

            ''--------------------------Renewal Advice
            'If cbosearch.SelectedValue = "F" Then
            '    Str = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],S_PLUS_PREM,INV_NO,PLAN_NAME,SCHEME_NAME  FROM CRM.[dbo].[VW_RENEWAL_ADVICE] WHERE   RENEWAL_DATE  BETWEEN '" & CDate(dtmonthfr.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtmonthto.DbSelectedDate).ToString("yyyy-MM-dd") & "'  AND FAMILY_NO='" & cbotext.Text.ToUpper & "'  ORDER BY FAMILY_NO"
            'ElseIf cbosearch.SelectedValue = "P" Then
            '    Str = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],S_PLUS_PREM,INV_NO,PLAN_NAME,SCHEME_NAME  FROM CRM.[dbo].[VW_RENEWAL_ADVICE] WHERE   RENEWAL_DATE  BETWEEN '" & CDate(dtmonthfr.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtmonthto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND PROPOSER_DISPLAY_NAME='" & cbotext.Text & "'  ORDER BY FAMILY_NO"
            'ElseIf cbosearch.SelectedValue = "A" Then
            '    Str = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],S_PLUS_PREM,INV_NO,PLAN_NAME,SCHEME_NAME  FROM CRM.[dbo].[VW_RENEWAL_ADVICE] WHERE  RENEWAL_DATE  BETWEEN '" & CDate(dtmonthfr.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtmonthto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND AGENT_CODE = '" & cbotext.SelectedValue & "'  ORDER BY FAMILY_NO"
            'ElseIf cbosearch.SelectedValue = "RM" Then
            '    Str = "SELECT [POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],S_PLUS_PREM,INV_NO,PLAN_NAME,SCHEME_NAME  FROM CRM.[dbo].[VW_RENEWAL_ADVICE] WHERE  RENEWAL_DATE  BETWEEN '" & CDate(dtmonthfr.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtmonthto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND RMS_CODE = '" & cbotext.SelectedValue & "'  ORDER BY FAMILY_NO"

            'End If
            'Str = "SELECT S_PLUS_PREM,[POLICY_CODE],[PROPOSER_DISPLAY_NAME],[FAMILY_NO],[PERIOD_FROM],[PERIOD_TO],[CURR_EXP_DATE],[RENEWAL_DATE],[MEMBER_ADMINISTRATIVE_SEX],[RELATION],[PROPOSER_PRI_ADD_LINE1],POSTAL_CODE,[PROPOSER_PRI_EMAIL],[TOTAL_PREMIUM],[AGENT],[DISPLAY_MEMBERSHIP_NO],[MEMBER_NAME],[CATEGORY],[OP_LIMIT],[OP_PREMIUM],IP_LIMIT,[IP_PREMIUM],[PA],[NCD],[LEVIES],[TOT_PREMIUM],[IP_PREM_SILVERPLUS],[LEVIES_S],[SILVERPLUS_PREMIUM],INV_NO,SCHEME_NAME  FROM CRM.[dbo].[VW_RENEWAL_ADVICE] WHERE   FAMILY_NO='" & cbotext.Text.ToUpper & "'  AND RENEWAL_DATE  BETWEEN '" & CDate(dtmonthfr.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND '" & CDate(dtmonthto.DbSelectedDate).ToString("yyyy-MM-dd") & "' AND PLAN_NAME='RET' ORDER BY PROPOSER_DISPLAY_NAME"
            MyDatable_1 = Nothing
            MyDatable_1 = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), Data.DataTable)
            If MyDatable_1.Rows.Count > 0 Then
                Session("Report_") = "Renewal Advice"
                'GENERATE_RPT(MyDatable_1)

                Session("PRINT") = "PDF"
                'MyDatable_1 = Nothing
                Session("Mytable") = Nothing
                Session("Reportname") = Nothing
                Session("Mytable") = (MyDatable_1)
                Session("Reportname") = Session("Report_")
                ResponseHelper.Redirect("Reports.aspx", "_blank", "")
                Mytable = Nothing
                System.Threading.Thread.Sleep(5000)
                'ShowReport()
            Else
                lblerr.Text = "No Data Found"
                Exit Sub
            End If




        End If
        'End If

    End Sub



    Protected Sub cbosearch_SelectedIndexChanged(ByVal sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles cbosearch.SelectedIndexChanged
        cbotext.SelectedValue = ""
        cbotext.Text = ""
        If cbosearch.SelectedValue = "A" Then
            Str = "SELECT DISTINCT USER_ID,AGENT_NAME FROM COMMISSION.dbo.TBL_MIS_SALES_AGENTS WHERE ACTIVE=1 AND TERMINATED=0 ORDER BY AGENT_NAME"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbotext

                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("AGENT_NAME").ToString
                .DataValueField = MyDatatable.Columns("USER_ID").ToString
                .DataBind()
            End With

        ElseIf cbosearch.SelectedValue = "RM" Then
            Str = "SELECT DISTINCT RE_CODE,RE_NAME FROM TBL_MIS_CRM_RMS WHERE IS_ACTIVE=1" '"
            MyDatatable = TryCast(MyDBAction.DBAction(Str, DataManagement.DBActionType.DataTable), DataTable)
            With cbotext
                .Items.Clear()
                .DataSource = MyDatatable
                .DataTextField = MyDatatable.Columns("RE_NAME").ToString
                .DataValueField = MyDatatable.Columns("RE_CODE").ToString
                .DataBind()
            End With

        End If
    End Sub
End Class
